/**
* MapLibre GL JS
* @license 3-Clause BSD. Full text of license: https://github.com/maplibre/maplibre-gl-js/blob/v6.19.0/LICENSE.txt
*/
var bm = Object.create, Qp = Object.defineProperty, wm = Object.getOwnPropertyDescriptor, _m = Object.getOwnPropertyNames, Dm = Object.getPrototypeOf, Sm = Object.prototype.hasOwnProperty, Kl = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), Am = (e, t, r, i) => {
  if (t && typeof t == "object" || typeof t == "function") for (var n = _m(t), a = 0, s = n.length, o; a < s; a++) o = n[a], !Sm.call(e, o) && o !== r && Qp(e, o, { get: ((l) => t[l]).bind(null, o), enumerable: !(i = wm(t, o)) || i.enumerable });
  return e;
}, Em = (e, t, r) => (r = e == null ? {} : bm(Dm(e)), Am(Qp(r, "default", { value: e, enumerable: !0 }), e));
function T(e, t) {
  this.x = e, this.y = t;
}
T.prototype = { clone() {
  return new T(this.x, this.y);
}, add(e) {
  return this.clone()._add(e);
}, sub(e) {
  return this.clone()._sub(e);
}, multByPoint(e) {
  return this.clone()._multByPoint(e);
}, divByPoint(e) {
  return this.clone()._divByPoint(e);
}, mult(e) {
  return this.clone()._mult(e);
}, div(e) {
  return this.clone()._div(e);
}, rotate(e) {
  return this.clone()._rotate(e);
}, rotateAround(e, t) {
  return this.clone()._rotateAround(e, t);
}, matMult(e) {
  return this.clone()._matMult(e);
}, unit() {
  return this.clone()._unit();
}, perp() {
  return this.clone()._perp();
}, round() {
  return this.clone()._round();
}, mag() {
  return Math.sqrt(this.x * this.x + this.y * this.y);
}, equals(e) {
  return this.x === e.x && this.y === e.y;
}, dist(e) {
  return Math.sqrt(this.distSqr(e));
}, distSqr(e) {
  let t = e.x - this.x, r = e.y - this.y;
  return t * t + r * r;
}, angle() {
  return Math.atan2(this.y, this.x);
}, angleTo(e) {
  return Math.atan2(this.y - e.y, this.x - e.x);
}, angleWith(e) {
  return this.angleWithSep(e.x, e.y);
}, angleWithSep(e, t) {
  return Math.atan2(this.x * t - this.y * e, this.x * e + this.y * t);
}, _matMult(e) {
  let t = e[0] * this.x + e[1] * this.y, r = e[2] * this.x + e[3] * this.y;
  return this.x = t, this.y = r, this;
}, _add(e) {
  return this.x += e.x, this.y += e.y, this;
}, _sub(e) {
  return this.x -= e.x, this.y -= e.y, this;
}, _mult(e) {
  return this.x *= e, this.y *= e, this;
}, _div(e) {
  return this.x /= e, this.y /= e, this;
}, _multByPoint(e) {
  return this.x *= e.x, this.y *= e.y, this;
}, _divByPoint(e) {
  return this.x /= e.x, this.y /= e.y, this;
}, _unit() {
  return this._div(this.mag()), this;
}, _perp() {
  let e = this.y;
  return this.y = this.x, this.x = -e, this;
}, _rotate(e) {
  let t = Math.cos(e), r = Math.sin(e), i = t * this.x - r * this.y, n = r * this.x + t * this.y;
  return this.x = i, this.y = n, this;
}, _rotateAround(e, t) {
  let r = Math.cos(e), i = Math.sin(e), n = t.x + r * (this.x - t.x) - i * (this.y - t.y), a = t.y + i * (this.x - t.x) + r * (this.y - t.y);
  return this.x = n, this.y = a, this;
}, _round() {
  return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
}, constructor: T }, T.convert = function(e) {
  if (e instanceof T) return e;
  if (Array.isArray(e)) return new T(+e[0], +e[1]);
  if (e.x !== void 0 && e.y !== void 0) return new T(+e.x, +e.y);
  throw Error("Expected [x, y] or {x, y} point format");
};
let Oc;
function Tm() {
  return Oc ?? (Oc = typeof OffscreenCanvas < "u" && !!new OffscreenCanvas(1, 1).getContext("2d") && typeof createImageBitmap == "function"), Oc;
}
let la;
function Im() {
  if (la == null && (la = !1, Tm())) {
    let e = new OffscreenCanvas(5, 5).getContext("2d", { willReadFrequently: !0 });
    if (e) {
      for (let r = 0; r < 25; r++) {
        let i = r * 4;
        e.fillStyle = `rgb(${i},${i + 1},${i + 2})`, e.fillRect(r % 5, Math.floor(r / 5), 1, 1);
      }
      let t = e.getImageData(0, 0, 5, 5).data;
      for (let r = 0; r < 100; r++) if (r % 4 != 3 && t[r] !== r) {
        la = !0;
        break;
      }
    }
  }
  return la || !1;
}
var fn = typeof Float32Array < "u" ? Float32Array : Array;
function Jl(e) {
  return e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 0, e[5] = 1, e[6] = 0, e[7] = 0, e[8] = 0, e[9] = 0, e[10] = 1, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, e;
}
function Mo(e, t, r) {
  var i = t[0], n = t[1], a = t[2], s = t[3], o = t[4], l = t[5], u = t[6], c = t[7], h = t[8], p = t[9], f = t[10], d = t[11], y = t[12], m = t[13], g = t[14], v = t[15], x = r[0], b = r[1], w = r[2], D = r[3];
  return e[0] = x * i + b * o + w * h + D * y, e[1] = x * n + b * l + w * p + D * m, e[2] = x * a + b * u + w * f + D * g, e[3] = x * s + b * c + w * d + D * v, x = r[4], b = r[5], w = r[6], D = r[7], e[4] = x * i + b * o + w * h + D * y, e[5] = x * n + b * l + w * p + D * m, e[6] = x * a + b * u + w * f + D * g, e[7] = x * s + b * c + w * d + D * v, x = r[8], b = r[9], w = r[10], D = r[11], e[8] = x * i + b * o + w * h + D * y, e[9] = x * n + b * l + w * p + D * m, e[10] = x * a + b * u + w * f + D * g, e[11] = x * s + b * c + w * d + D * v, x = r[12], b = r[13], w = r[14], D = r[15], e[12] = x * i + b * o + w * h + D * y, e[13] = x * n + b * l + w * p + D * m, e[14] = x * a + b * u + w * f + D * g, e[15] = x * s + b * c + w * d + D * v, e;
}
function Cm(e, t, r) {
  var i = r[0], n = r[1], a = r[2], s, o, l, u, c, h, p, f, d, y, m, g;
  return t === e ? (e[12] = t[0] * i + t[4] * n + t[8] * a + t[12], e[13] = t[1] * i + t[5] * n + t[9] * a + t[13], e[14] = t[2] * i + t[6] * n + t[10] * a + t[14], e[15] = t[3] * i + t[7] * n + t[11] * a + t[15]) : (s = t[0], o = t[1], l = t[2], u = t[3], c = t[4], h = t[5], p = t[6], f = t[7], d = t[8], y = t[9], m = t[10], g = t[11], e[0] = s, e[1] = o, e[2] = l, e[3] = u, e[4] = c, e[5] = h, e[6] = p, e[7] = f, e[8] = d, e[9] = y, e[10] = m, e[11] = g, e[12] = s * i + c * n + d * a + t[12], e[13] = o * i + h * n + y * a + t[13], e[14] = l * i + p * n + m * a + t[14], e[15] = u * i + f * n + g * a + t[15]), e;
}
function ef(e, t, r) {
  var i = r[0], n = r[1], a = r[2];
  return e[0] = t[0] * i, e[1] = t[1] * i, e[2] = t[2] * i, e[3] = t[3] * i, e[4] = t[4] * n, e[5] = t[5] * n, e[6] = t[6] * n, e[7] = t[7] * n, e[8] = t[8] * a, e[9] = t[9] * a, e[10] = t[10] * a, e[11] = t[11] * a, e[12] = t[12], e[13] = t[13], e[14] = t[14], e[15] = t[15], e;
}
function km() {
  var e = new fn(3);
  return fn != Float32Array && (e[0] = 0, e[1] = 0, e[2] = 0), e;
}
function Fm(e) {
  var t = new fn(3);
  return t[0] = e[0], t[1] = e[1], t[2] = e[2], t;
}
function Ql(e) {
  var t = e[0], r = e[1], i = e[2];
  return Math.sqrt(t * t + r * r + i * i);
}
function ro(e, t, r) {
  return e[0] = t[0] + r[0], e[1] = t[1] + r[1], e[2] = t[2] + r[2], e;
}
function tf(e, t, r) {
  return e[0] = t[0] - r[0], e[1] = t[1] - r[1], e[2] = t[2] - r[2], e;
}
function as(e, t, r) {
  return e[0] = t[0] * r, e[1] = t[1] * r, e[2] = t[2] * r, e;
}
function rf(e, t, r, i) {
  return e[0] = t[0] + r[0] * i, e[1] = t[1] + r[1] * i, e[2] = t[2] + r[2] * i, e;
}
function jt(e, t) {
  var r = t[0], i = t[1], n = t[2], a = r * r + i * i + n * n;
  return a > 0 && (a = 1 / Math.sqrt(a)), e[0] = t[0] * a, e[1] = t[1] * a, e[2] = t[2] * a, e;
}
function an(e, t) {
  return e[0] * t[0] + e[1] * t[1] + e[2] * t[2];
}
function nf(e, t, r) {
  var i = t[0], n = t[1], a = t[2], s = r[0], o = r[1], l = r[2];
  return e[0] = n * l - a * o, e[1] = a * s - i * l, e[2] = i * o - n * s, e;
}
function Mm(e, t, r, i) {
  var n = t[0], a = t[1], s = t[2];
  return e[0] = n + i * (r[0] - n), e[1] = a + i * (r[1] - a), e[2] = s + i * (r[2] - s), e;
}
var dn = tf, Pm = Ql;
(function() {
  var e = km();
  return function(t, r, i, n, a, s) {
    var o, l;
    for (r || (r = 3), i || (i = 0), l = n ? Math.min(n * r + i, t.length) : t.length, o = i; o < l; o += r) e[0] = t[o], e[1] = t[o + 1], e[2] = t[o + 2], a(e, e, s), t[o] = e[0], t[o + 1] = e[1], t[o + 2] = e[2];
    return t;
  };
})();
function Bm() {
  var e = new fn(4);
  return fn != Float32Array && (e[0] = 0, e[1] = 0, e[2] = 0, e[3] = 0), e;
}
function Lm(e, t, r) {
  return e[0] = t[0] * r[0], e[1] = t[1] * r[1], e[2] = t[2] * r[2], e[3] = t[3] * r[3], e;
}
function Bt(e, t, r) {
  var i = t[0], n = t[1], a = t[2], s = t[3];
  return e[0] = r[0] * i + r[4] * n + r[8] * a + r[12] * s, e[1] = r[1] * i + r[5] * n + r[9] * a + r[13] * s, e[2] = r[2] * i + r[6] * n + r[10] * a + r[14] * s, e[3] = r[3] * i + r[7] * n + r[11] * a + r[15] * s, e;
}
var zm = Lm;
(function() {
  var e = Bm();
  return function(t, r, i, n, a, s) {
    var o, l;
    for (r || (r = 4), i || (i = 0), l = n ? Math.min(n * r + i, t.length) : t.length, o = i; o < l; o += r) e[0] = t[o], e[1] = t[o + 1], e[2] = t[o + 2], e[3] = t[o + 3], a(e, e, s), t[o] = e[0], t[o + 1] = e[1], t[o + 2] = e[2], t[o + 3] = e[3];
    return t;
  };
})();
const te = 8192;
function La(e) {
  return e instanceof Error ? e : Error(typeof e == "string" ? e : String(e));
}
function eu() {
  return /* @__PURE__ */ new Float64Array(4);
}
function qe() {
  return /* @__PURE__ */ new Float64Array(3);
}
function af() {
  return /* @__PURE__ */ new Float64Array(16);
}
function Vm() {
  let e = /* @__PURE__ */ new Float32Array(16);
  return Jl(e), e;
}
function Rc(e, t) {
  return e[0] * t[0] + e[1] * t[1] + e[2] * t[2] + e[3];
}
function $c(e, t) {
  let r = za(e, 360), i = za(t, 360), n = i - r, a = i > r ? n - 360 : n + 360;
  return Math.abs(n) < Math.abs(a) ? n : a;
}
function za(e, t) {
  return (e % t + t) % t;
}
function Nc(e, t, r) {
  return e * (1 - r) + t * r;
}
function Om(e) {
  if (e <= 0) return 0;
  if (e >= 1) return 1;
  let t = e * e, r = t * e;
  return 4 * (e < 0.5 ? r : 3 * (e - t) + r - 0.75);
}
function rt(e, t, r) {
  return Math.min(r, Math.max(t, e));
}
function ti(e, t, r) {
  let i = r - t, n = ((e - t) % i + i) % i + t;
  return n === t ? r : n;
}
function it(e, ...t) {
  for (let r of t) for (let i in r) e[i] = r[i];
  return e;
}
function Rm(e) {
  return Math.log(e) / Math.LN2 % 1 == 0;
}
function $m(e) {
  return 2 ** e;
}
function Va(e, t, r) {
  let i = {};
  for (let n in e) i[n] = t.call(this, e[n], n, e);
  return i;
}
function Nm(e, t, r) {
  let i = {};
  for (let n in e) t.call(this, e[n], n, e) && (i[n] = e[n]);
  return i;
}
function Po(e, t) {
  if (Array.isArray(e)) {
    if (!Array.isArray(t) || e.length !== t.length) return !1;
    for (let r = 0; r < e.length; r++) if (!Po(e[r], t[r])) return !1;
    return !0;
  }
  if (typeof e == "object" && e && t !== null) {
    if (typeof t != "object" || Object.keys(e).length !== Object.keys(t).length) return !1;
    for (let r in e) if (!Po(e[r], t[r])) return !1;
    return !0;
  }
  return e === t;
}
function hr(e) {
  return Array.isArray(e) ? e.map(hr) : typeof e == "object" && e ? Va(e, hr) : e;
}
const Uc = {};
function Me(e) {
  Uc[e] || (typeof console < "u" && console.warn(e), Uc[e] = !0);
}
function pr(e, t, r) {
  return (r.y - e.y) * (t.x - e.x) > (t.y - e.y) * (r.x - e.x);
}
function pi(e) {
  return typeof WorkerGlobalScope < "u" && e !== void 0 && e instanceof WorkerGlobalScope;
}
function tu(e) {
  return typeof ImageBitmap < "u" && e instanceof ImageBitmap;
}
function Um(e, t, r, i, n) {
  let a = Math.max(-t, 0) * 4, s = (Math.max(0, r) - r) * i * 4 + a, o = i * 4, l = Math.max(0, t), u = Math.max(0, r), c = Math.min(e.width, t + i), h = Math.min(e.height, r + n);
  return { rect: { x: l, y: u, width: c - l, height: h - u }, layout: [{ offset: s, stride: o }] };
}
async function jm(e, t, r, i, n) {
  if (typeof VideoFrame > "u") throw Error("VideoFrame not supported");
  let a = new VideoFrame(e, { timestamp: 0 });
  try {
    let s = a == null ? void 0 : a.format;
    if (!s || !(s.startsWith("BGR") || s.startsWith("RGB"))) throw Error(`Unrecognized format ${s}`);
    let o = s.startsWith("BGR"), l = new Uint8ClampedArray(i * n * 4);
    if (await a.copyTo(l, Um(e, t, r, i, n)), o) for (let u = 0; u < l.length; u += 4) {
      let c = l[u];
      l[u] = l[u + 2], l[u + 2] = c;
    }
    return l;
  } finally {
    a.close();
  }
}
let Ni, Ui;
function qm(e, t, r, i, n) {
  let a = e.width, s = e.height;
  Ni && Ui || (Ni = new OffscreenCanvas(a, s), Ui = Ni.getContext("2d", { willReadFrequently: !0 })), Ni.width = a, Ni.height = s, Ui.drawImage(e, 0, 0, a, s);
  let o = Ui.getImageData(t, r, i, n);
  return Ui.clearRect(0, 0, a, s), o.data;
}
async function Gm(e, t, r, i, n) {
  if (Im()) try {
    return await jm(e, t, r, i, n);
  } catch {
  }
  return qm(e, t, r, i, n);
}
function jc(e, t, r, i) {
  return e.addEventListener(t, r, i), { unsubscribe: () => {
    e.removeEventListener(t, r, i);
  } };
}
function fi(e) {
  return e * Math.PI / 180;
}
function qc(e, t, r) {
  var i;
  (i = r[e]) != null && i.includes(t) || (r[e] || (r[e] = []), r[e].push(t));
}
function io(e, t, r) {
  if (r != null && r[e]) {
    let i = r[e].indexOf(t);
    i !== -1 && r[e].splice(i, 1);
  }
}
var sf = class {
  constructor(e, t = {}) {
    it(this, t), this.type = e;
  }
}, Oa = class extends sf {
  constructor(e, t = {}) {
    super("error", it({ error: e }, t));
  }
}, Xm = class {
  on(e, t) {
    return this._listeners || (this._listeners = {}), qc(e, t, this._listeners), { unsubscribe: () => {
      this.off(e, t);
    } };
  }
  off(e, t) {
    return io(e, t, this._listeners), io(e, t, this._oneTimeListeners), this;
  }
  once(e, t) {
    return t ? (this._oneTimeListeners || (this._oneTimeListeners = {}), qc(e, t, this._oneTimeListeners), this) : new Promise((r) => this.once(e, r));
  }
  fire(e, t) {
    var n, a, s, o;
    let r = typeof e == "string" ? new sf(e, t || {}) : e, i = r.type;
    if (this.listens(i)) {
      r.target = this;
      let l = ((a = (n = this._listeners) == null ? void 0 : n[i]) == null ? void 0 : a.slice()) ?? [];
      for (let h of l) h.call(this, r);
      let u = ((o = (s = this._oneTimeListeners) == null ? void 0 : s[i]) == null ? void 0 : o.slice()) ?? [];
      for (let h of u) io(i, h, this._oneTimeListeners), h.call(this, r);
      let c = this._eventedParent;
      c && (it(r, typeof this._eventedParentData == "function" ? this._eventedParentData() : this._eventedParentData), c.fire(r));
    } else r instanceof Oa && console.error(r.error);
    return this;
  }
  listens(e) {
    var t, r, i, n, a;
    return !!((r = (t = this._listeners) == null ? void 0 : t[e]) != null && r.length || (n = (i = this._oneTimeListeners) == null ? void 0 : i[e]) != null && n.length || (a = this._eventedParent) != null && a.listens(e));
  }
  setEventedParent(e, t) {
    return this._eventedParent = e, this._eventedParentData = t, this;
  }
};
const Gc = "AbortError";
var ru = class extends Error {
  constructor(e = Gc) {
    super(e instanceof Error ? e.message : e), this.name = Gc, e instanceof Error && e.stack && (this.stack = e.stack);
  }
};
function of(e) {
  return e instanceof Error && e.name === "AbortError";
}
function Ym(e) {
  if (e.aborted) throw new ru(e.reason);
}
var Bo = class lf {
  constructor(t, r, i) {
    let n = this.cells = [];
    if (t instanceof ArrayBuffer) {
      this.arrayBuffer = t;
      let s = new Int32Array(this.arrayBuffer);
      t = s[0], r = s[1], i = s[2], this.d = r + 2 * i;
      for (let u = 0; u < this.d * this.d; u++) {
        let c = s[3 + u], h = s[3 + u + 1];
        n.push(c === h ? null : s.subarray(c, h));
      }
      let o = s[3 + n.length], l = s[3 + n.length + 1];
      this.keys = s.subarray(o, l), this.bboxes = s.subarray(l), this.insert = this._insertReadonly;
    } else {
      this.d = r + 2 * i;
      for (let s = 0; s < this.d * this.d; s++) n.push([]);
      this.keys = [], this.bboxes = [];
    }
    this.n = r, this.extent = t, this.padding = i, this.scale = r / t, this.uid = 0;
    let a = i / r * t;
    this.min = -a, this.max = t + a;
  }
  insert(t, r, i, n, a) {
    this._forEachCell(r, i, n, a, this._insertCell, this.uid++, void 0, void 0), this.keys.push(t), this.bboxes.push(r), this.bboxes.push(i), this.bboxes.push(n), this.bboxes.push(a);
  }
  _insertReadonly() {
    throw Error("Cannot insert into a GridIndex created from an ArrayBuffer.");
  }
  _insertCell(t, r, i, n, a, s) {
    this.cells[a].push(s);
  }
  query(t, r, i, n, a) {
    let s = this.min, o = this.max;
    if (t <= s && r <= s && o <= i && o <= n && !a) return [...this.keys];
    {
      let l = [];
      return this._forEachCell(t, r, i, n, this._queryCell, l, {}, a), l;
    }
  }
  _queryCell(t, r, i, n, a, s, o, l) {
    let u = this.cells[a];
    if (u !== null) {
      let c = this.keys, h = this.bboxes;
      for (let p of u) if (o[p] === void 0) {
        let f = p * 4;
        (l ? l(h[f + 0], h[f + 1], h[f + 2], h[f + 3]) : t <= h[f + 2] && r <= h[f + 3] && i >= h[f + 0] && n >= h[f + 1]) ? (o[p] = !0, s.push(c[p])) : o[p] = !1;
      }
    }
  }
  _forEachCell(t, r, i, n, a, s, o, l) {
    let u = this._convertToCellCoord(t), c = this._convertToCellCoord(r), h = this._convertToCellCoord(i), p = this._convertToCellCoord(n);
    for (let f = u; f <= h; f++) for (let d = c; d <= p; d++) {
      let y = this.d * d + f;
      if ((!l || l(this._convertFromCellCoord(f), this._convertFromCellCoord(d), this._convertFromCellCoord(f + 1), this._convertFromCellCoord(d + 1))) && a.call(this, t, r, i, n, y, s, o, l)) return;
    }
  }
  _convertFromCellCoord(t) {
    return (t - this.padding) / this.scale;
  }
  _convertToCellCoord(t) {
    return Math.max(0, Math.min(this.d - 1, Math.floor(t * this.scale) + this.padding));
  }
  toArrayBuffer() {
    if (this.arrayBuffer) return this.arrayBuffer;
    let t = this.cells, r = 3 + this.cells.length + 1 + 1, i = 0;
    for (let s of this.cells) i += s.length;
    let n = new Int32Array(r + i + this.keys.length + this.bboxes.length);
    n[0] = this.extent, n[1] = this.n, n[2] = this.padding;
    let a = r;
    for (let s = 0; s < t.length; s++) {
      let o = t[s];
      n[3 + s] = a, n.set(o, a), a += o.length;
    }
    return n[3 + t.length] = a, n.set(this.keys, a), a += this.keys.length, n[3 + t.length + 1] = a, n.set(this.bboxes, a), a += this.bboxes.length, n.buffer;
  }
  static serialize(t, r) {
    let i = t.toArrayBuffer();
    return r && r.push(i), { buffer: i };
  }
  static deserialize(t) {
    return new lf(t.buffer);
  }
}, uf = { $version: 8, $root: { version: { required: !0, type: "enum", values: [8] }, name: { type: "string" }, metadata: { type: "*" }, center: { type: "array", value: "number", length: 2 }, centerAltitude: { type: "number" }, zoom: { type: "number" }, bearing: { type: "number", default: 0, period: 360, units: "degrees" }, pitch: { type: "number", default: 0, units: "degrees" }, roll: { type: "number", default: 0, units: "degrees" }, state: { type: "state", default: {} }, light: { type: "light" }, sky: { type: "sky" }, projection: { type: "projection" }, terrain: { type: "terrain" }, sources: { required: !0, type: "sources" }, sprite: { type: "sprite" }, glyphs: { type: "string" }, "font-faces": { type: "fontFaces" }, transition: { type: "transition" }, layers: { required: !0, type: "array", value: "layer" } }, sources: { "*": { type: "source" } }, source: ["source_vector", "source_raster", "source_raster_dem", "source_geojson", "source_video", "source_image"], source_vector: { type: { required: !0, type: "enum", values: { vector: {} } }, url: { type: "string" }, tiles: { type: "array", value: "string" }, bounds: { type: "array", value: "number", length: 4, default: [-180, -85.051129, 180, 85.051129] }, scheme: { type: "enum", values: { xyz: {}, tms: {} }, default: "xyz" }, sparse: { type: "boolean", default: !1 }, minzoom: { type: "number", default: 0 }, maxzoom: { type: "number", default: 22 }, attribution: { type: "string" }, promoteId: { type: "promoteId" }, volatile: { type: "boolean", default: !1 }, encoding: { type: "enum", values: { mvt: {}, mlt: {} }, default: "mvt" }, "*": { type: "*" } }, source_raster: { type: { required: !0, type: "enum", values: { raster: {} } }, url: { type: "string" }, tiles: { type: "array", value: "string" }, bounds: { type: "array", value: "number", length: 4, default: [-180, -85.051129, 180, 85.051129] }, minzoom: { type: "number", default: 0 }, maxzoom: { type: "number", default: 22 }, tileSize: { type: "number", default: 512, units: "pixels" }, scheme: { type: "enum", values: { xyz: {}, tms: {} }, default: "xyz" }, attribution: { type: "string" }, volatile: { type: "boolean", default: !1 }, "*": { type: "*" } }, source_raster_dem: { type: { required: !0, type: "enum", values: { "raster-dem": {} } }, url: { type: "string" }, tiles: { type: "array", value: "string" }, bounds: { type: "array", value: "number", length: 4, default: [-180, -85.051129, 180, 85.051129] }, minzoom: { type: "number", default: 0 }, maxzoom: { type: "number", default: 22 }, tileSize: { type: "number", default: 512, units: "pixels" }, attribution: { type: "string" }, encoding: { type: "enum", values: { terrarium: {}, mapbox: {}, custom: {} }, default: "mapbox" }, redFactor: { type: "number", default: 1 }, blueFactor: { type: "number", default: 1 }, greenFactor: { type: "number", default: 1 }, baseShift: { type: "number", default: 0 }, volatile: { type: "boolean", default: !1 }, "*": { type: "*" } }, source_geojson: { type: { required: !0, type: "enum", values: { geojson: {} } }, data: { required: !0, type: "*" }, maxzoom: { type: "number", default: 18 }, attribution: { type: "string" }, buffer: { type: "number", default: 128, maximum: 512, minimum: 0 }, filter: { type: "filter" }, tolerance: { type: "number", default: 0.375 }, cluster: { type: "boolean", default: !1 }, clusterRadius: { type: "number", default: 50, minimum: 0 }, clusterMaxZoom: { type: "number" }, clusterMinPoints: { type: "number" }, clusterProperties: { type: "*" }, lineMetrics: { type: "boolean", default: !1 }, generateId: { type: "boolean", default: !1 }, promoteId: { type: "promoteId" } }, source_video: { type: { required: !0, type: "enum", values: { video: {} } }, urls: { required: !0, type: "array", value: "string" }, coordinates: { required: !0, type: "array", length: 4, value: { type: "array", length: 2, value: "number" } } }, source_image: { type: { required: !0, type: "enum", values: { image: {} } }, url: { type: "string" }, coordinates: { required: !0, type: "array", length: 4, value: { type: "array", length: 2, value: "number" } } }, layer: { id: { type: "string", required: !0 }, type: { type: "enum", values: { fill: {}, line: {}, symbol: {}, circle: {}, heatmap: {}, "fill-extrusion": {}, raster: {}, hillshade: {}, "color-relief": {}, background: {} }, required: !0 }, metadata: { type: "*" }, source: { type: "string" }, "source-layer": { type: "string" }, minzoom: { type: "number", minimum: 0, maximum: 24 }, maxzoom: { type: "number", minimum: 0, maximum: 24 }, filter: { type: "filter" }, layout: { type: "layout" }, paint: { type: "paint" } }, layout: ["layout_fill", "layout_line", "layout_circle", "layout_heatmap", "layout_fill-extrusion", "layout_symbol", "layout_raster", "layout_hillshade", "layout_color-relief", "layout_background"], layout_background: { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_fill: { "fill-sort-key": { type: "number", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_circle: { "circle-sort-key": { type: "number", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_heatmap: { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, "layout_fill-extrusion": { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" }, "fill-extrusion-rounded-corner-distance": { type: "number", default: 0, minimum: 0, units: "meters", "property-type": "constant" } }, layout_line: { "line-cap": { type: "enum", values: { butt: {}, round: {}, square: {} }, default: "butt", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "line-join": { type: "enum", values: { bevel: {}, round: {}, miter: {} }, default: "miter", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "line-miter-limit": { type: "number", default: 2, requires: [{ "line-join": "miter" }], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "line-round-limit": { type: "number", default: 1.05, requires: [{ "line-join": "round" }], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "line-sort-key": { type: "number", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_symbol: { "symbol-placement": { type: "enum", values: { point: {}, line: {}, "line-center": {} }, default: "point", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "symbol-spacing": { type: "number", default: 250, minimum: 1, units: "pixels", requires: [{ "symbol-placement": "line" }], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "symbol-avoid-edges": { type: "boolean", default: !1, expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "symbol-sort-key": { type: "number", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "symbol-z-order": { type: "enum", values: { auto: {}, "viewport-y": {}, source: {} }, default: "auto", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-allow-overlap": { type: "boolean", default: !1, requires: ["icon-image", { "!": "icon-overlap" }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-overlap": { type: "enum", values: { never: {}, always: {}, cooperative: {} }, requires: ["icon-image"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-ignore-placement": { type: "boolean", default: !1, requires: ["icon-image"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-optional": { type: "boolean", default: !1, requires: ["icon-image", "text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-rotation-alignment": { type: "enum", values: { map: {}, viewport: {}, auto: {} }, default: "auto", requires: ["icon-image"], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-size": { type: "number", default: 1, minimum: 0, units: "factor of the original icon size", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-text-fit": { type: "enum", values: { none: {}, width: {}, height: {}, both: {} }, default: "none", requires: ["icon-image", "text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-text-fit-padding": { type: "array", value: "number", length: 4, default: [0, 0, 0, 0], units: "pixels", requires: ["icon-image", "text-field", { "icon-text-fit": ["both", "width", "height"] }], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-image": { type: "resolvedImage", tokens: !0, expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-rotate": { type: "number", default: 0, period: 360, units: "degrees", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-padding": { type: "padding", default: [2], units: "pixels", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-keep-upright": { type: "boolean", default: !1, requires: ["icon-image", { "icon-rotation-alignment": "map" }, { "symbol-placement": ["line", "line-center"] }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-offset": { type: "array", value: "number", length: 2, default: [0, 0], requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-anchor": { type: "enum", values: { center: {}, left: {}, right: {}, top: {}, bottom: {}, "top-left": {}, "top-right": {}, "bottom-left": {}, "bottom-right": {} }, default: "center", requires: ["icon-image"], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "icon-pitch-alignment": { type: "enum", values: { map: {}, viewport: {}, auto: {} }, default: "auto", requires: ["icon-image"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-pitch-alignment": { type: "enum", values: { map: {}, viewport: {}, auto: {} }, default: "auto", requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-rotation-alignment": { type: "enum", values: { map: {}, viewport: {}, "viewport-glyph": {}, auto: {} }, default: "auto", requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-field": { type: "formatted", default: "", tokens: !0, expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-font": { type: "array", value: "string", default: ["Open Sans Regular", "Arial Unicode MS Regular"], requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-size": { type: "number", default: 16, minimum: 0, units: "pixels", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-max-width": { type: "number", default: 10, minimum: 0, units: "ems", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-line-height": { type: "number", default: 1.2, units: "ems", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-letter-spacing": { type: "number", default: 0, units: "ems", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-justify": { type: "enum", values: { auto: {}, left: {}, center: {}, right: {} }, default: "center", requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-radial-offset": { type: "number", units: "ems", default: 0, requires: ["text-field"], "property-type": "data-driven", expression: { interpolated: !0, parameters: ["zoom", "feature"] } }, "text-variable-anchor": { type: "array", value: "enum", values: { center: {}, left: {}, right: {}, top: {}, bottom: {}, "top-left": {}, "top-right": {}, "bottom-left": {}, "bottom-right": {} }, requires: ["text-field", { "symbol-placement": ["point"] }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-variable-anchor-offset": { type: "variableAnchorOffsetCollection", requires: ["text-field", { "symbol-placement": ["point"] }], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-anchor": { type: "enum", values: { center: {}, left: {}, right: {}, top: {}, bottom: {}, "top-left": {}, "top-right": {}, "bottom-left": {}, "bottom-right": {} }, default: "center", requires: ["text-field", { "!": "text-variable-anchor" }], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-max-angle": { type: "number", default: 45, units: "degrees", requires: ["text-field", { "symbol-placement": ["line", "line-center"] }], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-writing-mode": { type: "array", value: "enum", values: { horizontal: {}, vertical: {} }, requires: ["text-field", { "symbol-placement": ["point"] }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-rotate": { type: "number", default: 0, period: 360, units: "degrees", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-padding": { type: "number", default: 2, minimum: 0, units: "pixels", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-keep-upright": { type: "boolean", default: !0, requires: ["text-field", { "text-rotation-alignment": "map" }, { "symbol-placement": ["line", "line-center"] }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-transform": { type: "enum", values: { none: {}, uppercase: {}, lowercase: {} }, default: "none", requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-offset": { type: "array", value: "number", units: "ems", length: 2, default: [0, 0], requires: ["text-field", { "!": "text-radial-offset" }], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "text-allow-overlap": { type: "boolean", default: !1, requires: ["text-field", { "!": "text-overlap" }], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-overlap": { type: "enum", values: { never: {}, always: {}, cooperative: {} }, requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-ignore-placement": { type: "boolean", default: !1, requires: ["text-field"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-optional": { type: "boolean", default: !1, requires: ["text-field", "icon-image"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "symbol-height-offset": { type: "number", default: 0, units: "meters", requires: [{ "symbol-placement": ["point"] }], expression: { interpolated: !0, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, "symbol-height-anchor": { type: "enum", values: { ground: {}, absolute: {} }, default: "ground", requires: ["symbol-height-offset"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_raster: { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, layout_hillshade: { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, "layout_color-relief": { visibility: { type: "enum", values: { visible: {}, none: {} }, default: "visible", expression: { interpolated: !1, parameters: ["global-state"] }, "property-type": "data-constant" } }, filter: { type: "boolean", expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "data-driven" }, filter_operator: { type: "enum", values: { "==": {}, "!=": {}, ">": {}, ">=": {}, "<": {}, "<=": {}, in: {}, "!in": {}, all: {}, any: {}, none: {}, has: {}, "!has": {} } }, geometry_type: { type: "enum", values: { Point: {}, LineString: {}, Polygon: {} } }, function: { expression: { type: "expression" }, stops: { type: "array", value: "function_stop" }, base: { type: "number", default: 1, minimum: 0 }, property: { type: "string", default: "$zoom" }, type: { type: "enum", values: { identity: {}, exponential: {}, interval: {}, categorical: {} }, default: "exponential" }, colorSpace: { type: "enum", values: { rgb: {}, lab: {}, hcl: {}, oklch: {}, oklab: {} }, default: "rgb" }, default: { type: "*", required: !1 } }, function_stop: { type: "array", minimum: 0, maximum: 24, value: ["number", "color"], length: 2 }, expression: { type: "array", value: "expression_name", minimum: 1 }, light: { anchor: { type: "enum", default: "viewport", values: { map: {}, viewport: {} }, "property-type": "data-constant", transition: !1, expression: { interpolated: !1, parameters: ["zoom"] } }, position: { type: "array", default: [1.15, 210, 30], length: 3, value: "number", "property-type": "data-constant", transition: !0, expression: { interpolated: !0, parameters: ["zoom"] } }, color: { type: "color", "property-type": "data-constant", default: "#ffffff", expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, intensity: { type: "number", "property-type": "data-constant", default: 0.5, minimum: 0, maximum: 1, expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 } }, sky: { "sky-color": { type: "color", "property-type": "data-constant", default: "#88C6FC", expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "horizon-color": { type: "color", "property-type": "data-constant", default: "#ffffff", expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "fog-color": { type: "color", "property-type": "data-constant", default: "#ffffff", expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "fog-ground-blend": { type: "number", "property-type": "data-constant", default: 0.5, minimum: 0, maximum: 1, expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "horizon-fog-blend": { type: "number", "property-type": "data-constant", default: 0.8, minimum: 0, maximum: 1, expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "sky-horizon-blend": { type: "number", "property-type": "data-constant", default: 0.8, minimum: 0, maximum: 1, expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 }, "atmosphere-blend": { type: "number", "property-type": "data-constant", default: 0.8, minimum: 0, maximum: 1, expression: { interpolated: !0, parameters: ["zoom"] }, transition: !0 } }, terrain: { source: { type: "string", required: !0 }, exaggeration: { type: "number", minimum: 0, default: 1 } }, projection: { type: { type: "projectionDefinition", default: "mercator", "property-type": "data-constant", transition: !1, expression: { interpolated: !0, parameters: ["zoom"] } } }, paint: ["paint_fill", "paint_line", "paint_circle", "paint_heatmap", "paint_fill-extrusion", "paint_symbol", "paint_raster", "paint_hillshade", "paint_color-relief", "paint_background"], paint_fill: { "fill-antialias": { type: "boolean", default: !0, expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "fill-layer-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "global-state"] }, "property-type": "data-constant" }, "fill-layer-blend": { type: "enum", values: { normal: {}, multiply: {}, color: {}, luminosity: {}, "plus-lighter": {}, screen: {}, overlay: {} }, default: "normal", "property-type": "constant", transition: !1 }, "fill-color": { type: "color", default: "#000000", transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "fill-outline-color": { type: "color", transition: !0, requires: [{ "!": "fill-pattern" }, { "fill-antialias": !0 }], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "fill-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["fill-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-pattern": { type: "resolvedImage", transition: !0, expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "cross-faded-data-driven" } }, "paint_fill-extrusion": { "fill-extrusion-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-extrusion-color": { type: "color", default: "#000000", transition: !0, requires: [{ "!": "fill-extrusion-pattern" }], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state", "elevation"] }, "property-type": "data-driven" }, "fill-extrusion-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-extrusion-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["fill-extrusion-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "fill-extrusion-pattern": { type: "resolvedImage", transition: !0, expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "cross-faded-data-driven" }, "fill-extrusion-height": { type: "number", default: 0, units: "meters", transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "fill-extrusion-base": { type: "number", default: 0, units: "meters", transition: !0, requires: ["fill-extrusion-height"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "fill-extrusion-vertical-gradient": { type: "boolean", default: !0, transition: !1, expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" } }, paint_line: { "line-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-layer-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "global-state"] }, "property-type": "data-constant" }, "line-layer-blend": { type: "enum", values: { normal: {}, multiply: {}, color: {}, luminosity: {}, "plus-lighter": {}, screen: {}, overlay: {} }, default: "normal", "property-type": "constant", transition: !1 }, "line-color": { type: "color", default: "#000000", transition: !0, requires: [{ "!": "line-pattern" }], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "line-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["line-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "line-width": { type: "number", default: 1, minimum: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-gap-width": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-offset": { type: "number", default: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-blur": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "line-dasharray": { type: "array", value: "number", minimum: 0, transition: !0, units: "line widths", requires: [{ "!": "line-pattern" }], expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "cross-faded-data-driven" }, "line-pattern": { type: "resolvedImage", transition: !0, expression: { interpolated: !1, parameters: ["zoom", "feature"] }, "property-type": "cross-faded-data-driven" }, "line-gradient": { type: "color", transition: !1, requires: [{ "!": "line-dasharray" }, { "!": "line-pattern" }, { source: "geojson", has: { lineMetrics: !0 } }], expression: { interpolated: !0, parameters: ["line-progress"] }, "property-type": "color-ramp" } }, paint_circle: { "circle-radius": { type: "number", default: 5, minimum: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-color": { type: "color", default: "#000000", transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-blur": { type: "number", default: 0, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "circle-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["circle-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "circle-pitch-scale": { type: "enum", values: { map: {}, viewport: {} }, default: "map", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "circle-pitch-alignment": { type: "enum", values: { map: {}, viewport: {} }, default: "viewport", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "circle-stroke-width": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-stroke-color": { type: "color", default: "#000000", transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "circle-stroke-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" } }, paint_heatmap: { "heatmap-radius": { type: "number", default: 30, minimum: 1, transition: !0, units: "pixels", expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "heatmap-weight": { type: "number", default: 1, minimum: 0, transition: !1, expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "heatmap-intensity": { type: "number", default: 1, minimum: 0, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "heatmap-color": { type: "color", default: ["interpolate", ["linear"], ["heatmap-density"], 0, "rgba(0, 0, 255, 0)", 0.1, "royalblue", 0.3, "cyan", 0.5, "lime", 0.7, "yellow", 1, "red"], transition: !1, expression: { interpolated: !0, parameters: ["heatmap-density"] }, "property-type": "color-ramp" }, "heatmap-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" } }, paint_symbol: { "icon-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "icon-color": { type: "color", default: "#000000", transition: !0, requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "icon-halo-color": { type: "color", default: "rgba(0, 0, 0, 0)", transition: !0, requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "icon-halo-width": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "icon-halo-blur": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "icon-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", requires: ["icon-image"], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "icon-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["icon-image", "icon-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "text-color": { type: "color", default: "#000000", transition: !0, overridable: !0, requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "text-halo-color": { type: "color", default: "rgba(0, 0, 0, 0)", transition: !0, requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "text-halo-width": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "text-halo-blur": { type: "number", default: 0, minimum: 0, transition: !0, units: "pixels", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom", "feature", "feature-state"] }, "property-type": "data-driven" }, "text-translate": { type: "array", value: "number", length: 2, default: [0, 0], transition: !0, units: "pixels", requires: ["text-field"], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "text-translate-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "map", requires: ["text-field", "text-translate"], expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" } }, paint_raster: { "raster-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-layer-blend": { type: "enum", values: { normal: {}, multiply: {}, color: {}, luminosity: {}, "plus-lighter": {}, screen: {}, overlay: {} }, default: "normal", "property-type": "constant", transition: !1 }, "raster-hue-rotate": { type: "number", default: 0, period: 360, transition: !0, units: "degrees", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-brightness-min": { type: "number", default: 0, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-brightness-max": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-saturation": { type: "number", default: 0, minimum: -1, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-contrast": { type: "number", default: 0, minimum: -1, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, resampling: { type: "enum", values: { linear: {}, nearest: {} }, default: "linear", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-resampling": { type: "enum", values: { linear: {}, nearest: {} }, default: "linear", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "raster-fade-duration": { type: "number", default: 300, minimum: 0, transition: !1, units: "milliseconds", expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" } }, paint_hillshade: { "hillshade-illumination-direction": { type: "numberArray", default: 335, minimum: 0, maximum: 359, transition: !1, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-illumination-altitude": { type: "numberArray", default: 45, minimum: 0, maximum: 90, transition: !1, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-illumination-anchor": { type: "enum", values: { map: {}, viewport: {} }, default: "viewport", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-exaggeration": { type: "number", default: 0.5, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-shadow-color": { type: "colorArray", default: "#000000", transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-highlight-color": { type: "colorArray", default: "#FFFFFF", transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-accent-color": { type: "color", default: "#000000", transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "hillshade-method": { type: "enum", values: { standard: {}, basic: {}, combined: {}, igor: {}, multidirectional: {} }, default: "standard", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" }, resampling: { type: "enum", values: { linear: {}, nearest: {} }, default: "linear", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" } }, "paint_color-relief": { "color-relief-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "color-relief-color": { type: "color", transition: !1, expression: { interpolated: !0, parameters: ["elevation"] }, "property-type": "color-ramp" }, resampling: { type: "enum", values: { linear: {}, nearest: {} }, default: "linear", expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "data-constant" } }, paint_background: { "background-color": { type: "color", default: "#000000", transition: !0, requires: [{ "!": "background-pattern" }], expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" }, "background-pattern": { type: "resolvedImage", transition: !0, expression: { interpolated: !1, parameters: ["zoom"] }, "property-type": "cross-faded" }, "background-opacity": { type: "number", default: 1, minimum: 0, maximum: 1, transition: !0, expression: { interpolated: !0, parameters: ["zoom"] }, "property-type": "data-constant" } }, transition: { duration: { type: "number", default: 300, minimum: 0, units: "milliseconds" }, delay: { type: "number", default: 0, minimum: 0, units: "milliseconds" } }, "property-type": { "data-driven": { type: "property-type" }, "cross-faded": { type: "property-type" }, "cross-faded-data-driven": { type: "property-type" }, "color-ramp": { type: "property-type" }, "data-constant": { type: "property-type" }, constant: { type: "property-type" } }, promoteId: { "*": { type: "string" } }, interpolation: { type: "array", value: "interpolation_name", minimum: 1 }, interpolation_name: { type: "enum", values: { linear: { syntax: { overloads: [{ parameters: [], "output-type": "interpolation" }], parameters: [] } }, exponential: { syntax: { overloads: [{ parameters: ["base"], "output-type": "interpolation" }], parameters: [{ name: "base", type: "number literal" }] } }, "cubic-bezier": { syntax: { overloads: [{ parameters: ["x1", "y1", "x2", "y2"], "output-type": "interpolation" }], parameters: [{ name: "x1", type: "number literal" }, { name: "y1", type: "number literal" }, { name: "x2", type: "number literal" }, { name: "y2", type: "number literal" }] } } } } };
const S = uf, Wm = ["type", "source", "source-layer", "minzoom", "maxzoom", "filter", "layout"];
var I = class {
  constructor(e, t, r, i, n = "error") {
    this.message = (e ? `${e}: ` : "") + r, i && (this.identifier = i), this.severity = n, t != null && t.__line__ && (this.line = t.__line__);
  }
}, kt = class extends Error {
  constructor(e, t) {
    super(t), this.message = t, this.key = e;
  }
}, Zm = class cf {
  constructor(t, r = []) {
    this.parent = t, this.bindings = {};
    for (let [i, n] of r) this.bindings[i] = n;
  }
  concat(t) {
    return new cf(this, t);
  }
  get(t) {
    if (this.bindings[t]) return this.bindings[t];
    if (this.parent) return this.parent.get(t);
    throw Error(`${t} not found in scope.`);
  }
  has(t) {
    return this.bindings[t] ? !0 : this.parent ? this.parent.has(t) : !1;
  }
};
const Bn = { kind: "null" }, F = { kind: "number" }, Y = { kind: "string" }, J = { kind: "boolean" }, Dt = { kind: "color" }, ss = { kind: "projectionDefinition" }, Cr = { kind: "object" }, W = { kind: "value" }, Hm = { kind: "error" }, os = { kind: "collator" }, Ln = { kind: "formatted" }, ls = { kind: "padding" }, yn = { kind: "colorArray" }, us = { kind: "numberArray" }, zn = { kind: "resolvedImage" }, cs = { kind: "variableAnchorOffsetCollection" };
function Ye(e, t) {
  return { kind: "array", itemType: e, N: t };
}
function xe(e) {
  if (e.kind === "array") {
    let t = xe(e.itemType);
    return typeof e.N == "number" ? `array<${t}, ${e.N}>` : e.itemType.kind === "value" ? "array" : `array<${t}>`;
  }
  return e.kind;
}
const Km = [Bn, F, Y, J, Dt, ss, Ln, Cr, Ye(W), ls, us, yn, zn, cs];
function mn(e, t) {
  if (t.kind === "error") return null;
  if (e.kind === "array") {
    if (t.kind === "array" && (t.N === 0 && t.itemType.kind === "value" || !mn(e.itemType, t.itemType)) && (typeof e.N != "number" || e.N === t.N)) return null;
  } else {
    if (e.kind === t.kind) return null;
    if (e.kind === "value") {
      for (let r of Km) if (!mn(r, t)) return null;
    }
  }
  return `Expected ${xe(e)} but found ${xe(t)} instead.`;
}
function iu(e, t) {
  return t.some((r) => r.kind === e.kind);
}
function kr(e, t) {
  return t.some((r) => r === "null" ? e === null : r === "array" ? Array.isArray(e) : r === "object" ? e && !Array.isArray(e) && typeof e == "object" : r === typeof e);
}
function or(e, t) {
  return e.kind === "array" && t.kind === "array" ? e.itemType.kind === t.itemType.kind && typeof e.N == "number" : e.kind === t.kind;
}
const hf = 0.96422, pf = 0.82521, ff = 4 / 29, Lo = 6 / 29, df = 3 * Lo * Lo, yf = Math.PI / 180, nu = 180 / Math.PI;
function au(e) {
  return e %= 360, e < 0 && (e += 360), e;
}
function mf([e, t, r, i]) {
  e = Ft(e), t = Ft(t), r = Ft(r);
  let n, a, s = no((0.2225045 * e + 0.7168786 * t + 0.0606169 * r) / 1);
  return e === t && t === r ? n = a = s : (n = no((0.4360747 * e + 0.3850649 * t + 0.1430804 * r) / hf), a = no((0.0139322 * e + 0.0971045 * t + 0.7141733 * r) / pf)), [116 * s - 16, 500 * (n - s), 200 * (s - a), i];
}
function Ft(e) {
  let t = Math.abs(e);
  return t <= 0.04045 ? e / 12.92 : Math.sign(e) * ((t + 0.055) / 1.055) ** 2.4;
}
function no(e) {
  return e > 0.008856451679035631 ? e ** (1 / 3) : e / df + ff;
}
function gf([e, t, r, i]) {
  let n = (e + 16) / 116, a = isNaN(t) ? n : n + t / 500, s = isNaN(r) ? n : n - r / 200;
  return n = 1 * so(n), a = hf * so(a), s = pf * so(s), [ao(3.1338561 * a - 1.6168667 * n - 0.4906146 * s), ao(-0.9787684 * a + 1.9161415 * n + 0.033454 * s), ao(0.0719453 * a - 0.2289914 * n + 1.4052427 * s), i];
}
function ao(e) {
  let t = Math.abs(e);
  return t <= 304e-5 ? 12.92 * e : Math.sign(e) * (1.055 * t ** (1 / 2.4) - 0.055);
}
function so(e) {
  return e > Lo ? e * e * e : df * (e - ff);
}
function Jm(e) {
  let [t, r, i, n] = mf(e), a = Math.sqrt(r * r + i * i);
  return [Math.round(a * 1e4) ? au(Math.atan2(i, r) * nu) : NaN, a, t, n];
}
function Qm([e, t, r, i]) {
  return e = isNaN(e) ? 0 : e * yf, gf([r, Math.cos(e) * t, Math.sin(e) * t, i]);
}
function eg([e, t, r, i]) {
  e = au(e), t /= 100, r /= 100;
  function n(a) {
    let s = (a + e / 30) % 12, o = t * Math.min(r, 1 - r);
    return r - o * Math.max(-1, Math.min(s - 3, 9 - s, 1));
  }
  return [n(0), n(8), n(4), i];
}
const xf = [[506752 / 1228815, 87881 / 245763, 12673 / 70218], [87098 / 409605, 175762 / 245763, 12673 / 175545], [7918 / 409605, 87881 / 737289, 1001167 / 1053270]], vf = [[12831 / 3959, -329 / 214, -1974 / 3959], [-851781 / 878810, 1648619 / 878810, 36519 / 878810], [705 / 12673, -2585 / 12673, 705 / 667]], tg = [[0.819022437996703, 0.3619062600528904, -0.1288737815209879], [0.0329836539323885, 0.9292868615863434, 0.0361446663506424], [0.0481771893596242, 0.2642395317527308, 0.6335478284694309]], rg = [[0.210454268309314, 0.7936177747023054, -0.0040720430116193], [1.9779985324311684, -2.42859224204858, 0.450593709617411], [0.0259040424655478, 0.7827717124575296, -0.8086757549230774]], ig = [[1, 0.3963377773761749, 0.2158037573099136], [1, -0.1055613458156586, -0.0638541728258133], [1, -0.0894841775298119, -1.2914855480194092]], ng = [[1.2268798758459243, -0.5578149944602171, 0.2813910456659647], [-0.0405757452148008, 1.112286803280317, -0.0717110580655164], [-0.0763729366746601, -0.4214933324022432, 1.5869240198367816]];
function Mt(e, [t, r, i]) {
  return [e[0][0] * t + e[0][1] * r + e[0][2] * i, e[1][0] * t + e[1][1] * r + e[1][2] * i, e[2][0] * t + e[2][1] * r + e[2][2] * i];
}
function sn(e) {
  let t = Math.abs(e);
  return t > 31308e-7 ? Math.sign(e) * (1.055 * t ** (1 / 2.4) - 0.055) : 12.92 * e;
}
function bf([e, t, r]) {
  let [i, n, a] = Mt(tg, Mt(xf, [Ft(e), Ft(t), Ft(r)]));
  return Mt(rg, [Math.cbrt(i), Math.cbrt(n), Math.cbrt(a)]);
}
function ag(e) {
  let [t, r, i] = Mt(ig, e), [n, a, s] = Mt(vf, Mt(ng, [t * t * t, r * r * r, i * i * i]));
  return [sn(n), sn(a), sn(s)];
}
function sg([e, t, r, i]) {
  let [n, a, s] = bf([e, t, r]);
  return [n, a, s, i];
}
function og([e, t, r, i]) {
  let [n, a, s] = bf([e, t, r]), o = Math.sqrt(a * a + s * s);
  return o <= 4e-6 ? [n, 0, NaN, i] : [n, o, au(Math.atan2(s, a) * nu), i];
}
function su([e, t, r, i]) {
  let n = isNaN(r) ? 0 : r * yf, a = Math.min(t, 1e6), [s, o, l] = ag([e, a * Math.cos(n), a * Math.sin(n)]);
  return [s, o, l, i];
}
function wf([e, t, r, i]) {
  return su([e, Math.hypot(t, r), Math.atan2(r, t) * nu, i]);
}
const lg = [[608311 / 1250200, 189793 / 714400, 198249 / 1000160], [35783 / 156275, 247089 / 357200, 198249 / 2500400], [0, 32229 / 714400, 5220557 / 5000800]], ug = [[446124 / 178915, -333277 / 357830, -72051 / 178915], [-14852 / 17905, 63121 / 35810, 423 / 17905], [11844 / 330415, -50337 / 660830, 316169 / 330415]];
function cg([e, t, r, i]) {
  let [n, a, s] = [e, t, r].map((c) => Ft(Math.min(Math.max(c, -1e6), 1e6))), [o, l, u] = Mt(vf, Mt(lg, [n, a, s])).map(sn);
  return [o, l, u, i];
}
function hg([e, t, r, i]) {
  let [n, a, s] = Mt(ug, Mt(xf, [Ft(e), Ft(t), Ft(r)])).map((o) => Math.min(Math.max(sn(o), 0), 1));
  return [n, a, s, i];
}
const pg = Object.hasOwn || function(e, t) {
  return Object.prototype.hasOwnProperty.call(e, t);
};
function on(e, t) {
  return pg(e, t) ? e[t] : void 0;
}
function fg(e) {
  if (e = e.toLowerCase().trim(), e === "transparent") return [0, 0, 0, 0];
  let t = on(gg, e);
  if (t) {
    let [s, o, l] = t;
    return [s / 255, o / 255, l / 255, 1];
  }
  if (e.startsWith("#") && /^#(?:[0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.test(e)) {
    let s = e.length < 6 ? 1 : 2, o = 1;
    return [ua(e.slice(o, o += s)), ua(e.slice(o, o += s)), ua(e.slice(o, o += s)), ua(e.slice(o, o + s) || "ff")];
  }
  if (e.startsWith("rgb")) {
    let s = e.match(/^rgba?\(\s*([\de.+-]+)(%)?(?:\s+|\s*(,)\s*)([\de.+-]+)(%)?(?:\s+|\s*(,)\s*)([\de.+-]+)(%)?(?:\s*([,\/])\s*([\de.+-]+)(%)?)?\s*\)$/);
    if (s) {
      let [o, l, u, c, h, p, f, d, y, m, g, v] = s, x = [c || " ", f || " ", m].join("");
      if (x === "  " || x === "  /" || x === ",," || x === ",,,") {
        let b = [u, p, y].join(""), w = b === "%%%" ? 100 : b === "" ? 255 : 0;
        if (w) {
          let D = [bt(+l / w, 0, 1), bt(+h / w, 0, 1), bt(+d / w, 0, 1), g ? Yc(+g, v) : 1];
          if (Wc(D)) return D;
        }
      }
      return;
    }
  }
  let r = e.match(/^hsla?\(\s*([\de.+-]+)(?:deg)?(?:\s+|\s*(,)\s*)([\de.+-]+)%(?:\s+|\s*(,)\s*)([\de.+-]+)%(?:\s*([,\/])\s*([\de.+-]+)(%)?)?\s*\)$/);
  if (r) {
    let [s, o, l, u, c, h, p, f, d] = r, y = [l || " ", c || " ", p].join("");
    if (y === "  " || y === "  /" || y === ",," || y === ",,,") {
      let m = [+o, bt(+u, 0, 100), bt(+h, 0, 100), f ? Yc(+f, d) : 1];
      if (Wc(m)) return eg(m);
    }
  }
  let i = e.match(dg);
  if (i) {
    let [, s, o, l, u] = i, c = [ct(s, 1), ct(o, 0.4), ct(l, 1), u === void 0 ? 1 : ct(u, 1)];
    if (c.every(Number.isFinite)) return su([bt(c[0], 0, 1), Math.max(c[1], 0), c[2] % 360, bt(c[3], 0, 1)]);
  }
  let n = e.match(yg);
  if (n) {
    let [, s, o, l, u] = n, c = [ct(s, 1), ct(o, 0.4), ct(l, 0.4), u === void 0 ? 1 : ct(u, 1)];
    if (c.every(Number.isFinite)) return wf([bt(c[0], 0, 1), c[1], c[2], bt(c[3], 0, 1)]);
  }
  let a = e.match(mg);
  if (a) {
    let [, s, o, l, u] = a, c = [ct(s, 1), ct(o, 1), ct(l, 1), u === void 0 ? 1 : ct(u, 1)];
    if (c.every(Number.isFinite)) return cg([c[0], c[1], c[2], bt(c[3], 0, 1)]);
  }
}
const yt = "[+-]?(?:\\d+(?:\\.\\d+)?|\\.\\d+)(?:e[+-]?\\d+)?", dg = RegExp(`^oklch\\(\\s*(none|${yt}%?)\\s+(none|${yt}%?)\\s+(none|${yt}(?:deg|grad|rad|turn)?)\\s*(?:\\/\\s*(none|${yt}%?)\\s*)?\\)$`), yg = RegExp(`^oklab\\(\\s*(none|${yt}%?)\\s+(none|${yt}%?)\\s+(none|${yt}%?)\\s*(?:\\/\\s*(none|${yt}%?)\\s*)?\\)$`), mg = RegExp(`^color\\(\\s*display-p3\\s+(none|${yt}%?)\\s+(none|${yt}%?)\\s+(none|${yt}%?)\\s*(?:\\/\\s*(none|${yt}%?)\\s*)?\\)$`), Xc = { deg: 1, grad: 0.9, rad: 180 / Math.PI, turn: 360 };
function ct(e, t) {
  if (e === "none") return 0;
  let [, r, i] = e.match(/^(.+?)(%|[a-z]+)?$/);
  return i === "%" ? r / 100 * t : i ? +r % (360 / Xc[i]) * Xc[i] : +r;
}
function ua(e) {
  return parseInt(e.padEnd(2, e), 16) / 255;
}
function Yc(e, t) {
  return bt(t ? e / 100 : e, 0, 1);
}
function bt(e, t, r) {
  return Math.min(Math.max(t, e), r);
}
function Wc(e) {
  return !e.some(Number.isNaN);
}
const gg = { aliceblue: [240, 248, 255], antiquewhite: [250, 235, 215], aqua: [0, 255, 255], aquamarine: [127, 255, 212], azure: [240, 255, 255], beige: [245, 245, 220], bisque: [255, 228, 196], black: [0, 0, 0], blanchedalmond: [255, 235, 205], blue: [0, 0, 255], blueviolet: [138, 43, 226], brown: [165, 42, 42], burlywood: [222, 184, 135], cadetblue: [95, 158, 160], chartreuse: [127, 255, 0], chocolate: [210, 105, 30], coral: [255, 127, 80], cornflowerblue: [100, 149, 237], cornsilk: [255, 248, 220], crimson: [220, 20, 60], cyan: [0, 255, 255], darkblue: [0, 0, 139], darkcyan: [0, 139, 139], darkgoldenrod: [184, 134, 11], darkgray: [169, 169, 169], darkgreen: [0, 100, 0], darkgrey: [169, 169, 169], darkkhaki: [189, 183, 107], darkmagenta: [139, 0, 139], darkolivegreen: [85, 107, 47], darkorange: [255, 140, 0], darkorchid: [153, 50, 204], darkred: [139, 0, 0], darksalmon: [233, 150, 122], darkseagreen: [143, 188, 143], darkslateblue: [72, 61, 139], darkslategray: [47, 79, 79], darkslategrey: [47, 79, 79], darkturquoise: [0, 206, 209], darkviolet: [148, 0, 211], deeppink: [255, 20, 147], deepskyblue: [0, 191, 255], dimgray: [105, 105, 105], dimgrey: [105, 105, 105], dodgerblue: [30, 144, 255], firebrick: [178, 34, 34], floralwhite: [255, 250, 240], forestgreen: [34, 139, 34], fuchsia: [255, 0, 255], gainsboro: [220, 220, 220], ghostwhite: [248, 248, 255], gold: [255, 215, 0], goldenrod: [218, 165, 32], gray: [128, 128, 128], green: [0, 128, 0], greenyellow: [173, 255, 47], grey: [128, 128, 128], honeydew: [240, 255, 240], hotpink: [255, 105, 180], indianred: [205, 92, 92], indigo: [75, 0, 130], ivory: [255, 255, 240], khaki: [240, 230, 140], lavender: [230, 230, 250], lavenderblush: [255, 240, 245], lawngreen: [124, 252, 0], lemonchiffon: [255, 250, 205], lightblue: [173, 216, 230], lightcoral: [240, 128, 128], lightcyan: [224, 255, 255], lightgoldenrodyellow: [250, 250, 210], lightgray: [211, 211, 211], lightgreen: [144, 238, 144], lightgrey: [211, 211, 211], lightpink: [255, 182, 193], lightsalmon: [255, 160, 122], lightseagreen: [32, 178, 170], lightskyblue: [135, 206, 250], lightslategray: [119, 136, 153], lightslategrey: [119, 136, 153], lightsteelblue: [176, 196, 222], lightyellow: [255, 255, 224], lime: [0, 255, 0], limegreen: [50, 205, 50], linen: [250, 240, 230], magenta: [255, 0, 255], maroon: [128, 0, 0], mediumaquamarine: [102, 205, 170], mediumblue: [0, 0, 205], mediumorchid: [186, 85, 211], mediumpurple: [147, 112, 219], mediumseagreen: [60, 179, 113], mediumslateblue: [123, 104, 238], mediumspringgreen: [0, 250, 154], mediumturquoise: [72, 209, 204], mediumvioletred: [199, 21, 133], midnightblue: [25, 25, 112], mintcream: [245, 255, 250], mistyrose: [255, 228, 225], moccasin: [255, 228, 181], navajowhite: [255, 222, 173], navy: [0, 0, 128], oldlace: [253, 245, 230], olive: [128, 128, 0], olivedrab: [107, 142, 35], orange: [255, 165, 0], orangered: [255, 69, 0], orchid: [218, 112, 214], palegoldenrod: [238, 232, 170], palegreen: [152, 251, 152], paleturquoise: [175, 238, 238], palevioletred: [219, 112, 147], papayawhip: [255, 239, 213], peachpuff: [255, 218, 185], peru: [205, 133, 63], pink: [255, 192, 203], plum: [221, 160, 221], powderblue: [176, 224, 230], purple: [128, 0, 128], rebeccapurple: [102, 51, 153], red: [255, 0, 0], rosybrown: [188, 143, 143], royalblue: [65, 105, 225], saddlebrown: [139, 69, 19], salmon: [250, 128, 114], sandybrown: [244, 164, 96], seagreen: [46, 139, 87], seashell: [255, 245, 238], sienna: [160, 82, 45], silver: [192, 192, 192], skyblue: [135, 206, 235], slateblue: [106, 90, 205], slategray: [112, 128, 144], slategrey: [112, 128, 144], snow: [255, 250, 250], springgreen: [0, 255, 127], steelblue: [70, 130, 180], tan: [210, 180, 140], teal: [0, 128, 128], thistle: [216, 191, 216], tomato: [255, 99, 71], turquoise: [64, 224, 208], violet: [238, 130, 238], wheat: [245, 222, 179], white: [255, 255, 255], whitesmoke: [245, 245, 245], yellow: [255, 255, 0], yellowgreen: [154, 205, 50] };
function Xe(e, t, r) {
  return e + r * (t - e);
}
function di(e, t, r) {
  return e.map((i, n) => Xe(i, t[n], r));
}
function xg(e) {
  return e === "rgb" || e === "hcl" || e === "lab" || e === "oklch" || e === "oklab";
}
var ke, fe = (ke = class {
  constructor(t, r, i, n = 1, a = !0) {
    !a && (Math.min(t, r, i) < 0 || Math.max(t, r, i) > 1) && (this.overwriteGetter("unclippedRgb", [t, r, i, n]), t = Math.min(Math.max(t, 0), 1), r = Math.min(Math.max(r, 0), 1), i = Math.min(Math.max(i, 0), 1)), this.r = t, this.g = r, this.b = i, this.a = n, a || (this.r *= n, this.g *= n, this.b *= n, n || this.overwriteGetter("rgb", [t, r, i, n]));
  }
  static parse(t) {
    if (t instanceof ke) return t;
    if (typeof t != "string") return;
    let r = fg(t);
    if (r) return new ke(...r, !1);
  }
  get rgb() {
    let { r: t, g: r, b: i, a: n } = this, a = n || 1 / 0;
    return this.overwriteGetter("rgb", [t / a, r / a, i / a, n]);
  }
  get hcl() {
    return this.overwriteGetter("hcl", Jm(this.unclippedRgb));
  }
  get lab() {
    return this.overwriteGetter("lab", mf(this.unclippedRgb));
  }
  get oklch() {
    return this.overwriteGetter("oklch", og(this.unclippedRgb));
  }
  get oklab() {
    return this.overwriteGetter("oklab", sg(this.unclippedRgb));
  }
  get displayP3() {
    return this.overwriteGetter("displayP3", hg(this.unclippedRgb));
  }
  get unclippedRgb() {
    return this.rgb;
  }
  overwriteGetter(t, r) {
    return Object.defineProperty(this, t, { value: r }), r;
  }
  toString() {
    let [t, r, i, n] = this.rgb;
    return `rgba(${[t, r, i].map((a) => Math.round(a * 255)).join(",")},${n})`;
  }
  static interpolate(t, r, i, n = "rgb") {
    switch (n) {
      case "rgb": {
        let [a, s, o, l] = di(t.unclippedRgb, r.unclippedRgb, i);
        return new ke(a, s, o, l, !1);
      }
      case "hcl": {
        let [a, s, o, l] = t.hcl, [u, c, h, p] = r.hcl, f, d;
        if (!isNaN(a) && !isNaN(u)) {
          let x = u - a;
          u > a && x > 180 ? x -= 360 : u < a && a - u > 180 && (x += 360), f = a + i * x;
        } else isNaN(a) ? isNaN(u) ? f = NaN : (f = u, (o === 1 || o === 0) && (d = c)) : (f = a, (h === 1 || h === 0) && (d = s));
        let [y, m, g, v] = Qm([f, d ?? Xe(s, c, i), Xe(o, h, i), Xe(l, p, i)]);
        return new ke(y, m, g, v, !1);
      }
      case "lab": {
        let [a, s, o, l] = gf(di(t.lab, r.lab, i));
        return new ke(a, s, o, l, !1);
      }
      case "oklch": {
        let [a, s, o, l] = t.oklch, [u, c, h, p] = r.oklch, f = isNaN(o) ? h : o, d = isNaN(h) ? o : h;
        d - f > 180 ? f += 360 : d - f < -180 && (d += 360);
        let y = Xe(l, p, i), m = y === 0 ? 1 : y, [g, v, x] = su([Xe(a * l, u * p, i) / m, Xe(s * l, c * p, i) / m, Xe(f, d, i), y]);
        return new ke(g, v, x, y, !1);
      }
      case "oklab": {
        let [a, s, o, l] = t.oklab, [u, c, h, p] = r.oklab, f = Xe(l, p, i), d = f === 0 ? 1 : f, [y, m, g] = wf([Xe(a * l, u * p, i) / d, Xe(s * l, c * p, i) / d, Xe(o * l, h * p, i) / d, f]);
        return new ke(y, m, g, f, !1);
      }
    }
  }
}, ke.black = new ke(0, 0, 0, 1), ke.white = new ke(1, 1, 1, 1), ke.transparent = new ke(0, 0, 0, 0), ke.red = new ke(1, 0, 0, 1), ke), ou = class {
  constructor(e, t, r) {
    this.sensitivity = e ? t ? "variant" : "case" : t ? "accent" : "base", this.locale = r, this.collator = new Intl.Collator(this.locale ? this.locale : [], { sensitivity: this.sensitivity, usage: "search" });
  }
  compare(e, t) {
    return this.collator.compare(e, t);
  }
  resolvedLocale() {
    return new Intl.Collator(this.locale ? this.locale : []).resolvedOptions().locale;
  }
};
const vg = ["bottom", "center", "top"];
var zo = class {
  constructor(e, t, r, i, n, a) {
    this.text = e, this.image = t, this.scale = r, this.fontStack = i, this.textColor = n, this.verticalAlign = a;
  }
}, Ht = class Ta {
  constructor(t) {
    this.sections = t;
  }
  static fromString(t) {
    return new Ta([new zo(t, null, null, null, null, null)]);
  }
  isEmpty() {
    return this.sections.length === 0 || !this.sections.some((t) => t.text.length !== 0 || t.image && t.image.name.length !== 0);
  }
  static factory(t) {
    return t instanceof Ta ? t : Ta.fromString(t);
  }
  toString() {
    return this.sections.length === 0 ? "" : this.sections.map((t) => t.text).join("");
  }
}, Vt = class Hi {
  constructor(t) {
    this.values = t.slice();
  }
  static parse(t) {
    if (t instanceof Hi) return t;
    if (typeof t == "number") return new Hi([t, t, t, t]);
    if (Array.isArray(t) && !(t.length < 1 || t.length > 4)) {
      for (let r of t) if (typeof r != "number") return;
      switch (t.length) {
        case 1:
          t = [t[0], t[0], t[0], t[0]];
          break;
        case 2:
          t = [t[0], t[1], t[0], t[1]];
          break;
        case 3:
          t = [t[0], t[1], t[2], t[1]];
      }
      return new Hi(t);
    }
  }
  toString() {
    return JSON.stringify(this.values);
  }
  static interpolate(t, r, i) {
    return new Hi(di(t.values, r.values, i));
  }
}, Ot = class Ki {
  constructor(t) {
    this.values = t.slice();
  }
  static parse(t) {
    if (t instanceof Ki) return t;
    if (typeof t == "number") return new Ki([t]);
    if (Array.isArray(t)) {
      for (let r of t) if (typeof r != "number") return;
      return new Ki(t);
    }
  }
  toString() {
    return JSON.stringify(this.values);
  }
  static interpolate(t, r, i) {
    return new Ki(di(t.values, r.values, i));
  }
}, tt = class Ji {
  constructor(t) {
    this.values = t.slice();
  }
  static parse(t) {
    if (t instanceof Ji) return t;
    if (typeof t == "string") {
      let i = fe.parse(t);
      return i ? new Ji([i]) : void 0;
    }
    if (!Array.isArray(t)) return;
    let r = [];
    for (let i of t) {
      if (typeof i != "string") return;
      let n = fe.parse(i);
      if (!n) return;
      r.push(n);
    }
    return new Ji(r);
  }
  toString() {
    return JSON.stringify(this.values);
  }
  static interpolate(t, r, i, n = "rgb") {
    let a = [];
    if (t.values.length != r.values.length) throw Error(`colorArray: Arrays have mismatched length (${t.values.length} vs. ${r.values.length}), cannot interpolate.`);
    for (let s = 0; s < t.values.length; s++) a.push(fe.interpolate(t.values[s], r.values[s], i, n));
    return new Ji(a);
  }
}, de = class extends Error {
  constructor(e, t) {
    super(e), this.name = "RuntimeError", this.path = t;
  }
  toJSON() {
    return this.message;
  }
};
const bg = /* @__PURE__ */ new Set(["center", "left", "right", "top", "bottom", "top-left", "top-right", "bottom-left", "bottom-right"]);
var Lt = class Ia {
  constructor(t) {
    this.values = t.slice();
  }
  static parse(t) {
    if (t instanceof Ia) return t;
    if (!(!Array.isArray(t) || t.length < 1 || t.length % 2 != 0)) {
      for (let r = 0; r < t.length; r += 2) {
        let i = t[r], n = t[r + 1];
        if (typeof i != "string" || !bg.has(i) || !Array.isArray(n) || n.length !== 2 || typeof n[0] != "number" || typeof n[1] != "number") return;
      }
      return new Ia(t);
    }
  }
  toString() {
    return JSON.stringify(this.values);
  }
  static interpolate(t, r, i, n) {
    let a = t.values, s = r.values;
    if (a.length !== s.length) throw new de(`Cannot interpolate values of different length. from: ${t.toString()}, to: ${r.toString()}`, n);
    let o = [];
    for (let l = 0; l < a.length; l += 2) {
      if (a[l] !== s[l]) throw new de(`Cannot interpolate values containing mismatched anchors. from[${l}]: ${a[l]}, to[${l}]: ${s[l]}`, n);
      o.push(a[l]);
      let [u, c] = a[l + 1], [h, p] = s[l + 1];
      o.push([Xe(u, h, i), Xe(c, p, i)]);
    }
    return new Ia(o);
  }
}, zt = class _f {
  constructor(t) {
    this.name = t.name, this.available = t.available;
  }
  toString() {
    return this.name;
  }
  static fromString(t) {
    return t ? new _f({ name: t, available: !1 }) : null;
  }
}, zr = class Hr {
  constructor(t, r, i) {
    this.from = t, this.to = r, this.transition = i;
  }
  toString() {
    return this.from === this.to && this.transition === 1 ? this.from : JSON.stringify([this.from, this.to, this.transition]);
  }
  static interpolate(t, r, i) {
    return new Hr(t, r, i);
  }
  static parse(t) {
    if (t instanceof Hr) return t;
    if (Array.isArray(t) && t.length === 3 && typeof t[0] == "string" && typeof t[1] == "string" && typeof t[2] == "number") return new Hr(t[0], t[1], t[2]);
    if (typeof t == "object" && typeof t.from == "string" && typeof t.to == "string" && typeof t.transition == "number") return new Hr(t.from, t.to, t.transition);
    if (typeof t == "string") return new Hr(t, t, 1);
  }
};
function Df(e, t, r, i) {
  return typeof e == "number" && e >= 0 && e <= 255 && typeof t == "number" && t >= 0 && t <= 255 && typeof r == "number" && r >= 0 && r <= 255 ? i === void 0 || typeof i == "number" && i >= 0 && i <= 1 ? null : `Invalid rgba value [${[e, t, r, i].join(", ")}]: 'a' must be between 0 and 1.` : `Invalid rgba value [${(typeof i == "number" ? [e, t, r, i] : [e, t, r]).join(", ")}]: 'r', 'g', and 'b' must be between 0 and 255.`;
}
function yi(e) {
  if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" || e instanceof zr || e instanceof fe || e instanceof ou || e instanceof Ht || e instanceof Vt || e instanceof Ot || e instanceof tt || e instanceof Lt || e instanceof zt) return !0;
  if (Array.isArray(e)) {
    for (let t of e) if (!yi(t)) return !1;
    return !0;
  }
  if (typeof e == "object") {
    for (let t in e) if (!yi(e[t])) return !1;
    return !0;
  }
  return !1;
}
function Ae(e) {
  if (e === null) return Bn;
  if (typeof e == "string") return Y;
  if (typeof e == "boolean") return J;
  if (typeof e == "number") return F;
  if (e instanceof fe) return Dt;
  if (e instanceof zr) return ss;
  if (e instanceof ou) return os;
  if (e instanceof Ht) return Ln;
  if (e instanceof Vt) return ls;
  if (e instanceof Ot) return us;
  if (e instanceof tt) return yn;
  if (e instanceof Lt) return cs;
  if (e instanceof zt) return zn;
  if (Array.isArray(e)) {
    let t = e.length, r;
    for (let i of e) {
      let n = Ae(i);
      if (!r) r = n;
      else {
        if (r === n) continue;
        r = W;
        break;
      }
    }
    return Ye(r || W, t);
  }
  return Cr;
}
function ln(e) {
  let t = typeof e;
  return e === null ? "" : t === "string" || t === "number" || t === "boolean" ? String(e) : e instanceof fe || e instanceof zr || e instanceof Ht || e instanceof Vt || e instanceof Ot || e instanceof tt || e instanceof Lt || e instanceof zt ? e.toString() : JSON.stringify(e);
}
var mi = class Sf {
  constructor(t, r) {
    this.type = t, this.value = r;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`'literal' expression requires exactly one argument, but found ${t.length - 1} instead.`);
    if (!yi(t[1])) return r.error(`invalid value of type "${typeof t[1]}"`);
    let i = t[1], n = Ae(i), a = r.expectedType;
    return n.kind === "array" && n.N === 0 && a && a.kind === "array" && (typeof a.N != "number" || a.N === 0) && (n = a), new Sf(n, i);
  }
  evaluate() {
    return this.value;
  }
  eachChild() {
  }
  outputDefined() {
    return !0;
  }
};
const ca = { string: Y, number: F, boolean: J, object: Cr };
var qt = class Af {
  constructor(t, r, i) {
    this.type = t, this.args = r, this.key = i;
  }
  static parse(t, r) {
    if (t.length < 2) return r.error("Expected at least one argument.");
    let i = 1, n, a = t[0];
    if (a === "array") {
      let o;
      if (t.length > 2) {
        let u = t[1];
        if (typeof u != "string" || !(u in ca) || u === "object") return r.error('The item type argument of "array" must be one of string, number, boolean', 1);
        o = ca[u], i++;
      } else o = W;
      let l;
      if (t.length > 3) {
        if (t[2] !== null && (typeof t[2] != "number" || t[2] < 0 || t[2] !== Math.floor(t[2]))) return r.error('The length argument to "array" must be a positive integer literal', 2);
        l = t[2], i++;
      }
      n = Ye(o, l);
    } else {
      if (!ca[a]) throw Error(`Types doesn't contain name = ${a}`);
      n = ca[a];
    }
    let s = [];
    for (; i < t.length; i++) {
      let o = r.parse(t[i], i, W);
      if (!o) return null;
      s.push(o);
    }
    return new Af(n, s, r.key);
  }
  evaluate(t) {
    for (let r = 0; r < this.args.length; r++) {
      let i = this.args[r].evaluate(t);
      if (!mn(this.type, Ae(i))) return i;
      if (r === this.args.length - 1) throw new de(`Expected value to be of type ${xe(this.type)}, but found ${xe(Ae(i))} instead.`, this.key);
    }
    throw Error();
  }
  eachChild(t) {
    this.args.forEach(t);
  }
  outputDefined() {
    return this.args.every((t) => t.outputDefined());
  }
};
const Zc = { "to-boolean": J, "to-color": Dt, "to-number": F, "to-string": Y };
var ri = class Ef {
  constructor(t, r, i) {
    this.type = t, this.args = r, this.key = i;
  }
  static parse(t, r) {
    if (t.length < 2) return r.error("Expected at least one argument.");
    let i = t[0];
    if (!Zc[i]) throw Error(`Can't parse ${i} as it is not part of the known types`);
    if ((i === "to-boolean" || i === "to-string") && t.length !== 2) return r.error("Expected one argument.");
    let n = Zc[i], a = [];
    for (let s = 1; s < t.length; s++) {
      let o = r.parse(t[s], s, W);
      if (!o) return null;
      a.push(o);
    }
    return new Ef(n, a, r.key);
  }
  evaluate(t) {
    switch (this.type.kind) {
      case "boolean":
        return !!this.args[0].evaluate(t);
      case "color": {
        let r, i;
        for (let n of this.args) {
          if (r = n.evaluate(t), i = null, r instanceof fe) return r;
          if (typeof r == "string") {
            let a = t.parseColor(r);
            if (a) return a;
          } else if (Array.isArray(r) && (i = r.length < 3 || r.length > 4 ? `Invalid rgba value ${JSON.stringify(r)}: expected an array containing either three or four numeric values.` : Df(r[0], r[1], r[2], r[3]), !i)) return new fe(r[0] / 255, r[1] / 255, r[2] / 255, r[3]);
        }
        throw new de(i || `Could not parse color from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      case "padding": {
        let r;
        for (let i of this.args) {
          r = i.evaluate(t);
          let n = Vt.parse(r);
          if (n) return n;
        }
        throw new de(`Could not parse padding from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      case "numberArray": {
        let r;
        for (let i of this.args) {
          r = i.evaluate(t);
          let n = Ot.parse(r);
          if (n) return n;
        }
        throw new de(`Could not parse numberArray from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      case "colorArray": {
        let r;
        for (let i of this.args) {
          r = i.evaluate(t);
          let n = tt.parse(r);
          if (n) return n;
        }
        throw new de(`Could not parse colorArray from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      case "variableAnchorOffsetCollection": {
        let r;
        for (let i of this.args) {
          r = i.evaluate(t);
          let n = Lt.parse(r);
          if (n) return n;
        }
        throw new de(`Could not parse variableAnchorOffsetCollection from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      case "number": {
        let r = null;
        for (let i of this.args) {
          if (r = i.evaluate(t), r === null) return 0;
          let n = Number(r);
          if (!isNaN(n)) return n;
        }
        throw new de(`Could not convert ${JSON.stringify(r)} to number.`, this.key);
      }
      case "formatted":
        return Ht.fromString(ln(this.args[0].evaluate(t)));
      case "resolvedImage":
        return zt.fromString(ln(this.args[0].evaluate(t)));
      case "projectionDefinition": {
        let r = this.args[0].evaluate(t);
        if (zr.parse(r)) return r;
        throw new de(`Could not parse projectionDefinition from value '${typeof r == "string" ? r : JSON.stringify(r)}'`, this.key);
      }
      default:
        return ln(this.args[0].evaluate(t));
    }
  }
  eachChild(t) {
    this.args.forEach(t);
  }
  outputDefined() {
    return this.args.every((t) => t.outputDefined());
  }
};
const wg = ["Unknown", "Point", "LineString", "Polygon"];
var Tf = class {
  constructor() {
    this.globals = null, this.feature = null, this.featureState = null, this.formattedSection = null, this._parseColorCache = /* @__PURE__ */ new Map(), this.availableImages = null, this.canonical = null;
  }
  id() {
    return this.feature && "id" in this.feature ? this.feature.id : null;
  }
  geometryType() {
    return this.feature ? typeof this.feature.type == "number" ? wg[this.feature.type] : this.feature.type : null;
  }
  geometry() {
    return this.feature && "geometry" in this.feature ? this.feature.geometry : null;
  }
  canonicalID() {
    return this.canonical;
  }
  properties() {
    return this.feature && this.feature.properties || {};
  }
  parseColor(e) {
    let t = this._parseColorCache.get(e);
    return t || (t = fe.parse(e), this._parseColorCache.set(e, t)), t;
  }
}, If = class Cf {
  constructor(t, r, i = [], n, a = new Zm(), s = []) {
    this.registry = t, this.path = i, this.key = i.map((o) => `[${o}]`).join(""), this.scope = a, this.errors = s, this.expectedType = n, this._isConstant = r;
  }
  parse(t, r, i, n, a = {}) {
    return r == null ? this._parse(t, a) : this.concat(r, i, n)._parse(t, a);
  }
  _parse(t, r) {
    (t === null || typeof t == "string" || typeof t == "boolean" || typeof t == "number") && (t = ["literal", t]);
    let i = this.key;
    function n(a, s, o) {
      return o === "assert" ? new qt(s, [a], i) : o === "coerce" ? new ri(s, [a], i) : a;
    }
    if (Array.isArray(t)) {
      if (t.length === 0) return this.error('Expected an array with at least one element. If you wanted a literal array, use ["literal", []].');
      let a = t[0];
      if (typeof a != "string") return this.error(`Expression name must be a string, but found ${typeof a} instead. If you wanted a literal array, use ["literal", [...]].`, 0), null;
      let s = this.registry[a];
      if (s) {
        let o = s.parse(t, this);
        if (!o) return null;
        if (this.expectedType) {
          let l = this.expectedType, u = o.type;
          if ((l.kind === "string" || l.kind === "number" || l.kind === "boolean" || l.kind === "object" || l.kind === "array") && u.kind === "value") o = n(o, l, r.typeAnnotation || "assert");
          else if (l.kind === "projectionDefinition" && ["string", "array", "value"].includes(u.kind) || ["color", "formatted", "resolvedImage"].includes(l.kind) && ["value", "string"].includes(u.kind) || ["padding", "numberArray"].includes(l.kind) && ["value", "number", "array"].includes(u.kind) || l.kind === "colorArray" && ["value", "string", "array"].includes(u.kind) || l.kind === "variableAnchorOffsetCollection" && ["value", "array"].includes(u.kind)) o = n(o, l, r.typeAnnotation || "coerce");
          else if (this.checkSubtype(l, u)) return null;
        }
        if (!(o instanceof mi) && o.type.kind !== "resolvedImage" && this._isConstant(o)) {
          let l = new Tf();
          try {
            o = new mi(o.type, o.evaluate(l));
          } catch (u) {
            return this.error(u.message), null;
          }
        }
        return o;
      }
      return this.error(`Unknown expression "${a}". If you wanted a literal array, use ["literal", [...]].`, 0);
    }
    return t === void 0 ? this.error("'undefined' value invalid. Use null instead.") : typeof t == "object" ? this.error('Bare objects invalid. Use ["literal", {...}] instead.') : this.error(`Expected an array, but found ${typeof t} instead.`);
  }
  concat(t, r, i) {
    let n = typeof t == "number" ? this.path.concat(t) : this.path, a = i ? this.scope.concat(i) : this.scope;
    return new Cf(this.registry, this._isConstant, n, r || null, a, this.errors);
  }
  error(t, ...r) {
    let i = `${this.key}${r.map((n) => `[${n}]`).join("")}`;
    this.errors.push(new kt(i, t));
  }
  checkSubtype(t, r) {
    let i = mn(t, r);
    return i && this.error(i), i;
  }
}, kf = class Ff {
  constructor(t, r) {
    this.type = r.type, this.bindings = [].concat(t), this.result = r;
  }
  evaluate(t) {
    return this.result.evaluate(t);
  }
  eachChild(t) {
    for (let r of this.bindings) t(r[1]);
    t(this.result);
  }
  static parse(t, r) {
    if (t.length < 4) return r.error(`Expected at least 3 arguments, but found ${t.length - 1} instead.`);
    let i = [];
    for (let a = 1; a < t.length - 1; a += 2) {
      let s = t[a];
      if (typeof s != "string") return r.error(`Expected string, but found ${typeof s} instead.`, a);
      if (/[^a-zA-Z0-9_]/.test(s)) return r.error("Variable names must contain only alphanumeric characters or '_'.", a);
      let o = r.parse(t[a + 1], a + 1);
      if (!o) return null;
      i.push([s, o]);
    }
    let n = r.parse(t[t.length - 1], t.length - 1, r.expectedType, i);
    return n ? new Ff(i, n) : null;
  }
  outputDefined() {
    return this.result.outputDefined();
  }
}, Mf = class Pf {
  constructor(t, r) {
    this.type = r.type, this.name = t, this.boundExpression = r;
  }
  static parse(t, r) {
    if (t.length !== 2 || typeof t[1] != "string") return r.error("'var' expression requires exactly one string literal argument.");
    let i = t[1];
    return r.scope.has(i) ? new Pf(i, r.scope.get(i)) : r.error(`Unknown variable "${i}". Make sure "${i}" has been bound in an enclosing "let" expression before using it.`, 1);
  }
  evaluate(t) {
    return this.boundExpression.evaluate(t);
  }
  eachChild() {
  }
  outputDefined() {
    return !1;
  }
}, _g = class Bf {
  constructor(t, r, i, n) {
    this.type = t, this.index = r, this.input = i, this.key = n;
  }
  static parse(t, r) {
    if (t.length !== 3) return r.error(`Expected 2 arguments, but found ${t.length - 1} instead.`);
    let i = r.parse(t[1], 1, F), n = r.parse(t[2], 2, Ye(r.expectedType || W));
    if (!i || !n) return null;
    let a = n.type;
    return new Bf(a.itemType, i, n, r.key);
  }
  evaluate(t) {
    let r = this.index.evaluate(t), i = this.input.evaluate(t);
    if (r < 0) throw new de(`Array index out of bounds: ${r} < 0.`, this.key);
    if (r >= i.length) throw new de(`Array index out of bounds: ${r} > ${i.length - 1}.`, this.key);
    if (r !== Math.floor(r)) throw new de(`Array index must be an integer, but found ${r} instead.`, this.key);
    return i[r];
  }
  eachChild(t) {
    t(this.index), t(this.input);
  }
  outputDefined() {
    return !1;
  }
}, Dg = class Lf {
  constructor(t, r, i) {
    this.needle = t, this.haystack = r, this.key = i, this.type = J;
  }
  static parse(t, r) {
    if (t.length !== 3) return r.error(`Expected 2 arguments, but found ${t.length - 1} instead.`);
    let i = r.parse(t[1], 1, W), n = r.parse(t[2], 2, W);
    return !i || !n ? null : iu(i.type, [J, Y, F, Bn, W]) ? new Lf(i, n, r.key) : r.error(`Expected first argument to be of type boolean, string, number or null, but found ${xe(i.type)} instead`);
  }
  evaluate(t) {
    let r = this.needle.evaluate(t), i = this.haystack.evaluate(t);
    if (!i) return !1;
    if (!kr(r, ["boolean", "string", "number", "null"])) throw new de(`Expected first argument to be of type boolean, string, number or null, but found ${xe(Ae(r))} instead.`, this.key);
    if (!kr(i, ["string", "array"])) throw new de(`Expected second argument to be of type array or string, but found ${xe(Ae(i))} instead.`, this.key);
    return i.indexOf(r) >= 0;
  }
  eachChild(t) {
    t(this.needle), t(this.haystack);
  }
  outputDefined() {
    return !0;
  }
}, Sg = class Vo {
  constructor(t, r, i, n) {
    this.needle = t, this.haystack = r, this.key = i, this.fromIndex = n, this.type = F;
  }
  static parse(t, r) {
    if (t.length <= 2 || t.length >= 5) return r.error(`Expected 2 or 3 arguments, but found ${t.length - 1} instead.`);
    let i = r.parse(t[1], 1, W), n = r.parse(t[2], 2, W);
    if (!i || !n) return null;
    if (!iu(i.type, [J, Y, F, Bn, W])) return r.error(`Expected first argument to be of type boolean, string, number or null, but found ${xe(i.type)} instead`);
    if (t.length === 4) {
      let a = r.parse(t[3], 3, F);
      return a ? new Vo(i, n, r.key, a) : null;
    }
    return new Vo(i, n, r.key);
  }
  evaluate(t) {
    let r = this.needle.evaluate(t), i = this.haystack.evaluate(t);
    if (!kr(r, ["boolean", "string", "number", "null"])) throw new de(`Expected first argument to be of type boolean, string, number or null, but found ${xe(Ae(r))} instead.`, this.key);
    let n;
    if (this.fromIndex && (n = this.fromIndex.evaluate(t)), kr(i, ["string"])) {
      let a = i.indexOf(r, n);
      return a === -1 ? -1 : [...i.slice(0, a)].length;
    }
    if (kr(i, ["array"])) return i.indexOf(r, n);
    throw new de(`Expected second argument to be of type array or string, but found ${xe(Ae(i))} instead.`, this.key);
  }
  eachChild(t) {
    t(this.needle), t(this.haystack), this.fromIndex && t(this.fromIndex);
  }
  outputDefined() {
    return !1;
  }
}, Ag = class zf {
  constructor(t, r, i, n, a, s) {
    this.inputType = t, this.type = r, this.input = i, this.cases = n, this.outputs = a, this.otherwise = s;
  }
  static parse(t, r) {
    if (t.length < 5) return r.error(`Expected at least 4 arguments, but found only ${t.length - 1}.`);
    if (t.length % 2 != 1) return r.error("Expected an even number of arguments.");
    let i, n;
    r.expectedType && r.expectedType.kind !== "value" && (n = r.expectedType);
    let a = {}, s = [];
    for (let u = 2; u < t.length - 1; u += 2) {
      let c = t[u], h = t[u + 1];
      Array.isArray(c) || (c = [c]);
      let p = r.concat(u);
      if (c.length === 0) return p.error("Expected at least one branch label.");
      for (let d of c) {
        if (typeof d != "number" && typeof d != "string") return p.error("Branch labels must be numbers or strings.");
        if (typeof d == "number" && Math.abs(d) > 2 ** 53 - 1) return p.error(`Branch labels must be integers no larger than ${2 ** 53 - 1}.`);
        if (typeof d == "number" && Math.floor(d) !== d) return p.error("Numeric branch labels must be integer values.");
        if (!i) i = Ae(d);
        else if (p.checkSubtype(i, Ae(d))) return null;
        if (a[String(d)] !== void 0) return p.error("Branch labels must be unique.");
        a[String(d)] = s.length;
      }
      let f = r.parse(h, u, n);
      if (!f) return null;
      n || (n = f.type), s.push(f);
    }
    let o = r.parse(t[1], 1, W);
    if (!o) return null;
    let l = r.parse(t[t.length - 1], t.length - 1, n);
    return !l || o.type.kind !== "value" && r.concat(1).checkSubtype(i, o.type) ? null : new zf(i, n, o, a, s, l);
  }
  evaluate(t) {
    let r = this.input.evaluate(t);
    return (Ae(r) === this.inputType && this.outputs[this.cases[r]] || this.otherwise).evaluate(t);
  }
  eachChild(t) {
    t(this.input), this.outputs.forEach(t), t(this.otherwise);
  }
  outputDefined() {
    return this.outputs.every((t) => t.outputDefined()) && this.otherwise.outputDefined();
  }
}, Eg = class Vf {
  constructor(t, r, i) {
    this.type = t, this.branches = r, this.otherwise = i;
  }
  static parse(t, r) {
    if (t.length < 4) return r.error(`Expected at least 3 arguments, but found only ${t.length - 1}.`);
    if (t.length % 2 != 0) return r.error("Expected an odd number of arguments.");
    let i;
    r.expectedType && r.expectedType.kind !== "value" && (i = r.expectedType);
    let n = [];
    for (let s = 1; s < t.length - 1; s += 2) {
      let o = r.parse(t[s], s, J);
      if (!o) return null;
      let l = r.parse(t[s + 1], s + 1, i);
      if (!l) return null;
      n.push([o, l]), i || (i = l.type);
    }
    let a = r.parse(t[t.length - 1], t.length - 1, i);
    if (!a) return null;
    if (!i) throw Error("Can't infer output type");
    return new Vf(i, n, a);
  }
  evaluate(t) {
    for (let [r, i] of this.branches) if (r.evaluate(t)) return i.evaluate(t);
    return this.otherwise.evaluate(t);
  }
  eachChild(t) {
    for (let [r, i] of this.branches) t(r), t(i);
    t(this.otherwise);
  }
  outputDefined() {
    return this.branches.every(([t, r]) => r.outputDefined()) && this.otherwise.outputDefined();
  }
}, Tg = class Oo {
  constructor(t, r, i, n, a) {
    this.type = t, this.input = r, this.beginIndex = i, this.key = n, this.endIndex = a;
  }
  static parse(t, r) {
    if (t.length <= 2 || t.length >= 5) return r.error(`Expected 2 or 3 arguments, but found ${t.length - 1} instead.`);
    let i = r.parse(t[1], 1, W), n = r.parse(t[2], 2, F);
    if (!i || !n) return null;
    if (!iu(i.type, [Ye(W), Y, W])) return r.error(`Expected first argument to be of type array or string, but found ${xe(i.type)} instead`);
    if (t.length === 4) {
      let a = r.parse(t[3], 3, F);
      return a ? new Oo(i.type, i, n, r.key, a) : null;
    }
    return new Oo(i.type, i, n, r.key);
  }
  evaluate(t) {
    let r = this.input.evaluate(t), i = this.beginIndex.evaluate(t), n;
    if (this.endIndex && (n = this.endIndex.evaluate(t)), kr(r, ["string"])) return [...r].slice(i, n).join("");
    if (kr(r, ["array"])) return r.slice(i, n);
    throw new de(`Expected first argument to be of type array or string, but found ${xe(Ae(r))} instead.`, this.key);
  }
  eachChild(t) {
    t(this.input), t(this.beginIndex), this.endIndex && t(this.endIndex);
  }
  outputDefined() {
    return !1;
  }
};
function hs(e, t, r) {
  let i = e.length - 1, n = 0, a = i, s = 0, o, l;
  for (; n <= a; ) if (s = Math.floor((n + a) / 2), o = e[s], l = e[s + 1], o <= t) {
    if (s === i || t < l) return s;
    n = s + 1;
  } else if (o > t) a = s - 1;
  else throw new de("Input is not a number.", r);
  return 0;
}
var lu = class Of {
  constructor(t, r, i, n) {
    this.type = t, this.input = r, this.key = n, this.labels = [], this.outputs = [];
    for (let [a, s] of i) this.labels.push(a), this.outputs.push(s);
  }
  static parse(t, r) {
    if (t.length - 1 < 4) return r.error(`Expected at least 4 arguments, but found only ${t.length - 1}.`);
    if ((t.length - 1) % 2 != 0) return r.error("Expected an even number of arguments.");
    let i = r.parse(t[1], 1, F);
    if (!i) return null;
    let n = [], a = null;
    r.expectedType && r.expectedType.kind !== "value" && (a = r.expectedType);
    for (let s = 1; s < t.length; s += 2) {
      let o = s === 1 ? -1 / 0 : t[s], l = t[s + 1], u = s, c = s + 1;
      if (typeof o != "number") return r.error('Input/output pairs for "step" expressions must be defined using literal numeric values (not computed expressions) for the input values.', u);
      if (n.length && n[n.length - 1][0] >= o) return r.error('Input/output pairs for "step" expressions must be arranged with input values in strictly ascending order.', u);
      let h = r.parse(l, c, a);
      if (!h) return null;
      a || (a = h.type), n.push([o, h]);
    }
    return new Of(a, i, n, r.key);
  }
  evaluate(t) {
    let r = this.labels, i = this.outputs;
    if (r.length === 1) return i[0].evaluate(t);
    let n = this.input.evaluate(t);
    if (n <= r[0]) return i[0].evaluate(t);
    let a = r.length;
    return n >= r[a - 1] ? i[a - 1].evaluate(t) : i[hs(r, n, this.key)].evaluate(t);
  }
  eachChild(t) {
    t(this.input);
    for (let r of this.outputs) t(r);
  }
  outputDefined() {
    return this.outputs.every((t) => t.outputDefined());
  }
};
function Ig(e, t, r, i) {
  let n = 3 * e, a = 3 * (r - e) - n, s = 1 - n - a, o = 3 * t, l = 3 * (i - t) - o, u = 1 - o - l;
  return function(c, h = 1e-6) {
    if (c <= 0) return 0;
    if (c >= 1) return 1;
    let p = c;
    for (let y = 0; y < 8; y++) {
      let m = ((s * p + a) * p + n) * p - c;
      if (Math.abs(m) < h) return ((u * p + l) * p + o) * p;
      let g = (3 * s * p + 2 * a) * p + n;
      if (Math.abs(g) < 1e-6) break;
      p -= m / g;
    }
    let f = 0, d = 1;
    p = c;
    for (let y = 0; y < 20; y++) {
      let m = ((s * p + a) * p + n) * p;
      if (Math.abs(m - c) < h) break;
      c > m ? f = p : d = p, p = (f + d) * 0.5;
    }
    return ((u * p + l) * p + o) * p;
  };
}
var dt = class Ro {
  constructor(t, r, i, n, a, s) {
    this.type = t, this.operator = r, this.interpolation = i, this.input = n, this.key = s, this.labels = [], this.outputs = [];
    for (let [o, l] of a) this.labels.push(o), this.outputs.push(l);
  }
  static interpolationFactor(t, r, i, n) {
    let a = 0;
    if (t.name === "exponential") a = oo(r, t.base, i, n);
    else if (t.name === "linear") a = oo(r, 1, i, n);
    else if (t.name === "cubic-bezier") {
      let s = t.controlPoints;
      a = Ig(s[0], s[1], s[2], s[3])(oo(r, 1, i, n));
    }
    return a;
  }
  static parse(t, r) {
    let [i, n, a, ...s] = t;
    if (!Array.isArray(n) || n.length === 0) return r.error("Expected an interpolation type expression.", 1);
    if (n[0] === "linear") n = { name: "linear" };
    else if (n[0] === "exponential") {
      let u = n[1];
      if (typeof u != "number") return r.error("Exponential interpolation requires a numeric base.", 1, 1);
      n = { name: "exponential", base: u };
    } else if (n[0] === "cubic-bezier") {
      let u = n.slice(1);
      if (u.length !== 4 || u.some((c) => typeof c != "number" || c < 0 || c > 1)) return r.error("Cubic bezier interpolation requires four numeric arguments with values between 0 and 1.", 1);
      n = { name: "cubic-bezier", controlPoints: u };
    } else return r.error(`Unknown interpolation type ${String(n[0])}`, 1, 0);
    if (t.length - 1 < 4) return r.error(`Expected at least 4 arguments, but found only ${t.length - 1}.`);
    if ((t.length - 1) % 2 != 0) return r.error("Expected an even number of arguments.");
    if (a = r.parse(a, 2, F), !a) return null;
    let o = [], l = null;
    (i === "interpolate-hcl" || i === "interpolate-lab" || i === "interpolate-oklch" || i === "interpolate-oklab") && r.expectedType != yn ? l = Dt : r.expectedType && r.expectedType.kind !== "value" && (l = r.expectedType);
    for (let u = 0; u < s.length; u += 2) {
      let c = s[u], h = s[u + 1], p = u + 3, f = u + 4;
      if (typeof c != "number") return r.error('Input/output pairs for "interpolate" expressions must be defined using literal numeric values (not computed expressions) for the input values.', p);
      if (o.length && o[o.length - 1][0] >= c) return r.error('Input/output pairs for "interpolate" expressions must be arranged with input values in strictly ascending order.', p);
      let d = r.parse(h, f, l);
      if (!d) return null;
      l || (l = d.type), o.push([c, d]);
    }
    return !or(l, F) && !or(l, ss) && !or(l, Dt) && !or(l, ls) && !or(l, us) && !or(l, yn) && !or(l, cs) && !or(l, Ye(F)) ? r.error(`Type ${xe(l)} is not interpolatable.`) : new Ro(l, i, n, a, o, r.key);
  }
  evaluate(t) {
    let r = this.labels, i = this.outputs;
    if (r.length === 1) return i[0].evaluate(t);
    let n = this.input.evaluate(t);
    if (n <= r[0]) return i[0].evaluate(t);
    let a = r.length;
    if (n >= r[a - 1]) return i[a - 1].evaluate(t);
    let s = hs(r, n, this.key), o = r[s], l = r[s + 1], u = Ro.interpolationFactor(this.interpolation, n, o, l), c = i[s].evaluate(t), h = i[s + 1].evaluate(t);
    switch (this.operator) {
      case "interpolate":
        switch (this.type.kind) {
          case "number":
            return Xe(c, h, u);
          case "color":
            return fe.interpolate(c, h, u);
          case "padding":
            return Vt.interpolate(c, h, u);
          case "colorArray":
            return tt.interpolate(c, h, u);
          case "numberArray":
            return Ot.interpolate(c, h, u);
          case "variableAnchorOffsetCollection":
            return Lt.interpolate(c, h, u, this.key);
          case "array":
            return di(c, h, u);
          case "projectionDefinition":
            return zr.interpolate(c, h, u);
        }
      case "interpolate-hcl":
        switch (this.type.kind) {
          case "color":
            return fe.interpolate(c, h, u, "hcl");
          case "colorArray":
            return tt.interpolate(c, h, u, "hcl");
        }
      case "interpolate-lab":
        switch (this.type.kind) {
          case "color":
            return fe.interpolate(c, h, u, "lab");
          case "colorArray":
            return tt.interpolate(c, h, u, "lab");
        }
      case "interpolate-oklch":
        switch (this.type.kind) {
          case "color":
            return fe.interpolate(c, h, u, "oklch");
          case "colorArray":
            return tt.interpolate(c, h, u, "oklch");
        }
      case "interpolate-oklab":
        switch (this.type.kind) {
          case "color":
            return fe.interpolate(c, h, u, "oklab");
          case "colorArray":
            return tt.interpolate(c, h, u, "oklab");
        }
    }
  }
  eachChild(t) {
    t(this.input);
    for (let r of this.outputs) t(r);
  }
  outputDefined() {
    return this.outputs.every((t) => t.outputDefined());
  }
};
function oo(e, t, r, i) {
  let n = i - r, a = e - r;
  return n === 0 ? 0 : t === 1 ? a / n : (t ** +a - 1) / (t ** +n - 1);
}
const Kt = { color: fe.interpolate, number: Xe, padding: Vt.interpolate, numberArray: Ot.interpolate, colorArray: tt.interpolate, variableAnchorOffsetCollection: Lt.interpolate, array: di };
var Rf = class $o {
  constructor(t, r) {
    this.type = t, this.args = r;
  }
  static parse(t, r) {
    if (t.length < 2) return r.error("Expected at least one argument.");
    let i = null, n = r.expectedType;
    n && n.kind !== "value" && (i = n);
    let a = [];
    for (let s of t.slice(1)) {
      let o = r.parse(s, 1 + a.length, i, void 0, { typeAnnotation: "omit" });
      if (!o) return null;
      i || (i = o.type), a.push(o);
    }
    if (!i) throw Error("No output type");
    return n && a.some((s) => mn(n, s.type)) ? new $o(W, a) : new $o(i, a);
  }
  evaluate(t) {
    let r = null, i = 0, n;
    for (let a of this.args) if (i++, r = a.evaluate(t), r && r instanceof zt && !r.available && (n || (n = r.name), r = null, i === this.args.length && (r = n)), r !== null) break;
    return r;
  }
  eachChild(t) {
    this.args.forEach(t);
  }
  outputDefined() {
    return this.args.every((t) => t.outputDefined());
  }
};
function Hc(e, t) {
  return e === "==" || e === "!=" ? t.kind === "boolean" || t.kind === "string" || t.kind === "number" || t.kind === "null" || t.kind === "value" : t.kind === "string" || t.kind === "number" || t.kind === "value";
}
function Cg(e, t, r) {
  return t === r;
}
function kg(e, t, r) {
  return t !== r;
}
function Fg(e, t, r) {
  return t < r;
}
function Mg(e, t, r) {
  return t > r;
}
function Pg(e, t, r) {
  return t <= r;
}
function Bg(e, t, r) {
  return t >= r;
}
function $f(e, t, r, i) {
  return i.compare(t, r) === 0;
}
function Lg(e, t, r, i) {
  return !$f(e, t, r, i);
}
function zg(e, t, r, i) {
  return i.compare(t, r) < 0;
}
function Vg(e, t, r, i) {
  return i.compare(t, r) > 0;
}
function Og(e, t, r, i) {
  return i.compare(t, r) <= 0;
}
function Rg(e, t, r, i) {
  return i.compare(t, r) >= 0;
}
function Si(e, t, r) {
  let i = e !== "==" && e !== "!=";
  return class Nf {
    constructor(a, s, o, l) {
      this.lhs = a, this.rhs = s, this.key = o, this.collator = l, this.type = J, this.hasUntypedArgument = a.type.kind === "value" || s.type.kind === "value";
    }
    static parse(a, s) {
      if (a.length !== 3 && a.length !== 4) return s.error("Expected two or three arguments.");
      let o = a[0], l = s.parse(a[1], 1, W);
      if (!l) return null;
      if (!Hc(o, l.type)) return s.concat(1).error(`"${o}" comparisons are not supported for type '${xe(l.type)}'.`);
      let u = s.parse(a[2], 2, W);
      if (!u) return null;
      if (!Hc(o, u.type)) return s.concat(2).error(`"${o}" comparisons are not supported for type '${xe(u.type)}'.`);
      if (l.type.kind !== u.type.kind && l.type.kind !== "value" && u.type.kind !== "value") return s.error(`Cannot compare types '${xe(l.type)}' and '${xe(u.type)}'.`);
      i && (l.type.kind === "value" && u.type.kind !== "value" ? l = new qt(u.type, [l], s.key) : l.type.kind !== "value" && u.type.kind === "value" && (u = new qt(l.type, [u], s.key)));
      let c = null;
      if (a.length === 4) {
        if (l.type.kind !== "string" && u.type.kind !== "string" && l.type.kind !== "value" && u.type.kind !== "value") return s.error("Cannot use collator to compare non-string types.");
        if (c = s.parse(a[3], 3, os), !c) return null;
      }
      return new Nf(l, u, s.key, c);
    }
    evaluate(a) {
      let s = this.lhs.evaluate(a), o = this.rhs.evaluate(a);
      if (i && this.hasUntypedArgument) {
        let l = Ae(s), u = Ae(o);
        if (l.kind !== u.kind || l.kind !== "string" && l.kind !== "number") throw new de(`Expected arguments for "${e}" to be (string, string) or (number, number), but found (${l.kind}, ${u.kind}) instead.`, this.key);
      }
      if (this.collator && !i && this.hasUntypedArgument) {
        let l = Ae(s), u = Ae(o);
        if (l.kind !== "string" || u.kind !== "string") return t(a, s, o);
      }
      return this.collator ? r(a, s, o, this.collator.evaluate(a)) : t(a, s, o);
    }
    eachChild(a) {
      a(this.lhs), a(this.rhs), this.collator && a(this.collator);
    }
    outputDefined() {
      return !0;
    }
  };
}
const $g = Si("==", Cg, $f), Ng = Si("!=", kg, Lg), Ug = Si("<", Fg, zg), jg = Si(">", Mg, Vg), qg = Si("<=", Pg, Og), Gg = Si(">=", Bg, Rg);
var Uf = class jf {
  constructor(t, r, i) {
    this.type = os, this.locale = i, this.caseSensitive = t, this.diacriticSensitive = r;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error("Expected one argument.");
    let i = t[1];
    if (typeof i != "object" || Array.isArray(i)) return r.error("Collator options argument must be an object.");
    let n = r.parse(i["case-sensitive"] !== void 0 && i["case-sensitive"], 1, J);
    if (!n) return null;
    let a = r.parse(i["diacritic-sensitive"] !== void 0 && i["diacritic-sensitive"], 1, J);
    if (!a) return null;
    let s = null;
    return i.locale && (s = r.parse(i.locale, 1, Y), !s) ? null : new jf(n, a, s);
  }
  evaluate(t) {
    return new ou(this.caseSensitive.evaluate(t), this.diacriticSensitive.evaluate(t), this.locale ? this.locale.evaluate(t) : null);
  }
  eachChild(t) {
    t(this.caseSensitive), t(this.diacriticSensitive), this.locale && t(this.locale);
  }
  outputDefined() {
    return !1;
  }
}, Xg = class qf {
  constructor(t, r, i, n, a, s) {
    this.type = Y, this.number = t, this.locale = r, this.currency = i, this.unit = n, this.minFractionDigits = a, this.maxFractionDigits = s;
  }
  static parse(t, r) {
    if (t.length !== 3) return r.error("Expected two arguments.");
    let i = r.parse(t[1], 1, F);
    if (!i) return null;
    let n = t[2];
    if (typeof n != "object" || Array.isArray(n)) return r.error("NumberFormat options argument must be an object.");
    let a = null;
    if (n.locale && (a = r.parse(n.locale, 1, Y), !a)) return null;
    let s = null;
    if (n.currency && (s = r.parse(n.currency, 1, Y), !s)) return null;
    let o = null;
    if (n.unit && (o = r.parse(n.unit, 1, Y), !o)) return null;
    if (s && o) return r.error("NumberFormat options `currency` and `unit` are mutually exclusive");
    let l = null;
    if (n["min-fraction-digits"] && (l = r.parse(n["min-fraction-digits"], 1, F), !l)) return null;
    let u = null;
    return n["max-fraction-digits"] && (u = r.parse(n["max-fraction-digits"], 1, F), !u) ? null : new qf(i, a, s, o, l, u);
  }
  evaluate(t) {
    return new Intl.NumberFormat(this.locale ? this.locale.evaluate(t) : [], { style: this.currency ? "currency" : this.unit ? "unit" : "decimal", currency: this.currency ? this.currency.evaluate(t) : void 0, unit: this.unit ? this.unit.evaluate(t) : void 0, minimumFractionDigits: this.minFractionDigits ? this.minFractionDigits.evaluate(t) : void 0, maximumFractionDigits: this.maxFractionDigits ? this.maxFractionDigits.evaluate(t) : void 0 }).format(this.number.evaluate(t));
  }
  eachChild(t) {
    t(this.number), this.locale && t(this.locale), this.currency && t(this.currency), this.unit && t(this.unit), this.minFractionDigits && t(this.minFractionDigits), this.maxFractionDigits && t(this.maxFractionDigits);
  }
  outputDefined() {
    return !1;
  }
}, Gf = class Xf {
  constructor(t) {
    this.type = Ln, this.sections = t;
  }
  static parse(t, r) {
    if (t.length < 2) return r.error("Expected at least one argument.");
    let i = t[1];
    if (!Array.isArray(i) && typeof i == "object") return r.error("First argument must be an image or text section.");
    let n = [], a = !1;
    for (let s = 1; s <= t.length - 1; ++s) {
      let o = t[s];
      if (a && typeof o == "object" && !Array.isArray(o)) {
        a = !1;
        let l = null;
        if (o["font-scale"] && (l = r.parse(o["font-scale"], 1, F), !l)) return null;
        let u = null;
        if (o["text-font"] && (u = r.parse(o["text-font"], 1, Ye(Y)), !u)) return null;
        let c = null;
        if (o["text-color"] && (c = r.parse(o["text-color"], 1, Dt), !c)) return null;
        let h = null;
        if (o["vertical-align"]) {
          if (typeof o["vertical-align"] == "string" && !vg.includes(o["vertical-align"])) return r.error(`'vertical-align' must be one of: 'bottom', 'center', 'top' but found '${o["vertical-align"]}' instead.`);
          if (h = r.parse(o["vertical-align"], 1, Y), !h) return null;
        }
        let p = n[n.length - 1];
        p.scale = l, p.font = u, p.textColor = c, p.verticalAlign = h;
      } else {
        let l = r.parse(t[s], 1, W);
        if (!l) return null;
        let u = l.type.kind;
        if (u !== "string" && u !== "value" && u !== "null" && u !== "resolvedImage") return r.error("Formatted text type must be 'string', 'value', 'image' or 'null'.");
        a = !0, n.push({ content: l, scale: null, font: null, textColor: null, verticalAlign: null });
      }
    }
    return new Xf(n);
  }
  evaluate(t) {
    return new Ht(this.sections.map((r) => {
      let i = r.content.evaluate(t);
      return Ae(i) === zn ? new zo("", i, null, null, null, r.verticalAlign ? r.verticalAlign.evaluate(t) : null) : new zo(ln(i), null, r.scale ? r.scale.evaluate(t) : null, r.font ? r.font.evaluate(t).join(",") : null, r.textColor ? r.textColor.evaluate(t) : null, r.verticalAlign ? r.verticalAlign.evaluate(t) : null);
    }));
  }
  eachChild(t) {
    for (let r of this.sections) t(r.content), r.scale && t(r.scale), r.font && t(r.font), r.textColor && t(r.textColor), r.verticalAlign && t(r.verticalAlign);
  }
  outputDefined() {
    return !1;
  }
}, Yg = class Yf {
  constructor(t) {
    this.type = zn, this.input = t;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error("Expected two arguments.");
    let i = r.parse(t[1], 1, Y);
    return i ? new Yf(i) : r.error("No image name provided.");
  }
  evaluate(t) {
    let r = this.input.evaluate(t), i = zt.fromString(r);
    return i && t.availableImages && (i.available = t.availableImages.indexOf(r) > -1), i;
  }
  eachChild(t) {
    t(this.input);
  }
  outputDefined() {
    return !1;
  }
}, Wg = class Wf {
  constructor(t, r) {
    this.input = t, this.key = r, this.type = F;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`Expected 1 argument, but found ${t.length - 1} instead.`);
    let i = r.parse(t[1], 1);
    return i ? i.type.kind !== "array" && i.type.kind !== "string" && i.type.kind !== "value" ? r.error(`Expected argument of type string or array, but found ${xe(i.type)} instead.`) : new Wf(i, r.key) : null;
  }
  evaluate(t) {
    let r = this.input.evaluate(t);
    if (typeof r == "string") return [...r].length;
    if (Array.isArray(r)) return r.length;
    throw new de(`Expected value to be of type string or array, but found ${xe(Ae(r))} instead.`, this.key);
  }
  eachChild(t) {
    t(this.input);
  }
  outputDefined() {
    return !1;
  }
};
const Pt = 8192;
function Zg(e, t) {
  let r = Hg(e[0]), i = Jg(e[1]), n = 2 ** t.z;
  return [Math.round(r * n * Pt), Math.round(i * n * Pt)];
}
function uu(e, t) {
  let r = 2 ** t.z, i = (e[0] / Pt + t.x) / r, n = (e[1] / Pt + t.y) / r;
  return [Kg(i), Qg(n)];
}
function Hg(e) {
  return (180 + e) / 360;
}
function Kg(e) {
  return e * 360 - 180;
}
function Jg(e) {
  return (180 - 180 / Math.PI * Math.log(Math.tan(Math.PI / 4 + e * Math.PI / 360))) / 360;
}
function Qg(e) {
  return 360 / Math.PI * Math.atan(Math.exp((180 - e * 360) * Math.PI / 180)) - 90;
}
function Vn(e, t) {
  e[0] = Math.min(e[0], t[0]), e[1] = Math.min(e[1], t[1]), e[2] = Math.max(e[2], t[0]), e[3] = Math.max(e[3], t[1]);
}
function gn(e, t) {
  return !(e[0] <= t[0] || e[2] >= t[2] || e[1] <= t[1] || e[3] >= t[3]);
}
function e0(e, t, r) {
  return t[1] > e[1] != r[1] > e[1] && e[0] < (r[0] - t[0]) * (e[1] - t[1]) / (r[1] - t[1]) + t[0];
}
function t0(e, t, r) {
  let i = e[0] - t[0], n = e[1] - t[1], a = e[0] - r[0], s = e[1] - r[1];
  return i * s - a * n === 0 && i * a <= 0 && n * s <= 0;
}
function ps(e, t, r, i) {
  let n = [t[0] - e[0], t[1] - e[1]];
  return a0([i[0] - r[0], i[1] - r[1]], n) !== 0 && !!(Kc(e, t, r, i) && Kc(r, i, e, t));
}
function r0(e, t, r) {
  for (let i of r) for (let n = 0; n < i.length - 1; ++n) if (ps(e, t, i[n], i[n + 1])) return !0;
  return !1;
}
function Ai(e, t, r = !1) {
  let i = !1;
  for (let n of t) for (let a = 0; a < n.length - 1; a++) {
    if (t0(e, n[a], n[a + 1])) return r;
    e0(e, n[a], n[a + 1]) && (i = !i);
  }
  return i;
}
function i0(e, t) {
  for (let r of t) if (Ai(e, r)) return !0;
  return !1;
}
function Zf(e, t) {
  for (let r of e) if (!Ai(r, t)) return !1;
  for (let r = 0; r < e.length - 1; ++r) if (r0(e[r], e[r + 1], t)) return !1;
  return !0;
}
function n0(e, t) {
  for (let r of t) if (Zf(e, r)) return !0;
  return !1;
}
function a0(e, t) {
  return e[0] * t[1] - e[1] * t[0];
}
function Kc(e, t, r, i) {
  let n = e[0] - r[0], a = e[1] - r[1], s = t[0] - r[0], o = t[1] - r[1], l = i[0] - r[0], u = i[1] - r[1], c = n * u - l * a, h = s * u - l * o;
  return c > 0 && h < 0 || c < 0 && h > 0;
}
function cu(e, t, r) {
  let i = [];
  for (let n = 0; n < e.length; n++) {
    let a = [];
    for (let s = 0; s < e[n].length; s++) {
      let o = Zg(e[n][s], r);
      Vn(t, o), a.push(o);
    }
    i.push(a);
  }
  return i;
}
function Hf(e, t, r) {
  let i = [];
  for (let n = 0; n < e.length; n++) {
    let a = cu(e[n], t, r);
    i.push(a);
  }
  return i;
}
function Kf(e, t, r, i) {
  if (e[0] < r[0] || e[0] > r[2]) {
    let n = i * 0.5, a = e[0] - r[0] > n ? -i : r[0] - e[0] > n ? i : 0;
    a === 0 && (a = e[0] - r[2] > n ? -i : r[2] - e[0] > n ? i : 0), e[0] += a;
  }
  Vn(t, e);
}
function s0(e) {
  e[0] = e[1] = 1 / 0, e[2] = e[3] = -1 / 0;
}
function Jc(e, t, r, i) {
  let n = 2 ** i.z * Pt, a = [i.x * Pt, i.y * Pt], s = [];
  for (let o of e) for (let l of o) {
    let u = [l.x + a[0], l.y + a[1]];
    Kf(u, t, r, n), s.push(u);
  }
  return s;
}
function Qc(e, t, r, i) {
  let n = 2 ** i.z * Pt, a = [i.x * Pt, i.y * Pt], s = [];
  for (let o of e) {
    let l = [];
    for (let u of o) {
      let c = [u.x + a[0], u.y + a[1]];
      Vn(t, c), l.push(c);
    }
    s.push(l);
  }
  if (t[2] - t[0] <= n / 2) {
    s0(t);
    for (let o of s) for (let l of o) Kf(l, t, r, n);
  }
  return s;
}
function o0(e, t) {
  let r = [1 / 0, 1 / 0, -1 / 0, -1 / 0], i = [1 / 0, 1 / 0, -1 / 0, -1 / 0], n = e.canonicalID();
  if (t.type === "Polygon") {
    let a = cu(t.coordinates, i, n), s = Jc(e.geometry(), r, i, n);
    if (!gn(r, i)) return !1;
    for (let o of s) if (!Ai(o, a)) return !1;
  }
  if (t.type === "MultiPolygon") {
    let a = Hf(t.coordinates, i, n), s = Jc(e.geometry(), r, i, n);
    if (!gn(r, i)) return !1;
    for (let o of s) if (!i0(o, a)) return !1;
  }
  return !0;
}
function l0(e, t) {
  let r = [1 / 0, 1 / 0, -1 / 0, -1 / 0], i = [1 / 0, 1 / 0, -1 / 0, -1 / 0], n = e.canonicalID();
  if (t.type === "Polygon") {
    let a = cu(t.coordinates, i, n), s = Qc(e.geometry(), r, i, n);
    if (!gn(r, i)) return !1;
    for (let o of s) if (!Zf(o, a)) return !1;
  }
  if (t.type === "MultiPolygon") {
    let a = Hf(t.coordinates, i, n), s = Qc(e.geometry(), r, i, n);
    if (!gn(r, i)) return !1;
    for (let o of s) if (!n0(o, a)) return !1;
  }
  return !0;
}
var hu = class Ca {
  constructor(t, r) {
    this.type = J, this.geojson = t, this.geometries = r;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`'within' expression requires exactly one argument, but found ${t.length - 1} instead.`);
    if (yi(t[1])) {
      let i = t[1];
      if (i.type === "FeatureCollection") {
        let n = [];
        for (let a of i.features) {
          let { type: s, coordinates: o } = a.geometry;
          s === "Polygon" && n.push(o), s === "MultiPolygon" && n.push(...o);
        }
        if (n.length) return new Ca(i, { type: "MultiPolygon", coordinates: n });
      } else if (i.type === "Feature") {
        let n = i.geometry.type;
        if (n === "Polygon" || n === "MultiPolygon") return new Ca(i, i.geometry);
      } else if (i.type === "Polygon" || i.type === "MultiPolygon") return new Ca(i, i);
    }
    return r.error("'within' expression requires valid geojson object that contains polygon geometry type.");
  }
  evaluate(t) {
    if (t.geometry() != null && t.canonicalID() != null) {
      if (t.geometryType() === "Point") return o0(t, this.geometries);
      if (t.geometryType() === "LineString") return l0(t, this.geometries);
    }
    return !1;
  }
  eachChild() {
  }
  outputDefined() {
    return !0;
  }
}, Jf = class {
  constructor(e = [], t = (r, i) => r < i ? -1 : +(r > i)) {
    if (this.data = e, this.length = this.data.length, this.compare = t, this.length > 0) for (let r = (this.length >> 1) - 1; r >= 0; r--) this._down(r);
  }
  push(e) {
    this.data.push(e), this._up(this.length++);
  }
  pop() {
    if (this.length === 0) return;
    let e = this.data[0], t = this.data.pop();
    return --this.length > 0 && (this.data[0] = t, this._down(0)), e;
  }
  peek() {
    return this.data[0];
  }
  _up(e) {
    let { data: t, compare: r } = this, i = t[e];
    for (; e > 0; ) {
      let n = e - 1 >> 1, a = t[n];
      if (r(i, a) >= 0) break;
      t[e] = a, e = n;
    }
    t[e] = i;
  }
  _down(e) {
    let { data: t, compare: r } = this, i = this.length >> 1, n = t[e];
    for (; e < i; ) {
      let a = (e << 1) + 1, s = a + 1;
      if (s < this.length && r(t[s], t[a]) < 0 && (a = s), r(t[a], n) >= 0) break;
      t[e] = t[a], e = a;
    }
    t[e] = n;
  }
};
function Qf(e, t, r = 0, i = e.length - 1, n = u0) {
  for (; i > r; ) {
    if (i - r > 600) {
      let l = i - r + 1, u = t - r + 1, c = Math.log(l), h = 0.5 * Math.exp(2 * c / 3), p = 0.5 * Math.sqrt(c * h * (l - h) / l) * (u - l / 2 < 0 ? -1 : 1);
      Qf(e, t, Math.max(r, Math.floor(t - u * h / l + p)), Math.min(i, Math.floor(t + (l - u) * h / l + p)), n);
    }
    let a = e[t], s = r, o = i;
    for (ji(e, r, t), n(e[i], a) > 0 && ji(e, r, i); s < o; ) {
      for (ji(e, s, o), s++, o--; n(e[s], a) < 0; ) s++;
      for (; n(e[o], a) > 0; ) o--;
    }
    n(e[r], a) === 0 ? ji(e, r, o) : (o++, ji(e, o, i)), o <= t && (r = o + 1), t <= o && (i = o - 1);
  }
}
function ji(e, t, r) {
  let i = e[t];
  e[t] = e[r], e[r] = i;
}
function u0(e, t) {
  return e < t ? -1 : +(e > t);
}
function fs(e, t) {
  if (e.length <= 1) return [e];
  let r = [], i, n;
  for (let a of e) {
    let s = h0(a);
    s !== 0 && (a.area = Math.abs(s), n === void 0 && (n = s < 0), n === s < 0 ? (i && r.push(i), i = [a]) : i.push(a));
  }
  if (i && r.push(i), t > 1) for (let a = 0; a < r.length; a++) r[a].length <= t || (Qf(r[a], t, 1, r[a].length - 1, c0), r[a] = r[a].slice(0, t));
  return r;
}
function c0(e, t) {
  return t.area - e.area;
}
function h0(e) {
  let t = 0;
  for (let r = 0, i = e.length, n = i - 1, a, s; r < i; n = r++) a = e[r], s = e[n], t += (s.x - a.x) * (a.y + s.y);
  return t;
}
const eh = Math.PI / 180;
var pu = class {
  constructor(e) {
    let t = eh * 6378.137 * 1e3, r = Math.cos(e * eh), i = 1 / (1 - 0.0066943799901413165 * (1 - r * r)), n = Math.sqrt(i);
    this.kx = t * n * r, this.ky = t * n * i * 0.9933056200098587;
  }
  distance(e, t) {
    let r = this.wrap(e[0] - t[0]) * this.kx, i = (e[1] - t[1]) * this.ky;
    return Math.sqrt(r * r + i * i);
  }
  pointOnLine(e, t) {
    let r = 1 / 0, i, n, a, s;
    for (let o = 0; o < e.length - 1; o++) {
      let l = e[o][0], u = e[o][1], c = this.wrap(e[o + 1][0] - l) * this.kx, h = (e[o + 1][1] - u) * this.ky, p = 0;
      (c !== 0 || h !== 0) && (p = (this.wrap(t[0] - l) * this.kx * c + (t[1] - u) * this.ky * h) / (c * c + h * h), p > 1 ? (l = e[o + 1][0], u = e[o + 1][1]) : p > 0 && (l += c / this.kx * p, u += h / this.ky * p)), c = this.wrap(t[0] - l) * this.kx, h = (t[1] - u) * this.ky;
      let f = c * c + h * h;
      f < r && (r = f, i = l, n = u, a = o, s = p);
    }
    return { point: [i, n], index: a, t: Math.max(0, Math.min(1, s)) };
  }
  wrap(e) {
    for (; e < -180; ) e += 360;
    for (; e > 180; ) e -= 360;
    return e;
  }
};
function ed(e, t) {
  return t[0] - e[0];
}
function Ra(e) {
  return e[1] - e[0] + 1;
}
function Jt(e, t) {
  return e[1] >= e[0] && e[1] < t;
}
function No(e, t) {
  if (e[0] > e[1]) return [null, null];
  let r = Ra(e);
  if (t) {
    if (r === 2) return [e, null];
    let n = Math.floor(r / 2);
    return [[e[0], e[0] + n], [e[0] + n, e[1]]];
  }
  if (r === 1) return [e, null];
  let i = Math.floor(r / 2) - 1;
  return [[e[0], e[0] + i], [e[0] + i + 1, e[1]]];
}
function Uo(e, t) {
  if (!Jt(t, e.length)) return [1 / 0, 1 / 0, -1 / 0, -1 / 0];
  let r = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
  for (let i = t[0]; i <= t[1]; ++i) Vn(r, e[i]);
  return r;
}
function jo(e) {
  let t = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
  for (let r of e) for (let i of r) Vn(t, i);
  return t;
}
function th(e) {
  return e[0] !== -1 / 0 && e[1] !== -1 / 0 && e[2] !== 1 / 0 && e[3] !== 1 / 0;
}
function fu(e, t, r) {
  if (!th(e) || !th(t)) return NaN;
  let i = 0, n = 0;
  return e[2] < t[0] && (i = t[0] - e[2]), e[0] > t[2] && (i = e[0] - t[2]), e[1] > t[3] && (n = e[1] - t[3]), e[3] < t[1] && (n = t[1] - e[3]), r.distance([0, 0], [i, n]);
}
function Er(e, t, r) {
  let i = r.pointOnLine(t, e);
  return r.distance(e, i.point);
}
function du(e, t, r, i, n) {
  let a = Math.min(Er(e, [r, i], n), Er(t, [r, i], n)), s = Math.min(Er(r, [e, t], n), Er(i, [e, t], n));
  return Math.min(a, s);
}
function p0(e, t, r, i, n) {
  if (!(Jt(t, e.length) && Jt(i, r.length))) return 1 / 0;
  let a = 1 / 0;
  for (let s = t[0]; s < t[1]; ++s) {
    let o = e[s], l = e[s + 1];
    for (let u = i[0]; u < i[1]; ++u) {
      let c = r[u], h = r[u + 1];
      if (ps(o, l, c, h)) return 0;
      a = Math.min(a, du(o, l, c, h, n));
    }
  }
  return a;
}
function f0(e, t, r, i, n) {
  if (!(Jt(t, e.length) && Jt(i, r.length))) return NaN;
  let a = 1 / 0;
  for (let s = t[0]; s <= t[1]; ++s) for (let o = i[0]; o <= i[1]; ++o) if (a = Math.min(a, n.distance(e[s], r[o])), a === 0) return a;
  return a;
}
function d0(e, t, r) {
  if (Ai(e, t, !0)) return 0;
  let i = 1 / 0;
  for (let n of t) {
    let a = n[0], s = n[n.length - 1];
    if (a !== s && (i = Math.min(i, Er(e, [s, a], r)), i === 0)) return i;
    let o = r.pointOnLine(n, e);
    if (i = Math.min(i, r.distance(e, o.point)), i === 0) return i;
  }
  return i;
}
function y0(e, t, r, i) {
  if (!Jt(t, e.length)) return NaN;
  for (let a = t[0]; a <= t[1]; ++a) if (Ai(e[a], r, !0)) return 0;
  let n = 1 / 0;
  for (let a = t[0]; a < t[1]; ++a) {
    let s = e[a], o = e[a + 1];
    for (let l of r) for (let u = 0, c = l.length, h = c - 1; u < c; h = u++) {
      let p = l[h], f = l[u];
      if (ps(s, o, p, f)) return 0;
      n = Math.min(n, du(s, o, p, f, i));
    }
  }
  return n;
}
function rh(e, t) {
  for (let r of e) for (let i of r) if (Ai(i, t, !0)) return !0;
  return !1;
}
function m0(e, t, r, i = 1 / 0) {
  let n = jo(e), a = jo(t);
  if (i !== 1 / 0 && fu(n, a, r) >= i) return i;
  if (gn(n, a)) {
    if (rh(e, t)) return 0;
  } else if (rh(t, e)) return 0;
  let s = 1 / 0;
  for (let o of e) for (let l = 0, u = o.length, c = u - 1; l < u; c = l++) {
    let h = o[c], p = o[l];
    for (let f of t) for (let d = 0, y = f.length, m = y - 1; d < y; m = d++) {
      let g = f[m], v = f[d];
      if (ps(h, p, g, v)) return 0;
      s = Math.min(s, du(h, p, g, v, r));
    }
  }
  return s;
}
function ih(e, t, r, i, n, a) {
  if (!a) return;
  let s = fu(Uo(i, a), n, r);
  s < t && e.push([s, a, [0, 0]]);
}
function ha(e, t, r, i, n, a, s) {
  if (!a || !s) return;
  let o = fu(Uo(i, a), Uo(n, s), r);
  o < t && e.push([o, a, s]);
}
function $a(e, t, r, i, n = 1 / 0) {
  let a = Math.min(i.distance(e[0], r[0][0]), n);
  if (a === 0) return a;
  let s = new Jf([[0, [0, e.length - 1], [0, 0]]], ed), o = jo(r);
  for (; s.length > 0; ) {
    let l = s.pop();
    if (l[0] >= a) continue;
    let u = l[1], c = t ? 50 : 100;
    if (Ra(u) <= c) {
      if (!Jt(u, e.length)) return NaN;
      if (t) {
        let h = y0(e, u, r, i);
        if (isNaN(h) || h === 0) return h;
        a = Math.min(a, h);
      } else for (let h = u[0]; h <= u[1]; ++h) {
        let p = d0(e[h], r, i);
        if (a = Math.min(a, p), a === 0) return 0;
      }
    } else {
      let h = No(u, t);
      ih(s, a, i, e, o, h[0]), ih(s, a, i, e, o, h[1]);
    }
  }
  return a;
}
function Na(e, t, r, i, n, a = 1 / 0) {
  let s = Math.min(a, n.distance(e[0], r[0]));
  if (s === 0) return s;
  let o = new Jf([[0, [0, e.length - 1], [0, r.length - 1]]], ed);
  for (; o.length > 0; ) {
    let l = o.pop();
    if (l[0] >= s) continue;
    let u = l[1], c = l[2], h = t ? 50 : 100, p = i ? 50 : 100;
    if (Ra(u) <= h && Ra(c) <= p) {
      if (!Jt(u, e.length) && Jt(c, r.length)) return NaN;
      let f;
      if (t && i) f = p0(e, u, r, c, n), s = Math.min(s, f);
      else if (t && !i) {
        let d = e.slice(u[0], u[1] + 1);
        for (let y = c[0]; y <= c[1]; ++y) if (f = Er(r[y], d, n), s = Math.min(s, f), s === 0) return s;
      } else if (!t && i) {
        let d = r.slice(c[0], c[1] + 1);
        for (let y = u[0]; y <= u[1]; ++y) if (f = Er(e[y], d, n), s = Math.min(s, f), s === 0) return s;
      } else f = f0(e, u, r, c, n), s = Math.min(s, f);
    } else {
      let f = No(u, t), d = No(c, i);
      ha(o, s, n, e, r, f[0], d[0]), ha(o, s, n, e, r, f[0], d[1]), ha(o, s, n, e, r, f[1], d[0]), ha(o, s, n, e, r, f[1], d[1]);
    }
  }
  return s;
}
function g0(e, t) {
  let r = e.geometry(), i = r.flat().map((s) => uu([s.x, s.y], e.canonical));
  if (r.length === 0) return NaN;
  let n = new pu(i[0][1]), a = 1 / 0;
  for (let s of t) {
    switch (s.type) {
      case "Point":
        a = Math.min(a, Na(i, !1, [s.coordinates], !1, n, a));
        break;
      case "LineString":
        a = Math.min(a, Na(i, !1, s.coordinates, !0, n, a));
        break;
      case "Polygon":
        a = Math.min(a, $a(i, !1, s.coordinates, n, a));
    }
    if (a === 0) return a;
  }
  return a;
}
function x0(e, t) {
  let r = e.geometry(), i = r.flat().map((s) => uu([s.x, s.y], e.canonical));
  if (r.length === 0) return NaN;
  let n = new pu(i[0][1]), a = 1 / 0;
  for (let s of t) {
    switch (s.type) {
      case "Point":
        a = Math.min(a, Na(i, !0, [s.coordinates], !1, n, a));
        break;
      case "LineString":
        a = Math.min(a, Na(i, !0, s.coordinates, !0, n, a));
        break;
      case "Polygon":
        a = Math.min(a, $a(i, !0, s.coordinates, n, a));
    }
    if (a === 0) return a;
  }
  return a;
}
function v0(e, t) {
  let r = e.geometry();
  if (r.length === 0 || r[0].length === 0) return NaN;
  let i = fs(r, 0).map((s) => s.map((o) => o.map((l) => uu([l.x, l.y], e.canonical)))), n = new pu(i[0][0][0][1]), a = 1 / 0;
  for (let s of t) for (let o of i) {
    switch (s.type) {
      case "Point":
        a = Math.min(a, $a([s.coordinates], !1, o, n, a));
        break;
      case "LineString":
        a = Math.min(a, $a(s.coordinates, !0, o, n, a));
        break;
      case "Polygon":
        a = Math.min(a, m0(o, s.coordinates, n, a));
    }
    if (a === 0) return a;
  }
  return a;
}
function lo(e) {
  return e.type === "MultiPolygon" ? e.coordinates.map((t) => ({ type: "Polygon", coordinates: t })) : e.type === "MultiLineString" ? e.coordinates.map((t) => ({ type: "LineString", coordinates: t })) : e.type === "MultiPoint" ? e.coordinates.map((t) => ({ type: "Point", coordinates: t })) : [e];
}
var yu = class ka {
  constructor(t, r) {
    this.type = F, this.geojson = t, this.geometries = r;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`'distance' expression requires exactly one argument, but found ${t.length - 1} instead.`);
    if (yi(t[1])) {
      let i = t[1];
      if (i.type === "FeatureCollection") return new ka(i, i.features.map((n) => lo(n.geometry)).flat());
      if (i.type === "Feature") return new ka(i, lo(i.geometry));
      if ("type" in i && "coordinates" in i) return new ka(i, lo(i));
    }
    return r.error("'distance' expression requires valid geojson object that contains polygon geometry type.");
  }
  evaluate(t) {
    if (t.geometry() != null && t.canonicalID() != null) {
      if (t.geometryType() === "Point") return g0(t, this.geometries);
      if (t.geometryType() === "LineString") return x0(t, this.geometries);
      if (t.geometryType() === "Polygon") return v0(t, this.geometries);
    }
    return NaN;
  }
  eachChild() {
  }
  outputDefined() {
    return !0;
  }
}, b0 = class td {
  constructor(t) {
    let r = null;
    for (let i of t) if (!r) r = i.type;
    else {
      if (r === i.type) continue;
      r = W;
      break;
    }
    this.type = Ye(r ?? W, t.length), this.arr = t;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`'semiliteral' expression requires exactly one argument, but found ${t.length - 1} instead.`);
    if (!yi(t[1])) return r.error(`invalid value of type "${typeof t[1]}"`);
    let i = t[1], n = Ae(i);
    if (n.kind === "array") {
      let a = i, s = r.concat(1), o = [];
      for (let l = 0; l < a.length; l++) {
        let u = s.parse(a[l], l, W);
        if (!u) return null;
        o.push(u);
      }
      return new td(o);
    }
    return new mi(n, i);
  }
  evaluate(t) {
    return this.arr.map((r) => r.evaluate(t));
  }
  eachChild(t) {
    this.arr.forEach(t);
  }
  outputDefined() {
    return this.arr.every((t) => t.outputDefined());
  }
}, mu = class rd {
  constructor(t) {
    this.key = t, this.type = W;
  }
  static parse(t, r) {
    if (t.length !== 2) return r.error(`Expected 1 argument, but found ${t.length - 1} instead.`);
    let i = t[1];
    return i == null ? r.error("Global state property must be defined.") : typeof i == "string" ? new rd(i) : r.error(`Global state property must be string, but found ${typeof t[1]} instead.`);
  }
  evaluate(t) {
    var i;
    let r = (i = t.globals) == null ? void 0 : i.globalState;
    return !r || Object.keys(r).length === 0 ? null : on(r, this.key) ?? null;
  }
  eachChild() {
  }
  outputDefined() {
    return !1;
  }
};
const ai = { "==": $g, "!=": Ng, ">": jg, "<": Ug, ">=": Gg, "<=": qg, array: qt, at: _g, boolean: qt, case: Eg, coalesce: Rf, collator: Uf, format: Gf, image: Yg, in: Dg, "index-of": Sg, interpolate: dt, "interpolate-hcl": dt, "interpolate-lab": dt, "interpolate-oklch": dt, "interpolate-oklab": dt, length: Wg, let: kf, literal: mi, match: Ag, number: qt, "number-format": Xg, object: qt, semiliteral: b0, slice: Tg, step: lu, string: qt, "to-boolean": ri, "to-color": ri, "to-number": ri, "to-string": ri, var: Mf, within: hu, distance: yu, "global-state": mu };
var Vr = class Qi {
  constructor(t, r, i, n, a) {
    this.name = t, this.type = r, this._evaluate = i, this.args = n, this.key = a;
  }
  evaluate(t) {
    return this._evaluate(t, this.args, this.key);
  }
  eachChild(t) {
    this.args.forEach(t);
  }
  outputDefined() {
    return !1;
  }
  static parse(t, r) {
    let i = t[0], n = Qi.definitions[i];
    if (!n) return r.error(`Unknown expression "${i}". If you wanted a literal array, use ["literal", [...]].`, 0);
    let a = Array.isArray(n) ? n[0] : n.type, s = Array.isArray(n) ? [[n[1], n[2]]] : n.overloads, o = s.filter(([u]) => !Array.isArray(u) || u.length === t.length - 1), l = null;
    for (let [u, c] of o) {
      l = new If(r.registry, Ua, r.path, null, r.scope);
      let h = [], p = !1;
      for (let f = 1; f < t.length; f++) {
        let d = t[f], y = Array.isArray(u) ? u[f - 1] : u.type, m = l.parse(d, 1 + h.length, y);
        if (!m) {
          p = !0;
          break;
        }
        h.push(m);
      }
      if (!p)
        if (Array.isArray(u) && u.length !== h.length) l.error(`Expected ${u.length} arguments, but found ${h.length} instead.`);
        else {
          for (let f = 0; f < h.length; f++) {
            let d = Array.isArray(u) ? u[f] : u.type, y = h[f];
            l.concat(f + 1).checkSubtype(d, y.type);
          }
          if (l.errors.length === 0) return new Qi(i, a, c, h, r.key);
        }
    }
    if (o.length === 1) r.errors.push(...l.errors);
    else {
      let u = (o.length ? o : s).map(([h]) => _0(h)).join(" | "), c = [];
      for (let h = 1; h < t.length; h++) {
        let p = r.parse(t[h], 1 + c.length);
        if (!p) return null;
        c.push(xe(p.type));
      }
      r.error(`Expected arguments of type ${u}, but found (${c.join(", ")}) instead.`);
    }
    return null;
  }
  static register(t, r) {
    Qi.definitions = r;
    for (let i in r) t[i] = Qi;
  }
};
function nh(e, [t, r, i, n], a) {
  t = t.evaluate(e), r = r.evaluate(e), i = i.evaluate(e);
  let s = n ? n.evaluate(e) : 1, o = Df(t, r, i, s);
  if (o) throw new de(o, a);
  return new fe(t / 255, r / 255, i / 255, s, !1);
}
function ah(e, t) {
  return e in t && t[e] !== void 0;
}
function uo(e, t) {
  let r = t[e];
  return r === void 0 ? null : r;
}
function w0(e, t, r, i) {
  for (; r <= i; ) {
    let n = r + i >> 1;
    if (t[n] === e) return !0;
    t[n] > e ? i = n - 1 : r = n + 1;
  }
  return !1;
}
function wr(e) {
  return { type: e };
}
Vr.register(ai, { error: [Hm, [Y], (e, [t], r) => {
  throw new de(t.evaluate(e), r);
}], typeof: [Y, [W], (e, [t]) => xe(Ae(t.evaluate(e)))], "to-rgba": [Ye(F, 4), [Dt], (e, [t]) => {
  let [r, i, n, a] = t.evaluate(e).rgb;
  return [r * 255, i * 255, n * 255, a];
}], rgb: [Dt, [F, F, F], nh], rgba: [Dt, [F, F, F, F], nh], has: { type: J, overloads: [[[Y], (e, [t]) => ah(t.evaluate(e), e.properties())], [[Y, Cr], (e, [t, r]) => ah(t.evaluate(e), r.evaluate(e))]] }, get: { type: W, overloads: [[[Y], (e, [t]) => uo(t.evaluate(e), e.properties())], [[Y, Cr], (e, [t, r]) => uo(t.evaluate(e), r.evaluate(e))]] }, "feature-state": [W, [Y], (e, [t]) => uo(t.evaluate(e), e.featureState || {})], properties: [Cr, [], (e) => e.properties()], "geometry-type": [Y, [], (e) => e.geometryType()], id: [W, [], (e) => e.id()], zoom: [F, [], (e) => e.globals.zoom], "heatmap-density": [F, [], (e) => e.globals.heatmapDensity || 0], elevation: [F, [], (e) => e.globals.elevation || 0], "line-progress": [F, [], (e) => e.globals.lineProgress || 0], accumulated: [W, [], (e) => e.globals.accumulated === void 0 ? null : e.globals.accumulated], "+": [F, wr(F), (e, t) => {
  let r = 0;
  for (let i of t) r += i.evaluate(e);
  return r;
}], "*": [F, wr(F), (e, t) => {
  let r = 1;
  for (let i of t) r *= i.evaluate(e);
  return r;
}], "-": { type: F, overloads: [[[F, F], (e, [t, r]) => t.evaluate(e) - r.evaluate(e)], [[F], (e, [t]) => -t.evaluate(e)]] }, "/": [F, [F, F], (e, [t, r]) => t.evaluate(e) / r.evaluate(e)], "%": [F, [F, F], (e, [t, r]) => t.evaluate(e) % r.evaluate(e)], ln2: [F, [], () => Math.LN2], pi: [F, [], () => Math.PI], e: [F, [], () => Math.E], "^": [F, [F, F], (e, [t, r]) => t.evaluate(e) ** +r.evaluate(e)], sqrt: [F, [F], (e, [t]) => Math.sqrt(t.evaluate(e))], log10: [F, [F], (e, [t]) => Math.log(t.evaluate(e)) / Math.LN10], ln: [F, [F], (e, [t]) => Math.log(t.evaluate(e))], log2: [F, [F], (e, [t]) => Math.log(t.evaluate(e)) / Math.LN2], sin: [F, [F], (e, [t]) => Math.sin(t.evaluate(e))], cos: [F, [F], (e, [t]) => Math.cos(t.evaluate(e))], tan: [F, [F], (e, [t]) => Math.tan(t.evaluate(e))], asin: [F, [F], (e, [t]) => Math.asin(t.evaluate(e))], acos: [F, [F], (e, [t]) => Math.acos(t.evaluate(e))], atan: [F, [F], (e, [t]) => Math.atan(t.evaluate(e))], min: [F, wr(F), (e, t) => Math.min(...t.map((r) => r.evaluate(e)))], max: [F, wr(F), (e, t) => Math.max(...t.map((r) => r.evaluate(e)))], abs: [F, [F], (e, [t]) => Math.abs(t.evaluate(e))], round: [F, [F], (e, [t]) => {
  let r = t.evaluate(e);
  return r < 0 ? -Math.round(-r) : Math.round(r);
}], floor: [F, [F], (e, [t]) => Math.floor(t.evaluate(e))], ceil: [F, [F], (e, [t]) => Math.ceil(t.evaluate(e))], "filter-==": [J, [Y, W], (e, [t, r]) => e.properties()[t.value] === r.value], "filter-id-==": [J, [W], (e, [t]) => e.id() === t.value], "filter-type-==": [J, [Y], (e, [t]) => e.geometryType() === t.value], "filter-<": [J, [Y, W], (e, [t, r]) => {
  let i = e.properties()[t.value], n = r.value;
  return typeof i == typeof n && i < n;
}], "filter-id-<": [J, [W], (e, [t]) => {
  let r = e.id(), i = t.value;
  return typeof r == typeof i && r < i;
}], "filter->": [J, [Y, W], (e, [t, r]) => {
  let i = e.properties()[t.value], n = r.value;
  return typeof i == typeof n && i > n;
}], "filter-id->": [J, [W], (e, [t]) => {
  let r = e.id(), i = t.value;
  return typeof r == typeof i && r > i;
}], "filter-<=": [J, [Y, W], (e, [t, r]) => {
  let i = e.properties()[t.value], n = r.value;
  return typeof i == typeof n && i <= n;
}], "filter-id-<=": [J, [W], (e, [t]) => {
  let r = e.id(), i = t.value;
  return typeof r == typeof i && r <= i;
}], "filter->=": [J, [Y, W], (e, [t, r]) => {
  let i = e.properties()[t.value], n = r.value;
  return typeof i == typeof n && i >= n;
}], "filter-id->=": [J, [W], (e, [t]) => {
  let r = e.id(), i = t.value;
  return typeof r == typeof i && r >= i;
}], "filter-has": [J, [W], (e, [t]) => {
  let r = t.value, i = e.properties();
  return r in i && i[r] !== void 0;
}], "filter-has-id": [J, [], (e) => e.id() !== null && e.id() !== void 0], "filter-type-in": [J, [Ye(Y)], (e, [t]) => t.value.indexOf(e.geometryType()) >= 0], "filter-id-in": [J, [Ye(W)], (e, [t]) => t.value.indexOf(e.id()) >= 0], "filter-in-small": [J, [Y, Ye(W)], (e, [t, r]) => r.value.indexOf(e.properties()[t.value]) >= 0], "filter-in-large": [J, [Y, Ye(W)], (e, [t, r]) => w0(e.properties()[t.value], r.value, 0, r.value.length - 1)], all: { type: J, overloads: [[[J, J], (e, [t, r]) => t.evaluate(e) && r.evaluate(e)], [wr(J), (e, t) => {
  for (let r of t) if (!r.evaluate(e)) return !1;
  return !0;
}]] }, any: { type: J, overloads: [[[J, J], (e, [t, r]) => t.evaluate(e) || r.evaluate(e)], [wr(J), (e, t) => {
  for (let r of t) if (r.evaluate(e)) return !0;
  return !1;
}]] }, "!": [J, [J], (e, [t]) => !t.evaluate(e)], "is-supported-script": [J, [Y], (e, [t]) => {
  let r = e.globals && e.globals.isSupportedScript;
  return !r || r(t.evaluate(e));
}], upcase: [Y, [Y], (e, [t]) => t.evaluate(e).toUpperCase()], downcase: [Y, [Y], (e, [t]) => t.evaluate(e).toLowerCase()], concat: [Y, wr(W), (e, t) => t.map((r) => ln(r.evaluate(e))).join("")], split: [Ye(Y), [Y, Y], (e, [t, r]) => t.evaluate(e).split(r.evaluate(e))], join: [Y, [Ye(Y), Y], (e, [t, r]) => t.evaluate(e).join(r.evaluate(e))], "resolved-locale": [Y, [os], (e, [t]) => t.evaluate(e).resolvedLocale()] });
function _0(e) {
  return Array.isArray(e) ? `(${e.map(xe).join(", ")})` : `(${xe(e.type)}...)`;
}
function Ua(e) {
  if (e instanceof Mf) return Ua(e.boundExpression);
  if (e instanceof Vr && e.name === "error" || e instanceof Uf || e instanceof hu || e instanceof yu || e instanceof mu) return !1;
  let t = e instanceof ri || e instanceof qt, r = !0;
  return e.eachChild((i) => {
    r && (r = t ? Ua(i) : i instanceof mi);
  }), r ? ds(e) && ys(e, ["zoom", "heatmap-density", "elevation", "line-progress", "accumulated", "is-supported-script"]) : !1;
}
function ds(e) {
  if (e instanceof Vr && (e.name === "get" && e.args.length === 1 || e.name === "feature-state" || e.name === "has" && e.args.length === 1 || e.name === "properties" || e.name === "geometry-type" || e.name === "id" || /^filter-/.test(e.name)) || e instanceof hu || e instanceof yu) return !1;
  let t = !0;
  return e.eachChild((r) => {
    t && !ds(r) && (t = !1);
  }), t;
}
function xn(e) {
  if (e instanceof Vr && e.name === "feature-state") return !1;
  let t = !0;
  return e.eachChild((r) => {
    t && !xn(r) && (t = !1);
  }), t;
}
function ys(e, t) {
  if (e instanceof Vr && t.indexOf(e.name) >= 0) return !1;
  let r = !0;
  return e.eachChild((i) => {
    r && !ys(i, t) && (r = !1);
  }), r;
}
function qo(e) {
  return { result: "success", value: e };
}
function Kr(e) {
  return { result: "error", value: e };
}
function gi(e) {
  return e["property-type"] === "data-driven" || e["property-type"] === "cross-faded-data-driven";
}
function id(e) {
  return !!e.expression && e.expression.parameters.indexOf("zoom") > -1;
}
function gu(e) {
  return !!e.expression && e.expression.interpolated;
}
const xu = /^(.*)-transition$/;
function vn(e, ...t) {
  for (let r of t) for (let i in r) e[i] = r[i];
  return e;
}
function K(e) {
  return e instanceof Number ? "number" : e instanceof String ? "string" : e instanceof Boolean ? "boolean" : Array.isArray(e) ? "array" : e === null ? "null" : typeof e;
}
function ms(e) {
  return typeof e == "object" && !!e && !Array.isArray(e) && Ae(e) === Cr;
}
function D0(e) {
  return e;
}
function S0(e) {
  switch (e.type) {
    case "color":
      return fe.parse;
    case "padding":
      return Vt.parse;
    case "numberArray":
      return Ot.parse;
    case "colorArray":
      return tt.parse;
    default:
      return null;
  }
}
function A0(e) {
  switch (e) {
    case "exponential":
      return ad;
    case "interval":
      return T0;
    case "categorical":
      return E0;
    case "identity":
      return I0;
    default:
      throw Error(`Unknown function type "${e}"`);
  }
}
function nd(e, t) {
  let r = e.stops && typeof e.stops[0][0] == "object", i = r || e.property !== void 0, n = r || !i, a = e.type || (gu(t) ? "exponential" : "interval"), s = S0(t);
  if (s && (e = vn({}, e), e.stops && (e.stops = e.stops.map((c) => [c[0], s(c[1])])), e.default ? e.default = s(e.default) : e.default = s(t.default)), e.colorSpace && !xg(e.colorSpace)) throw Error(`Unknown color space: "${e.colorSpace}"`);
  let o = A0(a), l, u;
  if (a === "categorical") {
    l = /* @__PURE__ */ Object.create(null);
    for (let c of e.stops) l[c[0]] = c[1];
    u = typeof e.stops[0][0];
  }
  if (r) {
    let c = {}, h = [];
    for (let d = 0; d < e.stops.length; d++) {
      let y = e.stops[d], m = y[0].zoom;
      c[m] === void 0 && (c[m] = { zoom: m, type: e.type, property: e.property, default: e.default, colorSpace: e.colorSpace, stops: [] }, h.push(m)), c[m].stops.push([y[0].value, y[1]]);
    }
    let p = [];
    for (let d of h) p.push([c[d].zoom, nd(c[d], t)]);
    let f = { name: "linear" };
    return { kind: "composite", interpolationType: f, interpolationFactor: dt.interpolationFactor.bind(void 0, f), zoomStops: p.map((d) => d[0]), evaluate({ zoom: d }, y) {
      return ad({ stops: p, base: e.base, colorSpace: e.colorSpace }, t, d).evaluate(d, y);
    } };
  }
  if (n) {
    let c = a === "exponential" ? { name: "exponential", base: e.base === void 0 ? 1 : e.base } : null;
    return { kind: "camera", interpolationType: c, interpolationFactor: dt.interpolationFactor.bind(void 0, c), zoomStops: e.stops.map((h) => h[0]), evaluate: ({ zoom: h }) => o(e, t, h, l, u) };
  }
  return { kind: "source", evaluate(c, h) {
    let p = h && h.properties ? h.properties[e.property] : void 0;
    return p === void 0 ? On(e.default, t.default) : o(e, t, p, l, u);
  } };
}
function On(e, t, r) {
  if (e !== void 0) return e;
  if (t !== void 0) return t;
  if (r !== void 0) return r;
}
function E0(e, t, r, i, n) {
  return On(typeof r === n ? i[r] : void 0, e.default, t.default);
}
function T0(e, t, r) {
  if (K(r) !== "number") return On(e.default, t.default);
  let i = e.stops.length;
  if (i === 1 || r <= e.stops[0][0]) return e.stops[0][1];
  if (r >= e.stops[i - 1][0]) return e.stops[i - 1][1];
  let n = hs(e.stops.map((a) => a[0]), r, "");
  return e.stops[n][1];
}
function ad(e, t, r) {
  let i = e.base === void 0 ? 1 : e.base;
  if (K(r) !== "number") return On(e.default, t.default);
  let n = e.stops.length;
  if (n === 1 || r <= e.stops[0][0]) return e.stops[0][1];
  if (r >= e.stops[n - 1][0]) return e.stops[n - 1][1];
  let a = hs(e.stops.map((c) => c[0]), r, ""), s = C0(r, i, e.stops[a][0], e.stops[a + 1][0]), o = e.stops[a][1], l = e.stops[a + 1][1], u = Kt[t.type] || D0;
  return typeof o.evaluate == "function" ? { evaluate(...c) {
    let h = o.evaluate.apply(void 0, c), p = l.evaluate.apply(void 0, c);
    if (h !== void 0 && p !== void 0) return u(h, p, s, e.colorSpace);
  } } : u(o, l, s, e.colorSpace);
}
function I0(e, t, r) {
  switch (t.type) {
    case "color":
      r = fe.parse(r);
      break;
    case "formatted":
      r = Ht.fromString(r.toString());
      break;
    case "resolvedImage":
      r = zt.fromString(r.toString());
      break;
    case "padding":
      r = Vt.parse(r);
      break;
    case "colorArray":
      r = tt.parse(r);
      break;
    case "numberArray":
      r = Ot.parse(r);
      break;
    default:
      K(r) === t.type || t.type === "enum" && t.values[r] || (r = void 0);
  }
  return On(r, e.default, t.default);
}
function C0(e, t, r, i) {
  let n = i - r, a = e - r;
  return n === 0 ? 0 : t === 1 ? a / n : (t ** +a - 1) / (t ** +n - 1);
}
var vu = class {
  constructor(e, t, r, i) {
    this.expression = e, this._warningHistory = {}, this._evaluator = new Tf(), this._defaultValue = r ? hd(r) : null, this._enumValues = r && r.type === "enum" ? r.values : null, this._globalState = i, this._rootKey = t;
  }
  evaluateWithoutErrorHandling(e, t, r, i, n, a) {
    return this._globalState && (e = xi(e, this._globalState)), this._evaluator.globals = e, this._evaluator.feature = t, this._evaluator.featureState = r, this._evaluator.canonical = i, this._evaluator.availableImages = n || null, this._evaluator.formattedSection = a, this.expression.evaluate(this._evaluator);
  }
  evaluate(e, t, r, i, n, a) {
    this._globalState && (e = xi(e, this._globalState)), this._evaluator.globals = e, this._evaluator.feature = t || null, this._evaluator.featureState = r || null, this._evaluator.canonical = i, this._evaluator.availableImages = n || null, this._evaluator.formattedSection = a || null;
    try {
      let s = this.expression.evaluate(this._evaluator);
      if (s == null || typeof s == "number" && s !== s) return this._defaultValue;
      if (this._enumValues && !(s in this._enumValues)) throw new de(`Expected value to be one of ${Object.keys(this._enumValues).map((o) => JSON.stringify(o)).join(", ")}, but found ${JSON.stringify(s)} instead.`, "");
      return s;
    } catch (s) {
      let o = s instanceof de ? s.path : "", l = `${o}|${s.message}`;
      return this._warningHistory[l] || (this._warningHistory[l] = !0, typeof console < "u" && console.warn(sd(this._rootKey, o, s.message, this._defaultValue))), this._defaultValue;
    }
  }
};
function sd(e, t, r, i) {
  return `${e}${t}: ${r}${i == null ? "" : ` Falling back to ${String(i)}.`}`;
}
function od(e) {
  if (!e) throw Error('rootKey must identify the location of the expression in the style JSON, e.g. "layers[3].paint.line-width".');
}
function gs(e) {
  return Array.isArray(e) && e.length > 0 && typeof e[0] == "string" && e[0] in ai;
}
function Mr(e, t, r, i) {
  od(t);
  let n = new If(ai, Ua, [], r ? M0(r) : void 0), a = n.parse(e, void 0, void 0, void 0, r && r.type === "string" ? { typeAnnotation: "coerce" } : void 0);
  return a ? qo(new vu(a, t, r, i)) : Kr(n.errors);
}
var bn = class {
  constructor(e, t, r) {
    this.kind = e, this._styleExpression = t, this.isStateDependent = e !== "constant" && !xn(t.expression), this.globalStateRefs = Rn(t.expression), this._globalState = r;
  }
  evaluateWithoutErrorHandling(e, t, r, i, n, a) {
    return this._globalState && (e = xi(e, this._globalState)), this._styleExpression.evaluateWithoutErrorHandling(e, t, r, i, n, a);
  }
  evaluate(e, t, r, i, n, a) {
    return this._globalState && (e = xi(e, this._globalState)), this._styleExpression.evaluate(e, t, r, i, n, a);
  }
}, ja = class {
  constructor(e, t, r, i, n) {
    this.kind = e, this.zoomStops = r, this._styleExpression = t, this.isStateDependent = e !== "camera" && !xn(t.expression), this.globalStateRefs = Rn(t.expression), this.interpolationType = i, this._globalState = n;
  }
  evaluateWithoutErrorHandling(e, t, r, i, n, a) {
    return this._globalState && (e = xi(e, this._globalState)), this._styleExpression.evaluateWithoutErrorHandling(e, t, r, i, n, a);
  }
  evaluate(e, t, r, i, n, a) {
    return this._globalState && (e = xi(e, this._globalState)), this._styleExpression.evaluate(e, t, r, i, n, a);
  }
  interpolationFactor(e, t, r) {
    return this.interpolationType ? dt.interpolationFactor(this.interpolationType, e, t, r) : 0;
  }
};
function k0(e) {
  return e._styleExpression !== void 0;
}
function ld(e, t, r, i) {
  let n = Mr(e, t, r, i);
  if (n.result === "error") return n;
  let a = n.value.expression, s = ds(a);
  if (!s && !gi(r)) return Kr([new kt("", "data expressions not supported")]);
  let o = ys(a, ["zoom"]);
  if (!o && !id(r)) return Kr([new kt("", "zoom expressions not supported")]);
  let l = Fa(a);
  if (!l && !o) return Kr([new kt("", '"zoom" expression may only be used as input to a top-level "step" or "interpolate" expression.')]);
  if (l instanceof kt) return Kr([l]);
  if (l instanceof dt && !gu(r)) return Kr([new kt("", '"interpolate" expressions cannot be used with this property')]);
  if (!l) return qo(s ? new bn("constant", n.value, i) : new bn("source", n.value, i));
  let u = l instanceof dt ? l.interpolation : void 0;
  return qo(s ? new ja("camera", n.value, l.labels, u, i) : new ja("composite", n.value, l.labels, u, i));
}
var ud = class cd {
  constructor(t, r, i) {
    this.isStateDependent = !1, this.globalStateRefs = /* @__PURE__ */ new Set(), this._globalState = null, od(r), this._parameters = t, this._specification = i, this._rootKey = r, this._defaultValue = hd(i), this._warningHistory = {};
    let n = nd(this._parameters, this._specification);
    this.kind = n.kind, this.interpolationFactor = n.interpolationFactor, this.zoomStops = n.zoomStops, this.interpolationType = n.interpolationType, this._innerEvaluate = n.evaluate;
  }
  evaluate(t, r) {
    try {
      return this._innerEvaluate(t, r);
    } catch (i) {
      let n = i instanceof Error ? i.message : String(i), a = `|${n}`;
      return this._warningHistory[a] || (this._warningHistory[a] = !0, typeof console < "u" && console.warn(sd(this._rootKey, "", n, this._defaultValue))), this._defaultValue;
    }
  }
  static deserialize(t) {
    return new cd(t._parameters, t._rootKey, t._specification);
  }
  static serialize(t) {
    return { _parameters: t._parameters, _specification: t._specification, _rootKey: t._rootKey };
  }
};
function F0(e, t, r, i) {
  if (ms(e)) return new ud(e, t, r);
  if (gs(e)) {
    let n = ld(e, t, r, i);
    if (n.result === "error") throw Error(n.value.map((a) => `${a.key}: ${a.message}`).join(", "));
    return n.value;
  }
  {
    let n = e;
    return r.type === "color" && typeof e == "string" ? n = fe.parse(e) : r.type === "padding" && (typeof e == "number" || Array.isArray(e)) ? n = Vt.parse(e) : r.type === "numberArray" && (typeof e == "number" || Array.isArray(e)) ? n = Ot.parse(e) : r.type === "colorArray" && (typeof e == "string" || Array.isArray(e)) ? n = tt.parse(e) : r.type === "variableAnchorOffsetCollection" && Array.isArray(e) ? n = Lt.parse(e) : r.type === "projectionDefinition" && typeof e == "string" && (n = zr.parse(e)), { globalStateRefs: /* @__PURE__ */ new Set(), _globalState: null, kind: "constant", evaluate: () => n };
  }
}
function Fa(e, t = /* @__PURE__ */ new Map()) {
  if (t.has(e)) return t.get(e);
  let r = null;
  if (e instanceof kf) r = Fa(e.result, t);
  else if (e instanceof Rf) {
    for (let i of e.args) if (r = Fa(i, t), r) break;
  } else (e instanceof lu || e instanceof dt) && e.input instanceof Vr && e.input.name === "zoom" && (r = e);
  return r instanceof kt ? (t.set(e, r), r) : (e.eachChild((i) => {
    let n = Fa(i, t);
    n instanceof kt ? r = n : !r && n ? r = new kt("", '"zoom" expression may only be used as input to a top-level "step" or "interpolate" expression.') : r && n && r !== n && (r = new kt("", 'Only one zoom-based "step" or "interpolate" subexpression may be used in an expression.'));
  }), t.set(e, r), r);
}
function Rn(e, t = /* @__PURE__ */ new Set()) {
  return e instanceof mu && t.add(e.key), e.eachChild((r) => {
    Rn(r, t);
  }), t;
}
function M0(e) {
  let t = { color: Dt, string: Y, number: F, enum: Y, boolean: J, formatted: Ln, padding: ls, numberArray: us, colorArray: yn, projectionDefinition: ss, resolvedImage: zn, variableAnchorOffsetCollection: cs };
  return e.type === "array" ? Ye(t[e.value] || W, e.length) : t[e.type];
}
function hd(e) {
  if (e.type === "color" && ms(e.default)) return new fe(0, 0, 0, 0);
  switch (e.type) {
    case "color":
      return fe.parse(e.default) || null;
    case "padding":
      return Vt.parse(e.default) || null;
    case "numberArray":
      return Ot.parse(e.default) || null;
    case "colorArray":
      return tt.parse(e.default) || null;
    case "variableAnchorOffsetCollection":
      return Lt.parse(e.default) || null;
    case "projectionDefinition":
      return zr.parse(e.default) || null;
    default:
      return e.default === void 0 ? null : e.default;
  }
}
function xi(e, t) {
  let { zoom: r, heatmapDensity: i, elevation: n, lineProgress: a, isSupportedScript: s, accumulated: o } = e ?? {};
  return { zoom: r, heatmapDensity: i, elevation: n, lineProgress: a, isSupportedScript: s, accumulated: o, globalState: t };
}
function P0(e) {
  let t = !1;
  for (let r of e) {
    let i = pd(r);
    if (i === "expression") return "expression";
    i === "legacy" && (t = !0);
  }
  return t ? "legacy" : "neutral";
}
function pd(e) {
  if (typeof e == "boolean") return "neutral";
  if (!Array.isArray(e) || e.length === 0) return "legacy";
  switch (e[0]) {
    case "has":
      return e.length < 2 || e[1] === "$id" || e[1] === "$type" ? "legacy" : e.length === 2 ? "neutral" : "expression";
    case "in":
      return e.length >= 3 && (typeof e[1] != "string" || Array.isArray(e[2])) ? "expression" : "legacy";
    case "!in":
    case "!has":
      return "legacy";
    case "==":
    case "!=":
    case ">":
    case ">=":
    case "<":
    case "<=":
      return e.length !== 3 || Array.isArray(e[1]) || Array.isArray(e[2]) ? "expression" : "legacy";
    case "none":
      return "legacy";
    case "any":
    case "all":
      return P0(e.slice(1));
    default:
      return "expression";
  }
}
function bu(e) {
  return pd(e) !== "legacy";
}
function sh(e) {
  return e === "$type" ? ["geometry-type"] : e === "$id" ? ["id"] : ["get", e];
}
function B0(e) {
  switch (e[0]) {
    case "==":
    case "!=":
    case "<":
    case "<=":
    case ">":
    case ">=":
      return e.length !== 3 || typeof e[1] != "string" ? null : [e[0], sh(e[1]), e[2]];
    case "in":
    case "!in": {
      if (e.length < 2 || typeof e[1] != "string") return null;
      let t = ["in", sh(e[1]), ["literal", e.slice(2)]];
      return e[0] === "!in" ? ["!", t] : t;
    }
    case "has":
    case "!has": {
      if (e.length !== 2 || typeof e[1] != "string" || e[1] === "$type" || e[1] === "$id") return null;
      let t = ["has", e[1]];
      return e[0] === "!has" ? ["!", t] : t;
    }
    default:
      return null;
  }
}
function fd(e) {
  if ((e[0] === "<" || e[0] === "<=" || e[0] === ">" || e[0] === ">=") && e[1] === "$type") return `"$type" cannot be use with operator "${e[0]}"`;
  let t = B0(e);
  return t ? `Mixing deprecated filter syntax with expression syntax is not supported. Replace ${JSON.stringify(e)} with ${JSON.stringify(t)}.` : `Mixing deprecated filter syntax with expression syntax is not supported. Convert ${JSON.stringify(e)} to expression syntax.`;
}
function co(e, t, r) {
  let i = r[e];
  return Array.isArray(i) ? bu(i) ? wu(i, t.concat(e)) : { path: t.concat(e), legacyFilter: i } : null;
}
function wu(e, t = []) {
  if (!Array.isArray(e) || e.length < 1) return null;
  switch (e[0]) {
    case "all":
    case "any":
    case "none":
      for (let r = 1; r < e.length; r++) {
        let i = co(r, t, e);
        if (i) return i;
      }
      break;
    case "!": {
      let r = co(1, t, e);
      if (r) return r;
      break;
    }
    case "case":
      for (let r = 1; r < e.length - 1; r += 2) {
        let i = co(r, t, e);
        if (i) return i;
      }
  }
  return null;
}
function L0(e, t) {
  let r = wu(e);
  if (!r || typeof console > "u") return;
  let i = r.path.map((n) => `[${n}]`).join("");
  console.warn(`${t}${i}: ${fd(r.legacyFilter)}`);
}
const z0 = { type: "boolean", default: !1, transition: !1, "property-type": "data-driven", expression: { interpolated: !1, parameters: ["zoom", "feature"] } };
function wn(e, t, r) {
  if (e == null) return { filter: () => !0, needGeometry: !1, getGlobalStateRefs: () => /* @__PURE__ */ new Set() };
  bu(e) ? L0(e, t) : e = qa(e);
  let i = Mr(e, t, z0, r);
  if (i.result === "error") throw Error(i.value.map((n) => `${n.key}: ${n.message}`).join(", "));
  return { filter: (n, a, s) => i.value.evaluate(n, a, {}, s), needGeometry: dd(e), getGlobalStateRefs: () => Rn(i.value.expression) };
}
function V0(e, t) {
  return e < t ? -1 : +(e > t);
}
function dd(e) {
  if (!Array.isArray(e)) return !1;
  if (e[0] === "within" || e[0] === "distance") return !0;
  for (let t = 1; t < e.length; t++) if (dd(e[t])) return !0;
  return !1;
}
function qa(e) {
  if (!e) return !0;
  let t = e[0];
  return e.length <= 1 ? t !== "any" : t === "==" ? ho(e[1], e[2], "==") : t === "!=" ? pa(ho(e[1], e[2], "==")) : t === "<" || t === ">" || t === "<=" || t === ">=" ? ho(e[1], e[2], t) : t === "any" ? O0(e.slice(1)) : t === "all" ? ["all"].concat(e.slice(1).map(qa)) : t === "none" ? ["all"].concat(e.slice(1).map(qa).map(pa)) : t === "in" ? oh(e[1], e.slice(2)) : t === "!in" ? pa(oh(e[1], e.slice(2))) : t === "has" ? lh(e[1]) : t !== "!has" || pa(lh(e[1]));
}
function ho(e, t, r) {
  switch (e) {
    case "$type":
      return [`filter-type-${r}`, t];
    case "$id":
      return [`filter-id-${r}`, t];
    default:
      return [`filter-${r}`, e, t];
  }
}
function O0(e) {
  return ["any"].concat(e.map(qa));
}
function oh(e, t) {
  if (t.length === 0) return !1;
  switch (e) {
    case "$type":
      return ["filter-type-in", ["literal", t]];
    case "$id":
      return ["filter-id-in", ["literal", t]];
    default:
      return t.length > 200 && !t.some((r) => typeof r != typeof t[0]) ? ["filter-in-large", e, ["literal", t.sort(V0)]] : ["filter-in-small", e, ["literal", t]];
  }
}
function lh(e) {
  switch (e) {
    case "$type":
      return !0;
    case "$id":
      return ["filter-has-id"];
    default:
      return ["filter-has", e];
  }
}
function pa(e) {
  return ["!", e];
}
function Go(e) {
  let t = typeof e;
  if (t === "number" || t === "boolean" || t === "string" || e == null) return JSON.stringify(e);
  if (Array.isArray(e)) {
    let n = "[";
    for (let a of e) n += `${Go(a)},`;
    return `${n}]`;
  }
  let r = Object.keys(e).sort(), i = "{";
  for (let n = 0; n < r.length; n++) i += `${JSON.stringify(r[n])}:${Go(e[r[n]])},`;
  return `${i}}`;
}
function R0(e) {
  let t = "";
  for (let r of Wm) t += `/${Go(e[r])}`;
  return t;
}
function $0(e, t) {
  let r = {};
  for (let n = 0; n < e.length; n++) {
    let a = t && t[e[n].id] || R0(e[n]);
    t && (t[e[n].id] = a);
    let s = r[a];
    s || (s = r[a] = []), s.push(e[n]);
  }
  let i = [];
  for (let n in r) i.push(r[n]);
  return i;
}
function yd(e) {
  let t = e.key, r = e.value;
  return r ? [new I(t, r, "constants have been deprecated as of v8")] : [];
}
function Se(e) {
  return e instanceof Number || e instanceof String || e instanceof Boolean ? e.valueOf() : e;
}
function Pr(e) {
  if (Array.isArray(e)) return e.map(Pr);
  if (e instanceof Object && !(e instanceof Number || e instanceof String || e instanceof Boolean)) {
    let t = {};
    for (let r in e) t[r] = Pr(e[r]);
    return t;
  }
  return Se(e);
}
function lt(e) {
  let t = e.key, r = e.value, i = e.valueSpec || {}, n = e.objectElementValidators || {}, a = e.style, s = e.styleSpec, o = e.validateSpec, l = [], u = K(r);
  if (u !== "object") return [new I(t, r, `object expected, ${u} found`)];
  for (let c in r) {
    let h = c.split(".")[0], p = on(i, h) || i["*"], f;
    if (on(n, h)) f = n[h];
    else if (on(i, h)) {
      if (r[c] === void 0) continue;
      f = o;
    } else if (n["*"]) f = n["*"];
    else if (i["*"]) f = o;
    else {
      l.push(new I(t, r[c], `unknown property "${c}"`));
      continue;
    }
    l = l.concat(f({ key: (t && `${t}.`) + c, value: r[c], valueSpec: p, style: a, styleSpec: s, object: r, objectKey: c, validateSpec: o }, r));
  }
  for (let c in i) n[c] || i[c].required && i[c].default === void 0 && r[c] === void 0 && l.push(new I(t, r, `missing required property "${c}"`));
  return l;
}
function _u(e) {
  let t = e.value, r = e.valueSpec, i = e.validateSpec, n = e.style, a = e.styleSpec, s = e.key, o = e.arrayElementValidator || i;
  if (K(t) !== "array") return [new I(s, t, `array expected, ${K(t)} found`)];
  if (r.length && t.length !== r.length) return [new I(s, t, `array length ${r.length} expected, length ${t.length} found`)];
  let l = { type: r.value, values: r.values };
  a.$version < 7 && (l.function = r.function), K(r.value) === "object" && (l = r.value);
  let u = [];
  for (let c = 0; c < t.length; c++) u = u.concat(o({ array: t, arrayIndex: c, value: t[c], valueSpec: l, validateSpec: e.validateSpec, style: n, styleSpec: a, key: `${s}[${c}]` }));
  return u;
}
function xs(e) {
  let t = e.key, r = e.value, i = e.valueSpec, n = K(r);
  return n === "number" && r !== r && (n = "NaN"), n === "number" ? "minimum" in i && r < i.minimum ? [new I(t, r, `${r} is less than the minimum value ${i.minimum}`)] : "maximum" in i && r > i.maximum ? [new I(t, r, `${r} is greater than the maximum value ${i.maximum}`)] : [] : [new I(t, r, `number expected, ${n} found`)];
}
function md(e) {
  let t = e.valueSpec, r = Se(e.value.type), i, n = {}, a, s, o = r !== "categorical" && e.value.property === void 0, l = !o, u = K(e.value.stops) === "array" && K(e.value.stops[0]) === "array" && K(e.value.stops[0][0]) === "object", c = lt({ key: e.key, value: e.value, valueSpec: e.styleSpec.function, validateSpec: e.validateSpec, style: e.style, styleSpec: e.styleSpec, objectElementValidators: { stops: h, default: d } });
  return r === "identity" && o && c.push(new I(e.key, e.value, 'missing required property "property"')), r !== "identity" && !e.value.stops && c.push(new I(e.key, e.value, 'missing required property "stops"')), r === "exponential" && e.valueSpec.expression && !gu(e.valueSpec) && c.push(new I(e.key, e.value, "exponential functions not supported")), e.styleSpec.$version >= 8 && (l && !gi(e.valueSpec) ? c.push(new I(e.key, e.value, "property functions not supported")) : o && !id(e.valueSpec) && c.push(new I(e.key, e.value, "zoom functions not supported"))), (r === "categorical" || u) && e.value.property === void 0 && c.push(new I(e.key, e.value, '"property" property is required')), c;
  function h(y) {
    if (r === "identity") return [new I(y.key, y.value, 'identity function may not have a "stops" property')];
    let m = [], g = y.value;
    return m = m.concat(_u({ key: y.key, value: g, valueSpec: y.valueSpec, validateSpec: y.validateSpec, style: y.style, styleSpec: y.styleSpec, arrayElementValidator: p })), K(g) === "array" && g.length === 0 && m.push(new I(y.key, g, "array must have at least one stop")), m;
  }
  function p(y) {
    let m = [], g = y.value, v = y.key;
    if (K(g) !== "array") return [new I(v, g, `array expected, ${K(g)} found`)];
    if (g.length !== 2) return [new I(v, g, `array length 2 expected, length ${g.length} found`)];
    if (u) {
      if (K(g[0]) !== "object") return [new I(v, g, `object expected, ${K(g[0])} found`)];
      if (g[0].zoom === void 0) return [new I(v, g, "object stop key must have zoom")];
      if (g[0].value === void 0) return [new I(v, g, "object stop key must have value")];
      if (s && s > Se(g[0].zoom)) return [new I(v, g[0].zoom, "stop zoom values must appear in ascending order")];
      Se(g[0].zoom) !== s && (s = Se(g[0].zoom), a = void 0, n = {}), m = m.concat(lt({ key: `${v}[0]`, value: g[0], valueSpec: { zoom: {} }, validateSpec: y.validateSpec, style: y.style, styleSpec: y.styleSpec, objectElementValidators: { zoom: xs, value: f } }));
    } else m = m.concat(f({ key: `${v}[0]`, value: g[0], validateSpec: y.validateSpec, style: y.style, styleSpec: y.styleSpec }, g));
    return gs(Pr(g[1])) ? m.concat([new I(`${v}[1]`, g[1], "expressions are not allowed in function stops.")]) : m.concat(y.validateSpec({ key: `${v}[1]`, value: g[1], valueSpec: t, validateSpec: y.validateSpec, style: y.style, styleSpec: y.styleSpec }));
  }
  function f(y, m) {
    let g = K(y.value), v = Se(y.value), x = y.value === null ? m : y.value;
    if (!i) i = g;
    else if (g !== i) return [new I(y.key, x, `${g} stop domain type must match previous stop domain type ${i}`)];
    if (g !== "number" && g !== "string" && g !== "boolean") return [new I(y.key, x, "stop domain value must be a number, string, or boolean")];
    if (g !== "number" && r !== "categorical") {
      let b = `number expected, ${g} found`;
      return gi(t) && r === void 0 && (b += '\nIf you intended to use a categorical function, specify `"type": "categorical"`.'), [new I(y.key, x, b)];
    }
    return r === "categorical" && g === "number" && (!isFinite(v) || Math.floor(v) !== v) ? [new I(y.key, x, `integer expected, found ${v}`)] : r !== "categorical" && g === "number" && a !== void 0 && v < a ? [new I(y.key, x, "stop domain values must appear in ascending order")] : (a = v, r === "categorical" && v in n ? [new I(y.key, x, "stop domain values must be unique")] : (n[v] = !0, []));
  }
  function d(y) {
    return y.validateSpec({ key: y.key, value: y.value, valueSpec: t, validateSpec: y.validateSpec, style: y.style, styleSpec: y.styleSpec });
  }
}
function vi(e) {
  let t = (e.expressionContext === "property" ? ld : Mr)(Pr(e.value), e.key, e.valueSpec);
  if (t.result === "error") return t.value.map((i) => new I(`${e.key}${i.key}`, e.value, i.message));
  let r = t.value.expression || t.value._styleExpression.expression;
  if (e.expressionContext === "property" && e.propertyKey === "text-font" && !r.outputDefined()) return [new I(e.key, e.value, `Invalid data expression for "${e.propertyKey}". Output values must be contained as literals within the expression.`)];
  if (e.expressionContext === "property" && e.propertyType === "layout" && !xn(r)) return [new I(e.key, e.value, '"feature-state" data expressions are not supported with layout properties.')];
  if (e.expressionContext === "filter" && !xn(r)) return [new I(e.key, e.value, '"feature-state" data expressions are not supported with filters.')];
  if (e.expressionContext && e.expressionContext.indexOf("cluster") === 0) {
    if (!ys(r, ["zoom", "feature-state"])) return [new I(e.key, e.value, '"zoom" and "feature-state" expressions are not supported with cluster properties.')];
    if (e.expressionContext === "cluster-initial" && !ds(r)) return [new I(e.key, e.value, "Feature data expressions are not supported with initial expression part of cluster properties.")];
  }
  return [];
}
function N0(e) {
  let t = e.value, r = e.key, i = K(t);
  return i === "boolean" ? [] : [new I(r, t, `boolean expected, ${i} found`)];
}
function Xo(e) {
  let t = e.key, r = e.value, i = K(r);
  return i === "string" ? fe.parse(String(r)) ? [] : [new I(t, r, `color expected, "${r}" found`)] : [new I(t, r, `color expected, ${i} found`)];
}
function _n(e) {
  let t = e.key, r = e.value, i = e.valueSpec, n = [];
  return Array.isArray(i.values) ? i.values.indexOf(Se(r)) === -1 && n.push(new I(t, r, `expected one of [${i.values.join(", ")}], ${JSON.stringify(r)} found`)) : Object.keys(i.values).indexOf(Se(r)) === -1 && n.push(new I(t, r, `expected one of [${Object.keys(i.values).join(", ")}], ${JSON.stringify(r)} found`)), n;
}
function U0(e, t) {
  let r = e;
  for (let i of t) r = r[i];
  return r;
}
function j0(e, t) {
  let r = wu(t);
  return r ? [new I(`${e.key}${r.path.map((i) => `[${i}]`).join("")}`, U0(e.value, r.path), fd(r.legacyFilter), null, "warning")] : [];
}
function Du(e) {
  let t = Pr(e.value);
  return bu(t) ? [...j0(e, t), ...vi(vn({}, e, { expressionContext: "filter", valueSpec: { value: "boolean" } }))] : gd(e);
}
function gd(e) {
  let t = e.value, r = e.key;
  if (K(t) !== "array") return [new I(r, t, `array expected, ${K(t)} found`)];
  let i = e.styleSpec, n, a = [];
  if (t.length < 1) return [new I(r, t, "filter array must have at least 1 element")];
  switch (a = a.concat(_n({ key: `${r}[0]`, value: t[0], valueSpec: i.filter_operator, style: e.style, styleSpec: e.styleSpec })), Se(t[0])) {
    case "<":
    case "<=":
    case ">":
    case ">=":
      t.length >= 2 && Se(t[1]) === "$type" && a.push(new I(r, t, `"$type" cannot be use with operator "${t[0]}"`));
    case "==":
    case "!=":
      t.length !== 3 && a.push(new I(r, t, `filter array for operator "${t[0]}" must have 3 elements`));
    case "in":
    case "!in":
      t.length >= 2 && (n = K(t[1]), n !== "string" && a.push(new I(`${r}[1]`, t[1], `string expected, ${n} found`)));
      for (let s = 2; s < t.length; s++) n = K(t[s]), Se(t[1]) === "$type" ? a = a.concat(_n({ key: `${r}[${s}]`, value: t[s], valueSpec: i.geometry_type, style: e.style, styleSpec: e.styleSpec })) : n !== "string" && n !== "number" && n !== "boolean" && a.push(new I(`${r}[${s}]`, t[s], `string, number, or boolean expected, ${n} found`));
      break;
    case "any":
    case "all":
    case "none":
      for (let s = 1; s < t.length; s++) a = a.concat(gd({ key: `${r}[${s}]`, value: t[s], style: e.style, styleSpec: e.styleSpec }));
      break;
    case "has":
    case "!has":
      n = K(t[1]), t.length === 2 ? n !== "string" && a.push(new I(`${r}[1]`, t[1], `string expected, ${n} found`)) : a.push(new I(r, t, `filter array for "${t[0]}" operator must have 2 elements`));
  }
  return a;
}
function xd(e, t) {
  let r = e.key, i = e.validateSpec, n = e.style, a = e.styleSpec, s = e.value, o = e.objectKey, l = a[`${t}_${e.layerType}`];
  if (!l) return [];
  let u = o.match(xu);
  if (t === "paint" && u && l[u[1]] && l[u[1]].transition) return i({ key: r, value: s, valueSpec: a.transition, style: n, styleSpec: a });
  let c = e.valueSpec || l[o];
  if (!c) return [new I(r, s, `unknown property "${o}"`)];
  let h;
  if (K(s) === "string" && gi(c) && !c.tokens && (h = /^{([^}]+)}$/.exec(s))) return [new I(r, s, `"${o}" does not support interpolation syntax
Use an identity property function instead: \`{ "type": "identity", "property": ${JSON.stringify(h[1])} }\`.`)];
  let p = [];
  return e.layerType === "symbol" && o === "text-font" && ms(Pr(s)) && Se(s.type) === "identity" && p.push(new I(r, s, '"text-font" does not support identity functions')), p.concat(i({ key: e.key, value: s, valueSpec: c, style: n, styleSpec: a, expressionContext: "property", propertyType: t, propertyKey: o }));
}
function vd(e) {
  return xd(e, "paint");
}
function bd(e) {
  return xd(e, "layout");
}
function wd(e) {
  var l, u;
  let t = [], r = e.value, i = e.key, n = e.style, a = e.styleSpec;
  if (K(r) !== "object") return [new I(i, r, `object expected, ${K(r)} found`)];
  !r.type && !r.ref && t.push(new I(i, r, 'either "type" or "ref" is required'));
  let s = Se(r.type), o = Se(r.ref);
  if (r.id) {
    let c = Se(r.id);
    for (let h = 0; h < e.arrayIndex; h++) {
      let p = n.layers[h];
      Se(p.id) === c && t.push(new I(i, r.id, `duplicate layer id "${r.id}", previously used at line ${p.id.__line__}`));
    }
  }
  if ("ref" in r) {
    ["type", "source", "source-layer", "filter", "layout"].forEach((h) => {
      h in r && t.push(new I(i, r[h], `"${h}" is prohibited for ref layers`));
    });
    let c;
    n.layers.forEach((h) => {
      Se(h.id) === o && (c = h);
    }), c ? c.ref ? t.push(new I(i, r.ref, "ref cannot reference another ref layer")) : s = Se(c.type) : t.push(new I(i, r.ref, `ref layer "${o}" not found`));
  } else if (s !== "background")
    if (!r.source) t.push(new I(i, r, 'missing required property "source"'));
    else {
      let c = n.sources && n.sources[r.source], h = c && Se(c.type);
      c ? h === "vector" && s === "raster" ? t.push(new I(i, r.source, `layer "${r.id}" requires a raster source`)) : h !== "raster-dem" && s === "hillshade" || h !== "raster-dem" && s === "color-relief" ? t.push(new I(i, r.source, `layer "${r.id}" requires a raster-dem source`)) : h === "raster" && s !== "raster" ? t.push(new I(i, r.source, `layer "${r.id}" requires a vector source`)) : h === "vector" && !r["source-layer"] ? t.push(new I(i, r, `layer "${r.id}" must specify a "source-layer"`)) : h === "raster-dem" && s !== "hillshade" && s !== "color-relief" ? t.push(new I(i, r.source, "raster-dem source can only be used with layer type 'hillshade' or 'color-relief'.")) : s === "line" && r.paint && r.paint["line-gradient"] && (h !== "geojson" || !c.lineMetrics) && t.push(new I(i, r, `layer "${r.id}" specifies a line-gradient, which requires a GeoJSON source with \`lineMetrics\` enabled.`)) : t.push(new I(i, r.source, `source "${r.source}" not found`));
    }
  return s === "raster" && ((l = r.paint) != null && l.resampling) && ((u = r.paint) != null && u["raster-resampling"]) && t.push(new I(i, r.paint, `layer "${r.id}" redundantly specifies "resampling" and "raster-resampling" paint properties, but only one is allowed. It is advised to use "resampling".`)), t = t.concat(lt({ key: i, value: r, valueSpec: a.layer, style: e.style, styleSpec: e.styleSpec, validateSpec: e.validateSpec, objectElementValidators: { "*"() {
    return [];
  }, type() {
    return e.validateSpec({ key: `${i}.type`, value: r.type, valueSpec: a.layer.type, style: e.style, styleSpec: e.styleSpec, validateSpec: e.validateSpec, object: r, objectKey: "type" });
  }, filter: Du, layout(c) {
    return lt({ layer: r, key: c.key, value: c.value, style: c.style, styleSpec: c.styleSpec, validateSpec: c.validateSpec, objectElementValidators: { "*"(h) {
      return bd(vn({ layerType: s }, h));
    } } });
  }, paint(c) {
    return lt({ layer: r, key: c.key, value: c.value, style: c.style, styleSpec: c.styleSpec, validateSpec: c.validateSpec, objectElementValidators: { "*"(h) {
      return vd(vn({ layerType: s }, h));
    } } });
  } } })), t;
}
function yr(e) {
  let t = e.value, r = e.key, i = K(t);
  return i === "string" ? [] : [new I(r, t, `string expected, ${i} found`)];
}
function q0(e) {
  let t = e.sourceName ?? "", r = e.value, i = e.styleSpec, n = i.source_raster_dem, a = e.style, s = [], o = K(r);
  if (r === void 0) return s;
  if (o !== "object") return s.push(new I("source_raster_dem", r, `object expected, ${o} found`)), s;
  let l = Se(r.encoding) === "custom", u = ["redFactor", "greenFactor", "blueFactor", "baseShift"], c = e.value.encoding ? `"${e.value.encoding}"` : "Default";
  for (let h in r) !l && u.includes(h) ? s.push(new I(h, r[h], `In "${t}": "${h}" is only valid when "encoding" is set to "custom". ${c} encoding found`)) : n[h] ? s = s.concat(e.validateSpec({ key: h, value: r[h], valueSpec: n[h], validateSpec: e.validateSpec, style: a, styleSpec: i })) : s.push(new I(h, r[h], `unknown property "${h}"`));
  return s;
}
const uh = { promoteId: G0 };
function _d(e) {
  let t = e.value, r = e.key, i = e.styleSpec, n = e.style, a = e.validateSpec;
  if (!t.type) return [new I(r, t, '"type" is required')];
  let s = Se(t.type), o;
  switch (s) {
    case "vector":
    case "raster":
      return o = lt({ key: r, value: t, valueSpec: i[`source_${s.replace("-", "_")}`], style: e.style, styleSpec: i, objectElementValidators: uh, validateSpec: a }), o;
    case "raster-dem":
      return o = q0({ sourceName: r, value: t, style: e.style, styleSpec: i, validateSpec: a }), o;
    case "geojson":
      if (o = lt({ key: r, value: t, valueSpec: i.source_geojson, style: n, styleSpec: i, validateSpec: a, objectElementValidators: uh }), t.cluster) for (let l in t.clusterProperties) {
        let [u, c] = t.clusterProperties[l], h = typeof u == "string" ? [u, ["accumulated"], ["get", l]] : u;
        o.push(...vi({ key: `${r}.${l}.map`, value: c, expressionContext: "cluster-map" })), o.push(...vi({ key: `${r}.${l}.reduce`, value: h, expressionContext: "cluster-reduce" }));
      }
      return o;
    case "video":
      return lt({ key: r, value: t, valueSpec: i.source_video, style: n, validateSpec: a, styleSpec: i });
    case "image":
      return lt({ key: r, value: t, valueSpec: i.source_image, style: n, validateSpec: a, styleSpec: i });
    case "canvas":
      return [new I(r, null, "Please use runtime APIs to add canvas sources, rather than including them in stylesheets.", "source.canvas")];
    default:
      return _n({ key: `${r}.type`, value: t.type, valueSpec: { values: ["vector", "raster", "raster-dem", "geojson", "video", "image"] } });
  }
}
function G0({ key: e, value: t }) {
  if (K(t) === "string") return yr({ key: e, value: t });
  {
    let r = [];
    for (let i in t) r.push(...yr({ key: `${e}.${i}`, value: t[i] }));
    return r;
  }
}
function Dd(e) {
  let t = e.value, r = e.styleSpec, i = r.light, n = e.style, a = [], s = K(t);
  if (t === void 0) return a;
  if (s !== "object") return a = a.concat([new I("light", t, `object expected, ${s} found`)]), a;
  for (let o in t) {
    let l = o.match(xu);
    a = l && i[l[1]] && i[l[1]].transition ? a.concat(e.validateSpec({ key: o, value: t[o], valueSpec: r.transition, validateSpec: e.validateSpec, style: n, styleSpec: r })) : i[o] ? a.concat(e.validateSpec({ key: o, value: t[o], valueSpec: i[o], validateSpec: e.validateSpec, style: n, styleSpec: r })) : a.concat([new I(o, t[o], `unknown property "${o}"`)]);
  }
  return a;
}
function Sd(e) {
  let t = e.value, r = e.styleSpec, i = r.sky, n = e.style, a = K(t);
  if (t === void 0) return [];
  if (a !== "object") return [new I("sky", t, `object expected, ${a} found`)];
  let s = [];
  for (let o in t) {
    let l = o.match(xu);
    s = l && i[l[1]] && i[l[1]].transition ? s.concat(e.validateSpec({ key: o, value: t[o], valueSpec: r.transition, style: n, styleSpec: r })) : i[o] ? s.concat(e.validateSpec({ key: o, value: t[o], valueSpec: i[o], style: n, styleSpec: r })) : s.concat([new I(o, t[o], `unknown property "${o}"`)]);
  }
  return s;
}
function Ad(e) {
  let t = e.value, r = e.styleSpec, i = r.terrain, n = e.style, a = [], s = K(t);
  if (t === void 0) return a;
  if (s !== "object") return a = a.concat([new I("terrain", t, `object expected, ${s} found`)]), a;
  for (let o in t) a = i[o] ? a.concat(e.validateSpec({ key: o, value: t[o], valueSpec: i[o], validateSpec: e.validateSpec, style: n, styleSpec: r })) : a.concat([new I(o, t[o], `unknown property "${o}"`)]);
  return a;
}
function X0(e) {
  return yr(e).length === 0 ? [] : vi(e);
}
function Y0(e) {
  return yr(e).length === 0 ? [] : vi(e);
}
function W0(e) {
  let t = e.key, r = e.value;
  if (K(r) === "array") {
    if (r.length < 1 || r.length > 4) return [new I(t, r, `padding requires 1 to 4 values; ${r.length} values found`)];
    let i = { type: "number" }, n = [];
    for (let a = 0; a < r.length; a++) n = n.concat(e.validateSpec({ key: `${t}[${a}]`, value: r[a], validateSpec: e.validateSpec, valueSpec: i }));
    return n;
  }
  return xs({ key: t, value: r, valueSpec: {} });
}
function Z0(e) {
  let t = e.key, r = e.value;
  if (K(r) === "array") {
    let i = { type: "number" };
    if (r.length < 1) return [new I(t, r, "array length at least 1 expected, length 0 found")];
    let n = [];
    for (let a = 0; a < r.length; a++) n = n.concat(e.validateSpec({ key: `${t}[${a}]`, value: r[a], validateSpec: e.validateSpec, valueSpec: i }));
    return n;
  }
  return xs({ key: t, value: r, valueSpec: {} });
}
function H0(e) {
  let t = e.key, r = e.value;
  if (K(r) === "array") {
    if (r.length < 1) return [new I(t, r, "array length at least 1 expected, length 0 found")];
    let i = [];
    for (let n = 0; n < r.length; n++) i = i.concat(Xo({ key: `${t}[${n}]`, value: r[n] }));
    return i;
  }
  return Xo({ key: t, value: r });
}
function K0(e) {
  let t = e.key, r = e.value, i = K(r), n = e.styleSpec;
  if (i !== "array" || r.length < 1 || r.length % 2 != 0) return [new I(t, r, "variableAnchorOffsetCollection requires a non-empty array of even length")];
  let a = [];
  for (let s = 0; s < r.length; s += 2) a = a.concat(_n({ key: `${t}[${s}]`, value: r[s], valueSpec: n.layout_symbol["text-anchor"] })), a = a.concat(_u({ key: `${t}[${s + 1}]`, value: r[s + 1], valueSpec: { length: 2, value: "number" }, validateSpec: e.validateSpec, style: e.style, styleSpec: n }));
  return a;
}
function Ed(e) {
  let t = [], r = e.value, i = e.key;
  if (Array.isArray(r)) {
    let n = [], a = [];
    for (let s in r) r[s].id && n.includes(r[s].id) && t.push(new I(i, r, `all the sprites' ids must be unique, but ${r[s].id} is duplicated`)), n.push(r[s].id), r[s].url && a.includes(r[s].url) && t.push(new I(i, r, `all the sprites' URLs must be unique, but ${r[s].url} is duplicated`)), a.push(r[s].url), t = t.concat(lt({ key: `${i}[${s}]`, value: r[s], valueSpec: { id: { type: "string", required: !0 }, url: { type: "string", required: !0 } }, validateSpec: e.validateSpec }));
    return t;
  }
  return yr({ key: i, value: r });
}
function J0(e) {
  let t = e.value, r = e.styleSpec, i = r.projection, n = e.style, a = K(t);
  if (t === void 0) return [];
  if (a !== "object") return [new I("projection", t, `object expected, ${a} found`)];
  let s = [];
  for (let o in t) s = i[o] ? s.concat(e.validateSpec({ key: o, value: t[o], valueSpec: i[o], style: n, styleSpec: r })) : s.concat([new I(o, t[o], `unknown property "${o}"`)]);
  return s;
}
function Q0(e) {
  let t = e.key, r = e.value;
  r = r instanceof String ? r.valueOf() : r;
  let i = K(r);
  return i === "array" && !tx(r) && !ex(r) ? [new I(t, r, `projection expected, invalid array ${JSON.stringify(r)} found`)] : ["array", "string"].includes(i) ? [] : [new I(t, r, `projection expected, invalid type "${i}" found`)];
}
function ex(e) {
  return !!["interpolate", "step", "literal"].includes(e[0]);
}
function tx(e) {
  return Array.isArray(e) && e.length === 3 && typeof e[0] == "string" && typeof e[1] == "string" && typeof e[2] == "number";
}
function Yo(e) {
  return !!e && e.constructor === Object;
}
function Td(e) {
  return Yo(e.value) ? [] : [new I(e.key, e.value, `object expected, ${K(e.value)} found`)];
}
const ch = 1114111, rx = /^u\+(?:([0-9a-f]{1,6})(?:-([0-9a-f]{1,6}))?|([0-9a-f]{0,5}\?{1,6}))$/i;
function ix(e, t) {
  if (K(t) !== "string") return [];
  let r = `${t}`, i = () => [new I(e, t, 'invalid unicode range, expected a value such as "U+26", "U+0-10FFFF" or "U+4??"')], n = r.match(rx);
  if (!n) return i();
  let [, a, s, o] = n;
  if (o !== void 0) return o.length > 6 ? i() : [];
  let l = parseInt(a, 16), u = s === void 0 ? l : parseInt(s, 16);
  return l > ch || u > ch ? [new I(e, t, "unicode range is out of bounds, the maximum code point is U+10FFFF")] : l > u ? [new I(e, t, `unicode range start must not be greater than its end, but ${r} is`)] : [];
}
function Id(e) {
  let t = e.key ?? "font-faces", r = e.value, i = e.validateSpec, n = e.styleSpec ?? uf, a = e.style;
  if (!Yo(r)) return [new I(t, r, `object expected, ${K(r)} found`)];
  let s = [];
  for (let o in r) {
    let l = r[o], u = K(l);
    if (u === "string") s.push(...yr({ key: `${t}.${o}`, value: l }));
    else if (u === "array") {
      let c = { url: { type: "string", required: !0 }, "unicode-range": { type: "array", value: "string" } };
      for (let [h, p] of l.entries()) {
        let f = `${t}.${o}[${h}]`;
        s.push(...lt({ key: f, value: p, valueSpec: c, styleSpec: n, style: a, validateSpec: i }));
        let d = Yo(p) ? p["unicode-range"] : void 0;
        if (K(d) === "array") for (let [y, m] of d.entries()) s.push(...ix(`${f}.unicode-range[${y}]`, m));
      }
    } else s.push(new I(`${t}.${o}`, l, `string or array expected, ${u} found`));
  }
  return s;
}
const hh = { "*"() {
  return [];
}, array: _u, boolean: N0, number: xs, color: Xo, constants: yd, enum: _n, filter: Du, function: md, layer: wd, object: lt, source: _d, light: Dd, sky: Sd, terrain: Ad, projection: J0, projectionDefinition: Q0, string: yr, formatted: X0, resolvedImage: Y0, padding: W0, numberArray: Z0, colorArray: H0, variableAnchorOffsetCollection: K0, sprite: Ed, state: Td, fontFaces: Id };
function Ga(e) {
  let t = e.value, r = e.valueSpec, i = e.styleSpec;
  return e.validateSpec = Ga, r.expression && ms(Se(t)) ? md(e) : r.expression && gs(Pr(t)) ? vi(e) : r.type && hh[r.type] ? hh[r.type](e) : lt(vn({}, e, { valueSpec: r.type ? i[r.type] : r }));
}
function Cd(e) {
  let t = e.value, r = e.key, i = yr(e);
  return i.length || (t.indexOf("{fontstack}") === -1 && i.push(new I(r, t, '"glyphs" url must include a "{fontstack}" token')), t.indexOf("{range}") === -1 && i.push(new I(r, t, '"glyphs" url must include a "{range}" token'))), i;
}
function at(e, t = S) {
  let r = [];
  return r = r.concat(Ga({ key: "", value: e, valueSpec: t.$root, styleSpec: t, style: e, validateSpec: Ga, objectElementValidators: { glyphs: Cd, "*"() {
    return [];
  } } })), e.constants && (r = r.concat(yd({ key: "constants", value: e.constants }))), kd(r);
}
at.source = pt(ht(_d)), at.sprite = pt(ht(Ed)), at.glyphs = pt(ht(Cd)), at.fontFaces = pt(ht(Id)), at.light = pt(ht(Dd)), at.sky = pt(ht(Sd)), at.terrain = pt(ht(Ad)), at.state = pt(ht(Td)), at.layer = pt(ht(wd)), at.filter = pt(ht(Du)), at.paintProperty = pt(ht(vd)), at.layoutProperty = pt(ht(bd));
function ht(e) {
  return function(t) {
    return e(Object.assign({}, t, { validateSpec: Ga }));
  };
}
function kd(e) {
  return [].concat(e).sort((t, r) => t.line - r.line);
}
function pt(e) {
  return function(...t) {
    return kd(e.apply(this, t));
  };
}
const nx = { type: "enum", "property-type": "data-constant", expression: { interpolated: !1, parameters: ["global-state"] }, values: { visible: {}, none: {} }, transition: !1, default: "visible" };
var ax = class {
  constructor(e, t, r) {
    this._rootKey = t, this._globalState = r, this.setValue(e);
  }
  evaluate() {
    return this._literalValue ?? this._compiledValue.evaluate({});
  }
  setValue(e) {
    if (e == null || e === "visible" || e === "none") {
      this._literalValue = e === "none" ? "none" : "visible", this._compiledValue = void 0, this._globalStateRefs = /* @__PURE__ */ new Set();
      return;
    }
    let t = Mr(e, this._rootKey, nx, this._globalState);
    if (t.result === "error") throw this._literalValue = "visible", this._compiledValue = void 0, Error(t.value.map((r) => `${r.key}: ${r.message}`).join(", "));
    this._literalValue = void 0, this._compiledValue = t.value, this._globalStateRefs = Rn(t.value.expression);
  }
  getGlobalStateRefs() {
    return this._globalStateRefs;
  }
};
function sx(e, t, r) {
  return new ax(e, t, r);
}
const Su = { REGISTERED_PROTOCOLS: {} };
function ox(e) {
  return Su.REGISTERED_PROTOCOLS[e.substring(0, e.indexOf("://"))];
}
function lx(e, t) {
  Su.REGISTERED_PROTOCOLS[e] = t;
}
function ux(e) {
  delete Su.REGISTERED_PROTOCOLS[e];
}
const ph = "global-dispatcher";
var Xa = class extends Error {
  constructor(e, t, r, i) {
    super(`AJAXError: ${t} (${e}): ${r}`), this.status = e, this.statusText = t, this.url = r, this.body = i;
  }
};
function Fd() {
  var e;
  if (pi(self)) return (e = self.worker) == null ? void 0 : e.referrer;
  if (window.location.protocol === "blob:") try {
    return window.parent.location.href;
  } catch {
  }
  return window.location.href;
}
const cx = (e) => {
  var t;
  return e.startsWith("file:") || ((t = Fd()) == null ? void 0 : t.startsWith("file:")) && !/^\w+:/.test(e);
};
async function hx(e, t) {
  let r = new Request(e.url, { method: e.method || "GET", body: e.body, credentials: e.credentials, headers: e.headers, cache: e.cache, referrer: Fd(), referrerPolicy: e.referrerPolicy, signal: t.signal });
  e.type === "json" && !r.headers.has("Accept") && r.headers.set("Accept", "application/json");
  let i;
  try {
    i = await fetch(r);
  } catch (s) {
    throw of(s) ? s : new Xa(0, La(s).message, e.url, new Blob());
  }
  if (!i.ok) {
    let s = await i.blob();
    throw new Xa(i.status, i.statusText, e.url, s);
  }
  let n;
  n = e.type === "arrayBuffer" || e.type === "image" ? i.arrayBuffer() : e.type === "json" ? i.json() : i.text();
  let a = await n;
  return Ym(t.signal), { data: a, cacheControl: i.headers.get("Cache-Control"), expires: i.headers.get("Expires"), etag: i.headers.get("ETag") };
}
function px(e, t) {
  return new Promise((r, i) => {
    var a;
    let n = new XMLHttpRequest();
    n.open(e.method || "GET", e.url, !0), (e.type === "arrayBuffer" || e.type === "image") && (n.responseType = "arraybuffer");
    for (let s in e.headers) n.setRequestHeader(s, e.headers[s]);
    e.type === "json" && (n.responseType = "text", (a = e.headers) != null && a.Accept || n.setRequestHeader("Accept", "application/json")), n.withCredentials = e.credentials === "include", n.onerror = () => {
      i(Error(n.statusText));
    }, n.onload = () => {
      if (!t.signal.aborted)
        if ((n.status >= 200 && n.status < 300 || n.status === 0) && n.response !== null) {
          let s = n.response;
          if (e.type === "json") try {
            s = JSON.parse(n.response);
          } catch (o) {
            i(o);
            return;
          }
          r({ data: s, cacheControl: n.getResponseHeader("Cache-Control"), expires: n.getResponseHeader("Expires"), etag: n.getResponseHeader("ETag") });
        } else {
          let s = new Blob([n.response], { type: n.getResponseHeader("Content-Type") });
          i(new Xa(n.status, n.statusText, e.url, s));
        }
    }, t.signal.addEventListener("abort", () => {
      n.abort(), i(new ru(t.signal.reason));
    }), n.send(e.body);
  });
}
const Au = async function(e, t) {
  var r, i;
  if (e.url.includes("://") && !/^https?:|^file:/.test(e.url)) {
    let n = ox(e.url);
    if (n) {
      let a = await n(e, t);
      return !a.data && e.type === "arrayBuffer" ? it(a, { data: /* @__PURE__ */ new ArrayBuffer(0) }) : a;
    }
    if (pi(self) && ((r = self.worker) != null && r.actor)) return self.worker.actor.sendAsync({ type: "GR", data: e, targetMapId: ph }, t);
  }
  if (!cx(e.url)) {
    if (fetch && Request && AbortController && Object.hasOwn(Request.prototype, "signal")) return hx(e, t);
    if (pi(self) && ((i = self.worker) != null && i.actor)) return self.worker.actor.sendAsync({ type: "GR", data: e, mustQueue: !0, targetMapId: ph }, t);
  }
  return px(e, t);
}, fx = (e, t) => Au(it(e, { type: "json" }), t), dx = (e, t) => Au(it(e, { type: "arrayBuffer" }), t), Xt = {};
function P(e, t, r = {}) {
  if (Xt[e]) throw Error(`${e} is already registered.`);
  Object.defineProperty(t, "_classRegistryKey", { value: e, writeable: !1 }), Xt[e] = { klass: t, omit: r.omit || [], shallow: r.shallow || [] };
}
P("Object", Object), P("Set", Set), P("TransferableGridIndex", Bo), P("Color", fe), P("Error", Error), P("AJAXError", Xa), P("ResolvedImage", zt), P("StylePropertyFunction", ud), P("StyleExpression", vu, { omit: ["_evaluator"] }), P("ZoomDependentExpression", ja), P("ZoomConstantExpression", bn), P("CompoundExpression", Vr, { omit: ["_evaluate"] });
for (let e in ai) ai[e]._classRegistryKey || P(`Expression_${e}`, ai[e]);
function Md(e) {
  var t;
  return e && typeof ArrayBuffer < "u" && (e instanceof ArrayBuffer || ((t = e.constructor) == null ? void 0 : t.name) === "ArrayBuffer");
}
function Eu(e) {
  let t = e.constructor;
  return e.$name || t._classRegistryKey;
}
function yx(e) {
  if (typeof e != "object" || !e) return !1;
  let t = Eu(e);
  return t && t !== "Object";
}
function Pd(e) {
  return !yx(e) && (e == null || typeof e == "boolean" || typeof e == "number" || typeof e == "string" || e instanceof Boolean || e instanceof Number || e instanceof String || e instanceof Date || e instanceof RegExp || e instanceof Blob || e instanceof Error || Md(e) || tu(e) || ArrayBuffer.isView(e) || e instanceof ImageData);
}
function un(e, t) {
  if (Pd(e)) return (Md(e) || tu(e)) && t && t.push(e), ArrayBuffer.isView(e) && t && t.push(e.buffer), e instanceof ImageData && t && t.push(e.data.buffer), e;
  if (Array.isArray(e)) {
    let a = [];
    for (let s of e) a.push(un(s, t));
    return a;
  }
  if (typeof e != "object") throw Error(`can't serialize object of type ${typeof e}`);
  let r = Eu(e);
  if (!r) throw Error(`can't serialize object of unregistered class ${e.constructor.name}`);
  if (!Xt[r]) throw Error(`${r} is not registered.`);
  let { klass: i } = Xt[r], n = i.serialize ? i.serialize(e, t) : {};
  if (i.serialize) {
    if (n === (t == null ? void 0 : t[t.length - 1])) throw Error("statically serialized object won't survive transfer of $name property");
  } else {
    for (let a in e) {
      if (!e.hasOwnProperty(a) || Xt[r].omit.includes(a)) continue;
      let s = e[a];
      s !== void 0 && (n[a] = Xt[r].shallow.includes(a) ? s : un(s, t));
    }
    e instanceof Error && (n.message = e.message);
  }
  if (n.$name) throw Error("$name property is reserved for worker serialization logic.");
  return r !== "Object" && (n.$name = r), n;
}
function cn(e) {
  if (Pd(e)) return e;
  if (Array.isArray(e)) return e.map(cn);
  if (typeof e != "object") throw Error(`can't deserialize object of type ${typeof e}`);
  let t = Eu(e) || "Object";
  if (!Xt[t]) throw Error(`can't deserialize unregistered class ${t}`);
  let { klass: r } = Xt[t];
  if (!r) throw Error(`can't deserialize unregistered class ${t}`);
  if (r.deserialize) return r.deserialize(e);
  let i = Object.create(r.prototype);
  for (let n of Object.keys(e)) {
    if (n === "$name") continue;
    let a = e[n];
    i[n] = Xt[t].shallow.includes(n) ? a : cn(a);
  }
  return i;
}
var mx = class {
  constructor(e) {
    this._methodToThrottle = e, this._triggered = !1, this._channel = new MessageChannel(), this._channel.port2.onmessage = () => this._invoke();
  }
  trigger() {
    var e;
    this._triggered || (this._triggered = !0, (e = this._channel) == null || e.port1.postMessage(!0), setTimeout(() => this._invoke(), 0));
  }
  _invoke() {
    this._triggered && (this._triggered = !1, this._methodToThrottle());
  }
  remove() {
    delete this._channel, this._methodToThrottle = () => {
    };
  }
};
const gx = { once: !0 };
var xx = class {
  constructor(e, t) {
    this.target = e, this.mapId = t, this.resolveRejects = {}, this.tasks = {}, this.taskQueue = [], this.abortControllers = {}, this.messageHandlers = {}, this.invoker = new mx(() => this.process()), this.subscription = jc(this.target, "message", (r) => this.receive(r), !1), this.globalScope = pi(self) ? e : window;
  }
  registerMessageHandler(e, t) {
    this.messageHandlers[e] = t;
  }
  unregisterMessageHandler(e) {
    delete this.messageHandlers[e];
  }
  sendAsync(e, t) {
    return new Promise((r, i) => {
      let n = Math.round(Math.random() * 1e18).toString(36).substring(0, 10), a = t ? jc(t.signal, "abort", () => {
        a == null || a.unsubscribe(), delete this.resolveRejects[n];
        let l = { id: n, type: "<cancel>", origin: location.origin, targetMapId: e.targetMapId, sourceMapId: this.mapId };
        this.target.postMessage(l), i(new ru(t.signal.reason));
      }, gx) : null;
      this.resolveRejects[n] = { resolve: (l) => {
        a == null || a.unsubscribe(), r(l);
      }, reject: (l) => {
        a == null || a.unsubscribe(), i(l);
      } };
      let s = [], o = { ...e, id: n, sourceMapId: this.mapId, origin: location.origin, data: un(e.data, s) };
      this.target.postMessage(o, { transfer: s });
    });
  }
  receive(e) {
    let t = e.data, r = t.id, i = ["file://", "resource://android", "null"], n = [t.origin, location.origin], a = t.origin === location.origin, s = n.some((o) => i.includes(o));
    if ((a || s) && !(t.targetMapId && this.mapId !== t.targetMapId))
      if (t.type === "<cancel>") {
        delete this.tasks[r];
        let o = this.abortControllers[r];
        delete this.abortControllers[r], o && o.abort();
      } else pi(self) || t.mustQueue ? (this.tasks[r] = t, this.taskQueue.push(r), this.invoker.trigger()) : this.processTask(r, t);
  }
  process() {
    if (this.taskQueue.length === 0) return;
    let e = this.taskQueue.shift(), t = this.tasks[e];
    delete this.tasks[e], this.taskQueue.length > 0 && this.invoker.trigger(), t && this.processTask(e, t);
  }
  async processTask(e, t) {
    if (t.type === "<response>") {
      let n = this.resolveRejects[e];
      if (delete this.resolveRejects[e], !n) return;
      t.error ? n.reject(La(cn(t.error))) : n.resolve(cn(t.data));
      return;
    }
    if (!this.messageHandlers[t.type]) {
      this.completeTask(e, null, null);
      return;
    }
    let r = cn(t.data), i = new AbortController();
    this.abortControllers[e] = i;
    try {
      let n = await this.messageHandlers[t.type](t.sourceMapId, r, i);
      this.completeTask(e, null, n);
    } catch (n) {
      this.completeTask(e, La(n));
    }
  }
  completeTask(e, t, r) {
    let i = [];
    delete this.abortControllers[e];
    let n = { id: e, type: "<response>", sourceMapId: this.mapId, origin: location.origin, error: t ? un(t) : null, data: un(r, i) };
    this.target.postMessage(n, { transfer: i });
  }
  remove() {
    this.invoker.remove(), this.subscription.unsubscribe();
  }
};
const fh = at;
new Set(Object.keys(S).filter((e) => e.startsWith("source_")).map((e) => e.slice(7).replaceAll("_", "-")));
function vx(e, t) {
  let r = !1;
  for (let i of t) i.severity === "warning" ? Me(i.message) : (e.fire(new Oa(Error(i.message))), r = !0);
  return r;
}
function bx(e, t, r, i) {
  return (i == null ? void 0 : i.validate) !== !1 && vx(e, t({ styleSpec: S, ...r }));
}
var dh = class {
  constructor() {
    this.first = !0;
  }
  update(e, t) {
    let r = Math.floor(e);
    return this.first ? (this.first = !1, this.lastIntegerZoom = r, this.lastIntegerZoomTime = 0, this.lastZoom = e, this.lastFloorZoom = r, !0) : (this.lastFloorZoom > r ? (this.lastIntegerZoom = r + 1, this.lastIntegerZoomTime = t) : this.lastFloorZoom < r && (this.lastIntegerZoom = r, this.lastIntegerZoomTime = t), e !== this.lastZoom && (this.lastZoom = e, this.lastFloorZoom = r, !0));
  }
}, le = class {
  constructor(e, t) {
    this.zoom = e, t ? (this.now = t.now || 0, this.fadeDuration = t.fadeDuration || 0, this.zoomHistory = t.zoomHistory || new dh(), this.transition = t.transition || {}) : (this.now = 0, this.fadeDuration = 0, this.zoomHistory = new dh(), this.transition = {});
  }
  crossFadingFactor() {
    return this.fadeDuration === 0 ? 1 : Math.min((this.now - this.zoomHistory.lastIntegerZoomTime) / this.fadeDuration, 1);
  }
  getCrossfadeParameters() {
    let e = this.zoom, t = e - Math.floor(e), r = this.crossFadingFactor();
    return e > this.zoomHistory.lastIntegerZoom ? { fromScale: 2, toScale: 1, t: t + (1 - t) * r } : { fromScale: 0.5, toScale: 1, t: 1 - (1 - r) * t };
  }
}, Dn = class {
  constructor(e, t, r, i) {
    this.property = e, this.value = t, this.expression = F0(t === void 0 ? e.specification.default : t, r, e.specification, i);
  }
  isDataDriven() {
    return this.expression.kind === "source" || this.expression.kind === "composite";
  }
  getGlobalStateRefs() {
    return this.expression.globalStateRefs || /* @__PURE__ */ new Set();
  }
  readsGlobalState(e) {
    let t = this.getGlobalStateRefs();
    return e.some((r) => t.has(r));
  }
  possiblyEvaluate(e, t, r) {
    return this.property.possiblyEvaluate(this, e, t, r);
  }
}, Wo = class {
  constructor(e, t, r) {
    this.property = e, this.value = new Dn(e, void 0, t, r);
  }
  transitioned(e, t) {
    return t.value === this.value ? t : new yh(this.property, this.value, t, it({}, e.transition, this.transition), e.now);
  }
  untransitioned() {
    return new yh(this.property, this.value, null, {}, 0);
  }
}, wx = class {
  constructor(e, t, r) {
    this._properties = e, this._values = Object.create(e.defaultTransitionablePropertyValues), this._globalState = r, this._rootKey = t;
  }
  _propertyRootKey(e) {
    return `${this._rootKey}.${String(e)}`;
  }
  hasProperty(e) {
    return e in this._properties.defaultTransitionablePropertyValues;
  }
  getValue(e) {
    return hr(this._values[e].value.value);
  }
  setValue(e, t) {
    Object.hasOwn(this._values, e) || (this._values[e] = new Wo(this._values[e].property, this._propertyRootKey(e), this._globalState)), this._values[e].value = new Dn(this._values[e].property, t === null ? void 0 : hr(t), this._propertyRootKey(e), this._globalState);
  }
  setValues(e) {
    for (let t in e) {
      let r = e[t];
      t.endsWith("-transition") ? this.setTransition(t.slice(0, -11), r) : Po(this._values[t].value.value, r) || this.setValue(t, r);
    }
  }
  getTransition(e) {
    return hr(this._values[e].transition);
  }
  setTransition(e, t) {
    Object.hasOwn(this._values, e) || (this._values[e] = new Wo(this._values[e].property, this._propertyRootKey(e), this._globalState)), this._values[e].transition = hr(t) || void 0;
  }
  retainPriorGlobalState(e, t, r) {
    for (let i of Object.keys(r._values)) for (let n = r._values[i]; n; n = n.prior) {
      let { value: a } = n;
      a.property.specification.transition && !a.isDataDriven() && a.expression._globalState === this._globalState && a.readsGlobalState(e) && (n.value = new Dn(a.property, a.value, this._propertyRootKey(i), t));
    }
  }
  applyGlobalStateChange(e, t, r, i) {
    this.retainPriorGlobalState(e, t, r);
    let n = !1;
    for (let a of Object.keys(this._values)) {
      let { value: s } = this._values[a];
      s.readsGlobalState(e) && (this.setValue(a, s.value), n = !0);
    }
    return n ? this.transitioned(i, r) : r;
  }
  serialize() {
    let e = {};
    for (let t of Object.keys(this._values)) {
      let r = this.getValue(t);
      r !== void 0 && (e[t] = r);
      let i = this.getTransition(t);
      i !== void 0 && (e[`${t}-transition`] = i);
    }
    return e;
  }
  transitioned(e, t) {
    let r = new mh(this._properties);
    for (let i of Object.keys(this._values)) r._values[i] = this._values[i].transitioned(e, t._values[i]);
    return r;
  }
  untransitioned() {
    let e = new mh(this._properties);
    for (let t of Object.keys(this._values)) e._values[t] = this._values[t].untransitioned();
    return e;
  }
}, yh = class {
  constructor(e, t, r, i, n) {
    this.property = e, this.value = t, this.begin = n + i.delay || 0, this.end = this.begin + i.duration || 0, e.specification.transition && (i.delay || i.duration) && (this.prior = r);
  }
  possiblyEvaluate(e, t, r) {
    let i = e.now || 0, n = this.value.possiblyEvaluate(e, t, r), a = this.prior;
    if (!a) return n;
    if (i > this.end || this.value.isDataDriven()) return this.prior = null, n;
    if (i < this.begin) return a.possiblyEvaluate(e, t, r);
    {
      let s = (i - this.begin) / (this.end - this.begin);
      return this.property.interpolate(a.possiblyEvaluate(e, t, r), n, Om(s));
    }
  }
}, mh = class {
  constructor(e) {
    this._properties = e, this._values = Object.create(e.defaultTransitioningPropertyValues);
  }
  possiblyEvaluate(e, t, r) {
    let i = new vs(this._properties);
    for (let n of Object.keys(this._values)) i._values[n] = this._values[n].possiblyEvaluate(e, t, r);
    return i;
  }
  hasTransition() {
    for (let e of Object.keys(this._values)) if (this._values[e].prior) return !0;
    return !1;
  }
}, _x = class {
  constructor(e, t, r) {
    this._properties = e, this._values = Object.create(e.defaultPropertyValues), this._globalState = r, this._rootKey = t;
  }
  _propertyRootKey(e) {
    return `${this._rootKey}.${String(e)}`;
  }
  hasValue(e) {
    return this._values[e].value !== void 0;
  }
  hasProperty(e) {
    return e in this._properties.defaultPropertyValues;
  }
  getValue(e) {
    return hr(this._values[e].value);
  }
  setValue(e, t) {
    this._values[e] = new Dn(this._values[e].property, t === null ? void 0 : hr(t), this._propertyRootKey(e), this._globalState);
  }
  serialize() {
    let e = {};
    for (let t of Object.keys(this._values)) {
      let r = this.getValue(t);
      r !== void 0 && (e[t] = r);
    }
    return e;
  }
  possiblyEvaluate(e, t, r) {
    let i = new vs(this._properties);
    for (let n of Object.keys(this._values)) i._values[n] = this._values[n].possiblyEvaluate(e, t, r);
    return i;
  }
}, mt = class {
  constructor(e, t, r) {
    this.property = e, this.value = t, this.parameters = r;
  }
  isConstant() {
    return this.value.kind === "constant";
  }
  constantOr(e) {
    return this.value.kind === "constant" ? this.value.value : e;
  }
  evaluate(e, t, r, i) {
    return this.property.evaluate(this.value, this.parameters, e, t, r, i);
  }
}, vs = class {
  constructor(e) {
    this._properties = e, this._values = Object.create(e.defaultPossiblyEvaluatedValues);
  }
  get(e) {
    return this._values[e];
  }
};
function gh(e) {
  if (Array.isArray(e)) return e.length;
  let t = e == null ? void 0 : e.values;
  return Array.isArray(t) ? t.length : void 0;
}
function Bd(e, t) {
  let r = gh(e), i = gh(t);
  return r !== void 0 && i !== void 0 && r !== i;
}
var V = class {
  constructor(e, t) {
    this.specification = e, this.name = t;
  }
  possiblyEvaluate(e, t) {
    if (e.isDataDriven()) throw Error("Value should not be data driven");
    return e.expression.evaluate(t);
  }
  interpolate(e, t, r) {
    if (Bd(e, t)) return Me(`Property "${this.name}" is trying to interpolate arrays of different lengths. Rendering may 'jump'.`), t;
    let i = this.specification.type, n = Kt[i];
    return n ? n(e, t, r) : e;
  }
}, j = class {
  constructor(e, t, r) {
    this.specification = e, this.name = t, this.overrides = r;
  }
  possiblyEvaluate(e, t, r, i) {
    return e.expression.kind === "constant" || e.expression.kind === "camera" ? new mt(this, { kind: "constant", value: e.expression.evaluate(t, null, {}, r, i) }, t) : new mt(this, e.expression, t);
  }
  interpolate(e, t, r) {
    if (e.value.kind !== "constant" || t.value.kind !== "constant") return e;
    if (e.value.value === void 0 || t.value.value === void 0) return new mt(this, { kind: "constant", value: void 0 }, e.parameters);
    if (Bd(e.value.value, t.value.value)) return Me(`Property "${this.name}" is trying to interpolate arrays of different lengths. Rendering may 'jump'.`), t;
    let i = this.specification.type, n = Kt[i];
    if (n) {
      let a = n(e.value.value, t.value.value, r);
      return new mt(this, { kind: "constant", value: a }, e.parameters);
    }
    return e;
  }
  evaluate(e, t, r, i, n, a) {
    return e.kind === "constant" ? e.value : e.evaluate(t, r, i, n, a);
  }
}, Sn = class extends j {
  possiblyEvaluate(e, t, r, i) {
    if (e.value === void 0) return new mt(this, { kind: "constant", value: void 0 }, t);
    if (e.expression.kind === "constant") {
      let n = e.expression.evaluate(t, null, {}, r, i), a = e.property.specification.type === "resolvedImage" && typeof n != "string" ? n.name : n, s = this._calculate(a, a, a, t);
      return new mt(this, { kind: "constant", value: s }, t);
    }
    if (e.expression.kind === "camera") {
      let n = this._calculate(e.expression.evaluate({ zoom: t.zoom - 1 }), e.expression.evaluate({ zoom: t.zoom }), e.expression.evaluate({ zoom: t.zoom + 1 }), t);
      return new mt(this, { kind: "constant", value: n }, t);
    }
    return new mt(this, e.expression, t);
  }
  evaluate(e, t, r, i, n, a) {
    if (e.kind === "source") {
      let s = e.evaluate(t, r, i, n, a);
      return this._calculate(s, s, s, t);
    }
    return e.kind === "composite" ? this._calculate(e.evaluate({ zoom: Math.floor(t.zoom) - 1 }, r, i), e.evaluate({ zoom: Math.floor(t.zoom) }, r, i), e.evaluate({ zoom: Math.floor(t.zoom) + 1 }, r, i), t) : e.value;
  }
  _calculate(e, t, r, i) {
    return i.zoom > i.zoomHistory.lastIntegerZoom ? { from: e, to: t } : { from: r, to: t };
  }
  interpolate(e) {
    return e;
  }
}, Ld = class {
  constructor(e, t) {
    this.specification = e, this.name = t;
  }
  possiblyEvaluate(e, t, r, i) {
    if (e.value !== void 0) {
      if (e.expression.kind === "constant") {
        let n = e.expression.evaluate(t, null, {}, r, i);
        return this._calculate(n, n, n, t);
      }
      return this._calculate(e.expression.evaluate(new le(Math.floor(t.zoom - 1), t)), e.expression.evaluate(new le(Math.floor(t.zoom), t)), e.expression.evaluate(new le(Math.floor(t.zoom + 1), t)), t);
    }
  }
  _calculate(e, t, r, i) {
    return i.zoom > i.zoomHistory.lastIntegerZoom ? { from: e, to: t } : { from: r, to: t };
  }
  interpolate(e) {
    return e;
  }
}, bs = class {
  constructor(e, t) {
    this.specification = e, this.name = t;
  }
  possiblyEvaluate(e, t, r, i) {
    return !!e.expression.evaluate(t, null, {}, r, i);
  }
  interpolate() {
    return !1;
  }
}, Je = class {
  constructor(e) {
    this.properties = e, this.defaultPropertyValues = {}, this.defaultTransitionablePropertyValues = {}, this.defaultTransitioningPropertyValues = {}, this.defaultPossiblyEvaluatedValues = {}, this.overridableProperties = [];
    for (let t in e) {
      let r = e[t];
      r.specification.overridable && this.overridableProperties.push(t);
      let i = this.defaultPropertyValues[t] = new Dn(r, void 0, r.name, void 0), n = this.defaultTransitionablePropertyValues[t] = new Wo(r, r.name, void 0);
      this.defaultTransitioningPropertyValues[t] = n.untransitioned(), this.defaultPossiblyEvaluatedValues[t] = i.possiblyEvaluate({});
    }
  }
};
P("DataDrivenProperty", j), P("DataConstantProperty", V), P("CrossFadedDataDrivenProperty", Sn), P("CrossFadedProperty", Ld), P("ColorRampProperty", bs);
const xh = " is a PAINT property not a LAYOUT property. Use get/setPaintProperty instead?", po = " is a LAYOUT property not a PAINT property. Use get/setLayoutProperty instead?";
var At = class extends Xm {
  constructor(e, t, r) {
    if (super(), this.id = e.id, this.type = e.type, this._globalState = r, this._featureFilter = { filter: () => !0, needGeometry: !1, getGlobalStateRefs: () => /* @__PURE__ */ new Set() }, this._visibilityExpression = sx(this.visibility, `layers[${this.id}].layout.visibility`, r), e.type !== "custom" && (this.metadata = e.metadata, this.minzoom = e.minzoom, this.maxzoom = e.maxzoom, e.type !== "background" && (this.source = e.source, this.sourceLayer = e["source-layer"], this.filter = e.filter, this._featureFilter = wn(e.filter, `layers[${this.id}].filter`, r)), t.layout && (this._unevaluatedLayout = new _x(t.layout, `layers[${this.id}].layout`, r)), t.paint)) {
      this._transitionablePaint = new wx(t.paint, `layers[${this.id}].paint`, r);
      for (let i in e.paint) this.setPaintProperty(i, e.paint[i], { validate: !1 });
      for (let i in e.layout) this.setLayoutProperty(i, e.layout[i], { validate: !1 });
      this._transitioningPaint = this._transitionablePaint.untransitioned(), this.paint = new vs(t.paint);
    }
  }
  setFilter(e) {
    this.filter = e, this._featureFilter = wn(e, `layers[${this.id}].filter`, this._globalState);
  }
  getCrossfadeParameters() {
    return this._crossfadeParameters;
  }
  getLayoutProperty(e) {
    var t;
    if (e === "visibility") return this.visibility;
    if ((t = this._transitionablePaint) != null && t.hasProperty(e)) throw Error(e + xh);
    if (!this._unevaluatedLayout) throw Error(`Cannot get layout property "${e}" on layer type "${this.type}" which has no layout properties.`);
    return this._unevaluatedLayout.getValue(e);
  }
  getLayoutAffectingGlobalStateRefs() {
    let e = /* @__PURE__ */ new Set();
    for (let t of this._visibilityExpression.getGlobalStateRefs()) e.add(t);
    if (this._unevaluatedLayout) for (let t in this._unevaluatedLayout._values) {
      let r = this._unevaluatedLayout._values[t];
      for (let i of r.getGlobalStateRefs()) e.add(i);
    }
    for (let t of this._featureFilter.getGlobalStateRefs()) e.add(t);
    return e;
  }
  getPaintAffectingGlobalStateRefs() {
    let e = new globalThis.Map();
    if (this._transitionablePaint) for (let t in this._transitionablePaint._values) {
      let r = this._transitionablePaint._values[t].value;
      for (let i of r.getGlobalStateRefs()) {
        let n = e.get(i) ?? [];
        n.push({ name: t, value: r.value }), e.set(i, n);
      }
    }
    return e;
  }
  getVisibilityAffectingGlobalStateRefs() {
    return this._visibilityExpression.getGlobalStateRefs();
  }
  setLayoutProperty(e, t, r = {}) {
    var i;
    e === "visibility" ? (this.visibility = t, this._visibilityExpression.setValue(t), this.recalculateVisibility()) : (i = this._transitionablePaint) != null && i.hasProperty(e) ? this.fire(new Oa(/* @__PURE__ */ Error(e + xh))) : t != null && this._validate(fh.layoutProperty, `layers.${this.id}.layout.${e}`, e, t, r) || this._unevaluatedLayout.setValue(e, t);
  }
  getPaintProperty(e) {
    var t, r;
    if (e.endsWith("-transition")) {
      let i = e.slice(0, -11);
      if (i === "visibility" || (t = this._unevaluatedLayout) != null && t.hasProperty(i)) throw Error(e + po);
      return this._transitionablePaint.getTransition(i);
    }
    if (e === "visibility" || (r = this._unevaluatedLayout) != null && r.hasProperty(e)) throw Error(e + po);
    return this._transitionablePaint.getValue(e);
  }
  setPaintProperty(e, t, r = {}) {
    var i;
    if (e === "visibility" || (i = this._unevaluatedLayout) != null && i.hasProperty(e)) return this.fire(new Oa(/* @__PURE__ */ Error(e + po))), !1;
    if (t != null && this._validate(fh.paintProperty, `layers.${this.id}.paint.${e}`, e, t, r)) return !1;
    if (e.endsWith("-transition")) return this._transitionablePaint.setTransition(e.slice(0, -11), t || void 0), !1;
    {
      let n = this._transitionablePaint._values[e], a = n.property.specification["property-type"] === "cross-faded-data-driven", s = n.value.isDataDriven(), o = n.value;
      this._transitionablePaint.setValue(e, t), this._handleSpecialPaintPropertyUpdate(e);
      let l = this._transitionablePaint._values[e].value;
      return l.isDataDriven() || s || a || this._handleOverridablePaintPropertyUpdate(e, o, l);
    }
  }
  _handleSpecialPaintPropertyUpdate(e) {
  }
  _handleOverridablePaintPropertyUpdate(e, t, r) {
    return !1;
  }
  isHidden(e = this.minzoom, t = !1) {
    return this.minzoom && e < (t ? Math.floor(this.minzoom) : this.minzoom) || this.maxzoom && e >= this.maxzoom ? !0 : this._evaluatedVisibility === "none";
  }
  updateTransitions(e) {
    this._transitioningPaint = this._transitionablePaint.transitioned(e, this._transitioningPaint);
  }
  retainPriorGlobalState(e, t) {
    var r;
    (r = this._transitionablePaint) == null || r.retainPriorGlobalState(e, t, this._transitioningPaint);
  }
  hasTransition() {
    return this._transitioningPaint.hasTransition();
  }
  recalculateVisibility() {
    this._evaluatedVisibility = this._visibilityExpression.evaluate();
  }
  recalculate(e, t) {
    e.getCrossfadeParameters && (this._crossfadeParameters = e.getCrossfadeParameters()), this._unevaluatedLayout && (this.layout = this._unevaluatedLayout.possiblyEvaluate(e, void 0, t)), this.paint = this._transitioningPaint.possiblyEvaluate(e, void 0, t);
  }
  serialize() {
    var t, r;
    let e = { id: this.id, type: this.type, source: this.source, "source-layer": this.sourceLayer, metadata: this.metadata, minzoom: this.minzoom, maxzoom: this.maxzoom, filter: this.filter, layout: (t = this._unevaluatedLayout) == null ? void 0 : t.serialize(), paint: (r = this._transitionablePaint) == null ? void 0 : r.serialize() };
    return this.visibility && (e.layout || (e.layout = {}), e.layout.visibility = this.visibility), Nm(e, (i, n) => i !== void 0 && !(n === "layout" && !Object.keys(i).length) && !(n === "paint" && !Object.keys(i).length));
  }
  _validate(e, t, r, i, n = {}) {
    return bx(this, e, { key: t, layerType: this.type, objectKey: r, value: i }, n);
  }
  is3D() {
    return !1;
  }
  isTileClipped() {
    return !1;
  }
  hasOffscreenPass() {
    return !1;
  }
  resize() {
  }
  isStateDependent() {
    for (let e in this.paint._values) {
      let t = this.paint.get(e);
      if (t instanceof mt && gi(t.property.specification) && (t.value.kind === "source" || t.value.kind === "composite") && t.value.isStateDependent) return !0;
    }
    return !1;
  }
};
const Dx = { Int8: Int8Array, Uint8: Uint8Array, Int16: Int16Array, Uint16: Uint16Array, Int32: Int32Array, Uint32: Uint32Array, Float32: Float32Array };
var $n = class {
  constructor(e, t) {
    this._structArray = e, this._pos1 = t * this.size, this._pos2 = this._pos1 / 2, this._pos4 = this._pos1 / 4, this._pos8 = this._pos1 / 8;
  }
}, ve = class {
  constructor() {
    this.isTransferred = !1, this.capacity = -1, this.resize(0);
  }
  static serialize(e, t) {
    return e._trim(), t && (e.isTransferred = !0, t.push(e.arrayBuffer)), { length: e.length, arrayBuffer: e.arrayBuffer };
  }
  static deserialize(e) {
    let t = Object.create(this.prototype);
    return t.arrayBuffer = e.arrayBuffer, t.length = e.length, t.capacity = e.arrayBuffer.byteLength / t.bytesPerElement, t._refreshViews(), t;
  }
  _trim() {
    this.length !== this.capacity && (this.capacity = this.length, this.arrayBuffer = this.arrayBuffer.slice(0, this.length * this.bytesPerElement), this._refreshViews());
  }
  clear() {
    this.length = 0;
  }
  resize(e) {
    this.reserve(e), this.length = e;
  }
  reserve(e) {
    if (e > this.capacity) {
      this.capacity = Math.max(e, Math.floor(this.capacity * 5), 128), this.arrayBuffer = new ArrayBuffer(this.capacity * this.bytesPerElement);
      let t = this.uint8;
      this._refreshViews(), t && this.uint8.set(t);
    }
  }
  _refreshViews() {
    throw Error("_refreshViews() must be implemented by each concrete StructArray layout");
  }
  freeBufferAfterUpload() {
    this.arrayBuffer = /* @__PURE__ */ new ArrayBuffer(0), this._refreshViews();
  }
};
function Te(e, t = 1) {
  let r = 0, i = 0;
  return { members: e.map((n) => {
    let a = Sx(n.type), s = r = vh(r, Math.max(t, a)), o = n.components || 1;
    return i = Math.max(i, a), r += a * o, { name: n.name, type: n.type, components: o, offset: s };
  }), size: vh(r, Math.max(i, t)), alignment: t };
}
function Sx(e) {
  return Dx[e].BYTES_PER_ELEMENT;
}
function vh(e, t) {
  return Math.ceil(e / t) * t;
}
var An = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t) {
    let r = this.length;
    return this.resize(r + 1), this.emplace(r, e, t);
  }
  emplace(e, t, r) {
    let i = e * 2;
    return this.int16[i + 0] = t, this.int16[i + 1] = r, e;
  }
};
An.prototype.bytesPerElement = 4, P("StructArrayLayout2i4", An);
var Zo = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r) {
    let i = this.length;
    return this.resize(i + 1), this.emplace(i, e, t, r);
  }
  emplace(e, t, r, i) {
    let n = e * 3;
    return this.int16[n + 0] = t, this.int16[n + 1] = r, this.int16[n + 2] = i, e;
  }
};
Zo.prototype.bytesPerElement = 6, P("StructArrayLayout3i6", Zo);
var bh = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i) {
    let n = this.length;
    return this.resize(n + 1), this.emplace(n, e, t, r, i);
  }
  emplace(e, t, r, i, n) {
    let a = e * 4;
    return this.int16[a + 0] = t, this.int16[a + 1] = r, this.int16[a + 2] = i, this.int16[a + 3] = n, e;
  }
};
bh.prototype.bytesPerElement = 8, P("StructArrayLayout4i8", bh);
var Ho = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a) {
    let s = this.length;
    return this.resize(s + 1), this.emplace(s, e, t, r, i, n, a);
  }
  emplace(e, t, r, i, n, a, s) {
    let o = e * 6;
    return this.int16[o + 0] = t, this.int16[o + 1] = r, this.int16[o + 2] = i, this.int16[o + 3] = n, this.int16[o + 4] = a, this.int16[o + 5] = s, e;
  }
};
Ho.prototype.bytesPerElement = 12, P("StructArrayLayout2i4i12", Ho);
var Ko = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer), this.int8 = new Int8Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o) {
    let l = this.length;
    return this.resize(l + 1), this.emplace(l, e, t, r, i, n, a, s, o);
  }
  emplace(e, t, r, i, n, a, s, o, l) {
    let u = e * 5, c = e * 10;
    return this.int16[u + 0] = t, this.int16[u + 1] = r, this.uint8[c + 4] = i, this.uint8[c + 5] = n, this.uint8[c + 6] = a, this.uint8[c + 7] = s, this.int8[c + 8] = o, this.int8[c + 9] = l, e;
  }
};
Ko.prototype.bytesPerElement = 10, P("StructArrayLayout2i4ub2b10", Ko);
var En = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t) {
    let r = this.length;
    return this.resize(r + 1), this.emplace(r, e, t);
  }
  emplace(e, t, r) {
    let i = e * 2;
    return this.float32[i + 0] = t, this.float32[i + 1] = r, e;
  }
};
En.prototype.bytesPerElement = 8, P("StructArrayLayout2f8", En);
var Jo = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o, l, u) {
    let c = this.length;
    return this.resize(c + 1), this.emplace(c, e, t, r, i, n, a, s, o, l, u);
  }
  emplace(e, t, r, i, n, a, s, o, l, u, c) {
    let h = e * 10;
    return this.uint16[h + 0] = t, this.uint16[h + 1] = r, this.uint16[h + 2] = i, this.uint16[h + 3] = n, this.uint16[h + 4] = a, this.uint16[h + 5] = s, this.uint16[h + 6] = o, this.uint16[h + 7] = l, this.uint16[h + 8] = u, this.uint16[h + 9] = c, e;
  }
};
Jo.prototype.bytesPerElement = 20, P("StructArrayLayout10ui20", Jo);
var Qo = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o) {
    let l = this.length;
    return this.resize(l + 1), this.emplace(l, e, t, r, i, n, a, s, o);
  }
  emplace(e, t, r, i, n, a, s, o, l) {
    let u = e * 8;
    return this.uint16[u + 0] = t, this.uint16[u + 1] = r, this.uint16[u + 2] = i, this.uint16[u + 3] = n, this.uint16[u + 4] = a, this.uint16[u + 5] = s, this.uint16[u + 6] = o, this.uint16[u + 7] = l, e;
  }
};
Qo.prototype.bytesPerElement = 16, P("StructArrayLayout8ui16", Qo);
var el = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o, l, u, c, h, p) {
    let f = this.length;
    return this.resize(f + 1), this.emplace(f, e, t, r, i, n, a, s, o, l, u, c, h, p);
  }
  emplace(e, t, r, i, n, a, s, o, l, u, c, h, p, f) {
    let d = e * 14, y = e * 7;
    return this.int16[d + 0] = t, this.int16[d + 1] = r, this.int16[d + 2] = i, this.int16[d + 3] = n, this.uint16[d + 4] = a, this.uint16[d + 5] = s, this.uint16[d + 6] = o, this.uint16[d + 7] = l, this.int16[d + 8] = u, this.int16[d + 9] = c, this.int16[d + 10] = h, this.int16[d + 11] = p, this.float32[y + 6] = f, e;
  }
};
el.prototype.bytesPerElement = 28, P("StructArrayLayout4i4ui4i1f28", el);
var tl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r) {
    let i = this.length;
    return this.resize(i + 1), this.emplace(i, e, t, r);
  }
  emplace(e, t, r, i) {
    let n = e * 3;
    return this.float32[n + 0] = t, this.float32[n + 1] = r, this.float32[n + 2] = i, e;
  }
};
tl.prototype.bytesPerElement = 12, P("StructArrayLayout3f12", tl);
var rl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint32 = new Uint32Array(this.arrayBuffer);
  }
  emplaceBack(e) {
    let t = this.length;
    return this.resize(t + 1), this.emplace(t, e);
  }
  emplace(e, t) {
    let r = e * 1;
    return this.uint32[r + 0] = t, e;
  }
};
rl.prototype.bytesPerElement = 4, P("StructArrayLayout1ul4", rl);
var il = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer), this.uint32 = new Uint32Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o, l) {
    let u = this.length;
    return this.resize(u + 1), this.emplace(u, e, t, r, i, n, a, s, o, l);
  }
  emplace(e, t, r, i, n, a, s, o, l, u) {
    let c = e * 10, h = e * 5;
    return this.int16[c + 0] = t, this.int16[c + 1] = r, this.int16[c + 2] = i, this.int16[c + 3] = n, this.int16[c + 4] = a, this.int16[c + 5] = s, this.uint32[h + 3] = o, this.uint16[c + 8] = l, this.uint16[c + 9] = u, e;
  }
};
il.prototype.bytesPerElement = 20, P("StructArrayLayout6i1ul2ui20", il);
var nl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a) {
    let s = this.length;
    return this.resize(s + 1), this.emplace(s, e, t, r, i, n, a);
  }
  emplace(e, t, r, i, n, a, s) {
    let o = e * 6;
    return this.int16[o + 0] = t, this.int16[o + 1] = r, this.int16[o + 2] = i, this.int16[o + 3] = n, this.int16[o + 4] = a, this.int16[o + 5] = s, e;
  }
};
nl.prototype.bytesPerElement = 12, P("StructArrayLayout2i2i2i12", nl);
var wh = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n) {
    let a = this.length;
    return this.resize(a + 1), this.emplace(a, e, t, r, i, n);
  }
  emplace(e, t, r, i, n, a) {
    let s = e * 4, o = e * 8;
    return this.float32[s + 0] = t, this.float32[s + 1] = r, this.float32[s + 2] = i, this.int16[o + 6] = n, this.int16[o + 7] = a, e;
  }
};
wh.prototype.bytesPerElement = 16, P("StructArrayLayout2f1f2i16", wh);
var al = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a) {
    let s = this.length;
    return this.resize(s + 1), this.emplace(s, e, t, r, i, n, a);
  }
  emplace(e, t, r, i, n, a, s) {
    let o = e * 16, l = e * 4, u = e * 8;
    return this.uint8[o + 0] = t, this.uint8[o + 1] = r, this.float32[l + 1] = i, this.float32[l + 2] = n, this.int16[u + 6] = a, this.int16[u + 7] = s, e;
  }
};
al.prototype.bytesPerElement = 16, P("StructArrayLayout2ub2f2i16", al);
var sl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r) {
    let i = this.length;
    return this.resize(i + 1), this.emplace(i, e, t, r);
  }
  emplace(e, t, r, i) {
    let n = e * 3;
    return this.uint16[n + 0] = t, this.uint16[n + 1] = r, this.uint16[n + 2] = i, e;
  }
};
sl.prototype.bytesPerElement = 6, P("StructArrayLayout3ui6", sl);
var ol = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer), this.uint32 = new Uint32Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g) {
    let v = this.length;
    return this.resize(v + 1), this.emplace(v, e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g);
  }
  emplace(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g, v) {
    let x = e * 26, b = e * 13, w = e * 52;
    return this.int16[x + 0] = t, this.int16[x + 1] = r, this.uint16[x + 2] = i, this.uint16[x + 3] = n, this.uint32[b + 2] = a, this.uint32[b + 3] = s, this.uint32[b + 4] = o, this.uint16[x + 10] = l, this.uint16[x + 11] = u, this.uint16[x + 12] = c, this.float32[b + 7] = h, this.float32[b + 8] = p, this.uint8[w + 36] = f, this.uint8[w + 37] = d, this.uint8[w + 38] = y, this.uint32[b + 10] = m, this.int16[x + 22] = g, this.float32[b + 12] = v, e;
  }
};
ol.prototype.bytesPerElement = 52, P("StructArrayLayout2i2ui3ul3ui2f3ub1ul1i1f52", ol);
var ll = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.int16 = new Int16Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer), this.uint32 = new Uint32Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g, v, x, b, w, D, _, A, E, R, B, L) {
    let $ = this.length;
    return this.resize($ + 1), this.emplace($, e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g, v, x, b, w, D, _, A, E, R, B, L);
  }
  emplace(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g, v, x, b, w, D, _, A, E, R, B, L, $) {
    let M = e * 34, C = e * 17;
    return this.int16[M + 0] = t, this.int16[M + 1] = r, this.int16[M + 2] = i, this.int16[M + 3] = n, this.int16[M + 4] = a, this.int16[M + 5] = s, this.int16[M + 6] = o, this.int16[M + 7] = l, this.uint16[M + 8] = u, this.uint16[M + 9] = c, this.uint16[M + 10] = h, this.uint16[M + 11] = p, this.uint16[M + 12] = f, this.uint16[M + 13] = d, this.uint16[M + 14] = y, this.uint16[M + 15] = m, this.uint16[M + 16] = g, this.uint16[M + 17] = v, this.uint16[M + 18] = x, this.uint16[M + 19] = b, this.uint16[M + 20] = w, this.uint16[M + 21] = D, this.uint16[M + 22] = _, this.uint32[C + 12] = A, this.float32[C + 13] = E, this.float32[C + 14] = R, this.uint16[M + 30] = B, this.uint16[M + 31] = L, this.float32[C + 16] = $, e;
  }
};
ll.prototype.bytesPerElement = 68, P("StructArrayLayout8i15ui1ul2f2ui1f68", ll);
var Ya = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e) {
    let t = this.length;
    return this.resize(t + 1), this.emplace(t, e);
  }
  emplace(e, t) {
    let r = e * 1;
    return this.float32[r + 0] = t, e;
  }
};
Ya.prototype.bytesPerElement = 4, P("StructArrayLayout1f4", Ya);
var ul = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r) {
    let i = this.length;
    return this.resize(i + 1), this.emplace(i, e, t, r);
  }
  emplace(e, t, r, i) {
    let n = e * 6, a = e * 3;
    return this.uint16[n + 0] = t, this.float32[a + 1] = r, this.float32[a + 2] = i, e;
  }
};
ul.prototype.bytesPerElement = 12, P("StructArrayLayout1ui2f12", ul);
var cl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint32 = new Uint32Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r) {
    let i = this.length;
    return this.resize(i + 1), this.emplace(i, e, t, r);
  }
  emplace(e, t, r, i) {
    let n = e * 2, a = e * 4;
    return this.uint32[n + 0] = t, this.uint16[a + 2] = r, this.uint16[a + 3] = i, e;
  }
};
cl.prototype.bytesPerElement = 8, P("StructArrayLayout1ul2ui8", cl);
var hl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e, t) {
    let r = this.length;
    return this.resize(r + 1), this.emplace(r, e, t);
  }
  emplace(e, t, r) {
    let i = e * 2;
    return this.uint16[i + 0] = t, this.uint16[i + 1] = r, e;
  }
};
hl.prototype.bytesPerElement = 4, P("StructArrayLayout2ui4", hl);
var _h = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.uint16 = new Uint16Array(this.arrayBuffer);
  }
  emplaceBack(e) {
    let t = this.length;
    return this.resize(t + 1), this.emplace(t, e);
  }
  emplace(e, t) {
    let r = e * 1;
    return this.uint16[r + 0] = t, e;
  }
};
_h.prototype.bytesPerElement = 2, P("StructArrayLayout1ui2", _h);
var pl = class extends ve {
  _refreshViews() {
    this.uint8 = new Uint8Array(this.arrayBuffer), this.float32 = new Float32Array(this.arrayBuffer);
  }
  emplaceBack(e, t, r, i) {
    let n = this.length;
    return this.resize(n + 1), this.emplace(n, e, t, r, i);
  }
  emplace(e, t, r, i, n) {
    let a = e * 4;
    return this.float32[a + 0] = t, this.float32[a + 1] = r, this.float32[a + 2] = i, this.float32[a + 3] = n, e;
  }
};
pl.prototype.bytesPerElement = 16, P("StructArrayLayout4f16", pl);
var zd = class extends $n {
  get anchorPointX() {
    return this._structArray.int16[this._pos2 + 0];
  }
  get anchorPointY() {
    return this._structArray.int16[this._pos2 + 1];
  }
  get x1() {
    return this._structArray.int16[this._pos2 + 2];
  }
  get y1() {
    return this._structArray.int16[this._pos2 + 3];
  }
  get x2() {
    return this._structArray.int16[this._pos2 + 4];
  }
  get y2() {
    return this._structArray.int16[this._pos2 + 5];
  }
  get featureIndex() {
    return this._structArray.uint32[this._pos4 + 3];
  }
  get sourceLayerIndex() {
    return this._structArray.uint16[this._pos2 + 8];
  }
  get bucketIndex() {
    return this._structArray.uint16[this._pos2 + 9];
  }
  get anchorPoint() {
    return new T(this.anchorPointX, this.anchorPointY);
  }
};
zd.prototype.size = 20;
var Vd = class extends il {
  get(e) {
    return new zd(this, e);
  }
};
P("CollisionBoxArray", Vd);
var Od = class extends $n {
  get anchorX() {
    return this._structArray.int16[this._pos2 + 0];
  }
  get anchorY() {
    return this._structArray.int16[this._pos2 + 1];
  }
  get glyphStartIndex() {
    return this._structArray.uint16[this._pos2 + 2];
  }
  get numGlyphs() {
    return this._structArray.uint16[this._pos2 + 3];
  }
  get vertexStartIndex() {
    return this._structArray.uint32[this._pos4 + 2];
  }
  get lineStartIndex() {
    return this._structArray.uint32[this._pos4 + 3];
  }
  get lineLength() {
    return this._structArray.uint32[this._pos4 + 4];
  }
  get segment() {
    return this._structArray.uint16[this._pos2 + 10];
  }
  get lowerSize() {
    return this._structArray.uint16[this._pos2 + 11];
  }
  get upperSize() {
    return this._structArray.uint16[this._pos2 + 12];
  }
  get lineOffsetX() {
    return this._structArray.float32[this._pos4 + 7];
  }
  get lineOffsetY() {
    return this._structArray.float32[this._pos4 + 8];
  }
  get writingMode() {
    return this._structArray.uint8[this._pos1 + 36];
  }
  get placedOrientation() {
    return this._structArray.uint8[this._pos1 + 37];
  }
  set placedOrientation(e) {
    this._structArray.uint8[this._pos1 + 37] = e;
  }
  get hidden() {
    return this._structArray.uint8[this._pos1 + 38];
  }
  set hidden(e) {
    this._structArray.uint8[this._pos1 + 38] = e;
  }
  get crossTileID() {
    return this._structArray.uint32[this._pos4 + 10];
  }
  set crossTileID(e) {
    this._structArray.uint32[this._pos4 + 10] = e;
  }
  get associatedIconIndex() {
    return this._structArray.int16[this._pos2 + 22];
  }
  get heightOffset() {
    return this._structArray.float32[this._pos4 + 12];
  }
};
Od.prototype.size = 52;
var Rd = class extends ol {
  get(e) {
    return new Od(this, e);
  }
};
P("PlacedSymbolArray", Rd);
var $d = class extends $n {
  get anchorX() {
    return this._structArray.int16[this._pos2 + 0];
  }
  get anchorY() {
    return this._structArray.int16[this._pos2 + 1];
  }
  get rightJustifiedTextSymbolIndex() {
    return this._structArray.int16[this._pos2 + 2];
  }
  get centerJustifiedTextSymbolIndex() {
    return this._structArray.int16[this._pos2 + 3];
  }
  get leftJustifiedTextSymbolIndex() {
    return this._structArray.int16[this._pos2 + 4];
  }
  get verticalPlacedTextSymbolIndex() {
    return this._structArray.int16[this._pos2 + 5];
  }
  get placedIconSymbolIndex() {
    return this._structArray.int16[this._pos2 + 6];
  }
  get verticalPlacedIconSymbolIndex() {
    return this._structArray.int16[this._pos2 + 7];
  }
  get key() {
    return this._structArray.uint16[this._pos2 + 8];
  }
  get textBoxStartIndex() {
    return this._structArray.uint16[this._pos2 + 9];
  }
  get textBoxEndIndex() {
    return this._structArray.uint16[this._pos2 + 10];
  }
  get verticalTextBoxStartIndex() {
    return this._structArray.uint16[this._pos2 + 11];
  }
  get verticalTextBoxEndIndex() {
    return this._structArray.uint16[this._pos2 + 12];
  }
  get iconBoxStartIndex() {
    return this._structArray.uint16[this._pos2 + 13];
  }
  get iconBoxEndIndex() {
    return this._structArray.uint16[this._pos2 + 14];
  }
  get verticalIconBoxStartIndex() {
    return this._structArray.uint16[this._pos2 + 15];
  }
  get verticalIconBoxEndIndex() {
    return this._structArray.uint16[this._pos2 + 16];
  }
  get featureIndex() {
    return this._structArray.uint16[this._pos2 + 17];
  }
  get numHorizontalGlyphVertices() {
    return this._structArray.uint16[this._pos2 + 18];
  }
  get numVerticalGlyphVertices() {
    return this._structArray.uint16[this._pos2 + 19];
  }
  get numIconVertices() {
    return this._structArray.uint16[this._pos2 + 20];
  }
  get numVerticalIconVertices() {
    return this._structArray.uint16[this._pos2 + 21];
  }
  get useRuntimeCollisionCircles() {
    return this._structArray.uint16[this._pos2 + 22];
  }
  get crossTileID() {
    return this._structArray.uint32[this._pos4 + 12];
  }
  set crossTileID(e) {
    this._structArray.uint32[this._pos4 + 12] = e;
  }
  get textBoxScale() {
    return this._structArray.float32[this._pos4 + 13];
  }
  get collisionCircleDiameter() {
    return this._structArray.float32[this._pos4 + 14];
  }
  get textAnchorOffsetStartIndex() {
    return this._structArray.uint16[this._pos2 + 30];
  }
  get textAnchorOffsetEndIndex() {
    return this._structArray.uint16[this._pos2 + 31];
  }
  get heightOffset() {
    return this._structArray.float32[this._pos4 + 16];
  }
};
$d.prototype.size = 68;
var Nd = class extends ll {
  get(e) {
    return new $d(this, e);
  }
};
P("SymbolInstanceArray", Nd);
var Ud = class extends Ya {
  getoffsetX(e) {
    return this.float32[e * 1 + 0];
  }
};
P("GlyphOffsetArray", Ud);
var jd = class extends Zo {
  getx(e) {
    return this.int16[e * 3 + 0];
  }
  gety(e) {
    return this.int16[e * 3 + 1];
  }
  gettileUnitDistanceFromAnchor(e) {
    return this.int16[e * 3 + 2];
  }
};
P("SymbolLineVertexArray", jd);
var qd = class extends $n {
  get textAnchor() {
    return this._structArray.uint16[this._pos2 + 0];
  }
  get textOffset0() {
    return this._structArray.float32[this._pos4 + 1];
  }
  get textOffset1() {
    return this._structArray.float32[this._pos4 + 2];
  }
};
qd.prototype.size = 12;
var Gd = class extends ul {
  get(e) {
    return new qd(this, e);
  }
};
P("TextAnchorOffsetArray", Gd);
var Xd = class extends $n {
  get featureIndex() {
    return this._structArray.uint32[this._pos4 + 0];
  }
  get sourceLayerIndex() {
    return this._structArray.uint16[this._pos2 + 2];
  }
  get bucketIndex() {
    return this._structArray.uint16[this._pos2 + 3];
  }
};
Xd.prototype.size = 8;
var Yd = class extends cl {
  get(e) {
    return new Xd(this, e);
  }
};
P("FeatureIndexArray", Yd);
var Ax = class extends An {
}, Ex = class extends An {
}, Tx = class extends An {
}, Ix = class extends Ho {
}, Cx = class extends Ko {
}, kx = class extends En {
}, Wr = class extends Jo {
}, Dh = class extends Qo {
}, Fx = class extends el {
}, Mx = class extends tl {
}, Px = class extends rl {
}, Sh = class extends nl {
}, Bx = class extends al {
}, Nn = class extends sl {
}, fl = class extends hl {
};
const Lx = Te([{ name: "a_pos", components: 2, type: "Int16" }], 4), zx = Lx.members;
var ut = class Jr {
  constructor(t = []) {
    this._forceNewSegmentOnNextPrepare = !1, this.segments = t;
  }
  prepareSegment(t, r, i, n) {
    let a = this.segments[this.segments.length - 1];
    return t > Jr.MAX_VERTEX_ARRAY_LENGTH && Me(`Max vertices per segment is ${Jr.MAX_VERTEX_ARRAY_LENGTH}: bucket requested ${t}. Consider using the \`fillLargeMeshArrays\` function if you require meshes with more than ${Jr.MAX_VERTEX_ARRAY_LENGTH} vertices.`), this._forceNewSegmentOnNextPrepare || !a || a.vertexLength + t > Jr.MAX_VERTEX_ARRAY_LENGTH || a.sortKey !== n ? this.createNewSegment(r, i, n) : a;
  }
  createNewSegment(t, r, i) {
    let n = { vertexOffset: t.length, primitiveOffset: r.length, vertexLength: 0, primitiveLength: 0, vaos: {} };
    return i !== void 0 && (n.sortKey = i), this._forceNewSegmentOnNextPrepare = !1, this.segments.push(n), n;
  }
  getOrCreateLatestSegment(t, r, i) {
    return this.prepareSegment(0, t, r, i);
  }
  forceNewSegmentOnNextPrepare() {
    this._forceNewSegmentOnNextPrepare = !0;
  }
  get() {
    return this.segments;
  }
  destroy() {
    for (let t of this.segments) for (let r in t.vaos) t.vaos[r].destroy();
  }
  static simpleSegment(t, r, i, n) {
    return new Jr([{ vertexOffset: t, primitiveOffset: r, vertexLength: i, primitiveLength: n, vaos: {}, sortKey: 0 }]);
  }
};
ut.MAX_VERTEX_ARRAY_LENGTH = 2 ** 16 - 1, P("SegmentVector", ut);
function Ah(e, t) {
  return e = rt(Math.floor(e), 0, 255), t = rt(Math.floor(t), 0, 255), 256 * e + t;
}
const Vx = Te([{ name: "a_pattern_from", components: 4, type: "Uint16" }, { name: "a_pattern_to", components: 4, type: "Uint16" }, { name: "a_pixel_ratio_from", components: 1, type: "Uint16" }, { name: "a_pixel_ratio_to", components: 1, type: "Uint16" }]), Ox = Te([{ name: "a_dasharray_from", components: 4, type: "Uint16" }, { name: "a_dasharray_to", components: 4, type: "Uint16" }]);
var Rx = /* @__PURE__ */ Kl(((e, t) => {
  function r(i, n) {
    for (var a = i.length & 3, s = i.length - a, o = n, l, u = 3432918353, c = 461845907, h, p = 0; p < s; ) h = i.charCodeAt(p) & 255 | (i.charCodeAt(++p) & 255) << 8 | (i.charCodeAt(++p) & 255) << 16 | (i.charCodeAt(++p) & 255) << 24, ++p, h = (h & 65535) * u + (((h >>> 16) * u & 65535) << 16) | 0, h = h << 15 | h >>> 17, h = (h & 65535) * c + (((h >>> 16) * c & 65535) << 16) | 0, o ^= h, o = o << 13 | o >>> 19, l = (o & 65535) * 5 + (((o >>> 16) * 5 & 65535) << 16) | 0, o = (l & 65535) + 27492 + (((l >>> 16) + 58964 & 65535) << 16);
    switch (h = 0, a) {
      case 3:
        h ^= (i.charCodeAt(p + 2) & 255) << 16;
      case 2:
        h ^= (i.charCodeAt(p + 1) & 255) << 8;
      case 1:
        h ^= i.charCodeAt(p) & 255, h = (h & 65535) * u + (((h >>> 16) * u & 65535) << 16) | 0, h = h << 15 | h >>> 17, h = (h & 65535) * c + (((h >>> 16) * c & 65535) << 16) | 0, o ^= h;
    }
    return o ^= i.length, o ^= o >>> 16, o = (o & 65535) * 2246822507 + (((o >>> 16) * 2246822507 & 65535) << 16) | 0, o ^= o >>> 13, o = (o & 65535) * 3266489909 + (((o >>> 16) * 3266489909 & 65535) << 16) | 0, o ^= o >>> 16, o >>> 0;
  }
  t !== void 0 && (t.exports = r);
})), $x = /* @__PURE__ */ Kl(((e, t) => {
  function r(i, n) {
    for (var a = i.length, s = n ^ a, o = 0, l; a >= 4; ) l = i.charCodeAt(o) & 255 | (i.charCodeAt(++o) & 255) << 8 | (i.charCodeAt(++o) & 255) << 16 | (i.charCodeAt(++o) & 255) << 24, l = (l & 65535) * 1540483477 + (((l >>> 16) * 1540483477 & 65535) << 16), l ^= l >>> 24, l = (l & 65535) * 1540483477 + (((l >>> 16) * 1540483477 & 65535) << 16), s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16) ^ l, a -= 4, ++o;
    switch (a) {
      case 3:
        s ^= (i.charCodeAt(o + 2) & 255) << 16;
      case 2:
        s ^= (i.charCodeAt(o + 1) & 255) << 8;
      case 1:
        s ^= i.charCodeAt(o) & 255, s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16);
    }
    return s ^= s >>> 13, s = (s & 65535) * 1540483477 + (((s >>> 16) * 1540483477 & 65535) << 16), s ^= s >>> 15, s >>> 0;
  }
  t.exports = r;
})), Wa = /* @__PURE__ */ Em((/* @__PURE__ */ Kl(((e, t) => {
  var r = Rx(), i = $x();
  t.exports = r, t.exports.murmur3 = r, t.exports.murmur2 = i;
})))()), Wd = class Zd {
  constructor() {
    this.ids = [], this.positions = [], this.indexed = !1;
  }
  add(t, r, i, n) {
    this.ids.push(Eh(t)), this.positions.push(r, i, n);
  }
  getPositions(t) {
    if (!this.indexed) throw Error("Trying to get index, but feature positions are not indexed");
    let r = Eh(t), i = 0, n = this.ids.length - 1;
    for (; i < n; ) {
      let s = i + n >> 1;
      this.ids[s] >= r ? n = s : i = s + 1;
    }
    let a = [];
    for (; this.ids[i] === r; ) {
      let s = this.positions[3 * i], o = this.positions[3 * i + 1], l = this.positions[3 * i + 2];
      a.push({ index: s, start: o, end: l }), i++;
    }
    return a;
  }
  static serialize(t, r) {
    let i = new Float64Array(t.ids), n = new Uint32Array(t.positions);
    return dl(i, n, 0, i.length - 1), r && r.push(i.buffer, n.buffer), { ids: i, positions: n };
  }
  static deserialize(t) {
    let r = new Zd();
    return r.ids = t.ids, r.positions = t.positions, r.indexed = !0, r;
  }
};
function Eh(e) {
  let t = +e;
  return !isNaN(t) && t <= 2 ** 53 - 1 ? t : (0, Wa.default)(String(e));
}
function dl(e, t, r, i) {
  let n = !1;
  for (; r < i; ) {
    let a = e[n ? r + Math.floor(Math.random() * (i - r)) : r + i >> 1], s = r - 1, o = i + 1;
    for (; ; ) {
      do
        s++;
      while (e[s] < a);
      do
        o--;
      while (e[o] > a);
      if (s >= o) break;
      fa(e, s, o), fa(t, 3 * s, 3 * o), fa(t, 3 * s + 1, 3 * o + 1), fa(t, 3 * s + 2, 3 * o + 2);
    }
    n = Math.min(o - r, i - o) < i - r >> 3, o - r < i - o ? (dl(e, t, r, o), r = o + 1) : (dl(e, t, o + 1, i), i = o);
  }
}
function fa(e, t, r) {
  let i = e[t];
  e[t] = e[r], e[r] = i;
}
P("FeaturePositionMap", Wd);
var Tu = class {
  constructor(e, t) {
    this.gl = e.gl, this.location = t;
  }
}, Iu = class extends Tu {
  constructor(e, t) {
    super(e, t), this.current = 0;
  }
  set(e) {
    this.current !== e && (this.current = e, this.gl.uniform1f(this.location, e));
  }
}, Nx = class extends Tu {
  constructor(e, t) {
    super(e, t), this.current = [0, 0, 0, 0];
  }
  set(e) {
    (e[0] !== this.current[0] || e[1] !== this.current[1] || e[2] !== this.current[2] || e[3] !== this.current[3]) && (this.current = e, this.gl.uniform4f(this.location, e[0], e[1], e[2], e[3]));
  }
}, Ux = class extends Tu {
  constructor(e, t) {
    super(e, t), this.current = fe.transparent;
  }
  set(e) {
    (e.r !== this.current.r || e.g !== this.current.g || e.b !== this.current.b || e.a !== this.current.a) && (this.current = e, this.gl.uniform4f(this.location, e.r, e.g, e.b, e.a));
  }
};
function yl(e) {
  return [Ah(255 * e.r, 255 * e.g), Ah(255 * e.b, 255 * e.a)];
}
var en = class {
  constructor(e, t, r) {
    this.value = e, this.uniformNames = t.map((i) => `u_${i}`), this.type = r;
  }
  setUniform(e, t, r) {
    e.set(r.constantOr(this.value));
  }
  getBinding(e, t, r) {
    return this.type === "color" ? new Ux(e, t) : new Iu(e, t);
  }
}, Sr = class {
  constructor(e, t) {
    this.uniformNames = t.map((r) => `u_${r}`), this.patternFrom = null, this.patternTo = null, this.dashFrom = null, this.dashTo = null, this.pixelRatioFrom = 1, this.pixelRatioTo = 1;
  }
  setConstantPatternPositions(e, t) {
    this.pixelRatioFrom = t.pixelRatio, this.pixelRatioTo = e.pixelRatio, this.patternFrom = t.tlbr, this.patternTo = e.tlbr;
  }
  setConstantDashPositions(e, t) {
    this.dashTo = [0, e.y, e.height, e.width], this.dashFrom = [0, t.y, t.height, t.width];
  }
  setUniform(e, t, r, i) {
    let n = null;
    i === "u_pattern_to" ? n = this.patternTo : i === "u_pattern_from" ? n = this.patternFrom : i === "u_dasharray_to" ? n = this.dashTo : i === "u_dasharray_from" ? n = this.dashFrom : i === "u_pixel_ratio_to" ? n = this.pixelRatioTo : i === "u_pixel_ratio_from" && (n = this.pixelRatioFrom), n !== null && e.set(n);
  }
  getBinding(e, t, r) {
    return r.startsWith("u_pattern") || r.startsWith("u_dasharray_") ? new Nx(e, t) : new Iu(e, t);
  }
}, Nt = class {
  constructor(e, t, r, i) {
    this.expression = e, this.type = r, this.maxValue = 0, this.paintVertexAttributes = t.map((n) => ({ name: `a_${n}`, type: "Float32", components: r === "color" ? 2 : 1, offset: 0 })), this.paintVertexArray = new i();
  }
  populatePaintArray(e, t, r) {
    let i = this.paintVertexArray.length, n = this.expression.evaluate(new le(0, r), t, {}, r.canonical, [], r.formattedSection);
    this.paintVertexArray.resize(e), this._setPaintValue(i, e, n);
  }
  updatePaintArray(e, t, r, i, n) {
    let a = this.expression.evaluate(new le(0, n), r, i);
    this._setPaintValue(e, t, a);
  }
  _setPaintValue(e, t, r) {
    if (this.type === "color") {
      let i = yl(r);
      for (let n = e; n < t; n++) this.paintVertexArray.emplace(n, i[0], i[1]);
    } else {
      for (let i = e; i < t; i++) this.paintVertexArray.emplace(i, r);
      this.maxValue = Math.max(this.maxValue, Math.abs(r));
    }
  }
  upload(e) {
    var t, r;
    (t = this.paintVertexArray) != null && t.arrayBuffer.byteLength && ((r = this.paintVertexBuffer) != null && r.buffer ? this.paintVertexBuffer.updateData(this.paintVertexArray) : this.paintVertexBuffer = e.createVertexBuffer(this.paintVertexArray, this.paintVertexAttributes, this.expression.isStateDependent));
  }
  destroy() {
    this.paintVertexBuffer && this.paintVertexBuffer.destroy();
  }
}, wt = class {
  constructor(e, t, r, i, n, a) {
    this.expression = e, this.uniformNames = t.map((s) => `u_${s}_t`), this.type = r, this.useIntegerZoom = i, this.zoom = n, this.maxValue = 0, this.paintVertexAttributes = t.map((s) => ({ name: `a_${s}`, type: "Float32", components: r === "color" ? 4 : 2, offset: 0 })), this.paintVertexArray = new a();
  }
  populatePaintArray(e, t, r) {
    let i = this.expression.evaluate(new le(this.zoom, r), t, {}, r.canonical, [], r.formattedSection), n = this.expression.evaluate(new le(this.zoom + 1, r), t, {}, r.canonical, [], r.formattedSection), a = this.paintVertexArray.length;
    this.paintVertexArray.resize(e), this._setPaintValue(a, e, i, n);
  }
  updatePaintArray(e, t, r, i, n) {
    let a = this.expression.evaluate(new le(this.zoom, n), r, i), s = this.expression.evaluate(new le(this.zoom + 1, n), r, i);
    this._setPaintValue(e, t, a, s);
  }
  _setPaintValue(e, t, r, i) {
    if (this.type === "color") {
      let n = yl(r), a = yl(i);
      for (let s = e; s < t; s++) this.paintVertexArray.emplace(s, n[0], n[1], a[0], a[1]);
    } else {
      for (let n = e; n < t; n++) this.paintVertexArray.emplace(n, r, i);
      this.maxValue = Math.max(this.maxValue, Math.abs(r), Math.abs(i));
    }
  }
  upload(e) {
    var t, r;
    (t = this.paintVertexArray) != null && t.arrayBuffer.byteLength && ((r = this.paintVertexBuffer) != null && r.buffer ? this.paintVertexBuffer.updateData(this.paintVertexArray) : this.paintVertexBuffer = e.createVertexBuffer(this.paintVertexArray, this.paintVertexAttributes, this.expression.isStateDependent));
  }
  destroy() {
    this.paintVertexBuffer && this.paintVertexBuffer.destroy();
  }
  setUniform(e, t) {
    let r = this.useIntegerZoom ? Math.floor(t.zoom) : t.zoom, i = rt(this.expression.interpolationFactor(r, this.zoom, this.zoom + 1), 0, 1);
    e.set(i);
  }
  getBinding(e, t, r) {
    return new Iu(e, t);
  }
}, ur = class {
  constructor(e, t, r, i, n, a) {
    this.expression = e, this.type = t, this.useIntegerZoom = r, this.zoom = i, this.layerId = a, this.zoomInPaintVertexArray = new n(), this.zoomOutPaintVertexArray = new n();
  }
  populatePaintArray(e, t, r) {
    let i = this.zoomInPaintVertexArray.length;
    this.zoomInPaintVertexArray.resize(e), this.zoomOutPaintVertexArray.resize(e), this._setPaintValues(i, e, this.getPositionIds(t), r);
  }
  updatePaintArray(e, t, r, i, n) {
    this._setPaintValues(e, t, this.getPositionIds(r), n);
  }
  _setPaintValues(e, t, r, i) {
    let n = this.getPositions(i);
    if (!n || !r) return;
    let a = n[r.min], s = n[r.mid], o = n[r.max];
    if (a && s && o) for (let l = e; l < t; l++) this.emplace(this.zoomInPaintVertexArray, l, a, s), this.emplace(this.zoomOutPaintVertexArray, l, o, s);
  }
  upload(e) {
    var t, r;
    if ((t = this.zoomInPaintVertexArray) != null && t.arrayBuffer.byteLength && ((r = this.zoomOutPaintVertexArray) != null && r.arrayBuffer.byteLength)) {
      let i = this.getVertexAttributes();
      this.zoomInPaintVertexBuffer = e.createVertexBuffer(this.zoomInPaintVertexArray, i, this.expression.isStateDependent), this.zoomOutPaintVertexBuffer = e.createVertexBuffer(this.zoomOutPaintVertexArray, i, this.expression.isStateDependent);
    }
  }
  destroy() {
    this.zoomOutPaintVertexBuffer && this.zoomOutPaintVertexBuffer.destroy(), this.zoomInPaintVertexBuffer && this.zoomInPaintVertexBuffer.destroy();
  }
}, Hd = class extends ur {
  getPositions(e) {
    return e.imagePositions;
  }
  getPositionIds(e) {
    var t;
    return (t = e.patterns) == null ? void 0 : t[this.layerId];
  }
  getVertexAttributes() {
    return Vx.members;
  }
  emplace(e, t, r, i) {
    e.emplace(t, r.tlbr[0], r.tlbr[1], r.tlbr[2], r.tlbr[3], i.tlbr[0], i.tlbr[1], i.tlbr[2], i.tlbr[3], r.pixelRatio, i.pixelRatio);
  }
}, Kd = class extends ur {
  getPositions(e) {
    return e.dashPositions;
  }
  getPositionIds(e) {
    var t;
    return (t = e.dashes) == null ? void 0 : t[this.layerId];
  }
  getVertexAttributes() {
    return Ox.members;
  }
  emplace(e, t, r, i) {
    e.emplace(t, 0, r.y, r.height, r.width, 0, i.y, i.height, i.width);
  }
}, Jd = class {
  constructor(e, t, r) {
    this.binders = {}, this._buffers = [];
    let i = [];
    for (let n in e.paint._values) {
      if (!r(n)) continue;
      let a = e.paint.get(n);
      if (!(a instanceof mt) || !gi(a.property.specification)) continue;
      let s = jx(n, e.type), o = a.value, l = a.property.specification.type, u = a.property.useIntegerZoom, c = a.property.specification["property-type"], h = c === "cross-faded" || c === "cross-faded-data-driven";
      if (o.kind === "constant") this.binders[n] = h ? new Sr(o.value, s) : new en(o.value, s, l), i.push(`/u_${n}`);
      else if (o.kind === "source" || h) {
        let p = Th(n, l, "source");
        this.binders[n] = h ? n === "line-dasharray" ? new Kd(o, l, u, t, p, e.id) : new Hd(o, l, u, t, p, e.id) : new Nt(o, s, l, p), i.push(`/a_${n}`);
      } else {
        let p = Th(n, l, "composite");
        this.binders[n] = new wt(o, s, l, u, t, p), i.push(`/z_${n}`);
      }
    }
    this.cacheKey = i.sort().join("");
  }
  getMaxValue(e) {
    let t = this.binders[e];
    return t instanceof Nt || t instanceof wt ? t.maxValue : 0;
  }
  populatePaintArrays(e, t, r) {
    for (let i in this.binders) {
      let n = this.binders[i];
      (n instanceof Nt || n instanceof wt || n instanceof ur) && n.populatePaintArray(e, t, r);
    }
  }
  setConstantPatternPositions(e, t) {
    for (let r in this.binders) {
      let i = this.binders[r];
      i instanceof Sr && i.setConstantPatternPositions(e, t);
    }
  }
  setConstantDashPositions(e, t) {
    for (let r in this.binders) {
      let i = this.binders[r];
      i instanceof Sr && i.setConstantDashPositions(e, t);
    }
  }
  updatePaintArrays(e, t, r, i, n) {
    let a = !1;
    for (let s of e) {
      let o = t.getPositions(s.id);
      for (let l of o) {
        let u = r.feature(l.index);
        for (let c in this.binders) {
          let h = this.binders[c];
          (h instanceof Nt || h instanceof wt || h instanceof ur) && h.expression.isStateDependent === !0 && (h.expression = i.paint.get(c).value, h.updatePaintArray(l.start, l.end, u, s.state, n), a = !0);
        }
      }
    }
    return a;
  }
  defines() {
    let e = [];
    for (let t in this.binders) {
      let r = this.binders[t];
      (r instanceof en || r instanceof Sr) && e.push(...r.uniformNames.map((i) => `#define HAS_UNIFORM_${i}`));
    }
    return e;
  }
  getBinderAttributes() {
    let e = [];
    for (let t in this.binders) {
      let r = this.binders[t];
      if (r instanceof Nt || r instanceof wt) for (let i of r.paintVertexAttributes) e.push(i.name);
      else if (r instanceof ur) {
        let i = r.getVertexAttributes();
        for (let n of i) e.push(n.name);
      }
    }
    return e;
  }
  getBinderUniforms() {
    let e = [];
    for (let t in this.binders) {
      let r = this.binders[t];
      if (r instanceof en || r instanceof Sr || r instanceof wt) for (let i of r.uniformNames) e.push(i);
    }
    return e;
  }
  getPaintVertexBuffers() {
    return this._buffers;
  }
  getUniforms(e, t) {
    let r = [];
    for (let i in this.binders) {
      let n = this.binders[i];
      if (n instanceof en || n instanceof Sr || n instanceof wt) {
        for (let a of n.uniformNames) if (t[a]) {
          let s = n.getBinding(e, t[a], a);
          r.push({ name: a, property: i, binding: s });
        }
      }
    }
    return r;
  }
  setUniforms(e, t, r, i) {
    for (let { name: n, property: a, binding: s } of t) this.binders[a].setUniform(s, i, r.get(a), n);
  }
  updatePaintBuffers(e) {
    this._buffers = [];
    for (let t in this.binders) {
      let r = this.binders[t];
      if (e && r instanceof ur) {
        let i = e.fromScale === 2 ? r.zoomInPaintVertexBuffer : r.zoomOutPaintVertexBuffer;
        i && this._buffers.push(i);
      } else (r instanceof Nt || r instanceof wt) && r.paintVertexBuffer && this._buffers.push(r.paintVertexBuffer);
    }
  }
  upload(e) {
    for (let t in this.binders) {
      let r = this.binders[t];
      (r instanceof Nt || r instanceof wt || r instanceof ur) && r.upload(e);
    }
    this.updatePaintBuffers();
  }
  destroy() {
    for (let e in this.binders) {
      let t = this.binders[e];
      (t instanceof Nt || t instanceof wt || t instanceof ur) && t.destroy();
    }
  }
}, Br = class {
  constructor(e, t, r = () => !0) {
    this.programConfigurations = {};
    for (let i of e) this.programConfigurations[i.id] = new Jd(i, t, r);
    this.needsUpload = !1, this._featureMap = new Wd(), this._bufferOffset = 0;
  }
  populatePaintArrays(e, t, r, i) {
    for (let n in this.programConfigurations) this.programConfigurations[n].populatePaintArrays(e, t, i);
    t.id !== void 0 && this._featureMap.add(t.id, r, this._bufferOffset, e), this._bufferOffset = e, this.needsUpload = !0;
  }
  updatePaintArrays(e, t, r, i) {
    for (let n of r) this.needsUpload = this.programConfigurations[n.id].updatePaintArrays(e, this._featureMap, t, n, i) || this.needsUpload;
  }
  get(e) {
    return this.programConfigurations[e];
  }
  upload(e) {
    if (this.needsUpload) {
      for (let t in this.programConfigurations) this.programConfigurations[t].upload(e);
      this.needsUpload = !1;
    }
  }
  destroy() {
    for (let e in this.programConfigurations) this.programConfigurations[e].destroy();
  }
};
function jx(e, t) {
  return { "text-opacity": ["opacity"], "icon-opacity": ["opacity"], "text-color": ["fill_color"], "icon-color": ["fill_color"], "text-halo-color": ["halo_color"], "icon-halo-color": ["halo_color"], "text-halo-blur": ["halo_blur"], "icon-halo-blur": ["halo_blur"], "text-halo-width": ["halo_width"], "icon-halo-width": ["halo_width"], "line-gap-width": ["gapwidth"], "line-dasharray": ["dasharray_to", "dasharray_from"], "line-pattern": ["pattern_to", "pattern_from", "pixel_ratio_to", "pixel_ratio_from"], "fill-pattern": ["pattern_to", "pattern_from", "pixel_ratio_to", "pixel_ratio_from"], "fill-extrusion-pattern": ["pattern_to", "pattern_from", "pixel_ratio_to", "pixel_ratio_from"] }[e] || [e.replace(`${t}-`, "").replace(/-/g, "_")];
}
function qx(e) {
  return { "line-pattern": { source: Wr, composite: Wr }, "fill-pattern": { source: Wr, composite: Wr }, "fill-extrusion-pattern": { source: Wr, composite: Wr }, "line-dasharray": { source: Dh, composite: Dh } }[e];
}
function Th(e, t, r) {
  var n;
  let i = { color: { source: En, composite: pl }, number: { source: Ya, composite: En } };
  return ((n = qx(e)) == null ? void 0 : n[r]) || i[t][r];
}
P("ConstantBinder", en), P("CrossFadedConstantBinder", Sr), P("SourceExpressionBinder", Nt), P("CrossFadedPatternBinder", Hd), P("CrossFadedDasharrayBinder", Kd), P("CompositeExpressionBinder", wt), P("ProgramConfiguration", Jd, { omit: ["_buffers"] }), P("ProgramConfigurationSet", Br);
const ml = 2 ** 14 - 1, Ih = -ml - 1;
function Or(e) {
  let t = te / e.extent, r = e.loadGeometry();
  for (let i of r) for (let n of i) {
    let a = Math.round(n.x * t), s = Math.round(n.y * t);
    n.x = rt(a, Ih, ml), n.y = rt(s, Ih, ml), (a < n.x || a > n.x + 1 || s < n.y || s > n.y + 1) && Me("Geometry exceeds allowed extent, reduce your vector tile buffer size");
  }
  return r;
}
function Ei(e, t) {
  return { type: e.type, id: e.id, properties: e.properties, geometry: t ? Or(e) : [] };
}
var Tn = class gl {
  constructor() {
    this.minX = 1 / 0, this.maxX = -1 / 0, this.minY = 1 / 0, this.maxY = -1 / 0;
  }
  extend(t) {
    return this.minX = Math.min(this.minX, t.x), this.minY = Math.min(this.minY, t.y), this.maxX = Math.max(this.maxX, t.x), this.maxY = Math.max(this.maxY, t.y), this;
  }
  expandBy(t) {
    return this.minX -= t, this.minY -= t, this.maxX += t, this.maxY += t, (this.minX > this.maxX || this.minY > this.maxY) && (this.minX = 1 / 0, this.maxX = -1 / 0, this.minY = 1 / 0, this.maxY = -1 / 0), this;
  }
  shrinkBy(t) {
    return this.expandBy(-t);
  }
  map(t) {
    let r = new gl();
    return r.extend(t(new T(this.minX, this.minY))), r.extend(t(new T(this.maxX, this.minY))), r.extend(t(new T(this.minX, this.maxY))), r.extend(t(new T(this.maxX, this.maxY))), r;
  }
  static fromPoints(t) {
    let r = new gl();
    for (let i of t) r.extend(i);
    return r;
  }
  contains(t) {
    return t.x >= this.minX && t.x <= this.maxX && t.y >= this.minY && t.y <= this.maxY;
  }
  empty() {
    return this.minX > this.maxX;
  }
  width() {
    return this.maxX - this.minX;
  }
  height() {
    return this.maxY - this.minY;
  }
  covers(t) {
    return !this.empty() && !t.empty() && t.minX >= this.minX && t.maxX <= this.maxX && t.minY >= this.minY && t.maxY <= this.maxY;
  }
  intersects(t) {
    return !this.empty() && !t.empty() && t.minX <= this.maxX && t.maxX >= this.minX && t.minY <= this.maxY && t.maxY >= this.minY;
  }
};
Tn.fromPoints([new T(0, 0), new T(te, te)]);
function Za(e, t) {
  return e.x === t.x && (e.x < 0 || e.x > 8192) || e.y === t.y && (e.y < 0 || e.y > 8192);
}
function Ch(e) {
  return e.every((t) => t.x < 0) || e.every((t) => t.x > 8192) || e.every((t) => t.y < 0) || e.every((t) => t.y > 8192);
}
function Cu(e) {
  return e.x < 0 || e.x >= 8192 || e.y < 0 || e.y >= 8192;
}
const kh = -32768;
function Gx(e, t, r, i, n) {
  e.emplaceBack(kh + t * 8 + i, kh + r * 8 + n);
}
var ku = class {
  constructor(e) {
    this.zoom = e.zoom, this.overscaling = e.overscaling, this.layers = e.layers, this.layerIds = this.layers.map((t) => t.id), this.index = e.index, this.hasDependencies = !1, this.layoutVertexArray = new Ex(), this.indexArray = new Nn(), this.segments = new ut(), this.programConfigurations = new Br(e.layers, e.zoom), this.stateDependentLayerIds = this.layers.filter((t) => t.isStateDependent()).map((t) => t.id);
  }
  populate(e, t, r) {
    let i = this.layers[0], n = [], a = null, s = !1, o = i.type === "heatmap";
    if (i.type === "circle") {
      let h = i;
      a = h.layout.get("circle-sort-key"), s = !a.isConstant(), o || (o = h.paint.get("circle-pitch-alignment") === "map");
    }
    let l = o ? t.subdivisionGranularity.circle : 1, u = new le(this.zoom), c = this.layers[0]._featureFilter.needGeometry;
    for (let { feature: h, id: p, index: f, sourceLayerIndex: d } of e) {
      let y = Ei(h, c);
      if (!this.layers[0]._featureFilter.filter(u, y, r)) continue;
      let m = s ? a.evaluate(y, {}, r) : void 0, g = { id: p, properties: h.properties, type: h.type, sourceLayerIndex: d, index: f, geometry: c ? y.geometry : Or(h), patterns: {}, sortKey: m };
      n.push(g);
    }
    s && n.sort((h, p) => h.sortKey - p.sortKey);
    for (let h of n) {
      let { geometry: p, index: f, sourceLayerIndex: d } = h, y = e[f].feature;
      this.addFeature(h, p, f, r, l), t.featureIndex.insert(y, p, f, d, this.index);
    }
  }
  update(e, t, r) {
    this.stateDependentLayers.length && this.programConfigurations.updatePaintArrays(e, t, this.stateDependentLayers, { imagePositions: r });
  }
  addFeatures(e) {
  }
  isEmpty() {
    return this.layoutVertexArray.length === 0;
  }
  uploadPending() {
    return !this.uploaded || this.programConfigurations.needsUpload;
  }
  upload(e) {
    this.uploaded || (this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, zx), this.indexBuffer = e.createIndexBuffer(this.indexArray)), this.programConfigurations.upload(e), this.uploaded = !0;
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.programConfigurations.destroy(), this.segments.destroy());
  }
  addFeature(e, t, r, i, n = 1) {
    let a;
    switch (n) {
      case 1:
        a = [0, 7];
        break;
      case 3:
        a = [0, 2, 5, 7];
        break;
      case 5:
        a = [0, 1, 3, 4, 6, 7];
        break;
      case 7:
        a = [0, 1, 2, 3, 4, 5, 6, 7];
        break;
      default:
        throw Error(`Invalid circle bucket granularity: ${n}; valid values are 1, 3, 5, 7.`);
    }
    let s = a.length;
    for (let o of t) for (let l of o) {
      let u = l.x, c = l.y;
      if (Cu(l)) continue;
      let h = this.segments.prepareSegment(s * s, this.layoutVertexArray, this.indexArray, e.sortKey), p = h.vertexLength;
      for (let f = 0; f < s; f++) for (let d = 0; d < s; d++) Gx(this.layoutVertexArray, u, c, a[d], a[f]);
      for (let f = 0; f < s - 1; f++) for (let d = 0; d < s - 1; d++) {
        let y = p + f * s + d, m = p + (f + 1) * s + d;
        this.indexArray.emplaceBack(y, m + 1, y + 1), this.indexArray.emplaceBack(y, m, m + 1);
      }
      h.vertexLength += s * s, h.primitiveLength += (s - 1) * (s - 1) * 2;
    }
    this.programConfigurations.populatePaintArrays(this.layoutVertexArray.length, e, r, { imagePositions: {}, canonical: i });
  }
};
P("CircleBucket", ku, { omit: ["layers"] });
function Xx(e, t) {
  for (let r of e) if (bi(t, r)) return !0;
  for (let r of t) if (bi(e, r)) return !0;
  return Fu(e, t);
}
function ws(e, t, r) {
  return bi(e, t) ? !0 : xl(t, e, r);
}
function Qd(e, t) {
  if (e.length === 1) return Fh(t, e[0]);
  for (let r of t) for (let i of r) if (bi(e, i)) return !0;
  for (let r of e) if (Fh(t, r)) return !0;
  for (let r of t) if (Fu(e, r)) return !0;
  return !1;
}
function Yx(e, t, r) {
  for (let i of t) {
    if (e.length >= 3) {
      for (let n of i) if (bi(e, n)) return !0;
    }
    if (Wx(e, i, r)) return !0;
  }
  return !1;
}
function Wx(e, t, r) {
  if (e.length > 1) {
    if (Fu(e, t)) return !0;
    for (let i of t) if (xl(i, e, r)) return !0;
  }
  for (let i of e) if (xl(i, t, r)) return !0;
  return !1;
}
function Fu(e, t) {
  if (e.length === 0 || t.length === 0) return !1;
  for (let r = 0; r < e.length - 1; r++) {
    let i = e[r], n = e[r + 1];
    for (let a = 0; a < t.length - 1; a++) {
      let s = t[a], o = t[a + 1];
      if (Zx(i, n, s, o)) return !0;
    }
  }
  return !1;
}
function Zx(e, t, r, i) {
  return pr(e, r, i) !== pr(t, r, i) && pr(e, t, r) !== pr(e, t, i);
}
function xl(e, t, r) {
  let i = r * r;
  if (t.length === 1) return e.distSqr(t[0]) < i;
  for (let n = 1; n < t.length; n++) {
    let a = t[n - 1], s = t[n];
    if (ey(e, a, s) < i) return !0;
  }
  return !1;
}
function ey(e, t, r) {
  let i = t.distSqr(r);
  if (i === 0) return e.distSqr(t);
  let n = ((e.x - t.x) * (r.x - t.x) + (e.y - t.y) * (r.y - t.y)) / i;
  return n < 0 ? e.distSqr(t) : n > 1 ? e.distSqr(r) : e.distSqr(r.sub(t)._mult(n)._add(t));
}
function Fh(e, t) {
  let r = !1, i, n, a;
  for (let s of e) {
    i = s;
    for (let o = 0, l = i.length - 1; o < i.length; l = o++) n = i[o], a = i[l], n.y > t.y != a.y > t.y && t.x < (a.x - n.x) * (t.y - n.y) / (a.y - n.y) + n.x && (r = !r);
  }
  return r;
}
function bi(e, t) {
  let r = !1;
  for (let i = 0, n = e.length - 1; i < e.length; n = i++) {
    let a = e[i], s = e[n];
    a.y > t.y != s.y > t.y && t.x < (s.x - a.x) * (t.y - a.y) / (s.y - a.y) + a.x && (r = !r);
  }
  return r;
}
function Hx(e, t, r, i, n) {
  for (let s of e) if (t <= s.x && r <= s.y && i >= s.x && n >= s.y) return !0;
  let a = [new T(t, r), new T(t, n), new T(i, n), new T(i, r)];
  if (e.length > 2) {
    for (let s of a) if (bi(e, s)) return !0;
  }
  for (let s = 0; s < e.length - 1; s++) {
    let o = e[s], l = e[s + 1];
    if (Kx(o, l, a)) return !0;
  }
  return !1;
}
function Kx(e, t, r) {
  let i = r[0], n = r[2];
  if (e.x < i.x && t.x < i.x || e.x > n.x && t.x > n.x || e.y < i.y && t.y < i.y || e.y > n.y && t.y > n.y) return !1;
  let a = pr(e, t, r[0]);
  return a !== pr(e, t, r[1]) || a !== pr(e, t, r[2]) || a !== pr(e, t, r[3]);
}
const Gt = 63710088e-1;
var he = class tn {
  constructor(t, r) {
    if (isNaN(t) || isNaN(r)) throw Error(`Invalid LngLat object: (${t}, ${r})`);
    if (this.lng = +t, this.lat = +r, this.lat > 90 || this.lat < -90) throw Error("Invalid LngLat latitude value: must be between -90 and 90");
  }
  wrap() {
    return new tn(ti(this.lng, -180, 180), this.lat);
  }
  toArray() {
    return [this.lng, this.lat];
  }
  toString() {
    return `LngLat(${this.lng}, ${this.lat})`;
  }
  distanceTo(t) {
    let r = Math.PI / 180, i = this.lat * r, n = t.lat * r, a = Math.sin(i) * Math.sin(n) + Math.cos(i) * Math.cos(n) * Math.cos((t.lng - this.lng) * r);
    return Gt * Math.acos(Math.min(a, 1));
  }
  static convert(t) {
    if (t instanceof tn) return t;
    if (Array.isArray(t) && (t.length === 2 || t.length === 3)) return new tn(Number(t[0]), Number(t[1]));
    if (!Array.isArray(t) && typeof t == "object" && t) return new tn(Number("lng" in t ? t.lng : t.lon), Number(t.lat));
    throw Error("`LngLatLike` argument must be specified as a LngLat instance, an object {lng: <lng>, lat: <lat>}, an object {lon: <lng>, lat: <lat>}, or an array of [<lng>, <lat>]");
  }
};
const fo = 6378137, vl = { origin: [-Math.PI * fo, Math.PI * fo], extentAtZoom0: 2 * Math.PI * fo }, Mu = 2 * Math.PI * Gt;
function ty(e) {
  return Mu * Math.cos(e * Math.PI / 180);
}
function ry(e) {
  return (180 + e) / 360;
}
function iy(e) {
  return (180 - 180 / Math.PI * Math.log(Math.tan(Math.PI / 4 + e * Math.PI / 360))) / 360;
}
function bl(e, t) {
  return e / ty(t);
}
function ny(e) {
  return e * 360 - 180;
}
function In(e) {
  let t = 180 - e * 360;
  return 360 / Math.PI * Math.atan(Math.exp(t * Math.PI / 180)) - 90;
}
function Jx(e, t) {
  return e * ty(In(t));
}
function ay(e) {
  return 1 / Math.cos(e * Math.PI / 180);
}
var xt = class sy {
  constructor(t, r, i = 0) {
    this.x = +t, this.y = +r, this.z = +i;
  }
  static fromLngLat(t, r = 0) {
    let i = he.convert(t);
    return new sy(ry(i.lng), iy(i.lat), bl(r, i.lat));
  }
  toLngLat() {
    return new he(ny(this.x), In(this.y));
  }
  toAltitude() {
    return Jx(this.z, this.y);
  }
  meterInMercatorCoordinateUnits() {
    return 1 / Mu * ay(In(this.y));
  }
};
const Qx = new class {
  constructor() {
    this.name = "mercator", this.wraps = !0, this.tileMatrixSet = vl;
  }
  worldFromLngLat(e, t, r) {
    return new xt(ry(e), iy(t), r === void 0 ? 0 : bl(r, t));
  }
  lngLatFromWorld(e, t) {
    return new he(ny(e), In(t));
  }
  hasLngLat(e, t) {
    return !0;
  }
  metersPerWorldUnit(e, t) {
    return 1 / (1 / Mu * ay(In(t)));
  }
  worldZFromAltitude(e, t) {
    return bl(e, t.lat);
  }
}();
function e2(e, t, r) {
  return !(e < 0 || e > 25 || r < 0 || r >= 2 ** e || t < 0 || t >= 2 ** e);
}
var oy = class {
  constructor(e, t, r) {
    if (!e2(e, t, r)) throw Error(`x=${t}, y=${r}, z=${e} outside of bounds. 0<=x<${2 ** e}, 0<=y<${2 ** e} 0<=z<=25 `);
    this.z = e, this.x = t, this.y = r, this.key = si(0, e, e, t, r);
  }
  equals(e) {
    return this.z === e.z && this.x === e.x && this.y === e.y;
  }
  url(e, t, r, i = vl) {
    let n = t2(this.z, this.x, this.y);
    return e[(this.x + this.y) % e.length].replace(/{prefix}/g, (this.x % 16).toString(16) + (this.y % 16).toString(16)).replace(/{z}/g, String(this.z)).replace(/{x}/g, String(this.x)).replace(/{y}/g, String(r === "tms" ? 2 ** this.z - this.y - 1 : this.y)).replace(/{ratio}/g, t > 1 ? "@2x" : "").replace(/{quadkey}/g, n).replace(/{bbox-epsg-3857}/g, () => Mh(this.x, this.y, this.z, vl)).replace(/{bbox}/g, () => Mh(this.x, this.y, this.z, i));
  }
  isChildOf(e) {
    let t = this.z - e.z;
    return t > 0 && e.x === this.x >> t && e.y === this.y >> t;
  }
  getTilePoint(e) {
    let t = 2 ** this.z;
    return new T((e.x * t - this.x) * te, (e.y * t - this.y) * te);
  }
  toString() {
    return `${this.z}/${this.x}/${this.y}`;
  }
}, Ha = class {
  constructor(e, t) {
    this.wrap = e, this.canonical = t, this.key = si(e, t.z, t.z, t.x, t.y);
  }
}, _s = class ft {
  constructor(t, r, i, n, a) {
    if (this.terrainRttPosMatrix32f = null, t < i) throw Error(`overscaledZ should be >= z; overscaledZ = ${t}; z = ${i}`);
    this.overscaledZ = t, this.wrap = r, this.canonical = new oy(i, +n, +a), this.key = si(r, t, i, n, a);
  }
  clone() {
    return new ft(this.overscaledZ, this.wrap, this.canonical.z, this.canonical.x, this.canonical.y);
  }
  equals(t) {
    return this.overscaledZ === t.overscaledZ && this.wrap === t.wrap && this.canonical.equals(t.canonical);
  }
  scaledTo(t) {
    if (t > this.overscaledZ) throw Error(`targetZ > this.overscaledZ; targetZ = ${t}; overscaledZ = ${this.overscaledZ}`);
    let r = this.canonical.z - t;
    return t > this.canonical.z ? new ft(t, this.wrap, this.canonical.z, this.canonical.x, this.canonical.y) : new ft(t, this.wrap, t, this.canonical.x >> r, this.canonical.y >> r);
  }
  isOverscaled() {
    return this.overscaledZ > this.canonical.z;
  }
  calculateScaledKey(t, r) {
    if (t > this.overscaledZ) throw Error(`targetZ > this.overscaledZ; targetZ = ${t}; overscaledZ = ${this.overscaledZ}`);
    let i = this.canonical.z - t;
    return t > this.canonical.z ? si(this.wrap * +r, t, this.canonical.z, this.canonical.x, this.canonical.y) : si(this.wrap * +r, t, t, this.canonical.x >> i, this.canonical.y >> i);
  }
  isChildOf(t) {
    if (t.wrap !== this.wrap || this.overscaledZ - t.overscaledZ <= 0) return !1;
    if (t.overscaledZ === 0) return this.overscaledZ > 0;
    let r = this.canonical.z - t.canonical.z;
    return r < 0 ? !1 : t.canonical.x === this.canonical.x >> r && t.canonical.y === this.canonical.y >> r;
  }
  children(t) {
    if (this.overscaledZ >= t) return [new ft(this.overscaledZ + 1, this.wrap, this.canonical.z, this.canonical.x, this.canonical.y)];
    let r = this.canonical.z + 1, i = this.canonical.x * 2, n = this.canonical.y * 2;
    return [new ft(r, this.wrap, r, i, n), new ft(r, this.wrap, r, i + 1, n), new ft(r, this.wrap, r, i, n + 1), new ft(r, this.wrap, r, i + 1, n + 1)];
  }
  isLessThan(t) {
    return this.wrap < t.wrap ? !0 : this.wrap > t.wrap ? !1 : this.overscaledZ < t.overscaledZ ? !0 : this.overscaledZ > t.overscaledZ ? !1 : this.canonical.x < t.canonical.x ? !0 : this.canonical.x > t.canonical.x ? !1 : this.canonical.y < t.canonical.y;
  }
  wrapped() {
    return new ft(this.overscaledZ, 0, this.canonical.z, this.canonical.x, this.canonical.y);
  }
  unwrapTo(t) {
    return new ft(this.overscaledZ, t, this.canonical.z, this.canonical.x, this.canonical.y);
  }
  overscaleFactor() {
    return 2 ** (this.overscaledZ - this.canonical.z);
  }
  toUnwrapped() {
    return new Ha(this.wrap, this.canonical);
  }
  toString() {
    return `${this.overscaledZ}/${this.canonical.x}/${this.canonical.y}`;
  }
  getTilePoint(t) {
    return this.canonical.getTilePoint(new xt(t.x - this.wrap, t.y));
  }
  normalizeCoordinates(t, r, i = te) {
    if (t >= 0 && t < i && r >= 0 && r < i) return { tileID: this, x: t, y: r };
    let n = Math.floor(t / i), a = Math.floor(r / i), s = t - n * i, o = r - a * i, l = this.canonical.z, u = 1 << l, c = this.canonical.y + a;
    if (c < 0 || c >= u) return null;
    let h = this.canonical.x + n, p = this.wrap;
    return h < 0 ? (p -= Math.ceil(-h / u), h = (h % u + u) % u) : h >= u && (p += Math.floor(h / u), h %= u), { tileID: new ft(this.overscaledZ, p, l, h, c), x: s, y: o };
  }
};
function si(e, t, r, i, n) {
  e *= 2, e < 0 && (e = e * -1 - 1);
  let a = 1 << r;
  return (a * a * e + a * n + i).toString(36) + r.toString(36) + t.toString(36);
}
function Mh(e, t, r, i) {
  let n = 2 ** r, a = i.extentAtZoom0 / n, [s, o] = i.origin, l = o - i.extentAtZoom0, u = n - t - 1;
  return `${s + e * a},${l + u * a},${s + (e + 1) * a},${l + (u + 1) * a}`;
}
function t2(e, t, r) {
  let i = "";
  for (let n = e; n > 0; n--) {
    let a = 1 << n - 1;
    i += (t & a ? 1 : 0) + (r & a ? 2 : 0);
  }
  return i;
}
P("CanonicalTileID", oy), P("OverscaledTileID", _s, { omit: ["terrainRttPosMatrix32f"] });
var ly = class Ut {
  constructor(t, r) {
    t && (r ? this.setSouthWest(t).setNorthEast(r) : Array.isArray(t) && (t.length === 4 ? this.setSouthWest([t[0], t[1]]).setNorthEast([t[2], t[3]]) : this.setSouthWest(t[0]).setNorthEast(t[1])));
  }
  setNorthEast(t) {
    return this._ne = t instanceof he ? new he(t.lng, t.lat) : he.convert(t), this;
  }
  setSouthWest(t) {
    return this._sw = t instanceof he ? new he(t.lng, t.lat) : he.convert(t), this;
  }
  extend(t) {
    let r = this._sw, i = this._ne, n, a;
    if (t instanceof he) n = t, a = t;
    else if (t instanceof Ut) {
      if (n = t._sw, a = t._ne, !n || !a) return this;
    } else {
      if (Array.isArray(t)) {
        if (t.length === 4 || t.every(Array.isArray)) {
          let s = t;
          return this.extend(Ut.convert(s));
        }
        {
          let s = t;
          return this.extend(he.convert(s));
        }
      }
      return t && ("lng" in t || "lon" in t) && "lat" in t ? this.extend(he.convert(t)) : this;
    }
    return !r && !i ? (this._sw = new he(n.lng, n.lat), this._ne = new he(a.lng, a.lat)) : (r.lng = Math.min(n.lng, r.lng), r.lat = Math.min(n.lat, r.lat), i.lng = Math.max(a.lng, i.lng), i.lat = Math.max(a.lat, i.lat)), this;
  }
  getCenter() {
    return new he((this._sw.lng + this._ne.lng) / 2, (this._sw.lat + this._ne.lat) / 2);
  }
  getSouthWest() {
    return this._sw;
  }
  getNorthEast() {
    return this._ne;
  }
  getNorthWest() {
    return new he(this.getWest(), this.getNorth());
  }
  getSouthEast() {
    return new he(this.getEast(), this.getSouth());
  }
  getWest() {
    return this._sw.lng;
  }
  getSouth() {
    return this._sw.lat;
  }
  getEast() {
    return this._ne.lng;
  }
  getNorth() {
    return this._ne.lat;
  }
  toArray() {
    return [this._sw.toArray(), this._ne.toArray()];
  }
  toString() {
    return `LngLatBounds(${this._sw.toString()}, ${this._ne.toString()})`;
  }
  isEmpty() {
    return !(this._sw && this._ne);
  }
  contains(t) {
    let { lng: r, lat: i } = he.convert(t), n = this._sw.lat <= i && i <= this._ne.lat, a = this._sw.lng <= r && r <= this._ne.lng;
    return this._sw.lng > this._ne.lng && (a = this._sw.lng >= r && r >= this._ne.lng), n && a;
  }
  intersects(t) {
    if (t = Ut.convert(t), !(t.getNorth() >= this.getSouth() && t.getSouth() <= this.getNorth())) return !1;
    let r = Math.abs(this.getEast() - this.getWest()), i = Math.abs(t.getEast() - t.getWest());
    if (r >= 360 || i >= 360) return !0;
    let n = ti(this.getWest(), -180, 180), a = ti(this.getEast(), -180, 180), s = ti(t.getWest(), -180, 180), o = ti(t.getEast(), -180, 180), l = n > a, u = s > o;
    return l && u ? !0 : l ? o >= n || s <= a : u ? a >= s || n <= o : s <= a && o >= n;
  }
  static convert(t) {
    return t instanceof Ut || !t ? t : new Ut(t);
  }
  static fromLngLat(t, r = 0) {
    let i = 360 * r / 40075017, n = i / Math.cos(Math.PI / 180 * t.lat);
    return new Ut(new he(t.lng - n, t.lat - i), new he(t.lng + n, t.lat + i));
  }
  adjustAntiMeridian() {
    let t = new he(this._sw.lng, this._sw.lat), r = new he(this._ne.lng, this._ne.lat);
    return t.lng > r.lng ? new Ut(t, new he(r.lng + 360, r.lat)) : new Ut(t, r);
  }
};
function uy(e, t, r) {
  let i = 1 / (1 << r.z);
  return new xt(e / te * i + r.x * i, t / te * i + r.y * i);
}
function cy(e) {
  if (!e) return [0, 0, 1, 1];
  let t = e.canonical.z >= 0 ? 1 << e.canonical.z : 2 ** e.canonical.z;
  return [e.canonical.x / t, e.canonical.y / t, 1 / t / te, 1 / t / te];
}
function r2(e, t, r) {
  return uy(e, t, r).toLngLat();
}
function i2(e) {
  return e.cameraToCenterDistance * Math.min(Math.tan(fi(90 - e.pitch)) * 0.85, Math.tan(fi(89.25 - e.pitch)));
}
function wl(e, t) {
  let r = e.canonical, i = t / $m(r.z), n = r.x + 2 ** r.z * e.wrap, a = /* @__PURE__ */ new Float64Array(16);
  return Jl(a), Cm(a, a, [n * i, r.y * i, 0]), ef(a, a, [i / te, i / te, 1]), a;
}
function n2(e, t, r, i) {
  let { x: n, y: a, z: s } = a2(t, r), o = i * -n, l = i * -a, u = i * s;
  return new xt(e.x + o, e.y + l, e.z + u);
}
function a2(e, t) {
  let r = fi(e), i = fi(t), n = Math.cos(-r), a = Math.sin(r);
  return { x: a * Math.sin(i), y: -a * Math.cos(i), z: n };
}
function s2(e, t, r) {
  let i = t[0], n = t[1];
  return e[0] = r[0] * i + r[4] * n + r[12], e[1] = r[1] * i + r[5] * n + r[13], e[3] = r[3] * i + r[7] * n + r[15], e;
}
function Ce(e) {
  return e.projection === "globe" ? e.globeness > 0 ? e.verticalPerspective : e.mercator : e;
}
function yo(e) {
  return Ce(e).projection === "vertical-perspective";
}
function o2(e) {
  let t = Math.tan(e.pitchInRadians) * (e.cameraToCenterDistance || 1);
  return e.centerPoint.add(new T(t * Math.sin(e.rollInRadians), t * Math.cos(e.rollInRadians)));
}
function hy(e, t) {
  let r = o2(e);
  if (t.length === 1) return [t[0], r];
  let { minX: i, minY: n, maxX: a, maxY: s } = Tn.fromPoints(t).extend(r);
  return [new T(i, n), new T(a, n), new T(a, s), new T(i, s), new T(i, n)];
}
function l2(e, t = 1, r = 0, i, n) {
  let a = [[-1, 1, -1, 1], [1, 1, -1, 1], [1, -1, -1, 1], [-1, -1, -1, 1], [-1, 1, 1, 1], [1, 1, 1, 1], [1, -1, 1, 1], [-1, -1, 1, 1]], s = [[0, 1, 2], [6, 5, 4], [0, 3, 7], [2, 1, 5], [3, 2, 6], [0, 4, 5]], o = 2 ** r, l = a.map((p) => u2(p, e, t, o)), u = s.map((p) => {
    let f = jt([], nf([], dn([], l[p[0]], l[p[1]]), dn([], l[p[2]], l[p[1]]))), d = -an(f, l[p[1]]);
    return f.concat(d);
  }), c = [1 / 0, 1 / 0, 1 / 0], h = [-1 / 0, -1 / 0, -1 / 0];
  for (let p of l) for (let f = 0; f < 3; f++) c[f] = Math.min(c[f], p[f]), h[f] = Math.max(h[f], p[f]);
  return { points: l, planes: u, aabb: { min: c, max: h } };
}
function u2(e, t, r, i) {
  let n = Bt([], e, t), a = 1 / n[3] / r * i;
  return zm(n, n, [a, a, 1 / n[3], a]);
}
const Ph = te * (1 - 1e-12), Bh = { covered: !1, demLoaded: !1, elevation: 0 };
function py(e, t, r, i, n) {
  if (i < 0 || i >= 1 || !n && (r < 0 || r >= 1)) return Bh;
  let a = n ? Math.floor(r) : 0, s = r - a;
  for (let o of e.zooms) {
    let l = 1 << o, u = s * l, c = i * l, h = Math.floor(u), p = Math.floor(c), f = `${a}/${o}/${h}/${p}`;
    if (!e.samplerPerTile.has(f)) continue;
    let d = e.samplerPerTile.get(f);
    return d ? { covered: !0, demLoaded: !0, elevation: d(Math.min((u - h) * te, Ph), Math.min((c - p) * te, Ph), te) * t } : { covered: !0, demLoaded: !1, elevation: 0 };
  }
  return Bh;
}
function fy(e, t) {
  return e.covered && t <= e.elevation + 1e-6;
}
function dy(e, t, r, i, n) {
  for (let a = 0; a < 40 && i - r > n; a++) {
    let s = (r + i) / 2;
    t(e, s) ? i = s : r = s;
  }
  return { lo: r, hi: i };
}
const Lh = /* @__PURE__ */ new WeakMap();
function _l(e) {
  let t = Lh.get(e);
  return t || (t = { posMatrices: /* @__PURE__ */ new Map(), alignedPosMatrices: /* @__PURE__ */ new Map(), fogMatrices: /* @__PURE__ */ new Map() }, Lh.set(e, t)), t;
}
function zh(e) {
  return i2(e);
}
function Vh(e, t) {
  return t ? e.lngLatFromWorld(t.x, t.y) : void 0;
}
function c2(e, t, r, i, n) {
  let a = n.getCoverageIndex();
  if (!a) return null;
  let s = e.worldSize, o = i[0] - r[0], l = i[1] - r[1], u = i[2] - r[2], c = { index: a, exaggeration: n.exaggeration, near: r, dx: o, dy: l, dz: u, worldSize: s, wraps: t.wraps }, h = 0, p = 1;
  if (u === 0) {
    if (r[2] > a.maxElevation || r[2] < a.minElevation) return null;
  } else {
    let g = (a.maxElevation - r[2]) / u, v = (a.minElevation - r[2]) / u;
    if (h = Math.max(h, Math.min(g, v)), p = Math.min(p, Math.max(g, v)), h > p) return null;
  }
  let f = Math.hypot(o, l), d = rt(Math.ceil(f * (p - h) / 4), 1, 512), y = 0, m = !da(c, 0);
  for (let g = 0; g <= d; g++) {
    let v = h + (p - h) * g / d;
    if (!m) m = !da(c, v);
    else if (da(c, v)) {
      let { lo: x, hi: b } = dy(c, da, y, v, 1e-3 / f), w = Ma(c, x), D = Ma(c, b), _ = r[2] + x * u - w.elevation, A = r[2] + b * u - D.elevation, E = w.covered && _ > A ? rt(x + _ * (b - x) / (_ - A), x, b) : b;
      return new xt((r[0] + E * o) / s, (r[1] + E * l) / s, Ma(c, E).elevation);
    }
    y = v;
  }
  return null;
}
function Dl(e, t, r = 0) {
  let i = [t.x, t.y, r, 1], n = [t.x, t.y, 1, 1];
  Bt(i, i, e.pixelMatrixInverse), Bt(n, n, e.pixelMatrixInverse);
  let a = i[3], s = n[3], o = e.elevation;
  return { near: [i[0] / a, i[1] / a, i[2] / a + o], far: [n[0] / s, n[1] / s, n[2] / s + o] };
}
function lr(e, t, r) {
  let i = r || 0, { near: n, far: a } = Dl(e, t), s = n[2] === a[2] ? 0 : (i + e.elevation - n[2]) / (a[2] - n[2]);
  return new xt(Kt.number(n[0], a[0], s) / e.worldSize, Kt.number(n[1], a[1], s) / e.worldSize, i);
}
function Oh(e, t, r = 0, i = e.pixelMatrix) {
  let n = yy(e, t, r, i), a = n[3];
  return a > 0 ? new T(n[0] / a, n[1] / a) : h2(e, n[0], n[1], a);
}
function yy(e, t, r, i) {
  let n = [t.x * e.worldSize, t.y * e.worldSize, r, 1];
  return Bt(n, n, i);
}
function h2(e, t, r, i) {
  let n = e.width / 2, a = e.height / 2, s = t - n * i, o = r - a * i;
  s === 0 && o === 0 && (o = 1);
  let l = n + e.width, u = a + e.height, c = Math.min(s === 0 ? 1 / 0 : l / Math.abs(s), o === 0 ? 1 / 0 : u / Math.abs(o));
  return new T(n + s * c, a + o * c);
}
function mo(e, t, r = !1, i = !1) {
  let n = t.key ?? si(t.wrap, t.canonical.z, t.canonical.z, t.canonical.x, t.canonical.y), a = r ? _l(e).alignedPosMatrices : _l(e).posMatrices;
  if (a.has(n)) {
    let l = a.get(n);
    return i ? l.f32 : l.f64;
  }
  let s = wl(t, e.worldSize);
  Mo(s, r ? e.alignedModelViewProjectionMatrix : e.modelViewProjectionMatrix, s);
  let o = { f64: s, f32: new Float32Array(s) };
  return a.set(n, o), i ? o.f32 : o.f64;
}
function Ma(e, t) {
  return py(e.index, e.exaggeration, (e.near[0] + t * e.dx) / e.worldSize, (e.near[1] + t * e.dy) / e.worldSize, e.wraps);
}
function da(e, t) {
  return fy(Ma(e, t), e.near[2] + t * e.dz);
}
function Rh({ near: e, far: t }, r, i, n) {
  let a = t[0] - e[0], s = t[1] - e[1], o = t[2] - e[2];
  return ((r - e[0]) * a + (i - e[1]) * s + (n - e[2]) * o) / (a * a + s * s + o * o);
}
var p2 = class {
  getVisibleUnwrappedCoordinates(e, t, r) {
    let i = [new Ha(0, r)];
    if (e.renderWorldCopies && t.wraps) {
      let n = lr(e, new T(0, 0)), a = lr(e, new T(e.width, 0)), s = lr(e, new T(e.width, e.height)), o = lr(e, new T(0, e.height)), l = Math.floor(Math.min(n.x, a.x, s.x, o.x)), u = Math.floor(Math.max(n.x, a.x, s.x, o.x));
      for (let c = l - 1; c <= u + 1; c++) c !== 0 && i.push(new Ha(c, r));
    }
    return i;
  }
  getCameraFrustum(e) {
    return l2(e.inverseModelViewProjectionMatrix, e.worldSize);
  }
  locationToScreenPoint(e, t, r, i) {
    let n = t.worldFromLngLat(r.lng, r.lat);
    return i ? Oh(e, n, i.getElevationForLngLat(r, e.tileZoom), e.pixelMatrix3D) : Oh(e, n);
  }
  screenPointToLocation(e, t, r, i) {
    return Vh(t, this.screenPointToMercatorCoordinate(e, t, r, i));
  }
  screenPointToLocationAtElevation(e, t, r, i) {
    return Vh(t, lr(e, r, i - e.elevation));
  }
  screenPointToMercatorCoordinate(e, t, r, i) {
    if (i) {
      let n = this.screenTerrainPointToMercatorCoordinate(e, t, r, i);
      if (n != null) return n;
    }
    return lr(e, r);
  }
  screenTerrainPointToMercatorCoordinate(e, t, r, i) {
    let { near: n, far: a } = Dl(e, r, -1);
    return c2(e, t, n, a, i);
  }
  getBounds(e, t) {
    let r = Math.max(0, e.height / 2 - zh(e));
    return new ly().extend(this.screenPointToLocation(e, t, new T(0, r))).extend(this.screenPointToLocation(e, t, new T(e.width, r))).extend(this.screenPointToLocation(e, t, new T(e.width, e.height))).extend(this.screenPointToLocation(e, t, new T(0, e.height)));
  }
  isPointOnMapSurface(e, t, r, i) {
    if (i) return this.screenTerrainPointToMercatorCoordinate(e, t, r, i) != null;
    let n = r.y > e.centerPoint.y - zh(e);
    if (!n || t.wraps) return n;
    let a = lr(e, r);
    return t.hasLngLat(a.x, a.y);
  }
  calculateFogMatrix(e, t) {
    let r = t.key, i = _l(e).fogMatrices;
    if (i.has(r)) return i.get(r);
    let n = wl(t, e.worldSize);
    return Mo(n, e.fogMatrix, n), i.set(r, new Float32Array(n)), i.get(r);
  }
  maxPitchScaleFactor(e) {
    if (!e.pixelMatrixInverse) return 1;
    let t = lr(e, new T(0, 0)), r = [t.x * e.worldSize, t.y * e.worldSize, 0, 1];
    return Bt(r, r, e.pixelMatrix)[3] / e.cameraToCenterDistance;
  }
  getCameraAltitude(e) {
    return Math.cos(e.pitchInRadians) * e.cameraToCenterDistance / e.pixelsPerMeter + e.elevation;
  }
  getCameraLngLat(e, t) {
    let r = e.center, i = t.worldZFromAltitude(1, r), n = i * e.worldSize, a = e.cameraToCenterDistance / n, s = n2(t.worldFromLngLat(r.lng, r.lat, e.elevation), e.pitch, e.bearing, a * i);
    return t.lngLatFromWorld(s.x, s.y);
  }
  getProjectionData(e, t) {
    let { overscaledTileID: r, aligned: i, applyTerrainMatrix: n } = t, a = cy(r), s = r ? mo(e, r, i, !0) : null, o;
    return o = r != null && r.terrainRttPosMatrix32f && n ? r.terrainRttPosMatrix32f : s || Vm(), { mainMatrix: o, tileMercatorCoords: a, clippingPlane: [0, 0, 0, 0], projectionTransition: 0, fallbackMatrix: o, clipAntimeridian: !1 };
  }
  isLocationOccluded(e, t, r, i, n) {
    if (!(i != null && i.getCoverageIndex())) return !1;
    let a = t.worldFromLngLat(r.lng, r.lat);
    n ?? (n = i.getElevationForLngLat(r, e.tileZoom));
    let s = yy(e, a, n, e.pixelMatrix3D), o = s[3];
    if (o <= 0 || s[2] > o) return !0;
    let l = new T(s[0] / o, s[1] / o), u = this.screenTerrainPointToMercatorCoordinate(e, t, l, i);
    if (u == null) return !1;
    let c = Dl(e, l, -1), h = Rh(c, a.x * e.worldSize, a.y * e.worldSize, n);
    return Rh(c, u.x * e.worldSize, u.y * e.worldSize, u.z) < h * 0.99;
  }
  getPixelScale(e) {
    return 1;
  }
  getCircleRadiusCorrection(e) {
    return 1;
  }
  getPitchedTextCorrection(e, t, r, i) {
    return 1;
  }
  transformLightDirection(e, t) {
    return Fm(t);
  }
  projectTileCoordinates(e, t, r, i, n) {
    let a = mo(e, i), s;
    n == null ? (s = [t, r, 0, 1], s2(s, s, a)) : (s = [t, r, n, 1], Bt(s, s, a));
    let o = s[3];
    return { point: new T(s[0] / o, s[1] / o), signedDistanceFromCamera: o, isOccluded: !1 };
  }
  getProjectionDataForCustomLayer(e, t = !0) {
    let r = new _s(0, 0, 0, 0, 0), i = this.getProjectionData(e, { overscaledTileID: r, applyGlobeMatrix: t }), n = wl(r, e.worldSize);
    Mo(n, e.modelViewProjectionMatrix, n);
    let a = [te, te, e.worldSize / e.pixelsPerMeter], s = af();
    return ef(s, n, a), { ...i, tileMercatorCoords: [0, 0, 1, 1], fallbackMatrix: s, mainMatrix: s };
  }
  getFastPathSimpleProjectionMatrix(e, t) {
    return mo(e, t);
  }
  getClippingPlane(e) {
    return null;
  }
  getRayDirectionFromPixel(e, t) {
    throw Error("Not implemented.");
  }
  getCameraQueryGeometry(e, t) {
    return hy(e, t);
  }
};
function f2(e, t) {
  return [za(e * Math.PI * 2 + Math.PI, Math.PI * 2), 2 * Math.atan(Math.exp(Math.PI - t * Math.PI * 2)) - Math.PI * 0.5];
}
function d2(e, t) {
  let r = Math.cos(t), i = /* @__PURE__ */ new Float64Array(3);
  return i[0] = Math.sin(e) * r, i[1] = Math.sin(t), i[2] = Math.cos(e) * r, i;
}
function y2(e, t, r, i, n) {
  let a = 1 / (1 << n), s = e / te * a + r * a, o = t / te * a + i * a, l = za(s * Math.PI * 2 + Math.PI, Math.PI * 2), u = 2 * Math.atan(Math.exp(Math.PI - o * Math.PI * 2)) - Math.PI * 0.5, c = Math.cos(u), h = /* @__PURE__ */ new Float64Array(3);
  return h[0] = Math.sin(l) * c, h[1] = Math.sin(u), h[2] = Math.cos(l) * c, h;
}
function Sl(e) {
  return d2(e.lng * Math.PI / 180, e.lat * Math.PI / 180);
}
function Ka(e) {
  let t = Math.asin(e[1]) / Math.PI * 180, r = Math.sqrt(e[0] * e[0] + e[2] * e[2]);
  if (r > 1e-6) {
    let i = e[0] / r, n = e[2] / r, a = Math.acos(n);
    return new he(ti((i > 0 ? a : -a) / Math.PI * 180, -180, 180), t);
  }
  return new he(0, t);
}
function m2(e) {
  let t = qe();
  return t[0] = e[0] * -e[3], t[1] = e[1] * -e[3], t[2] = e[2] * -e[3], { center: t, radius: Math.sqrt(1 - e[3] * e[3]) };
}
function g2(e, t, r) {
  let i = qe();
  dn(i, r, e);
  let n = qe();
  return rf(n, e, i, t / Pm(i)), n;
}
function $h(e) {
  return Math.cos(Math.min(Math.abs(e), 85.051129) * Math.PI / 180);
}
function Ja(e, t, r = 1) {
  let i = an(e, t), n = r * r, a = qe(), s = qe();
  as(s, t, i), dn(a, e, s);
  let o = n - an(a, a);
  if (o < 0) return null;
  let l = an(e, e) - n, u = -i + (i < 0 ? 1 : -1) * Math.sqrt(o), c = l / u, h = u, p = Math.max(c, h);
  return p < 0 ? null : { tMin: Math.min(c, h), tMax: p };
}
function x2(e, t, r, i) {
  let n = e.cameraPosition, a = t - n[0], s = r - n[1], o = i - n[2], l = a * a + s * s + o * o;
  if (l === 0) return !1;
  let u = rt(-(n[0] * a + n[1] * s + n[2] * o) / l, 0, 1), c = n[0] + u * a, h = n[1] + u * s, p = n[2] + u * o;
  return c * c + h * h + p * p < 1;
}
function go(e, t) {
  let r = eu();
  return Bt(r, [...t, 1], e.modelViewProjectionMatrix), r[0] /= r[3], r[1] /= r[3], new T((r[0] * 0.5 + 0.5) * e.width, (-r[1] * 0.5 + 0.5) * e.height);
}
function Nh(e, t) {
  return !!Ja(e.cameraPosition, hn(e, t));
}
function hn(e, t) {
  let r = eu();
  r[0] = t.x / e.width * 2 - 1, r[1] = (t.y / e.height * 2 - 1) * -1, r[2] = 1, r[3] = 1, Bt(r, r, e.inverseModelViewProjectionMatrix), r[0] /= r[3], r[1] /= r[3], r[2] /= r[3];
  let i = qe();
  i[0] = r[0] - e.cameraPosition[0], i[1] = r[1] - e.cameraPosition[1], i[2] = r[2] - e.cameraPosition[2];
  let n = qe();
  return jt(n, i), n;
}
function my(e, t) {
  let r = e.clippingPlane;
  return r[0] * t[0] + r[1] * t[1] + r[2] * t[2] + r[3] >= 0;
}
function Uh(e, t) {
  if (!my(e, t)) return !1;
  let r = eu();
  return Bt(r, [...t, 1], e.modelViewProjectionMatrix), r[0] /= r[3], r[1] /= r[3], r[2] /= r[3], r[0] > -1 && r[0] < 1 && r[1] > -1 && r[1] < 1 && r[2] > -1 && r[2] < 1;
}
function xo(e, t) {
  let r = e.cameraPosition, i = hn(e, t), n = Ja(r, i);
  if (n) {
    let c = qe();
    ro(c, r, [i[0] * n.tMin, i[1] * n.tMin, i[2] * n.tMin]);
    let h = qe();
    return jt(h, c), Ka(h);
  }
  let a = e.clippingPlane, s = a[0] * i[0] + a[1] * i[1] + a[2] * i[2], o = -Rc(a, r) / s, l = qe();
  if (o > 0) ro(l, r, [i[0] * o, i[1] * o, i[2] * o]);
  else {
    let c = qe();
    ro(c, r, [i[0] * 2, i[1] * 2, i[2] * 2]);
    let h = Rc(a, c);
    dn(l, c, [a[0] * h, a[1] * h, a[2] * h]);
  }
  let u = m2(a);
  return Ka(g2(u.center, u.radius, l));
}
function gy(e, t) {
  let r = qe();
  rf(r, e.origin, e.direction, t);
  let i = Ql(r), n = qe();
  as(n, r, 1 / i);
  let a = Ka(n), s = xt.fromLngLat(a), o = new xt(s.x, rt(s.y, 0, 0.999999999)), l = py(e.index, e.exaggeration, o.x, o.y, !1), u = Math.abs(a.lat) > 85.051129 ? 0 : l.elevation;
  return { sample: { ...l, elevation: u }, radius: i, mercator: o };
}
function jh(e, t) {
  let { sample: r, radius: i } = gy(e, t);
  return fy(r, (i - 1) * Gt);
}
function qh(e, t) {
  let r = Sl(e);
  return as(r, r, 1 + t / Gt);
}
function Gh(e, t, r) {
  return an(tf(qe(), r, e), t);
}
var v2 = class {
  getProjectionData(e, t) {
    let { overscaledTileID: r, applyGlobeMatrix: i } = t, n = cy(r);
    return { mainMatrix: e.modelViewProjectionMatrix32f, tileMercatorCoords: n, clippingPlane: e.clippingPlane, projectionTransition: +!!i, fallbackMatrix: e.modelViewProjectionMatrix32f, clipAntimeridian: (r == null ? void 0 : r.canonical.z) === 0 };
  }
  isLocationOccluded(e, t, r, i, n) {
    let a = i == null ? void 0 : i.getCoverageIndex();
    n ?? (n = a ? i.getElevationForLngLat(r, e.tileZoom) : 0);
    let s = qh(r, n);
    if (!my(e, s)) return !0;
    if (!a) return !1;
    let o = go(e, s), l = e.cameraPosition, u = hn(e, o), c = Gh(l, u, s);
    if (c <= 0) return !0;
    let h = this.screenTerrainPointToMercatorCoordinate(e, t, o, i);
    return h != null && Gh(l, u, qh(h.toLngLat(), h.z)) < c * 0.99;
  }
  transformLightDirection(e, t) {
    let r = e.center.lng * Math.PI / 180, i = e.center.lat * Math.PI / 180, n = Math.cos(i), a = [Math.sin(r) * n, Math.sin(i), Math.cos(r) * n], s = [a[2], 0, -a[0]], o = [0, 0, 0];
    nf(o, s, a), jt(s, s), jt(o, o);
    let l = [s[0] * t[0] + o[0] * t[1] + a[0] * t[2], s[1] * t[0] + o[1] * t[1] + a[1] * t[2], s[2] * t[0] + o[2] * t[1] + a[2] * t[2]], u = [0, 0, 0];
    return jt(u, l), u;
  }
  getPixelScale(e) {
    return 1 / $h(e.center.lat);
  }
  getCircleRadiusCorrection(e) {
    return $h(e.center.lat);
  }
  getPitchedTextCorrection(e, t, r, i) {
    let n = uy(t, r, i.canonical), a = f2(n.x, n.y);
    return this.getCircleRadiusCorrection(e) / Math.cos(a[1]);
  }
  projectTileCoordinates(e, t, r, i, n) {
    let a = i.canonical, s = y2(t, r, a.x, a.y, a.z), o = 1 + (n ?? 0) / Gt, l = s[0] * o, u = s[1] * o, c = s[2] * o, h = [l, u, c, 1];
    Bt(h, h, e.modelViewProjectionMatrix);
    let p;
    if (o <= 1) {
      let f = e.clippingPlane;
      p = f[0] * s[0] + f[1] * s[1] + f[2] * s[2] + f[3] < 0;
    } else p = x2(e, l, u, c);
    return { point: new T(h[0] / h[3], h[1] / h[3]), signedDistanceFromCamera: h[3], isOccluded: p };
  }
  calculateFogMatrix(e, t) {
    Me("calculateFogMatrix is not supported on globe projection.");
    let r = af();
    return Jl(r), r;
  }
  getVisibleUnwrappedCoordinates(e, t, r) {
    return [new Ha(0, r)];
  }
  getCameraFrustum(e) {
    return e.frustum;
  }
  maxPitchScaleFactor(e) {
    return 1;
  }
  getCameraAltitude(e) {
    return (Ql(e.cameraPosition) - 1) * Gt;
  }
  getCameraLngLat(e, t) {
    let r = qe();
    return jt(r, e.cameraPosition), Ka(r);
  }
  getBounds(e, t) {
    let r = e.width * 0.5, i = e.height * 0.5, n = [new T(0, 0), new T(r, 0), new T(e.width, 0), new T(e.width, i), new T(e.width, e.height), new T(r, e.height), new T(0, e.height), new T(0, i)], a = [];
    for (let p of n) a.push(xo(e, p));
    let s = 0, o = 0, l = 0, u = 0, c = e.center;
    for (let p of a) {
      let f = $c(c.lng, p.lng), d = $c(c.lat, p.lat);
      f < o && (o = f), f > s && (s = f), d < u && (u = d), d > l && (l = d);
    }
    let h = [c.lng + o, c.lat + u, c.lng + s, c.lat + l];
    return Uh(e, [0, 1, 0]) && (h[3] = 90, h[0] = -180, h[2] = 180), Uh(e, [0, -1, 0]) && (h[1] = -90, h[0] = -180, h[2] = 180), new ly(h);
  }
  locationToScreenPoint(e, t, r, i) {
    let n = Sl(r);
    return i && as(n, n, 1 + i.getElevationForLngLat(r, e.tileZoom) / Gt), go(e, n);
  }
  getCameraQueryGeometry(e, t) {
    if (t.length !== 1 || !Nh(e, t[0])) return hy(e, t);
    let r = Sl(xo(e, t[0])), i = jt(qe(), e.cameraPosition), n = [t[0]];
    for (let a = 1; a <= 8; a++) {
      let s = Mm(qe(), r, i, a / 8);
      n.push(go(e, jt(s, s)));
    }
    return n;
  }
  screenPointToMercatorCoordinate(e, t, r, i) {
    if (i) {
      let n = this.screenTerrainPointToMercatorCoordinate(e, t, r, i);
      if (n) return n;
    }
    return xt.fromLngLat(xo(e, r));
  }
  screenTerrainPointToMercatorCoordinate(e, t, r, i) {
    let n = i.getCoverageIndex();
    if (!n) return null;
    let a = e.cameraPosition, s = hn(e, r), o = Ja(a, s, 1 + n.maxElevation / Gt);
    if (!o) return null;
    let l = Ja(a, s, 1 + n.minElevation / Gt), u = Math.max(o.tMin, 0), c = l ? l.tMin : o.tMax;
    if (c <= u) return null;
    let h = { index: n, exaggeration: i.exaggeration, origin: a, direction: s }, p = 0;
    for (let f = 0; f <= 256; f++) {
      let d = u + (c - u) * f / 256;
      if (jh(h, d)) {
        let { hi: y } = dy(h, jh, p, d, 1e-12), { sample: m, mercator: g } = gy(h, y);
        return new xt(g.x, g.y, m.elevation);
      }
      p = d;
    }
    return null;
  }
  screenPointToLocation(e, t, r, i) {
    var n;
    return (n = this.screenPointToMercatorCoordinate(e, t, r, i)) == null ? void 0 : n.toLngLat();
  }
  screenPointToLocationAtElevation(e, t, r, i) {
    return this.screenPointToLocation(e, t, r);
  }
  isPointOnMapSurface(e, t, r, i) {
    return Nh(e, r);
  }
  getProjectionDataForCustomLayer(e, t = !0) {
    let r = this.getProjectionData(e, { overscaledTileID: new _s(0, 0, 0, 0, 0), applyGlobeMatrix: t });
    return r.tileMercatorCoords = [0, 0, 1, 1], r;
  }
  getFastPathSimpleProjectionMatrix(e, t) {
  }
  getClippingPlane(e) {
    return e.clippingPlane;
  }
  getRayDirectionFromPixel(e, t) {
    return hn(e, t);
  }
}, b2 = class {
  constructor(e, t) {
    this._mercator = e, this._verticalPerspective = t;
  }
  _renderedMath(e) {
    return yo(e) ? this._verticalPerspective : this._mercator;
  }
  getProjectionData(e, t) {
    let r = this._mercator.getProjectionData(e.mercator, t), i = this._verticalPerspective.getProjectionData(e.verticalPerspective, t);
    return { mainMatrix: yo(e) ? i.mainMatrix : r.mainMatrix, clippingPlane: i.clippingPlane, tileMercatorCoords: i.tileMercatorCoords, projectionTransition: t.applyGlobeMatrix ? e.globeness : 0, fallbackMatrix: r.fallbackMatrix, clipAntimeridian: i.clipAntimeridian };
  }
  getProjectionDataForCustomLayer(e, t = !0) {
    let r = this._mercator.getProjectionDataForCustomLayer(e.mercator, t);
    if (!yo(e)) return r;
    let i = this._verticalPerspective.getProjectionDataForCustomLayer(e.verticalPerspective, t);
    return i.fallbackMatrix = r.mainMatrix, i.projectionTransition = e.globeness, i;
  }
  getFastPathSimpleProjectionMatrix(e, t) {
    return this._renderedMath(e).getFastPathSimpleProjectionMatrix(Ce(e), t);
  }
  projectTileCoordinates(e, t, r, i, n) {
    return this._renderedMath(e).projectTileCoordinates(Ce(e), t, r, i, n);
  }
  getPitchedTextCorrection(e, t, r, i) {
    return Nc(this._mercator.getPitchedTextCorrection(e.mercator, t, r, i), this._verticalPerspective.getPitchedTextCorrection(e.verticalPerspective, t, r, i), e.globeness);
  }
  getCircleRadiusCorrection(e) {
    return this._renderedMath(e).getCircleRadiusCorrection(Ce(e));
  }
  getPixelScale(e) {
    return Nc(this._mercator.getPixelScale(e.mercator), this._verticalPerspective.getPixelScale(e.verticalPerspective), e.globeness);
  }
  transformLightDirection(e, t) {
    return this._renderedMath(e).transformLightDirection(Ce(e), t);
  }
  calculateFogMatrix(e, t) {
    return this._renderedMath(e).calculateFogMatrix(Ce(e), t);
  }
  getVisibleUnwrappedCoordinates(e, t, r) {
    return this._renderedMath(e).getVisibleUnwrappedCoordinates(Ce(e), t, r);
  }
  getCameraFrustum(e) {
    return this._renderedMath(e).getCameraFrustum(Ce(e));
  }
  getClippingPlane(e) {
    return this._renderedMath(e).getClippingPlane(Ce(e));
  }
  maxPitchScaleFactor(e) {
    return this._mercator.maxPitchScaleFactor(e.mercator);
  }
  getCameraAltitude(e) {
    return this._renderedMath(e).getCameraAltitude(Ce(e));
  }
  getCameraLngLat(e, t) {
    return this._renderedMath(e).getCameraLngLat(Ce(e), t);
  }
  getBounds(e, t) {
    return this._renderedMath(e).getBounds(Ce(e), t);
  }
  isLocationOccluded(e, t, r, i, n) {
    return this._renderedMath(e).isLocationOccluded(Ce(e), t, r, i, n);
  }
  locationToScreenPoint(e, t, r, i) {
    return this._renderedMath(e).locationToScreenPoint(Ce(e), t, r, i);
  }
  screenPointToLocation(e, t, r, i) {
    return this._renderedMath(e).screenPointToLocation(Ce(e), t, r, i);
  }
  screenPointToLocationAtElevation(e, t, r, i) {
    return this._renderedMath(e).screenPointToLocationAtElevation(Ce(e), t, r, i);
  }
  screenPointToMercatorCoordinate(e, t, r, i) {
    return this._renderedMath(e).screenPointToMercatorCoordinate(Ce(e), t, r, i);
  }
  screenTerrainPointToMercatorCoordinate(e, t, r, i) {
    return this._renderedMath(e).screenTerrainPointToMercatorCoordinate(Ce(e), t, r, i);
  }
  isPointOnMapSurface(e, t, r, i) {
    return this._renderedMath(e).isPointOnMapSurface(Ce(e), t, r, i);
  }
  getRayDirectionFromPixel(e, t) {
    return this._verticalPerspective.getRayDirectionFromPixel(e.verticalPerspective, t);
  }
  getCameraQueryGeometry(e, t) {
    return this._renderedMath(e).getCameraQueryGeometry(Ce(e), t);
  }
};
const xy = new p2(), vy = new v2(), w2 = new b2(xy, vy);
function Ds(e) {
  switch (e.projection) {
    case "mercator":
      return xy;
    case "vertical-perspective":
      return vy;
    case "globe":
      return w2;
  }
}
function oi(e, t, r) {
  let i = t.paint.get(e).value;
  return i.kind === "constant" ? i.value : r.programConfigurations.get(t.id).getMaxValue(e);
}
function Ss(e) {
  return Math.sqrt(e[0] * e[0] + e[1] * e[1]);
}
function As(e, t, r, i, n) {
  if (!t[0] && !t[1]) return e;
  let a = T.convert(t)._mult(n);
  r === "viewport" && a._rotate(-i);
  let s = [];
  for (let o of e) s.push(o.sub(a));
  return s;
}
function _2(e) {
  let t = [];
  for (let r = 0; r < e.length; r++) {
    let i = e[r], n = t.at(-1);
    (r === 0 || n && !i.equals(n)) && t.push(i);
  }
  return t;
}
function D2(e, t) {
  let r = [];
  for (let i of e) {
    let n = _2(i), a = [];
    for (let s = 0; s < n.length; s++) {
      let o = n[s], l = n[s - 1], u = n[s + 1], c = s === 0 ? new T(0, 0) : o.sub(l)._unit()._perp(), h = s === n.length - 1 ? new T(0, 0) : u.sub(o)._unit()._perp(), p = c._add(h)._unit(), f = p.x * h.x + p.y * h.y;
      f !== 0 && p._mult(1 / f), a.push(p._mult(t)._add(o));
    }
    r.push(a);
  }
  return r;
}
function S2({ queryGeometry: e, size: t }, r) {
  return ws(e, r, t);
}
function A2({ queryGeometry: e, size: t, projectedCamera: r, unwrappedTileID: i, getElevation: n }, a) {
  return ws(e, a, t * (Ds(r).projectTileCoordinates(r, a.x, a.y, i, n == null ? void 0 : n(a.x, a.y)).signedDistanceFromCamera / r.cameraToCenterDistance));
}
function E2({ queryGeometry: e, size: t, projectedCamera: r, unwrappedTileID: i, getElevation: n }, a) {
  let s = Ds(r).projectTileCoordinates(r, a.x, a.y, i, n == null ? void 0 : n(a.x, a.y)).signedDistanceFromCamera, o = t * (r.cameraToCenterDistance / s);
  return ws(e, Pu(a, r, i, n), o);
}
function T2({ queryGeometry: e, size: t, projectedCamera: r, unwrappedTileID: i, getElevation: n }, a) {
  return ws(e, Pu(a, r, i, n), t);
}
function by({ queryGeometry: e, size: t, projectedCamera: r, unwrappedTileID: i, getElevation: n, pitchAlignment: a = "map", pitchScale: s = "map" }, o) {
  let l = a === "map" ? s === "map" ? S2 : A2 : s === "map" ? E2 : T2, u = { queryGeometry: e, size: t, projectedCamera: r, unwrappedTileID: i, getElevation: n };
  for (let c of o) for (let h of c) if (l(u, h)) return !0;
  return !1;
}
function Pu(e, t, r, i) {
  let n = Ds(t).projectTileCoordinates(t, e.x, e.y, r, i == null ? void 0 : i(e.x, e.y)).point;
  return new T((n.x * 0.5 + 0.5) * t.width, (-n.y * 0.5 + 0.5) * t.height);
}
function I2(e, t, r, i) {
  return e.map((n) => Pu(n, t, r, i));
}
let C2;
const k2 = () => C2 || (C2 = new Je({ "circle-sort-key": new j(S.layout_circle["circle-sort-key"], "circle-sort-key") }));
let F2;
const M2 = () => F2 || (F2 = new Je({ "circle-radius": new j(S.paint_circle["circle-radius"], "circle-radius"), "circle-color": new j(S.paint_circle["circle-color"], "circle-color"), "circle-blur": new j(S.paint_circle["circle-blur"], "circle-blur"), "circle-opacity": new j(S.paint_circle["circle-opacity"], "circle-opacity"), "circle-translate": new V(S.paint_circle["circle-translate"], "circle-translate"), "circle-translate-anchor": new V(S.paint_circle["circle-translate-anchor"], "circle-translate-anchor"), "circle-pitch-scale": new V(S.paint_circle["circle-pitch-scale"], "circle-pitch-scale"), "circle-pitch-alignment": new V(S.paint_circle["circle-pitch-alignment"], "circle-pitch-alignment"), "circle-stroke-width": new j(S.paint_circle["circle-stroke-width"], "circle-stroke-width"), "circle-stroke-color": new j(S.paint_circle["circle-stroke-color"], "circle-stroke-color"), "circle-stroke-opacity": new j(S.paint_circle["circle-stroke-opacity"], "circle-stroke-opacity") }));
var P2 = { get paint() {
  return M2();
}, get layout() {
  return k2();
} }, B2 = class extends At {
  constructor(e, t) {
    super(e, P2, t);
  }
  createBucket(e) {
    return new ku(e);
  }
  queryRadius(e) {
    let t = e;
    return oi("circle-radius", this, t) + oi("circle-stroke-width", this, t) + Ss(this.paint.get("circle-translate"));
  }
  queryIntersectsFeature({ queryGeometry: e, feature: t, featureState: r, geometry: i, projectedCamera: n, pixelsToTileUnits: a, unwrappedTileID: s, getElevation: o }) {
    let l = As(e, this.paint.get("circle-translate"), this.paint.get("circle-translate-anchor"), -n.bearingInRadians, a), u = this.paint.get("circle-radius").evaluate(t, r) + this.paint.get("circle-stroke-width").evaluate(t, r), c = this.paint.get("circle-pitch-scale"), h = this.paint.get("circle-pitch-alignment"), p, f;
    return h === "map" ? (p = l, f = u * a) : (p = I2(l, n, s, o), f = u), by({ queryGeometry: p, size: f, projectedCamera: n, unwrappedTileID: s, getElevation: o, pitchAlignment: h, pitchScale: c }, i);
  }
}, wy = class extends ku {
};
P("HeatmapBucket", wy, { omit: ["layers"] });
let L2;
const z2 = () => L2 || (L2 = new Je({ "heatmap-radius": new j(S.paint_heatmap["heatmap-radius"], "heatmap-radius"), "heatmap-weight": new j(S.paint_heatmap["heatmap-weight"], "heatmap-weight"), "heatmap-intensity": new V(S.paint_heatmap["heatmap-intensity"], "heatmap-intensity"), "heatmap-color": new bs(S.paint_heatmap["heatmap-color"], "heatmap-color"), "heatmap-opacity": new V(S.paint_heatmap["heatmap-opacity"], "heatmap-opacity") }));
var V2 = { get paint() {
  return z2();
} };
function Bu(e, { width: t, height: r }, i, n) {
  if (!n) n = new Uint8Array(t * r * i);
  else if (n instanceof Uint8ClampedArray) n = new Uint8Array(n.buffer);
  else if (n.length !== t * r * i) throw RangeError(`mismatched image size. expected: ${n.length} but got: ${t * r * i}`);
  return e.width = t, e.height = r, e.data = n, e;
}
function _y(e, { width: t, height: r }, i) {
  if (t === e.width && r === e.height) return;
  let n = Bu({}, { width: t, height: r }, i);
  Lu(e, n, { x: 0, y: 0 }, { x: 0, y: 0 }, { width: Math.min(e.width, t), height: Math.min(e.height, r) }, i), e.width = t, e.height = r, e.data = n.data;
}
function Lu(e, t, r, i, n, a) {
  if (n.width === 0 || n.height === 0) return t;
  if (n.width > e.width || n.height > e.height || r.x > e.width - n.width || r.y > e.height - n.height) throw RangeError("out of range source coordinates for image copy");
  if (n.width > t.width || n.height > t.height || i.x > t.width - n.width || i.y > t.height - n.height) throw RangeError("out of range destination coordinates for image copy");
  let s = e.data, o = t.data;
  if (s === o) throw Error("srcData equals dstData, so image is already copied");
  for (let l = 0; l < n.height; l++) {
    let u = ((r.y + l) * e.width + r.x) * a, c = ((i.y + l) * t.width + i.x) * a;
    for (let h = 0; h < n.width * a; h++) o[c + h] = s[u + h];
  }
  return t;
}
var Al = class Dy {
  constructor(t, r) {
    Bu(this, t, 1, r);
  }
  resize(t) {
    _y(this, t, 1);
  }
  clone() {
    return new Dy({ width: this.width, height: this.height }, new Uint8Array(this.data));
  }
  static copy(t, r, i, n, a) {
    Lu(t, r, i, n, a, 1);
  }
}, ot = class Sy {
  constructor(t, r) {
    Bu(this, t, 4, r);
  }
  resize(t) {
    _y(this, t, 4);
  }
  replace(t, r) {
    r ? this.data.set(t) : this.data = t instanceof Uint8ClampedArray ? new Uint8Array(t.buffer) : t;
  }
  clone() {
    return new Sy({ width: this.width, height: this.height }, new Uint8Array(this.data));
  }
  static copy(t, r, i, n, a) {
    Lu(t, r, i, n, a, 4);
  }
  setPixel(t, r, i) {
    let n = (t * this.width + r) * 4;
    this.data[n + 0] = Math.round(i.r * 255 / i.a), this.data[n + 1] = Math.round(i.g * 255 / i.a), this.data[n + 2] = Math.round(i.b * 255 / i.a), this.data[n + 3] = Math.round(i.a * 255);
  }
};
function vo(e) {
  let t = new Uint8Array(e.length);
  for (let r = 0; r < e.length; r += 4) {
    let i = e[r + 3];
    t[r + 0] = Math.round(e[r + 0] * i / 255), t[r + 1] = Math.round(e[r + 1] * i / 255), t[r + 2] = Math.round(e[r + 2] * i / 255), t[r + 3] = i;
  }
  return t;
}
P("AlphaImage", Al), P("RGBAImage", ot);
function O2(e) {
  let t = {}, r = e.resolution || 256, i = e.clips ? e.clips.length : 1, n = e.image || new ot({ width: r, height: i });
  if (!Rm(r)) throw Error(`width is not a power of 2 - ${r}`);
  let a = (s, o, l) => {
    t[e.evaluationKey] = l;
    let u = e.expression.evaluate(t);
    n.setPixel(s / 4 / r, o / 4, u);
  };
  if (e.clips) for (let s = 0, o = 0; s < i; ++s, o += r * 4) for (let l = 0, u = 0; l < r; l++, u += 4) {
    let c = l / (r - 1), { start: h, end: p } = e.clips[s], f = h * (1 - c) + p * c;
    a(o, u, f);
  }
  else for (let s = 0, o = 0; s < r; s++, o += 4) {
    let l = s / (r - 1);
    a(0, o, l);
  }
  return n;
}
var R2 = class extends At {
  createBucket(e) {
    return new wy(e);
  }
  constructor(e, t) {
    super(e, V2, t), this.heatmapFbos = /* @__PURE__ */ new Map(), this._updateColorRamp();
  }
  _handleSpecialPaintPropertyUpdate(e) {
    e === "heatmap-color" && this._updateColorRamp();
  }
  _updateColorRamp() {
    let e = this._transitionablePaint._values["heatmap-color"].value.expression;
    this.colorRamp = O2({ expression: e, evaluationKey: "heatmapDensity", image: this.colorRamp }), this.colorRampTexture = null;
  }
  resize() {
    this.heatmapFbos.has("big-fb") && this.heatmapFbos.delete("big-fb");
  }
  queryRadius(e) {
    return oi("heatmap-radius", this, e);
  }
  queryIntersectsFeature({ queryGeometry: e, feature: t, featureState: r, geometry: i, projectedCamera: n, pixelsToTileUnits: a, unwrappedTileID: s, getElevation: o }) {
    return by({ queryGeometry: e, size: this.paint.get("heatmap-radius").evaluate(t, r) * a, projectedCamera: n, unwrappedTileID: s, getElevation: o }, i);
  }
  hasOffscreenPass() {
    return this.paint.get("heatmap-opacity") !== 0 && !this.isHidden();
  }
};
let $2;
const N2 = () => $2 || ($2 = new Je({ "hillshade-illumination-direction": new V(S.paint_hillshade["hillshade-illumination-direction"], "hillshade-illumination-direction"), "hillshade-illumination-altitude": new V(S.paint_hillshade["hillshade-illumination-altitude"], "hillshade-illumination-altitude"), "hillshade-illumination-anchor": new V(S.paint_hillshade["hillshade-illumination-anchor"], "hillshade-illumination-anchor"), "hillshade-exaggeration": new V(S.paint_hillshade["hillshade-exaggeration"], "hillshade-exaggeration"), "hillshade-shadow-color": new V(S.paint_hillshade["hillshade-shadow-color"], "hillshade-shadow-color"), "hillshade-highlight-color": new V(S.paint_hillshade["hillshade-highlight-color"], "hillshade-highlight-color"), "hillshade-accent-color": new V(S.paint_hillshade["hillshade-accent-color"], "hillshade-accent-color"), "hillshade-method": new V(S.paint_hillshade["hillshade-method"], "hillshade-method"), resampling: new V(S.paint_hillshade.resampling, "resampling") }));
var U2 = { get paint() {
  return N2();
} }, j2 = class extends At {
  constructor(e, t) {
    super(e, U2, t), this.recalculate({ zoom: 0, zoomHistory: {} }, void 0);
  }
  getIlluminationProperties() {
    let e = this.paint.get("hillshade-illumination-direction").values, t = this.paint.get("hillshade-illumination-altitude").values, r = this.paint.get("hillshade-highlight-color").values, i = this.paint.get("hillshade-shadow-color").values, n = Math.max(e.length, t.length, r.length, i.length);
    e = e.concat(Array(n - e.length).fill(e.at(-1))), t = t.concat(Array(n - t.length).fill(t.at(-1))), r = r.concat(Array(n - r.length).fill(r.at(-1))), i = i.concat(Array(n - i.length).fill(i.at(-1)));
    let a = t.map(fi);
    return { directionRadians: e.map(fi), altitudeRadians: a, shadowColor: i, highlightColor: r };
  }
  hasOffscreenPass() {
    return this.paint.get("hillshade-exaggeration") !== 0 && !this.isHidden();
  }
};
let q2;
const G2 = () => q2 || (q2 = new Je({ "color-relief-opacity": new V(S["paint_color-relief"]["color-relief-opacity"], "color-relief-opacity"), "color-relief-color": new bs(S["paint_color-relief"]["color-relief-color"], "color-relief-color"), resampling: new V(S["paint_color-relief"].resampling, "resampling") }));
var X2 = { get paint() {
  return G2();
} };
function ya(e) {
  return "data" in e;
}
var Xh = class {
  constructor(e, t, r, i) {
    this.context = e, this.format = r, this.texture = e.gl.createTexture(), this._ownedHandle = this.texture, this.update(t, i);
  }
  update(e, t, r) {
    var u;
    let { width: i, height: n } = e, a = (((u = this.size) == null ? void 0 : u[0]) !== i || this.size[1] !== n) && !r, { context: s } = this, { gl: o } = s;
    this.useMipmap = !!(t != null && t.useMipmap), a && this.size && this.format === o.RGBA && (o.deleteTexture(this.texture), this.texture = o.createTexture(), this._ownedHandle = this.texture, this.magFilter = void 0, this.minFilter = void 0, this.wrap = void 0), o.bindTexture(o.TEXTURE_2D, this.texture), s.pixelStoreUnpackFlipY.set(!1), s.pixelStoreUnpack.set(1);
    let l = this.format === o.RGBA && (t == null ? void 0 : t.premultiply) !== !1;
    if (a)
      if (this.size = [i, n], this.format === o.RGBA && i > 0 && n > 0) {
        let c = this.useMipmap ? Math.floor(Math.log2(Math.max(i, n))) + 1 : 1;
        if (o.texStorage2D(o.TEXTURE_2D, c, o.RGBA8, i, n), ya(e)) {
          s.pixelStoreUnpackPremultiplyAlpha.set(!1);
          let { data: h } = e;
          l && h && (h = vo(h)), h && o.texSubImage2D(o.TEXTURE_2D, 0, 0, 0, i, n, o.RGBA, o.UNSIGNED_BYTE, h);
        } else s.pixelStoreUnpackPremultiplyAlpha.set(l), o.texSubImage2D(o.TEXTURE_2D, 0, 0, 0, o.RGBA, o.UNSIGNED_BYTE, e);
      } else ya(e) ? (s.pixelStoreUnpackPremultiplyAlpha.set(!1), this._uploadRawData(e, l, i, n, o)) : (s.pixelStoreUnpackPremultiplyAlpha.set(l), this._uploadDomImage(e, o));
    else {
      let { x: c, y: h } = r || { x: 0, y: 0 };
      ya(e) ? (s.pixelStoreUnpackPremultiplyAlpha.set(!1), this._updateRawData(e, l, c, h, i, n, o)) : (s.pixelStoreUnpackPremultiplyAlpha.set(l), this._updateDomImage(e, c, h, o));
    }
    this.useMipmap && !(ya(e) && e.data === null) && o.generateMipmap(o.TEXTURE_2D), s.pixelStoreUnpackFlipY.setDefault(), s.pixelStoreUnpack.setDefault(), s.pixelStoreUnpackPremultiplyAlpha.setDefault();
  }
  _uploadDomImage(e, t) {
    t.texImage2D(t.TEXTURE_2D, 0, this.format, this.format, t.UNSIGNED_BYTE, e);
  }
  _uploadRawData(e, t, r, i, n) {
    let { data: a } = e;
    t && a && (a = vo(a)), n.texImage2D(n.TEXTURE_2D, 0, this.format, r, i, 0, this.format, n.UNSIGNED_BYTE, a);
  }
  _updateDomImage(e, t, r, i) {
    i.texSubImage2D(i.TEXTURE_2D, 0, t, r, i.RGBA, i.UNSIGNED_BYTE, e);
  }
  _updateRawData(e, t, r, i, n, a, s) {
    let { data: o } = e;
    t && o && (o = vo(o)), s.texSubImage2D(s.TEXTURE_2D, 0, r, i, n, a, s.RGBA, s.UNSIGNED_BYTE, o);
  }
  bind(e, t, r) {
    let { context: i } = this, { gl: n } = i;
    this.texture !== this._ownedHandle && (this.texture = this._ownedHandle), n.bindTexture(n.TEXTURE_2D, this.texture), r !== n.LINEAR_MIPMAP_NEAREST && r !== n.LINEAR_MIPMAP_LINEAR || this.useMipmap || (r = n.LINEAR);
    let a = r || e;
    e !== this.magFilter && (n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MAG_FILTER, e), this.magFilter = e), a !== this.minFilter && (n.texParameteri(n.TEXTURE_2D, n.TEXTURE_MIN_FILTER, a), this.minFilter = a), t !== this.wrap && (n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_S, t), n.texParameteri(n.TEXTURE_2D, n.TEXTURE_WRAP_T, t), this.wrap = t);
  }
  generateMipmap() {
    if (!this.useMipmap) return;
    let { gl: e } = this.context;
    e.bindTexture(e.TEXTURE_2D, this.texture), e.generateMipmap(e.TEXTURE_2D);
  }
  destroy() {
    let { gl: e } = this.context;
    e.deleteTexture(this.texture), this.texture = null, this._ownedHandle = null;
  }
}, Zt, Ay = (Zt = class {
  constructor(t, r, i, n = 1, a = 1, s = 1, o = 0) {
    if (this.uid = t, r.height !== r.width) throw RangeError("DEM tiles must be square");
    if (i && !["mapbox", "terrarium", "custom"].includes(i)) {
      Me(`"${i}" is not a valid encoding type. Valid types include "mapbox", "terrarium" and "custom".`);
      return;
    }
    this.stride = r.height;
    let l = this.dim = r.height - 4;
    switch (this.data = new Uint32Array(r.data.buffer), Zt.byteViewCache.set(this, new Uint8Array(this.data.buffer)), i) {
      case "terrarium":
        this.redFactor = 256, this.greenFactor = 1, this.blueFactor = 1 / 256, this.baseShift = 32768;
        break;
      case "custom":
        this.redFactor = n, this.greenFactor = a, this.blueFactor = s, this.baseShift = o;
        break;
      default:
        this.redFactor = 6553.6, this.greenFactor = 25.6, this.blueFactor = 0.1, this.baseShift = 1e4;
    }
    for (let c = -2; c < l + 2; c++) {
      let h = this._idx(0, Math.max(0, Math.min(l - 1, c)));
      (c < 0 || c >= l) && this.data.copyWithin(this._idx(0, c), h, h + l), this.data.fill(this.data[h], this._idx(-2, c), this._idx(0, c)), this.data.fill(this.data[h + l - 1], this._idx(l, c), this._idx(l + 1, c) + 1);
    }
    let u = this._getByteView();
    this.min = 2 ** 53 - 1, this.max = -9007199254740991;
    for (let c = 0; c < l; c++) for (let h = 0; h < l; h++) {
      let p = this._idx(c, h) * 4, f = this._unpackAtIndex(u, p);
      f > this.max && (this.max = f), f < this.min && (this.min = f);
    }
  }
  get(t, r) {
    let i = this._getByteView(), n = this._idx(t, r) * 4;
    return this._unpackAtIndex(i, n);
  }
  sampleBilinear(t, r) {
    let i = Math.floor(t), n = Math.floor(r);
    if (i < -1 || i >= this.dim || n < -1 || n >= this.dim) throw RangeError(`Out of range source coordinates for DEM data. x: ${t}, y: ${r}, dim: ${this.dim}`);
    let a = this._getByteView(), s = ((n + 2) * this.stride + i + 2) * 4, o = this.stride * 4, l = t - i, u = r - n, c = this._unpackAtIndex(a, s), h = this._unpackAtIndex(a, s + 4), p = this._unpackAtIndex(a, s + o), f = this._unpackAtIndex(a, s + o + 4);
    return c * (1 - l) * (1 - u) + h * l * (1 - u) + p * (1 - l) * u + f * l * u;
  }
  getUnpackVector() {
    return [this.redFactor, this.greenFactor, this.blueFactor, this.baseShift];
  }
  _idx(t, r) {
    if (t < -2 || t >= this.dim + 2 || r < -2 || r >= this.dim + 2) throw RangeError(`Out of range source coordinates for DEM data. x: ${t}, y: ${r}, dim: ${this.dim}`);
    return (r + 2) * this.stride + (t + 2);
  }
  unpack(t, r, i) {
    return t * this.redFactor + r * this.greenFactor + i * this.blueFactor - this.baseShift;
  }
  pack(t) {
    return Ey(t, this.getUnpackVector());
  }
  getPixels() {
    return new ot({ width: this.stride, height: this.stride }, this._getByteView());
  }
  backfillBorder(t, r, i) {
    if (this.dim !== t.dim) throw Error("dem dimension mismatch");
    let n = r * this.dim, a = r * this.dim + this.dim, s = i * this.dim, o = i * this.dim + this.dim;
    switch (r) {
      case -1:
        n = a - 2;
        break;
      case 1:
        a = n + 2;
    }
    switch (i) {
      case -1:
        s = o - 2;
        break;
      case 1:
        o = s + 2;
    }
    let l = -r * this.dim, u = -i * this.dim;
    for (let c = s; c < o; c++) for (let h = n; h < a; h++) this.data[this._idx(h, c)] = t.data[this._idx(h + l, c + u)];
  }
  _getByteView() {
    let t = Zt.byteViewCache.get(this);
    return (t == null ? void 0 : t.buffer) !== this.data.buffer && (t = new Uint8Array(this.data.buffer), Zt.byteViewCache.set(this, t)), t;
  }
  _unpackAtIndex(t, r) {
    return this.unpack(t[r], t[r + 1], t[r + 2]);
  }
}, Zt.byteViewCache = /* @__PURE__ */ new WeakMap(), Zt);
function Ey(e, t) {
  let r = t[0], i = t[1], n = t[2], a = t[3], s = [r, i, n].filter((c) => c !== 0);
  if (s.length === 0) return { r: 0, g: 0, b: 0 };
  let o = Math.min(...s), l = Math.round((e + a) / o), u = (c) => c === 0 ? 0 : Math.floor(l * o / c) % 256;
  return { r: u(r), g: u(i), b: u(n) };
}
P("DEMData", Ay);
var Y2 = class extends At {
  constructor(e, t) {
    super(e, X2, t);
  }
  _createColorRamp(e) {
    let t = { elevationStops: [], colorStops: [] }, r = this._transitionablePaint._values["color-relief-color"].value.expression;
    if (r instanceof bn && r._styleExpression.expression instanceof dt) {
      this.colorRampExpression = r;
      let a = r._styleExpression.expression;
      t.elevationStops = a.labels, t.colorStops = [];
      for (let s of t.elevationStops) t.colorStops.push(a.evaluate({ globals: { elevation: s } }));
    }
    if (t.elevationStops.length < 1 && (t.elevationStops = [0], t.colorStops = [fe.transparent]), t.elevationStops.length < 2 && (t.elevationStops.push(t.elevationStops[0] + 1), t.colorStops.push(t.colorStops[0])), t.elevationStops.length <= e) return t;
    let i = { elevationStops: [], colorStops: [] }, n = (t.elevationStops.length - 1) / (e - 1);
    for (let a = 0; a < t.elevationStops.length - 0.5; a += n) i.elevationStops.push(t.elevationStops[Math.round(a)]), i.colorStops.push(t.colorStops[Math.round(a)]);
    return Me(`Too many colors in specification of ${this.id} color-relief layer, may not render properly. Max possible colors: ${e}, provided: ${t.elevationStops.length}`), i;
  }
  _colorRampChanged() {
    return this.colorRampExpression != this._transitionablePaint._values["color-relief-color"].value.expression;
  }
  getColorRampTextures(e, t, r) {
    if (this.colorRampTextures && !this._colorRampChanged()) return this.colorRampTextures;
    let i = this._createColorRamp(t), n = new ot({ width: i.colorStops.length, height: 1 }), a = new ot({ width: i.colorStops.length, height: 1 });
    for (let s = 0; s < i.elevationStops.length; s++) {
      let o = Ey(i.elevationStops[s], r);
      a.setPixel(0, s, new fe(o.r / 255, o.g / 255, o.b / 255, 1)), n.setPixel(0, s, i.colorStops[s]);
    }
    return this.colorRampTextures = { elevationTexture: new Xh(e, a, e.gl.RGBA), colorTexture: new Xh(e, n, e.gl.RGBA) }, this.colorRampTextures;
  }
  hasOffscreenPass() {
    return !this.isHidden() && !!this.colorRampTextures;
  }
};
const W2 = Te([{ name: "a_pos", components: 2, type: "Int16" }], 4), Z2 = W2.members;
function Qa(e, t, r) {
  let i = r.patternDependencies, n = !1;
  for (let a of t) {
    let s = a.paint.get(`${e}-pattern`);
    s.isConstant() || (n = !0);
    let o = s.constantOr(null);
    o && (n = !0, i[o.to] = !0, i[o.from] = !0);
  }
  return n;
}
function zu(e, t, r, i, n) {
  let { zoom: a } = i, s = n.patternDependencies;
  for (let o of t) {
    let l = o.paint.get(`${e}-pattern`).value;
    if (l.kind !== "constant") {
      let u = l.evaluate({ zoom: a - 1 }, r, {}, n.availableImages), c = l.evaluate({ zoom: a }, r, {}, n.availableImages), h = l.evaluate({ zoom: a + 1 }, r, {}, n.availableImages);
      u = u != null && u.name ? u.name : u, c = c != null && c.name ? c.name : c, h = h != null && h.name ? h.name : h, s[u] = !0, s[c] = !0, s[h] = !0, r.patterns[o.id] = { min: u, mid: c, max: h };
    }
  }
  return r;
}
const Cn = /* @__PURE__ */ new Set();
let El = !1;
function H2(e, t, r = 2) {
  let i = t && t.length, n = i ? t[0] * r : e.length;
  Cn.size && Cn.clear();
  let a = Ty(e, 0, n, r, !0), s = [];
  if (!a || a.next === a.prev) return s;
  let o = 0, l = 0, u = 0;
  if (i && (a = tv(e, t, a, r)), e.length > 80 * r) {
    o = e[0], l = e[1];
    let c = o, h = l;
    for (let p = r; p < n; p += r) {
      let f = e[p], d = e[p + 1];
      f < o && (o = f), d < l && (l = d), f > c && (c = f), d > h && (h = d);
    }
    u = Math.max(c - o, h - l), u = u === 0 ? 0 : 32767 / u;
  }
  return Tl(a, s, o, l, u), s;
}
function Ty(e, t, r, i, n) {
  let a = null;
  if (n === dv(e, t, r, i) > 0) for (let s = t; s < r; s += i) a = Zh(s / i | 0, e[s], e[s + 1], a);
  else for (let s = r - i; s >= t; s -= i) a = Zh(s / i | 0, e[s], e[s + 1], a);
  return a && kn(a, a.next) && (Mn(a), a = a.next), a;
}
function Lr(e, t = e) {
  let r = t === e, i = e, n;
  do
    n = !1, i !== i.next && (Cn.size === 0 || !Cn.has(i)) && (kn(i, i.next) || Fe(i.prev, i, i.next) === 0) ? ((r || i === t) && (t = i.prev), El = !0, Mn(i), i = i.prev, n = !0) : (r || i !== t) && (i = i.next, n = !r);
  while (n || i !== t);
  return t;
}
function Tl(e, t, r, i, n) {
  n && lv(e, r, i, n);
  let a = e, s = !1;
  for (; e.prev !== e.next; ) {
    let o = e.prev, l = e.next;
    if (Fe(o, e, l) < 0 && (n ? J2(e, r, i, n) : K2(e))) t.push(o.i, e.i, l.i), Mn(e), e = l, a = l;
    else if (e = l, e === a) {
      if (El = !1, e = Lr(e), El) {
        a = e;
        continue;
      }
      if (!s) {
        e = Q2(e, t), a = e, s = !0;
        continue;
      }
      ev(e, t, r, i, n);
      break;
    }
  }
}
function K2(e) {
  let t = e.prev, r = e, i = e.next, n = t.x, a = r.x, s = i.x, o = t.y, l = r.y, u = i.y, c = Math.min(n, a, s), h = Math.min(o, l, u), p = Math.max(n, a, s), f = Math.max(o, l, u), d = i.next;
  for (; d !== t; ) {
    if (d.x >= c && d.x <= p && d.y >= h && d.y <= f && (n !== d.x || o !== d.y) && ts(n, o, a, l, s, u, d.x, d.y) && Fe(d.prev, d, d.next) >= 0) return !1;
    d = d.next;
  }
  return !0;
}
function J2(e, t, r, i) {
  let n = e.prev, a = e, s = e.next, o = n.x, l = a.x, u = s.x, c = n.y, h = a.y, p = s.y, f = Math.min(o, l, u), d = Math.min(c, h, p), y = Math.max(o, l, u), m = Math.max(c, h, p), g = Fl(f, d, t, r, i), v = Fl(y, m, t, r, i), x = e.prevZ;
  for (; x && x.z >= g; ) {
    if (x.x >= f && x.x <= y && x.y >= d && x.y <= m && x !== s && (o !== x.x || c !== x.y) && ts(o, c, l, h, u, p, x.x, x.y) && Fe(x.prev, x, x.next) >= 0) return !1;
    x = x.prevZ;
  }
  let b = e.nextZ;
  for (; b && b.z <= v; ) {
    if (b.x >= f && b.x <= y && b.y >= d && b.y <= m && b !== s && (o !== b.x || c !== b.y) && ts(o, c, l, h, u, p, b.x, b.y) && Fe(b.prev, b, b.next) >= 0) return !1;
    b = b.nextZ;
  }
  return !0;
}
function Q2(e, t) {
  let r = e, i = !1;
  do {
    let n = r.prev, a = r.next.next;
    Cy(n, r, r.next, a, !1) && Fn(n, a) && Fn(a, n) && (t.push(n.i, r.i, a.i), Mn(r), Mn(r.next), r = e = a, i = !0), r = r.next;
  } while (r !== e);
  return i ? Lr(r) : r;
}
function ev(e, t, r, i, n) {
  let a = e;
  do {
    let s = a.next.next;
    for (; s !== a.prev; ) {
      if (a.i !== s.i && hv(a, s)) {
        let o = ky(a, s);
        a = Lr(a, a.next), o = Lr(o, o.next), Tl(a, t, r, i, n), Tl(o, t, r, i, n);
        return;
      }
      s = s.next;
    }
    a = a.next;
  } while (a !== e);
}
let Il = !1;
function tv(e, t, r, i) {
  let n = [];
  for (let a = 0, s = t.length; a < s; a++) {
    let o = Ty(e, t[a] * i, a < s - 1 ? t[a + 1] * i : e.length, i, !1);
    o === o.next && Cn.add(o), n.push(cv(o));
  }
  n.sort(rv), nv(e.length / i, t.length), Iy(r, r), Il = !0;
  for (let a = 0; a < n.length; a++) r = iv(n[a], r);
  return Il = !1, Lr(r);
}
function rv(e, t) {
  return e.x - t.x || e.y - t.y || (e.next.y - e.y) / (e.next.x - e.x) - (t.next.y - t.y) / (t.next.x - t.x);
}
function iv(e, t) {
  let r = sv(e, t);
  if (!r) return t;
  let i = ky(r, e), n = i.next;
  return Iy(r, n.next), Lr(i, i.next), Lr(r, r.next);
}
let De = /* @__PURE__ */ new Float64Array(), es = 0;
const Cl = [], kl = [];
function nv(e, t) {
  let r = Math.ceil((e + 2 * t) / 16) + t + 2;
  De.length < r * 4 && (De = new Float64Array(r * 4)), es = 0;
}
function Iy(e, t) {
  let r = e;
  do {
    let i = es++;
    Cl[i] = r;
    let n = r.x, a = r.y, s = r.x, o = r.y, l = 0;
    do {
      let c = r.next;
      r.z = i, c.x < n && (n = c.x), c.x > s && (s = c.x), c.y < a && (a = c.y), c.y > o && (o = c.y), r = c;
    } while (++l < 16 && r !== t);
    kl[i] = r;
    let u = i * 4;
    De[u] = n, De[u + 1] = a, De[u + 2] = s, De[u + 3] = o;
  } while (r !== t);
}
function av(e, t) {
  let r = e.z * 4;
  t.x < De[r] && (De[r] = t.x), t.y < De[r + 1] && (De[r + 1] = t.y), t.x > De[r + 2] && (De[r + 2] = t.x), t.y > De[r + 3] && (De[r + 3] = t.y);
}
function Yh(e) {
  let t = kl[e];
  for (; t.prev.next !== t; ) t = t.next;
  return kl[e] = t, t;
}
function Wh(e) {
  let t = Cl[e];
  for (; t.prev.next !== t; ) t = t.next;
  return Cl[e] = t, t;
}
function sv(e, t) {
  let r = t, i = e.x, n = e.y, a = -1 / 0, s;
  if (kn(e, r)) return r;
  for (let p = 0, f = 0; p < es; p++, f += 4) {
    if (n < De[f + 1] || n > De[f + 3] || De[f] > i || De[f + 2] <= a) continue;
    let d = Yh(p);
    r = Wh(p);
    do {
      if (r.prev.next === r) {
        if (kn(e, r.next)) return r.next;
        if (n <= r.y && n >= r.next.y && r.next.y !== r.y) {
          let y = r.x + (n - r.y) * (r.next.x - r.x) / (r.next.y - r.y);
          if (y <= i && y > a && (a = y, s = r.x < r.next.x ? r : r.next, y === i)) return s;
        }
      }
      r = r.next;
    } while (r !== d);
  }
  if (!s) return null;
  let o = s.x, l = s.y, u = Math.min(n, l), c = Math.max(n, l), h = 1 / 0;
  for (let p = 0, f = 0; p < es; p++, f += 4) {
    if (De[f + 2] < o || De[f] > i || De[f + 3] < u || De[f + 1] > c) continue;
    let d = Yh(p);
    r = Wh(p);
    do {
      if (r.prev.next === r && i >= r.x && r.x >= o && i !== r.x && ts(n < l ? i : a, n, o, l, n < l ? a : i, n, r.x, r.y)) {
        let y = Math.abs(n - r.y) / (i - r.x);
        (Fn(r, e) || r.y === n && r.next.y === n && r.next.x > i) && (y < h || y === h && (r.x > s.x || r.x === s.x && ov(s, r))) && (s = r, h = y);
      }
      r = r.next;
    } while (r !== d);
  }
  return s;
}
function ov(e, t) {
  return Fe(e.prev, e, t.prev) < 0 && Fe(t.next, e, e.next) < 0;
}
const st = [];
let Qr = [], _r = /* @__PURE__ */ new Uint32Array(), qi = /* @__PURE__ */ new Uint32Array();
const Gi = /* @__PURE__ */ new Uint32Array(256);
function lv(e, t, r, i) {
  let n = e, a = 0;
  do
    n.z = Fl(n.x, n.y, t, r, i), st[a++] = n, n = n.next;
  while (n !== e);
  uv(a);
  let s = null;
  for (let o = 0; o < a; o++) {
    let l = st[o];
    l.prevZ = s, s && (s.nextZ = l), s = l;
  }
  s.nextZ = null, st.fill(null, 0, a), Qr.fill(null, 0, a);
}
function uv(e) {
  if (e <= 32) for (let t = 1; t < e; t++) {
    let r = st[t], i = r.z, n = t - 1;
    for (; n >= 0 && st[n].z > i; ) st[n + 1] = st[n], n--;
    st[n + 1] = r;
  }
  else {
    _r.length < e && (_r = new Uint32Array(e), qi = new Uint32Array(e), Qr = Array(e));
    for (let t = 0; t < e; t++) _r[t] = st[t].z;
    ma(e, st, _r, Qr, qi, 0), ma(e, Qr, qi, st, _r, 8), ma(e, st, _r, Qr, qi, 16), ma(e, Qr, qi, st, _r, 24);
  }
}
function ma(e, t, r, i, n, a) {
  Gi.fill(0);
  for (let o = 0; o < e; o++) Gi[r[o] >>> a & 255]++;
  let s = 0;
  for (let o = 0; o < 256; o++) {
    let l = Gi[o];
    Gi[o] = s, s += l;
  }
  for (let o = 0; o < e; o++) {
    let l = r[o], u = Gi[l >>> a & 255]++;
    i[u] = t[o], n[u] = l;
  }
}
function Fl(e, t, r, i, n) {
  return e = (e - r) * n | 0, t = (t - i) * n | 0, e = (e | e << 8) & 16711935, e = (e | e << 4) & 252645135, e = (e | e << 2) & 858993459, e = (e | e << 1) & 1431655765, t = (t | t << 8) & 16711935, t = (t | t << 4) & 252645135, t = (t | t << 2) & 858993459, t = (t | t << 1) & 1431655765, e | t << 1;
}
function cv(e) {
  let t = e, r = e;
  do
    (t.x < r.x || t.x === r.x && t.y < r.y) && (r = t), t = t.next;
  while (t !== e);
  return r;
}
function ts(e, t, r, i, n, a, s, o) {
  return (n - s) * (t - o) >= (e - s) * (a - o) && (e - s) * (i - o) >= (r - s) * (t - o) && (r - s) * (a - o) >= (n - s) * (i - o);
}
function hv(e, t) {
  let r = kn(e, t) && Fe(e.prev, e, e.next) > 0 && Fe(t.prev, t, t.next) > 0;
  return e.next.i !== t.i && (r || Fn(e, t) && Fn(t, e) && (Fe(e.prev, e, t.prev) !== 0 || Fe(e, t.prev, t) !== 0)) && !pv(e, t) && (r || fv(e, t));
}
function Fe(e, t, r) {
  return (t.y - e.y) * (r.x - t.x) - (t.x - e.x) * (r.y - t.y);
}
function kn(e, t) {
  return e.x === t.x && e.y === t.y;
}
function Cy(e, t, r, i, n = !0) {
  let a = Fe(e, t, r), s = Fe(e, t, i), o = Fe(r, i, e), l = Fe(r, i, t);
  return (a > 0 && s < 0 || a < 0 && s > 0) && (o > 0 && l < 0 || o < 0 && l > 0) ? !0 : n ? !!(a === 0 && ga(e, r, t) || s === 0 && ga(e, i, t) || o === 0 && ga(r, e, i) || l === 0 && ga(r, t, i)) : !1;
}
function ga(e, t, r) {
  return t.x <= Math.max(e.x, r.x) && t.x >= Math.min(e.x, r.x) && t.y <= Math.max(e.y, r.y) && t.y >= Math.min(e.y, r.y);
}
function pv(e, t) {
  let r = Math.min(e.x, t.x), i = Math.max(e.x, t.x), n = Math.min(e.y, t.y), a = Math.max(e.y, t.y), s = e;
  do {
    let o = s.next;
    if (s.x > i && o.x > i || s.x < r && o.x < r || s.y > a && o.y > a || s.y < n && o.y < n) s = o;
    else {
      if (s.i !== e.i && o.i !== e.i && s.i !== t.i && o.i !== t.i && Cy(s, o, e, t)) return !0;
      s = o;
    }
  } while (s !== e);
  return !1;
}
function Fn(e, t) {
  return Fe(e.prev, e, e.next) < 0 ? Fe(e, t, e.next) >= 0 && Fe(e, e.prev, t) >= 0 : Fe(e, t, e.prev) < 0 || Fe(e, e.next, t) < 0;
}
function fv(e, t) {
  let r = e, i = !1, n = (e.x + t.x) / 2, a = (e.y + t.y) / 2;
  do {
    let s = r.next;
    r.y > a != s.y > a && n < (s.x - r.x) * (a - r.y) / (s.y - r.y) + r.x && (i = !i), r = s;
  } while (r !== e);
  return i;
}
function ky(e, t) {
  let r = Ml(e.i, e.x, e.y), i = Ml(t.i, t.x, t.y), n = e.next, a = t.prev;
  return e.next = t, t.prev = e, r.next = n, n.prev = r, i.next = r, r.prev = i, a.next = i, i.prev = a, i;
}
function Zh(e, t, r, i) {
  let n = Ml(e, t, r);
  return i ? (n.next = i.next, n.prev = i, i.next.prev = n, i.next = n) : (n.prev = n, n.next = n), n;
}
function Mn(e) {
  e.next.prev = e.prev, e.prev.next = e.next, e.prevZ && (e.prevZ.nextZ = e.nextZ), e.nextZ && (e.nextZ.prevZ = e.prevZ), Il && av(e.prev, e.next);
}
function Ml(e, t, r) {
  return { i: e, x: t, y: r, prev: null, next: null, z: 0, prevZ: null, nextZ: null };
}
function dv(e, t, r, i) {
  let n = 0;
  for (let a = t, s = r - i; a < r; a += i) n += (e[s] - e[a]) * (e[a + 1] + e[s + 1]), s = a;
  return n;
}
var rn = class {
  constructor(e, t) {
    if (t > e) throw Error("Min granularity must not be greater than base granularity.");
    this._baseZoomGranularity = e, this._minGranularity = t;
  }
  getGranularityForZoomLevel(e) {
    let t = 1 << e;
    return Math.max(Math.floor(this._baseZoomGranularity / t), this._minGranularity, 1);
  }
}, Fr, yv = (Fr = class {
  constructor(t) {
    this.fill = t.fill, this.line = t.line, this.tile = t.tile, this.stencil = t.stencil, this.circle = t.circle;
  }
}, Fr.noSubdivision = new Fr({ fill: new rn(0, 0), line: new rn(0, 0), tile: new rn(0, 0), stencil: new rn(0, 0), circle: 1 }), Fr);
P("SubdivisionGranularityExpression", rn), P("SubdivisionGranularitySetting", yv);
const bo = -32768, wo = 32767;
var mv = class {
  constructor(e, t) {
    this._vertexBuffer = [], this._vertexDictionary = /* @__PURE__ */ new Map(), this._used = !1, this._granularity = e, this._granularityCellSize = te / e, this._canonical = t;
  }
  _getKey(e, t) {
    return e += 32768, t += 32768, e << 16 | t;
  }
  _vertexToIndex(e, t) {
    if (e < -32768 || t < -32768 || e > 32767 || t > 32767) throw Error("Vertex coordinates are out of signed 16 bit integer range.");
    let r = Math.round(e) | 0, i = Math.round(t) | 0, n = this._getKey(r, i), a = this._vertexDictionary.get(n);
    if (a !== void 0) return a;
    let s = this._vertexBuffer.length / 2;
    return this._vertexDictionary.set(n, s), this._vertexBuffer.push(r, i), s;
  }
  _subdivideTrianglesScanline(e, t) {
    if (this._granularity < 2) return vv(this._vertexBuffer, xv(e, t));
    let r = [], i = e.length;
    for (let n = 0; n < i; n += 3) {
      let a = [t[e[n + 0]], t[e[n + 1]], t[e[n + 2]]], s = [this._vertexBuffer[a[0] * 2 + 0], this._vertexBuffer[a[0] * 2 + 1], this._vertexBuffer[a[1] * 2 + 0], this._vertexBuffer[a[1] * 2 + 1], this._vertexBuffer[a[2] * 2 + 0], this._vertexBuffer[a[2] * 2 + 1]], o = 1 / 0, l = 1 / 0, u = -1 / 0, c = -1 / 0;
      for (let y = 0; y < 3; y++) {
        let m = s[y * 2], g = s[y * 2 + 1];
        o = Math.min(o, m), u = Math.max(u, m), l = Math.min(l, g), c = Math.max(c, g);
      }
      if (o === u || l === c) continue;
      let h = Math.floor(o / this._granularityCellSize), p = Math.ceil(u / this._granularityCellSize), f = Math.floor(l / this._granularityCellSize), d = Math.ceil(c / this._granularityCellSize);
      if (h === p && f === d) r.push(...a);
      else for (let y = f; y < d; y++) {
        let m = this._scanlineGenerateVertexRingForCellRow(y, s, a);
        bv(this._vertexBuffer, m, r);
      }
    }
    return r;
  }
  _scanlineGenerateVertexRingForCellRow(e, t, r) {
    let i = e * this._granularityCellSize, n = i + this._granularityCellSize, a = [];
    for (let s = 0; s < 3; s++) {
      let o = t[s * 2], l = t[s * 2 + 1], u = t[(s + 1) * 2 % 6], c = t[((s + 1) * 2 + 1) % 6], h = t[(s + 2) * 2 % 6], p = t[((s + 2) * 2 + 1) % 6], f = u - o, d = c - l, y = f === 0, m = d === 0, g = (i - l) / d, v = (n - l) / d, x = Math.min(g, v), b = Math.max(g, v);
      if (!m && (x >= 1 || b <= 0) || m && (l < i || l > n)) {
        c >= i && c <= n && a.push(r[(s + 1) % 3]);
        continue;
      }
      if (!m && x > 0) {
        let _ = o + f * x, A = l + d * x;
        a.push(this._vertexToIndex(_, A));
      }
      let w = o + f * Math.max(x, 0), D = o + f * Math.min(b, 1);
      if (y || this._generateIntraEdgeVertices(a, o, l, u, c, w, D), !m && b < 1) {
        let _ = o + f * b, A = l + d * b;
        a.push(this._vertexToIndex(_, A));
      }
      (m || c >= i && c <= n) && a.push(r[(s + 1) % 3]), !m && (c <= i || c >= n) && this._generateInterEdgeVertices(a, o, l, u, c, h, p, D, i, n);
    }
    return a;
  }
  _generateIntraEdgeVertices(e, t, r, i, n, a, s) {
    let o = i - t, l = n - r, u = l === 0, c = u ? Math.min(t, i) : Math.min(a, s), h = u ? Math.max(t, i) : Math.max(a, s), p = Math.floor(c / this._granularityCellSize) + 1, f = Math.ceil(h / this._granularityCellSize) - 1;
    if (u ? t < i : a < s) for (let d = p; d <= f; d++) {
      let y = d * this._granularityCellSize, m = r + l * (y - t) / o;
      e.push(this._vertexToIndex(y, m));
    }
    else for (let d = f; d >= p; d--) {
      let y = d * this._granularityCellSize, m = r + l * (y - t) / o;
      e.push(this._vertexToIndex(y, m));
    }
  }
  _generateInterEdgeVertices(e, t, r, i, n, a, s, o, l, u) {
    let c = n - r, h = a - i, p = s - n, f = (l - n) / p, d = (u - n) / p, y = Math.min(f, d), m = Math.max(f, d), g = i + h * y, v = Math.floor(Math.min(g, o) / this._granularityCellSize) + 1, x = Math.ceil(Math.max(g, o) / this._granularityCellSize) - 1, b = o < g, w = p === 0;
    if (w && (s === l || s === u)) return;
    if (w || y >= 1 || m <= 0) {
      let _ = t - a, A = r - s, E = (l - s) / A, R = (u - s) / A, B = a + _ * Math.min(E, R);
      v = Math.floor(Math.min(B, o) / this._granularityCellSize) + 1, x = Math.ceil(Math.max(B, o) / this._granularityCellSize) - 1, b = o < B;
    }
    let D = c > 0 ? u : l;
    if (b) for (let _ = v; _ <= x; _++) {
      let A = _ * this._granularityCellSize;
      e.push(this._vertexToIndex(A, D));
    }
    else for (let _ = x; _ >= v; _--) {
      let A = _ * this._granularityCellSize;
      e.push(this._vertexToIndex(A, D));
    }
  }
  _generateOutline(e, t) {
    let r = [], i = 0;
    for (let n of e) {
      let a = this._granularity < 2 ? this._ringPathIndices(n, i, t) : this._pointArrayToIndices(Tr(n, this._granularity, !0));
      i += n.length;
      let s = [];
      for (let o = 1; o < a.length; o++) s.push(a[o - 1]), s.push(a[o]);
      r.push(s);
    }
    return r;
  }
  _ringPathIndices(e, t, r) {
    let i = r.slice(t, t + e.length);
    return i.length >= 2 && My(e) && i.push(i[0]), i;
  }
  _handlePoles(e) {
    let t = !1, r = !1;
    this._canonical && (this._canonical.y === 0 && (t = !0), this._canonical.y === (1 << this._canonical.z) - 1 && (r = !0)), (t || r) && this._fillPoles(e, t, r);
  }
  _ensureNoPoleVertices() {
    let e = this._vertexBuffer;
    for (let t = 0; t < e.length; t += 2) {
      let r = e[t + 1];
      r === -32768 && (e[t + 1] = -32767), r === 32767 && (e[t + 1] = 32766);
    }
  }
  _generatePoleQuad(e, t, r, i, n, a) {
    i > n == (a === -32768) ? (e.push(r), e.push(t), e.push(this._vertexToIndex(i, a)), e.push(this._vertexToIndex(n, a)), e.push(r), e.push(this._vertexToIndex(i, a))) : (e.push(t), e.push(r), e.push(this._vertexToIndex(i, a)), e.push(r), e.push(this._vertexToIndex(n, a)), e.push(this._vertexToIndex(i, a)));
  }
  _fillPoles(e, t, r) {
    let i = this._vertexBuffer, n = te, a = e.length;
    for (let s = 2; s < a; s += 3) {
      let o = e[s - 2], l = e[s - 1], u = e[s], c = i[o * 2], h = i[o * 2 + 1], p = i[l * 2], f = i[l * 2 + 1], d = i[u * 2], y = i[u * 2 + 1];
      t && (h === 0 && f === 0 && this._generatePoleQuad(e, o, l, c, p, bo), f === 0 && y === 0 && this._generatePoleQuad(e, l, u, p, d, bo), y === 0 && h === 0 && this._generatePoleQuad(e, u, o, d, c, bo)), r && (h === n && f === n && this._generatePoleQuad(e, o, l, c, p, wo), f === n && y === n && this._generatePoleQuad(e, l, u, p, d, wo), y === n && h === n && this._generatePoleQuad(e, u, o, d, c, wo));
    }
  }
  _initializeVertices(e) {
    let t = [];
    for (let r = 0; r < e.length; r += 2) t.push(this._vertexToIndex(e[r], e[r + 1]));
    return t;
  }
  subdividePolygonInternal(e, t) {
    var o;
    if (this._used) throw Error("Subdivision: multiple use not allowed.");
    this._used = !0;
    let { flattened: r, holeIndices: i } = gv(e), n = this._initializeVertices(r), a;
    try {
      let l = H2(r, i);
      a = this._subdivideTrianglesScanline(l, n);
    } catch (l) {
      console.error(l);
    }
    let s = [];
    return t && (s = this._generateOutline(e, n)), this._ensureNoPoleVertices(), this._handlePoles(a), this._granularity >= 2 && ((o = this._canonical) == null ? void 0 : o.z) === 0 && (a = this._removeTrianglesOutsideTileX(a), s = s.map((l) => this._removeLinesOutsideTileX(l))), { verticesFlattened: this._vertexBuffer, indicesTriangles: a, indicesLineList: s };
  }
  _vertexOutsideTileX(e) {
    let t = this._vertexBuffer[e * 2];
    return t < 0 || t > 8192;
  }
  _removeTrianglesOutsideTileX(e) {
    let t = [];
    for (let r = 0; r < e.length; r += 3) this._vertexOutsideTileX(e[r]) || this._vertexOutsideTileX(e[r + 1]) || this._vertexOutsideTileX(e[r + 2]) || t.push(e[r], e[r + 1], e[r + 2]);
    return t;
  }
  _removeLinesOutsideTileX(e) {
    let t = [];
    for (let r = 0; r < e.length; r += 2) this._vertexOutsideTileX(e[r]) || this._vertexOutsideTileX(e[r + 1]) || t.push(e[r], e[r + 1]);
    return t;
  }
  _pointArrayToIndices(e) {
    let t = [];
    for (let r of e) t.push(this._vertexToIndex(r.x, r.y));
    return t;
  }
};
function Fy(e, t, r, i = !0) {
  return new mv(r, t).subdividePolygonInternal(e, i);
}
function Tr(e, t, r = !1) {
  if (!e || e.length < 1 || e.length < 2) return [];
  let i = r && My(e);
  if (t < 2) return i ? [...e, e[0]] : [...e];
  let n = Math.floor(te / t), a = [];
  a.push(new T(e[0].x, e[0].y));
  let s = e.length, o = i ? s : s - 1;
  for (let l = 0; l < o; l++) {
    let u = e[l], c = l < s - 1 ? e[l + 1] : e[0], h = u.x, p = u.y, f = c.x, d = c.y, y = h !== f, m = p !== d;
    if (!y && !m) continue;
    let g = f - h, v = d - p, x = Math.abs(g), b = Math.abs(v), w = h, D = p;
    for (; ; ) {
      let A = g > 0 ? (Math.floor(w / n) + 1) * n : (Math.ceil(w / n) - 1) * n, E = v > 0 ? (Math.floor(D / n) + 1) * n : (Math.ceil(D / n) - 1) * n, R = Math.abs(w - A), B = Math.abs(D - E), L = Math.abs(w - f), $ = Math.abs(D - d), M = y ? R / x : 1 / 0, C = m ? B / b : 1 / 0;
      if ((L <= R || !y) && ($ <= B || !m)) break;
      if (M < C && y || !m) {
        w = A, D += v * M;
        let N = new T(w, Math.round(D));
        (a[a.length - 1].x !== N.x || a[a.length - 1].y !== N.y) && a.push(N);
      } else {
        w += g * C, D = E;
        let N = new T(Math.round(w), D);
        (a[a.length - 1].x !== N.x || a[a.length - 1].y !== N.y) && a.push(N);
      }
    }
    let _ = new T(f, d);
    (a[a.length - 1].x !== _.x || a[a.length - 1].y !== _.y) && a.push(_);
  }
  return a;
}
function My(e) {
  return !e[0].equals(e[e.length - 1]);
}
function gv(e) {
  let t = [], r = [];
  for (let i of e) if (i.length !== 0) {
    i !== e[0] && t.push(r.length / 2);
    for (let n of i) r.push(n.x), r.push(n.y);
  }
  return { flattened: r, holeIndices: t };
}
function xv(e, t) {
  let r = Array(e.length);
  for (let i = 0; i < e.length; i++) r[i] = t[e[i]];
  return r;
}
function vv(e, t) {
  let r = [];
  for (let i = 0; i < t.length; i += 3) {
    let n = t[i], a = t[i + 1], s = t[i + 2], o = e[n * 2], l = e[n * 2 + 1], u = e[a * 2], c = e[a * 2 + 1], h = e[s * 2], p = e[s * 2 + 1], f = u - o, d = c - l, y = h - o;
    f * (p - l) - d * y > 0 ? (r.push(n), r.push(s), r.push(a)) : (r.push(n), r.push(a), r.push(s));
  }
  return r;
}
function bv(e, t, r) {
  if (t.length === 0) throw Error("Subdivision vertex ring is empty.");
  let i = 0, n = e[t[0] * 2];
  for (let l = 1; l < t.length; l++) {
    let u = e[t[l] * 2];
    u < n && (n = u, i = l);
  }
  let a = t.length, s = i, o = (s + 1) % a;
  for (; ; ) {
    let l = s - 1 >= 0 ? s - 1 : a - 1, u = (o + 1) % a, c = e[t[l] * 2], h = e[t[l] * 2 + 1], p = e[t[u] * 2], f = e[t[u] * 2 + 1], d = e[t[s] * 2], y = e[t[s] * 2 + 1], m = e[t[o] * 2], g = e[t[o] * 2 + 1], v = !1;
    if (c < p) v = !0;
    else if (c > p) v = !1;
    else {
      let x = g - y, b = -(m - d), w = y < g ? 1 : -1;
      ((c - d) * x + (h - y) * b) * w > ((p - d) * x + (f - y) * b) * w && (v = !0);
    }
    if (v) {
      let x = t[l], b = t[s], w = t[o];
      x !== b && x !== w && b !== w && r.push(w, b, x), s--, s < 0 && (s = a - 1);
    } else {
      let x = t[u], b = t[s], w = t[o];
      x !== b && x !== w && b !== w && r.push(w, b, x), o++, o >= a && (o = 0);
    }
    if (l === u) break;
  }
}
function Py(e, t, r, i, n, a, s, o, l) {
  let u = n.length / 2, c = s && o && l;
  if (u < ut.MAX_VERTEX_ARRAY_LENGTH) {
    let h = t.prepareSegment(u, r, i), p = h.vertexLength;
    for (let y = 0; y < a.length; y += 3) i.emplaceBack(p + a[y], p + a[y + 1], p + a[y + 2]);
    h.vertexLength += u, h.primitiveLength += a.length / 3;
    let f, d;
    c && (d = s.prepareSegment(u, r, o), f = d.vertexLength, d.vertexLength += u);
    for (let y = 0; y < n.length; y += 2) e(n[y], n[y + 1]);
    if (c) for (let y of l) {
      for (let m = 1; m < y.length; m += 2) o.emplaceBack(f + y[m - 1], f + y[m]);
      d.primitiveLength += y.length / 2;
    }
  } else wv(t, r, i, n, a, e), c && _v(s, r, o, n, l, e), t.forceNewSegmentOnNextPrepare(), s == null || s.forceNewSegmentOnNextPrepare();
}
function pn(e, t, r, i, n, a, s) {
  if (a) {
    let o = i.count;
    return r(t[n * 2], t[n * 2 + 1]), e[n] = i.count, i.count++, s.vertexLength++, o;
  }
  return e[n];
}
function wv(e, t, r, i, n, a) {
  let s = [];
  for (let h = 0; h < i.length / 2; h++) s.push(-1);
  let o = { count: 0 }, l = 0, u = e.getOrCreateLatestSegment(t, r), c = u.vertexLength;
  for (let h = 2; h < n.length; h += 3) {
    let p = n[h - 2], f = n[h - 1], d = n[h], y = s[p] < l, m = s[f] < l, g = s[d] < l, v = +!!y + +!!m + +!!g;
    u.vertexLength + v > ut.MAX_VERTEX_ARRAY_LENGTH && (u = e.createNewSegment(t, r), l = o.count, y = !0, m = !0, g = !0, c = 0);
    let x = pn(s, i, a, o, p, y, u), b = pn(s, i, a, o, f, m, u), w = pn(s, i, a, o, d, g, u);
    r.emplaceBack(c + x - l, c + b - l, c + w - l), u.primitiveLength++;
  }
}
function _v(e, t, r, i, n, a) {
  let s = [];
  for (let h = 0; h < i.length / 2; h++) s.push(-1);
  let o = { count: 0 }, l = 0, u = e.getOrCreateLatestSegment(t, r), c = u.vertexLength;
  for (let h of n) for (let p = 1; p < h.length; p += 2) {
    let f = h[p - 1], d = h[p], y = s[f] < l, m = s[d] < l, g = +!!y + +!!m;
    u.vertexLength + g > ut.MAX_VERTEX_ARRAY_LENGTH && (u = e.createNewSegment(t, r), l = o.count, y = !0, m = !0, c = 0);
    let v = pn(s, i, a, o, f, y, u), x = pn(s, i, a, o, d, m, u);
    r.emplaceBack(c + v - l, c + x - l), u.primitiveLength++;
  }
}
var By = class {
  constructor(e) {
    this.zoom = e.zoom, this.overscaling = e.overscaling, this.layers = e.layers, this.layerIds = this.layers.map((t) => t.id), this.index = e.index, this.hasDependencies = !1, this.sdfPatterns = {}, this.patternFeatures = [], this.layoutVertexArray = new Tx(), this.indexArray = new Nn(), this.indexArray2 = new fl(), this.programConfigurations = new Br(e.layers, e.zoom), this.segments = new ut(), this.segments2 = new ut(), this.stateDependentLayerIds = this.layers.filter((t) => t.isStateDependent()).map((t) => t.id);
  }
  populate(e, t, r) {
    this.hasDependencies = Qa("fill", this.layers, t);
    let i = this.layers[0].layout.get("fill-sort-key"), n = !i.isConstant(), a = [], s = new le(this.zoom), o = this.layers[0]._featureFilter.needGeometry;
    for (let { feature: l, id: u, index: c, sourceLayerIndex: h } of e) {
      let p = Ei(l, o);
      if (!this.layers[0]._featureFilter.filter(s, p, r)) continue;
      let f = n ? i.evaluate(p, {}, r, t.availableImages) : void 0, d = { id: u, properties: l.properties, type: l.type, sourceLayerIndex: h, index: c, geometry: o ? p.geometry : Or(l), patterns: {}, sortKey: f };
      a.push(d);
    }
    n && a.sort((l, u) => l.sortKey - u.sortKey);
    for (let l of a) {
      let { geometry: u, index: c, sourceLayerIndex: h } = l;
      if (this.hasDependencies) {
        let f = zu("fill", this.layers, l, { zoom: this.zoom }, t);
        this.patternFeatures.push(f);
      } else this.addFeature(l, u, c, r, {}, t.subdivisionGranularity);
      let p = e[c].feature;
      t.featureIndex.insert(p, u, c, h, this.index);
    }
  }
  update(e, t, r) {
    this.stateDependentLayers.length && this.programConfigurations.updatePaintArrays(e, t, this.stateDependentLayers, { imagePositions: r });
  }
  addFeatures({ options: e, canonical: t, patternPositions: r, patternMap: i }) {
    this.detectSdfPatterns(i);
    for (let n of this.patternFeatures) this.addFeature(n, n.geometry, n.index, t, r, e.subdivisionGranularity);
  }
  detectSdfPatterns(e) {
    for (let t of this.patternFeatures) for (let r in t.patterns) {
      let i = t.patterns[r];
      this.recordSdfPattern(r, e[i.min]), this.recordSdfPattern(r, e[i.mid]), this.recordSdfPattern(r, e[i.max]);
    }
    for (let t of this.layers) {
      let r = t.paint.get("fill-pattern").constantOr(null);
      r && (this.recordSdfPattern(t.id, e[r.from.toString()]), this.recordSdfPattern(t.id, e[r.to.toString()]));
    }
  }
  recordSdfPattern(e, t) {
    if (!t) return;
    let r = t.sdf === !0, i = this.sdfPatterns[e];
    i === void 0 ? this.sdfPatterns[e] = r : i !== r && Me(`Style sheet warning: Cannot mix SDF and non-SDF fill patterns in layer "${e}"`);
  }
  isEmpty() {
    return this.layoutVertexArray.length === 0;
  }
  uploadPending() {
    return !this.uploaded || this.programConfigurations.needsUpload;
  }
  upload(e) {
    this.uploaded || (this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, Z2), this.indexBuffer = e.createIndexBuffer(this.indexArray), this.indexBuffer2 = e.createIndexBuffer(this.indexArray2)), this.programConfigurations.upload(e), this.uploaded = !0;
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.indexBuffer2.destroy(), this.programConfigurations.destroy(), this.segments.destroy(), this.segments2.destroy());
  }
  addFeature(e, t, r, i, n, a) {
    for (let s of fs(t, 500)) {
      let o = Fy(s, i, a.fill.getGranularityForZoomLevel(i.z)), l = this.layoutVertexArray;
      Py((u, c) => {
        l.emplaceBack(u, c);
      }, this.segments, this.layoutVertexArray, this.indexArray, o.verticesFlattened, o.indicesTriangles, this.segments2, this.indexArray2, o.indicesLineList);
    }
    this.programConfigurations.populatePaintArrays(this.layoutVertexArray.length, e, r, { imagePositions: n, canonical: i });
  }
};
P("FillBucket", By, { omit: ["layers", "patternFeatures"] });
let Dv;
const Sv = () => Dv || (Dv = new Je({ "fill-sort-key": new j(S.layout_fill["fill-sort-key"], "fill-sort-key") }));
let Av;
const Ev = () => Av || (Av = new Je({ "fill-antialias": new V(S.paint_fill["fill-antialias"], "fill-antialias"), "fill-opacity": new j(S.paint_fill["fill-opacity"], "fill-opacity"), "fill-layer-opacity": new V(S.paint_fill["fill-layer-opacity"], "fill-layer-opacity"), "fill-layer-blend": new V(S.paint_fill["fill-layer-blend"], "fill-layer-blend"), "fill-color": new j(S.paint_fill["fill-color"], "fill-color"), "fill-outline-color": new j(S.paint_fill["fill-outline-color"], "fill-outline-color"), "fill-translate": new V(S.paint_fill["fill-translate"], "fill-translate"), "fill-translate-anchor": new V(S.paint_fill["fill-translate-anchor"], "fill-translate-anchor"), "fill-pattern": new Sn(S.paint_fill["fill-pattern"], "fill-pattern") }));
var Tv = { get paint() {
  return Ev();
}, get layout() {
  return Sv();
} }, Iv = class extends At {
  constructor(e, t) {
    super(e, Tv, t);
  }
  recalculate(e, t) {
    super.recalculate(e, t);
    let r = this.paint._values["fill-outline-color"];
    r.value.kind === "constant" && r.value.value === void 0 && (this.paint._values["fill-outline-color"] = this.paint._values["fill-color"]);
  }
  createBucket(e) {
    return new By(e);
  }
  queryRadius() {
    return Ss(this.paint.get("fill-translate"));
  }
  queryIntersectsFeature({ queryGeometry: e, geometry: t, projectedCamera: r, pixelsToTileUnits: i }) {
    return Qd(As(e, this.paint.get("fill-translate"), this.paint.get("fill-translate-anchor"), -r.bearingInRadians, i), t);
  }
  isTileClipped() {
    return !0;
  }
};
const Cv = Te([{ name: "a_pos", components: 2, type: "Int16" }, { name: "a_normal_ed", components: 4, type: "Int16" }], 4), kv = Te([{ name: "a_centroid", components: 2, type: "Int16" }], 4), Fv = Cv.members;
var Un = class {
  constructor(e, t, r, i, n) {
    for (this.properties = /* @__PURE__ */ Object.create(null), this.extent = r, this.type = 0, this.id = void 0, this._pbf = e, this._geometry = -1, this._keys = i, this._values = n; e.pos < t; ) {
      let a = e.readVarint();
      if (a === 8) this.id = e.readVarint();
      else if (a === 18) {
        let s = e.readVarint() + e.pos;
        for (; e.pos < s; ) {
          let o = i[e.readVarint()], l = n[e.readVarint()];
          this.properties[o] = l;
        }
      } else a === 24 ? this.type = e.readVarint() : (a === 34 && (this._geometry = e.pos), e.skip(a));
    }
  }
  loadGeometry() {
    if (this._geometry < 0) throw Error("feature has no geometry");
    let e = this._pbf;
    e.pos = this._geometry;
    let t = e.readVarint() + e.pos, r = [], i, n = 1, a = 0, s = 0, o = 0;
    for (; e.pos < t; ) {
      if (a <= 0) {
        let l = e.readVarint();
        if (n = l & 7, a = l >> 3, a === 0) continue;
      }
      if (a--, n === 1) s += e.readSVarint(), o += e.readSVarint(), i && r.push(i), i = [new T(s, o)];
      else if (n === 2) s += e.readSVarint(), o += e.readSVarint(), i && i.push(new T(s, o));
      else if (n === 7) i && i.push(i[0].clone());
      else throw Error(`unknown command ${n}`);
    }
    return i && r.push(i), r;
  }
  bbox() {
    if (this._geometry < 0) throw Error("feature has no geometry");
    let e = this._pbf;
    e.pos = this._geometry;
    let t = e.readVarint() + e.pos, r = 1, i = 0, n = 0, a = 0, s = 1 / 0, o = -1 / 0, l = 1 / 0, u = -1 / 0;
    for (; e.pos < t; ) {
      if (i <= 0) {
        let c = e.readVarint();
        if (r = c & 7, i = c >> 3, i === 0) continue;
      }
      if (i--, r === 1 || r === 2) n += e.readSVarint(), a += e.readSVarint(), n < s && (s = n), n > o && (o = n), a < l && (l = a), a > u && (u = a);
      else if (r !== 7) throw Error(`unknown command ${r}`);
    }
    return [s, l, o, u];
  }
  toGeoJSON(e, t, r) {
    let i = this.extent * 2 ** r, n = this.extent * e, a = this.extent * t, s = this.loadGeometry();
    function o(h) {
      return [(h.x + n) * 360 / i - 180, 360 / Math.PI * Math.atan(Math.exp((1 - (h.y + a) * 2 / i) * Math.PI)) - 90];
    }
    function l(h) {
      return h.map(o);
    }
    let u;
    if (this.type === 1) {
      let h = [];
      for (let f of s) h.push(f[0]);
      let p = l(h);
      u = h.length === 1 ? { type: "Point", coordinates: p[0] } : { type: "MultiPoint", coordinates: p };
    } else if (this.type === 2) {
      let h = s.map(l);
      u = h.length === 1 ? { type: "LineString", coordinates: h[0] } : { type: "MultiLineString", coordinates: h };
    } else if (this.type === 3) {
      let h = Ly(s), p = [];
      for (let f of h) p.push(f.map(l));
      u = p.length === 1 ? { type: "Polygon", coordinates: p[0] } : { type: "MultiPolygon", coordinates: p };
    } else throw Error("unknown feature type");
    let c = { type: "Feature", geometry: u, properties: this.properties };
    return this.id != null && (c.id = this.id), c;
  }
};
Un.types = ["Unknown", "Point", "LineString", "Polygon"];
function Ly(e) {
  let t = e.length;
  if (t <= 1) return [e];
  let r = [], i, n;
  for (let a = 0; a < t; a++) {
    let s = Mv(e[a]);
    s !== 0 && (n === void 0 && (n = s < 0), n === s < 0 ? (i && r.push(i), i = [e[a]]) : i && i.push(e[a]));
  }
  return i && r.push(i), r;
}
function Mv(e) {
  let t = 0;
  for (let r = 0, i = e.length, n = i - 1, a, s; r < i; n = r++) a = e[r], s = e[n], t += (s.x - a.x) * (a.y + s.y);
  return t;
}
var Pv = class {
  constructor(e, t) {
    for (this.version = 1, this.name = "", this.extent = 4096, this.length = 0, this._pbf = e, this._keys = [], this._values = [], this._features = [], t === void 0 && (t = e.length); e.pos < t; ) {
      let r = e.readVarint();
      r === 10 ? this.name = e.readString() : r === 18 ? (this._features.push(e.pos), e.skip(r)) : r === 26 ? this._keys.push(e.readString()) : r === 34 ? this._values.push(Bv(e)) : r === 40 ? this.extent = e.readVarint() : r === 120 ? this.version = e.readVarint() : e.skip(r);
    }
    this.length = this._features.length;
  }
  feature(e) {
    if (e < 0 || e >= this._features.length) throw Error("feature index out of bounds");
    this._pbf.pos = this._features[e];
    let t = this._pbf.readVarint() + this._pbf.pos;
    return new Un(this._pbf, t, this.extent, this._keys, this._values);
  }
};
function Bv(e) {
  let t = null, r = e.readVarint() + e.pos;
  for (; e.pos < r; ) {
    let i = e.readVarint();
    t = i === 10 ? e.readString() : i === 21 ? e.readFloat() : i === 25 ? e.readDouble() : i === 32 ? e.readVarint(!0) : i === 40 ? e.readVarint() : i === 48 ? e.readSVarint() : i === 56 ? e.readBoolean() : (e.skip(i), null);
  }
  if (t == null) throw Error("unknown feature value");
  return t;
}
var zy = class {
  constructor(e, t = e.length) {
    let r = /* @__PURE__ */ Object.create(null);
    for (; e.pos < t; ) {
      let i = e.readVarint();
      if (i === 26) {
        let n = new Pv(e, e.readVarint() + e.pos);
        n.length && (r[n.name] = n);
      } else e.skip(i);
    }
    this.layers = r;
  }
};
function Lv(e, t) {
  return t <= 0 || !e || e.length === 0 ? e : e.map((r) => Rv(r, t));
}
function zv(e, t) {
  let r = r2(te / 2, te / 2, t), i = xt.fromLngLat(r).meterInMercatorCoordinateUnits(), n = (1 << t.z) * te;
  return e * i * n;
}
const Vv = Math.cos(35 * Math.PI / 180);
function Ov(e) {
  let t = [null];
  for (let a = 1; a < e.length; a++) {
    let s = e[a].sub(e[a - 1]), o = !Za(e[a], e[a - 1]) && s.mag() > 0;
    t.push(o ? s._perp() : null);
  }
  let r = e.length - 1, i = r > 1 && e[0].equals(e[r]), n = [null];
  for (let a = 1; a <= r; a++) {
    let s = t[a];
    if (!s) {
      n.push(null);
      continue;
    }
    let o = i && a === 1 ? t[r] : t[a - 1], l = i && a === r ? t[1] : t[a + 1];
    n.push({ start: Hh(s, o), end: Hh(s, l) });
  }
  return n;
}
function Hh(e, t) {
  if (!t) return e.unit();
  let r = e.mag(), i = t.mag();
  return e.x * t.x + e.y * t.y < Vv * r * i || r >= 2 * i ? e.unit() : i >= 2 * r ? t.unit() : e.add(t)._unit();
}
function Rv(e, t) {
  if (!e || e.length < 3) return e;
  let r = e[0].x === e[e.length - 1].x && e[0].y === e[e.length - 1].y, i = r ? e.length - 1 : e.length;
  if (i < 3) return e;
  let n = [], a = Za(e[i - 1], e[0]);
  for (let o = 0; o < i; o++) {
    let l = e[(o - 1 + i) % i], u = e[o], c = e[(o + 1) % i], h = Za(u, c);
    a || h ? n.push(u.clone()) : Nv(n, l, u, c, t), a = h;
  }
  let s = $v(n);
  return s.length < 3 ? e : (r && s.push(s[0].clone()), s);
}
function $v(e) {
  let t = [];
  for (let r of e) {
    let i = r.round(), n = t[t.length - 1];
    ((n == null ? void 0 : n.x) !== i.x || (n == null ? void 0 : n.y) !== i.y) && t.push(i);
  }
  for (; t.length > 1 && t[0].x === t[t.length - 1].x && t[0].y === t[t.length - 1].y; ) t.pop();
  return t;
}
function Nv(e, t, r, i, n) {
  let a = t.sub(r), s = i.sub(r), o = a.mag(), l = s.mag();
  if (o < 1e-6 || l < 1e-6) {
    e.push(r.clone());
    return;
  }
  a._div(o), s._div(l);
  let u = a.x * s.x + a.y * s.y;
  if (Math.abs(u) > Math.cos(5 * Math.PI / 180)) {
    e.push(r.clone());
    return;
  }
  let c = 0.2, h = Math.min(n, o * c, l * c), p = r.add(a.mult(h)), f = r.add(s.mult(h)), d = Math.sqrt((1 + u) / 2), y = r.add(a.add(s)._unit()._mult(h / d)), m = p.sub(y).angleWith(f.sub(y)), g = Math.max(2, Math.ceil(Math.abs(m) / (Math.PI / 6) - 1e-6));
  for (let v = 0; v <= g; v++) e.push(p.rotateAround(v / g * m, y));
}
const _o = 8192;
function Xi(e, t, r, i, n, a, s, o) {
  e.emplaceBack(t, r, Math.floor(i * _o) * 2 + s, n * _o * 2, a * _o * 2, Math.round(o));
}
var Vy = class {
  constructor(e) {
    this.zoom = e.zoom, this.overscaling = e.overscaling, this.layers = e.layers, this.layerIds = this.layers.map((t) => t.id), this.index = e.index, this.hasDependencies = !1, this.layoutVertexArray = new Ix(), this.centroidVertexArray = new Ax(), this.indexArray = new Nn(), this.programConfigurations = new Br(e.layers, e.zoom), this.segments = new ut(), this.stateDependentLayerIds = this.layers.filter((t) => t.isStateDependent()).map((t) => t.id);
  }
  populate(e, t, r) {
    this.features = [], this.hasDependencies = Qa("fill-extrusion", this.layers, t);
    let i = new le(this.zoom), n = this.layers[0], a = n.layout.get("fill-extrusion-rounded-corner-distance"), s = a > 0 ? zv(a, r) : 0, o = n._featureFilter.needGeometry;
    for (let { feature: l, id: u, index: c, sourceLayerIndex: h } of e) {
      let p = Ei(l, o);
      if (!n._featureFilter.filter(i, p, r)) continue;
      let f = { id: u, sourceLayerIndex: h, index: c, geometry: Lv(o ? p.geometry : Or(l), s), properties: l.properties, type: l.type, patterns: {} };
      this.hasDependencies ? this.features.push(zu("fill-extrusion", this.layers, f, { zoom: this.zoom }, t)) : this.addFeature(f, f.geometry, c, r, {}, t.subdivisionGranularity), t.featureIndex.insert(l, f.geometry, c, h, this.index, !0);
    }
  }
  addFeatures({ options: e, canonical: t, patternPositions: r }) {
    for (let i of this.features) {
      let { geometry: n } = i;
      this.addFeature(i, n, i.index, t, r, e.subdivisionGranularity);
    }
  }
  update(e, t, r) {
    this.stateDependentLayers.length && this.programConfigurations.updatePaintArrays(e, t, this.stateDependentLayers, { imagePositions: r });
  }
  isEmpty() {
    return this.layoutVertexArray.length === 0 && this.centroidVertexArray.length === 0;
  }
  uploadPending() {
    return !this.uploaded || this.programConfigurations.needsUpload;
  }
  upload(e) {
    this.uploaded || (this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, Fv), this.centroidVertexBuffer = e.createVertexBuffer(this.centroidVertexArray, kv.members, !0), this.indexBuffer = e.createIndexBuffer(this.indexArray)), this.programConfigurations.upload(e), this.uploaded = !0;
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.programConfigurations.destroy(), this.segments.destroy(), this.centroidVertexBuffer.destroy());
  }
  addFeature(e, t, r, i, n, a) {
    for (let s of fs(t, 500)) {
      let o = { x: 0, y: 0, sampleCount: 0 }, l = this.layoutVertexArray.length;
      this.processPolygon(o, i, e, s, a);
      let u = this.layoutVertexArray.length - l, c = Math.floor(o.x / o.sampleCount), h = Math.floor(o.y / o.sampleCount);
      for (let p = 0; p < u; p++) this.centroidVertexArray.emplaceBack(c, h);
    }
    this.programConfigurations.populatePaintArrays(this.layoutVertexArray.length, e, r, { imagePositions: n, canonical: i });
  }
  processPolygon(e, t, r, i, n) {
    if (i.length < 1 || Ch(i[0])) return;
    for (let c of i) c.length !== 0 && Uv(e, c);
    let a = { segment: this.segments.prepareSegment(4, this.layoutVertexArray, this.indexArray) }, s = n.fill.getGranularityForZoomLevel(t.z), o = Un.types[r.type] === "Polygon";
    for (let c of i) {
      if (c.length === 0 || Ch(c)) continue;
      let h = Tr(c, s, o);
      this._generateSideFaces(h, a);
    }
    if (!o) return;
    let l = Fy(i, t, s, !1), u = this.layoutVertexArray;
    Py((c, h) => {
      Xi(u, c, h, 0, 0, 1, 1, 0);
    }, this.segments, this.layoutVertexArray, this.indexArray, l.verticesFlattened, l.indicesTriangles);
  }
  _generateSideFaces(e, t) {
    let r = 0, i = this.layers[0].layout.get("fill-extrusion-rounded-corner-distance") > 0 ? Ov(e) : null;
    for (let n = 1; n < e.length; n++) {
      let a = e[n], s = e[n - 1];
      if (Za(a, s) || i && !i[n]) continue;
      t.segment.vertexLength + 4 > ut.MAX_VERTEX_ARRAY_LENGTH && (t.segment = this.segments.prepareSegment(4, this.layoutVertexArray, this.indexArray));
      let o = a.sub(s)._perp()._unit(), { start: l, end: u } = i ? i[n] : { start: o, end: o }, c = s.dist(a);
      r + c > 32768 && (r = 0), Xi(this.layoutVertexArray, a.x, a.y, u.x, u.y, 0, 0, r), Xi(this.layoutVertexArray, a.x, a.y, u.x, u.y, 0, 1, r), r += c, Xi(this.layoutVertexArray, s.x, s.y, l.x, l.y, 0, 0, r), Xi(this.layoutVertexArray, s.x, s.y, l.x, l.y, 0, 1, r);
      let h = t.segment.vertexLength;
      this.indexArray.emplaceBack(h, h + 2, h + 1), this.indexArray.emplaceBack(h + 1, h + 2, h + 3), t.segment.vertexLength += 4, t.segment.primitiveLength += 2;
    }
  }
};
function Uv(e, t) {
  for (let r = 0; r < t.length; r++) {
    let i = t[r];
    (r !== t.length - 1 || t[0].x !== i.x || t[0].y !== i.y) && (e.x += i.x, e.y += i.y, e.sampleCount++);
  }
}
P("FillExtrusionBucket", Vy, { omit: ["layers", "features"] });
let jv;
const qv = () => jv || (jv = new Je({ "fill-extrusion-rounded-corner-distance": new V(S["layout_fill-extrusion"]["fill-extrusion-rounded-corner-distance"], "fill-extrusion-rounded-corner-distance") }));
let Gv;
const Xv = () => Gv || (Gv = new Je({ "fill-extrusion-opacity": new V(S["paint_fill-extrusion"]["fill-extrusion-opacity"], "fill-extrusion-opacity"), "fill-extrusion-color": new j(S["paint_fill-extrusion"]["fill-extrusion-color"], "fill-extrusion-color"), "fill-extrusion-translate": new V(S["paint_fill-extrusion"]["fill-extrusion-translate"], "fill-extrusion-translate"), "fill-extrusion-translate-anchor": new V(S["paint_fill-extrusion"]["fill-extrusion-translate-anchor"], "fill-extrusion-translate-anchor"), "fill-extrusion-pattern": new Sn(S["paint_fill-extrusion"]["fill-extrusion-pattern"], "fill-extrusion-pattern"), "fill-extrusion-height": new j(S["paint_fill-extrusion"]["fill-extrusion-height"], "fill-extrusion-height"), "fill-extrusion-base": new j(S["paint_fill-extrusion"]["fill-extrusion-base"], "fill-extrusion-base"), "fill-extrusion-vertical-gradient": new V(S["paint_fill-extrusion"]["fill-extrusion-vertical-gradient"], "fill-extrusion-vertical-gradient") }));
var Yv = { get paint() {
  return Xv();
}, get layout() {
  return qv();
} }, Wv = class extends At {
  constructor(e, t) {
    super(e, Yv, t);
  }
  createBucket(e) {
    return new Vy(e);
  }
  queryRadius() {
    return Ss(this.paint.get("fill-extrusion-translate"));
  }
  is3D() {
    return !0;
  }
  queryIntersectsFeature({ queryGeometry: e, feature: t, featureState: r, geometry: i, projectedCamera: n, pixelsToTileUnits: a, unwrappedTileID: s }) {
    let o = As(e, this.paint.get("fill-extrusion-translate"), this.paint.get("fill-extrusion-translate-anchor"), -n.bearingInRadians, a), l = this.paint.get("fill-extrusion-height").evaluate(t, r), u = this.paint.get("fill-extrusion-base").evaluate(t, r), c = o.map((h) => Do(h, 0, n, s));
    return Zv(i.map((h) => h.map((p) => Do(p, u, n, s))), i.map((h) => h.map((p) => Do(p, l, n, s))), c);
  }
};
function Do(e, t, r, i) {
  let { point: n, signedDistanceFromCamera: a } = Ds(r).projectTileCoordinates(r, e.x, e.y, i, t), s = n;
  return s.z = a, s;
}
function Yi(e, t) {
  return e.x * t.x + e.y * t.y;
}
function Kh(e, t) {
  if (e.length === 1) {
    let r = 0, i = t[r++], n;
    for (; !n || i.equals(n); ) if (n = t[r++], !n) return 1 / 0;
    for (; r < t.length; r++) {
      let a = t[r], s = e[0], o = n.sub(i), l = a.sub(i), u = s.sub(i), c = Yi(o, o), h = Yi(o, l), p = Yi(l, l), f = Yi(u, o), d = Yi(u, l), y = c * p - h * h, m = (p * f - h * d) / y, g = (c * d - h * f) / y, v = 1 - m - g, x = i.z * v + n.z * m + a.z * g;
      if (isFinite(x)) return x;
    }
    return 1 / 0;
  }
  {
    let r = 1 / 0;
    for (let i of t) r = Math.min(r, i.z);
    return r;
  }
}
function Zv(e, t, r) {
  let i = 1 / 0;
  Qd(r, t) && (i = Kh(r, t[0]));
  for (let n = 0; n < t.length; n++) {
    let a = t[n], s = e[n];
    for (let o = 0; o < a.length - 1; o++) {
      let l = a[o], u = a[o + 1], c = s[o], h = [l, u, s[o + 1], c, l];
      Xx(r, h) && (i = Math.min(i, Kh(r, h)));
    }
  }
  return i !== 1 / 0 && i;
}
function Hv(e, t, r, i) {
  let n = [t, r];
  for (; n.length; ) r = n.pop(), t = n.pop(), Kv(e, t, r, i, n);
}
function Kv(e, t, r, i, n) {
  let a = i, s = t + (r - t >> 1), o = r - t, l, u = e[t], c = e[t + 1], h = e[r], p = e[r + 1];
  for (let f = t + 3; f < r; f += 3) {
    let d = Jv(e[f], e[f + 1], u, c, h, p);
    if (d > a) l = f, a = d;
    else if (d === a) {
      let y = Math.abs(f - s);
      y < o && (l = f, o = y);
    }
  }
  a > i && (e[l + 2] = a, l - t > 3 && n.push(t, l), r - l > 3 && n.push(l, r));
}
function Jv(e, t, r, i, n, a) {
  let s = n - r, o = a - i;
  if (s !== 0 || o !== 0) {
    let l = ((e - r) * s + (t - i) * o) / (s * s + o * o);
    l > 1 ? (r = n, i = a) : l > 0 && (r += s * l, i += o * l);
  }
  return s = e - r, o = t - i, s * s + o * o;
}
function ze(e, t, r, i) {
  let n = { type: t, geom: r }, a = { id: e ?? null, type: n.type, geometry: n.geom, tags: i, minX: 1 / 0, minY: 1 / 0, maxX: -1 / 0, maxY: -1 / 0 };
  switch (n.type) {
    case "Point":
    case "MultiPoint":
      Wi(a, n.geom);
      break;
    case "LineString":
      Wi(a, n.geom.points);
      break;
    case "Polygon":
      Wi(a, n.geom[0].points);
      break;
    case "MultiLineString":
      for (let s of n.geom) Wi(a, s.points);
      break;
    case "MultiPolygon":
      for (let s of n.geom) Wi(a, s[0].points);
  }
  return a;
}
function Vu(e) {
  let t = e;
  e.points.length > 64 && (t.points = new Float64Array(e.points));
}
function Wi(e, t) {
  for (let r = 0; r < t.length; r += 3) e.minX = Math.min(e.minX, t[r]), e.minY = Math.min(e.minY, t[r + 1]), e.maxX = Math.max(e.maxX, t[r]), e.maxY = Math.max(e.maxY, t[r + 1]);
}
var Qv = class {
  projectX(e) {
    return e / 360 + 0.5;
  }
  projectY(e) {
    let t = Math.sin(e * Math.PI / 180), r = 0.5 - 0.25 * Math.log((1 + t) / (1 - t)) / Math.PI;
    return r < 0 ? 0 : r > 1 ? 1 : r;
  }
  unprojectX(e) {
    return (e - 0.5) * 360;
  }
  unprojectY(e) {
    let t = (180 - e * 360) * Math.PI / 180;
    return 360 * Math.atan(Math.exp(t)) / Math.PI - 90;
  }
}, eb = class {
  projectX(e) {
    return e;
  }
  projectY(e) {
    return e;
  }
  unprojectX(e) {
    return e;
  }
  unprojectY(e) {
    return e;
  }
};
const Es = new Qv(), tb = new eb();
function Ou(e) {
  return e === "unitSquare" ? tb : Es;
}
function Ru(e, t, r) {
  let i = [];
  switch (e.type) {
    case "FeatureCollection":
      for (let n = 0; n < e.features.length; n++) So(i, e.features[n], t, r, n);
      break;
    case "Feature":
      So(i, e, t, r);
      break;
    default:
      So(i, { type: "Feature", geometry: e, properties: void 0 }, t, r);
  }
  return i;
}
function So(e, t, r, i, n) {
  let a = e.length;
  if (Oy(e, t, r, n), !i) return;
  let s = Ry(t, r, n);
  s != null && (e.length > a ? i.delete(s) : i.set(s, { ...t, id: s }));
}
function Oy(e, t, r, i, n = 0) {
  var l;
  if (!t.geometry) return;
  if (n > 1024) throw Error("GeometryCollection nesting exceeds supported depth: 1024");
  if (t.geometry.type === "GeometryCollection") {
    rb(e, t, t.geometry, r, i, n + 1);
    return;
  }
  if (!((l = t.geometry.coordinates) != null && l.length)) return;
  let a = Ry(t, r, i), s = (r.tolerance / ((1 << r.maxZoom) * r.extent)) ** 2, o = Ou(r.coordinates);
  switch (t.geometry.type) {
    case "Point":
      ib(e, a, t.geometry, o, t.properties);
      return;
    case "MultiPoint":
      nb(e, a, t.geometry, o, t.properties);
      return;
    case "LineString":
      ab(e, a, t.geometry, s, o, t.properties);
      return;
    case "MultiLineString":
      sb(e, a, t.geometry, s, o, r, t.properties);
      return;
    case "Polygon":
      ob(e, a, t.geometry, s, o, t.properties);
      return;
    case "MultiPolygon":
      lb(e, a, t.geometry, s, o, t.properties);
      return;
    default:
      throw Error("Input data is not a valid GeoJSON object.");
  }
}
function Ry(e, t, r) {
  var i;
  return t.promoteId ? (i = e.properties) == null ? void 0 : i[t.promoteId] : t.generateId ? r || 0 : e.id;
}
function rb(e, t, r, i, n, a = 0) {
  for (let s of r.geometries) Oy(e, { id: t.id, geometry: s, properties: t.properties }, i, n, a);
}
function ib(e, t, r, i, n) {
  let a = [];
  a.push(i.projectX(r.coordinates[0]), i.projectY(r.coordinates[1]), 0), e.push(ze(t, "Point", a, n));
}
function nb(e, t, r, i, n) {
  let a = [];
  for (let s of r.coordinates) a.push(i.projectX(s[0]), i.projectY(s[1]), 0);
  e.push(ze(t, "MultiPoint", a, n));
}
function ab(e, t, r, i, n, a) {
  let s = { points: [] };
  $u(r.coordinates, s, i, !1, n), e.push(ze(t, "LineString", s, a));
}
function sb(e, t, r, i, n, a, s) {
  if (a.lineMetrics) for (let o of r.coordinates) {
    let l = { points: [] };
    $u(o, l, i, !1, n), e.push(ze(t, "LineString", l, s));
  }
  else {
    let o = [];
    Nu(r.coordinates, o, i, !1, n), e.push(ze(t, "MultiLineString", o, s));
  }
}
function ob(e, t, r, i, n, a) {
  let s = [];
  Nu(r.coordinates, s, i, !0, n), e.push(ze(t, "Polygon", s, a));
}
function lb(e, t, r, i, n, a) {
  let s = [];
  for (let o of r.coordinates) {
    let l = [];
    Nu(o, l, i, !0, n), l.length && s.push(l);
  }
  s.length && e.push(ze(t, "MultiPolygon", s, a));
}
function $u(e, t, r, i, n) {
  let a, s, o = 0;
  for (let u = 0; u < e.length; u++) {
    let c = n.projectX(e[u][0]), h = n.projectY(e[u][1]);
    t.points.push(c, h, 0), u > 0 && (o += i ? (a * h - c * s) / 2 : Math.sqrt((c - a) ** 2 + (h - s) ** 2)), a = c, s = h;
  }
  let l = t.points.length - 3;
  t.points[2] = 1, r > 0 && Hv(t.points, 0, l, r), t.points[l + 2] = 1, Vu(t), t.size = Math.abs(o), t.start = 0, t.end = t.size;
}
function Nu(e, t, r, i, n) {
  for (let a = 0; a < e.length; a++) {
    let s = { points: [] };
    $u(e[a], s, r, i, n), t.push(s);
  }
}
function ub(e, t = Es) {
  return { type: "FeatureCollection", features: e.map((r) => rs(r, t)) };
}
function rs(e, t = Es) {
  let r = { type: "Feature", geometry: cb(e, t), properties: e.tags };
  return e.id != null && (r.id = e.id), r;
}
function cb(e, t) {
  let { type: r, geometry: i } = e;
  switch (r) {
    case "Point":
      return { type: r, coordinates: $y(i[0], i[1], t) };
    case "MultiPoint":
      return { type: r, coordinates: xa(i, t) };
    case "LineString":
      return { type: r, coordinates: xa(i.points, t) };
    case "MultiLineString":
    case "Polygon":
      return { type: r, coordinates: i.map((n) => xa(n.points, t)) };
    case "MultiPolygon":
      return { type: r, coordinates: i.map((n) => n.map((a) => xa(a.points, t))) };
  }
}
function xa(e, t = Es) {
  let r = [];
  for (let i = 0; i < e.length; i += 3) r.push($y(e[i], e[i + 1], t));
  return r;
}
function $y(e, t, r) {
  return [r.unprojectX(e), r.unprojectY(t)];
}
function _t(e, t, r, i, n, a, s, o) {
  if (r /= t, i /= t, a >= r && s < i) return e;
  if (s < r || a >= i) return null;
  let l = [];
  for (let u of e) {
    let c = n === 0 ? u.minX : u.minY, h = n === 0 ? u.maxX : u.maxY;
    if (c >= r && h < i) l.push(u);
    else if (!(h < r || c >= i)) switch (u.type) {
      case "MultiPoint":
        hb(u, l, r, i, n);
        continue;
      case "LineString":
        pb(u, l, r, i, n, o);
        continue;
      case "MultiLineString":
        fb(u, l, r, i, n);
        continue;
      case "Polygon":
        db(u, l, r, i, n);
        continue;
      case "MultiPolygon":
        yb(u, l, r, i, n);
        continue;
    }
  }
  return l.length ? l : null;
}
function hb(e, t, r, i, n) {
  let a = [];
  if (mb(e.geometry, a, r, i, n), !a.length) return;
  let s = a.length === 3 ? "Point" : "MultiPoint";
  t.push(ze(e.id, s, a, e.tags));
}
function pb(e, t, r, i, n, a) {
  let s = [];
  if (Ny(e.geometry, s, r, i, n, !1, a.lineMetrics), s.length)
    if (a.lineMetrics) for (let o of s) t.push(ze(e.id, "LineString", o, e.tags));
    else s.length > 1 ? t.push(ze(e.id, "MultiLineString", s, e.tags)) : t.push(ze(e.id, "LineString", s[0], e.tags));
}
function fb(e, t, r, i, n) {
  let a = [];
  Uu(e.geometry, a, r, i, n, !1), a.length && (a.length === 1 ? t.push(ze(e.id, "LineString", a[0], e.tags)) : t.push(ze(e.id, "MultiLineString", a, e.tags)));
}
function db(e, t, r, i, n) {
  let a = [];
  Uu(e.geometry, a, r, i, n, !0), a.length && t.push(ze(e.id, "Polygon", a, e.tags));
}
function yb(e, t, r, i, n) {
  let a = [];
  for (let s of e.geometry) {
    let o = [];
    Uu(s, o, r, i, n, !0), o.length && a.push(o);
  }
  a.length && t.push(ze(e.id, "MultiPolygon", a, e.tags));
}
function mb(e, t, r, i, n) {
  for (let a = 0; a < e.length; a += 3) {
    let s = e[a + n];
    s >= r && s <= i && li(t, e[a], e[a + 1], e[a + 2]);
  }
}
function Ny(e, t, r, i, n, a, s) {
  let o = Jh(e), l = n === 0 ? gb : xb, u = e.start, c, h;
  for (let g = 0; g < e.points.length - 3; g += 3) {
    let v = e.points[g], x = e.points[g + 1], b = e.points[g + 2], w = e.points[g + 3], D = e.points[g + 4], _ = n === 0 ? v : x, A = n === 0 ? w : D, E = !1;
    s && (c = Math.sqrt((v - w) ** 2 + (x - D) ** 2)), _ < r ? A >= r && (h = l(o, v, x, w, D, r), s && (o.start = u + c * h)) : _ > i ? A <= i && (h = l(o, v, x, w, D, i), s && (o.start = u + c * h)) : li(o.points, v, x, b), A < r && _ >= r && (h = l(o, v, x, w, D, r), E = !0), A > i && _ <= i && (h = l(o, v, x, w, D, i), E = !0), !a && E && (s && (o.end = u + c * h), t.push(o), o = Jh(e)), s && (u += c);
  }
  let p = e.points.length - 3, f = e.points[p], d = e.points[p + 1], y = e.points[p + 2], m = n === 0 ? f : d;
  m >= r && m <= i && li(o.points, f, d, y), p = o.points.length - 3, a && p >= 3 && (o.points[p] !== o.points[0] || o.points[p + 1] !== o.points[1]) && li(o.points, o.points[0], o.points[1], o.points[2]), o.points.length && (Vu(o), t.push(o));
}
function Jh(e) {
  return { points: [], size: e.size, start: e.start, end: e.end };
}
function Uu(e, t, r, i, n, a) {
  for (let s of e) Ny(s, t, r, i, n, a, !1);
}
function li(e, t, r, i) {
  e.push(t, r, i);
}
function gb(e, t, r, i, n, a) {
  let s = (a - t) / (i - t);
  return li(e.points, a, r + (n - r) * s, 1), s;
}
function xb(e, t, r, i, n, a) {
  let s = (a - r) / (n - r);
  return li(e.points, t + (i - t) * s, a, 1), s;
}
function ju(e, t) {
  if (!t.wrap) return e;
  let r = t.buffer / t.extent, i = e, n = _t(e, 1, -1 - r, r, 0, -1, 2, t), a = _t(e, 1, 1 - r, 2 + r, 0, -1, 2, t);
  return !n && !a || (i = _t(e, 1, -r, 1 + r, 0, -1, 2, t) || [], n && (i = Qh(n, 1).concat(i)), a && (i = i.concat(Qh(a, -1)))), i;
}
function Qh(e, t) {
  let r = [];
  for (let i of e) switch (i.type) {
    case "Point":
    case "MultiPoint": {
      let n = vb(i.geometry, t);
      r.push(ze(i.id, i.type, n, i.tags));
      continue;
    }
    case "LineString": {
      let n = Ao(i.geometry, t);
      r.push(ze(i.id, i.type, n, i.tags));
      continue;
    }
    case "MultiLineString":
    case "Polygon": {
      let n = [];
      for (let a of i.geometry) n.push(Ao(a, t));
      r.push(ze(i.id, i.type, n, i.tags));
      continue;
    }
    case "MultiPolygon": {
      let n = [];
      for (let a of i.geometry) {
        let s = [];
        for (let o of a) s.push(Ao(o, t));
        n.push(s);
      }
      r.push(ze(i.id, i.type, n, i.tags));
      continue;
    }
  }
  return r;
}
function vb(e, t) {
  let r = [];
  for (let i = 0; i < e.length; i += 3) r.push(e[i] + t, e[i + 1], e[i + 2]);
  return r;
}
function Ao(e, t) {
  let r = { points: [], size: e.size };
  e.start !== void 0 && (r.start = e.start, r.end = e.end);
  for (let i = 0; i < e.points.length; i += 3) r.points.push(e.points[i] + t, e.points[i + 1], e.points[i + 2]);
  return Vu(r), r;
}
function bb(e, t, r, i) {
  let n = Db(t, r), a = [];
  if (n.removeAll && (a = e, e = [], i == null || i.clear()), n.remove.size || n.add.size) {
    for (let o of n.remove) i == null || i.delete(o);
    let s = [];
    for (let o of e) (n.remove.has(o.id) || n.add.has(o.id)) && s.push(o);
    if (s.length) {
      a = a.concat(s);
      let o = new Set(s.map((l) => l.id));
      e = e.filter((l) => !o.has(l.id));
    }
    if (n.add.size) {
      let o = Ru({ type: "FeatureCollection", features: Array.from(n.add.values()) }, { ...r, generateId: !1 }, i);
      o = ju(o, r), a = a.concat(o), e = e.concat(o);
    }
  }
  if (n.update.size) {
    let s = /* @__PURE__ */ new Map(), o = [];
    for (let l of e) n.update.has(l.id) ? s.set(l.id, [...s.get(l.id) || [], l]) : o.push(l);
    for (let [l, u] of n.update) {
      let c = s.get(l);
      if (!c || c.length === 0) {
        if (!(i != null && i.has(l))) continue;
        let p = _b(l, u, r, i);
        a = a.concat(p), o = o.concat(p);
        continue;
      }
      let h = wb(c, u, r, i);
      a = a.concat(c, h), o = o.concat(h);
    }
    e = o;
  }
  return { affected: a, source: e };
}
function wb(e, t, r, i) {
  let n = !!t.newGeometry, a = jy(t);
  if (n) {
    let s = e[0], o = a ? Pl(s.tags, t) : s.tags;
    return Uy(s.id, t.newGeometry, o, r, i);
  }
  if (a) {
    let s = [];
    for (let o of e) {
      let l = { ...o };
      l.tags = Pl(l.tags, t), s.push(l);
    }
    return s;
  }
  return e;
}
function _b(e, t, r, i) {
  let n = i.get(e), a = jy(t) ? Pl(n.properties, t) : n.properties;
  return t.newGeometry ? Uy(e, t.newGeometry, a, r, i) : (i.set(e, { ...n, properties: a }), []);
}
function Uy(e, t, r, i, n) {
  return ju(Ru({ type: "FeatureCollection", features: [{ type: "Feature", id: e, geometry: t, properties: r }] }, { ...i, promoteId: void 0, generateId: !1 }, n), i);
}
function jy(e) {
  var t, r;
  return e.removeAllProperties || ((t = e.removeProperties) == null ? void 0 : t.length) > 0 || ((r = e.addOrUpdateProperties) == null ? void 0 : r.length) > 0;
}
function Pl(e, t) {
  if (t.removeAllProperties) return {};
  let r = { ...e || {} };
  if (t.removeProperties) for (let i of t.removeProperties) delete r[i];
  if (t.addOrUpdateProperties) for (let { key: i, value: n } of t.addOrUpdateProperties) r[i] = n;
  return r;
}
function Db(e, t) {
  var r, i;
  return e ? { removeAll: e.removeAll, remove: new Set(e.remove || []), add: new Map((r = e.add) == null ? void 0 : r.map((n) => {
    var a;
    return [t.promoteId ? (a = n.properties) == null ? void 0 : a[t.promoteId] : n.id, n];
  })), update: new Map((i = e.update) == null ? void 0 : i.map((n) => [n.id, n])) } : { remove: /* @__PURE__ */ new Set(), add: /* @__PURE__ */ new Map(), update: /* @__PURE__ */ new Map() };
}
const ep = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array], ge = /* @__PURE__ */ new Uint32Array(96);
var Sb = class qy {
  static from(t) {
    if (!t || t.byteLength === void 0 || t.buffer) throw Error("Data must be an instance of ArrayBuffer or SharedArrayBuffer.");
    let [r, i] = new Uint8Array(t, 0, 2);
    if (r !== 219) throw Error("Data does not appear to be in a KDBush format.");
    let n = i >> 4;
    if (n !== 1) throw Error(`Got v${n} data when expected v1.`);
    let a = ep[i & 15];
    if (!a) throw Error("Unrecognized array type.");
    let [s] = new Uint16Array(t, 2, 1), [o] = new Uint32Array(t, 4, 1);
    return new qy(o, s, a, void 0, t);
  }
  constructor(t, r = 64, i = Float64Array, n = ArrayBuffer, a) {
    if (isNaN(t) || t < 0) throw Error(`Unexpected numItems value: ${t}.`);
    this.numItems = +t, this.nodeSize = Math.min(Math.max(+r, 2), 65535), this.ArrayType = i, this.IndexArrayType = t < 65536 ? Uint16Array : Uint32Array;
    let s = ep.indexOf(this.ArrayType), o = t * 2 * this.ArrayType.BYTES_PER_ELEMENT, l = t * this.IndexArrayType.BYTES_PER_ELEMENT, u = (8 - l % 8) % 8;
    if (s < 0) throw Error(`Unexpected typed array class: ${i}.`);
    if (a) this.data = a, this.ids = new this.IndexArrayType(a, 8, t), this.coords = new i(a, 8 + l + u, t * 2), this._pos = t * 2, this._finished = !0;
    else {
      let c = this.data = new n(8 + o + l + u);
      this.ids = new this.IndexArrayType(c, 8, t), this.coords = new i(c, 8 + l + u, t * 2), this._pos = 0, this._finished = !1, new Uint8Array(c, 0, 2).set([219, 16 + s]), new Uint16Array(c, 2, 1)[0] = r, new Uint32Array(c, 4, 1)[0] = t;
    }
  }
  add(t, r) {
    let i = this._pos >> 1;
    return this.ids[i] = i, this.coords[this._pos++] = t, this.coords[this._pos++] = r, i;
  }
  finish() {
    let t = this._pos >> 1;
    if (t !== this.numItems) throw Error(`Added ${t} items when expected ${this.numItems}.`);
    return Bl(this.ids, this.coords, this.nodeSize, 0, this.numItems - 1, 0), this._finished = !0, this;
  }
  range(t, r, i, n) {
    if (!this._finished) throw Error("Data not yet indexed - call index.finish().");
    let { ids: a, coords: s, nodeSize: o } = this;
    ge[0] = 0, ge[1] = a.length - 1, ge[2] = 0;
    let l = 3, u = [];
    for (; l > 0; ) {
      let c = ge[--l], h = ge[--l], p = ge[--l];
      if (h - p <= o) {
        for (let m = p; m <= h; m++) {
          let g = s[2 * m], v = s[2 * m + 1];
          g >= t && g <= i && v >= r && v <= n && u.push(a[m]);
        }
        continue;
      }
      let f = p + h >> 1, d = s[2 * f], y = s[2 * f + 1];
      d >= t && d <= i && y >= r && y <= n && u.push(a[f]), (c === 0 ? t <= d : r <= y) && (ge[l++] = p, ge[l++] = f - 1, ge[l++] = 1 - c), (c === 0 ? i >= d : n >= y) && (ge[l++] = f + 1, ge[l++] = h, ge[l++] = 1 - c);
    }
    return u;
  }
  within(t, r, i) {
    let n = [];
    return this.withinInto(t, r, i, n), n;
  }
  withinInto(t, r, i, n) {
    if (!this._finished) throw Error("Data not yet indexed - call index.finish().");
    let { ids: a, coords: s, nodeSize: o } = this;
    ge[0] = 0, ge[1] = a.length - 1, ge[2] = 0;
    let l = 3, u = 0, c = i * i;
    for (; l > 0; ) {
      let h = ge[--l], p = ge[--l], f = ge[--l];
      if (p - f <= o) {
        for (let g = f; g <= p; g++) tp(s[2 * g], s[2 * g + 1], t, r) <= c && (n[u++] = a[g]);
        continue;
      }
      let d = f + p >> 1, y = s[2 * d], m = s[2 * d + 1];
      tp(y, m, t, r) <= c && (n[u++] = a[d]), (h === 0 ? t - i <= y : r - i <= m) && (ge[l++] = f, ge[l++] = d - 1, ge[l++] = 1 - h), (h === 0 ? t + i >= y : r + i >= m) && (ge[l++] = d + 1, ge[l++] = p, ge[l++] = 1 - h);
    }
    return u;
  }
};
function Bl(e, t, r, i, n, a) {
  if (n - i <= r) return;
  let s = i + n >> 1;
  Gy(e, t, s, i, n, a), Bl(e, t, r, i, s - 1, 1 - a), Bl(e, t, r, s + 1, n, 1 - a);
}
function Gy(e, t, r, i, n, a) {
  for (; n > i; ) {
    if (n - i > 600) {
      let u = n - i + 1, c = r - i + 1, h = Math.log(u), p = 0.5 * Math.exp(2 * h / 3), f = 0.5 * Math.sqrt(h * p * (u - p) / u) * (c - u / 2 < 0 ? -1 : 1);
      Gy(e, t, r, Math.max(i, Math.floor(r - c * p / u + f)), Math.min(n, Math.floor(r + (u - c) * p / u + f)), a);
    }
    let s = t[2 * r + a], o = i, l = n;
    for (Zi(e, t, i, r), t[2 * n + a] > s && Zi(e, t, i, n); o < l; ) {
      for (Zi(e, t, o, l), o++, l--; t[2 * o + a] < s; ) o++;
      for (; t[2 * l + a] > s; ) l--;
    }
    t[2 * i + a] === s ? Zi(e, t, i, l) : (l++, Zi(e, t, l, n)), l <= r && (i = l + 1), r <= l && (n = l - 1);
  }
}
function Zi(e, t, r, i) {
  Eo(e, r, i), Eo(t, 2 * r, 2 * i), Eo(t, 2 * r + 1, 2 * i + 1);
}
function Eo(e, t, r) {
  let i = e[t];
  e[t] = e[r], e[r] = i;
}
function tp(e, t, r, i) {
  let n = e - r, a = t - i;
  return n * n + a * a;
}
const Xy = { minZoom: 0, maxZoom: 16, minPoints: 2, radius: 40, extent: 512, nodeSize: 64, log: !1, generateId: !1, reduce: null, map: (e) => e, coordinates: "lngLat", wrap: !0 }, is = 1073741824;
function He(e) {
  return (e - 0.5) * is;
}
function wi(e) {
  return e / is + 0.5;
}
function rp(e) {
  return Math.abs(He(e)) < 2147483647;
}
var Ab = class {
  constructor(e) {
    this.options = ip(e), this.worldCoordinateHelper = Ou(this.options.coordinates), this.trees = Array(this.options.maxZoom + 1), this.stride = this.options.reduce ? 5 : 4, this.clusterProps = [], this.points = [];
  }
  load(e) {
    let t = [];
    for (let r of e) {
      if (!r.geometry) continue;
      let i = r.geometry.type === "MultiPoint" ? r.geometry.coordinates : [r.geometry.coordinates];
      for (let [n, a] of i) {
        let [s, o] = [this.worldCoordinateHelper.projectX(n), this.worldCoordinateHelper.projectY(a)];
        if (!this.options.wrap && !To([s, o])) continue;
        let l = { id: r.id, type: "Point", geometry: [s, o], tags: r.properties };
        t.push(l);
      }
    }
    this.createIndex(t);
  }
  initialize(e) {
    let t = [];
    for (let r of e) if (r.type === "Point") {
      if (!this.options.wrap && !To(r.geometry)) continue;
      t.push(r);
    } else if (r.type === "MultiPoint") for (let i = 0; i < r.geometry.length; i += 3) {
      let n = [r.geometry[i], r.geometry[i + 1]];
      (this.options.wrap || To(n)) && t.push({ id: r.id, type: "Point", geometry: n, tags: r.tags });
    }
    this.createIndex(t);
  }
  updateIndex(e, t, r) {
    this.options = ip({ ...r.clusterOptions, coordinates: this.options.coordinates, wrap: this.options.wrap }), this.initialize(e);
  }
  createIndex(e) {
    let { log: t, minZoom: r, maxZoom: i } = this.options;
    this.trees = Array(i + 1), this.stride = this.options.reduce ? 5 : 4, this.clusterProps = [], t && console.time("total time");
    let n = `prepare ${e.length} points`;
    t && console.time(n), this.points = e;
    let a = this.stride, s = i + 1, o = new Int32Array(e.length * 2), l = new Int32Array(e.length * a), u = 0;
    for (let f = 0; f < e.length; f++) {
      let d = e[f];
      if (!(d != null && d.geometry) || !rp(d.geometry[0]) || !rp(d.geometry[1])) continue;
      o[u * 2] = Math.round(He(d.geometry[0])), o[u * 2 + 1] = Math.round(He(d.geometry[1]));
      let y = u * a;
      l[y + 0] = s, l[y + 1] = f, l[y + 2] = -1, l[y + 3] = 1, u++;
    }
    let c = this.trees[i + 1] = this.createTree(o, l, u);
    t && console.timeEnd(n);
    let h = new Int32Array(u * 2), p = new Int32Array(u * a);
    for (let f = i; f >= r; f--) {
      let d = Date.now(), y = this.cluster(c, f, h, p);
      this.isSameAsTree(c, p, y) || (c = this.createTree(h.slice(0, y * 2), p.slice(0, y * a), y)), this.trees[f] = c, t && console.log("z%d: %d clusters in %dms", f, c.numItems, Date.now() - d);
    }
    t && console.timeEnd("total time");
  }
  getClusters(e, t) {
    return (this.options.wrap ? this.options.coordinates === "unitSquare" ? this.getClustersAcrossEdge(e, t) : this.getClustersInternal(e, t) : this.getClustersInWorld(e, t)).map((r) => rs(r, this.worldCoordinateHelper));
  }
  getClustersInWorld(e, t) {
    let r = this.options.coordinates !== "unitSquare", i = this.worldCoordinateHelper.projectY(r ? Math.max(-90, Math.min(90, e[1])) : e[1]), n = this.worldCoordinateHelper.projectY(r ? Math.max(-90, Math.min(90, e[3])) : e[3]), a = Math.max(0, this.worldCoordinateHelper.projectX(e[0])), s = Math.min(1, this.worldCoordinateHelper.projectX(e[2]));
    return a > s ? [] : this.getClustersInRange([a, Math.min(i, n), s, Math.max(i, n)], t);
  }
  getClustersAcrossEdge([e, t, r, i], n) {
    if (r < e && (r += 1), r - e >= 1) return this.getClustersInRange([0, t, 1, i], n);
    let a = Math.floor(e), s = e - a, o = r - a;
    return o <= 1 ? this.getClustersInRange([s, t, o, i], n) : this.getClustersInRange([s, t, 1, i], n).concat(this.getClustersInRange([0, t, o - 1, i], n));
  }
  getClustersInternal(e, t) {
    let r = ((e[0] + 180) % 360 + 360) % 360 - 180, i = Math.max(-90, Math.min(90, e[1])), n = e[2] === 180 ? 180 : ((e[2] + 180) % 360 + 360) % 360 - 180, a = Math.max(-90, Math.min(90, e[3]));
    if (e[2] - e[0] >= 360) r = -180, n = 180;
    else if (r > n) {
      let s = this.getClustersInternal([r, i, 180, a], t), o = this.getClustersInternal([-180, i, n, a], t);
      return s.concat(o);
    }
    return this.getClustersInRange([this.worldCoordinateHelper.projectX(r), this.worldCoordinateHelper.projectY(a), this.worldCoordinateHelper.projectX(n), this.worldCoordinateHelper.projectY(i)], t);
  }
  getClustersInRange([e, t, r, i], n) {
    let a = this.trees[this.limitZoom(n)], s = a.range(He(e), He(t), He(r), He(i)), o = a.flatCoords, l = a.flatData, u = [];
    for (let c of s) {
      let h = this.stride * c;
      u.push(l[h + 3] > 1 ? Eb(o, c, l, h, this.clusterProps) : this.points[l[h + 1]]);
    }
    return u;
  }
  getChildren(e) {
    let t = this.getOriginId(e), r = this.getOriginZoom(e), i = /* @__PURE__ */ Error("No cluster with the specified id: " + e), n = this.trees[r];
    if (!n) throw i;
    let a = n.flatCoords, s = n.flatData;
    if (t >= n.numItems) throw i;
    let o = this.options.radius / (this.options.extent * 2 ** (r - 1)) * is, l = a[t * 2], u = a[t * 2 + 1], c = n.within(l, u, o), h = [];
    for (let p of c) {
      let f = p * this.stride;
      s[f + 2] === e && h.push(s[f + 3] > 1 ? Tb(a, p, s, f, this.clusterProps, this.worldCoordinateHelper) : rs(this.points[s[f + 1]], this.worldCoordinateHelper));
    }
    if (h.length === 0) throw i;
    return h;
  }
  getLeaves(e, t, r) {
    t || (t = 10), r || (r = 0);
    let i = [];
    return this.appendLeaves(i, e, t, r, 0), i;
  }
  getTile(e, t, r) {
    let i = this.trees[this.limitZoom(e)];
    if (!i) return null;
    let n = 2 ** e;
    if (!this.options.wrap && (t < 0 || t >= n || r < 0 || r >= n)) return null;
    let { extent: a, radius: s } = this.options, o = s / a, l = He((r - o) / n), u = He((r + 1 + o) / n), c = { transformed: !0, features: [], source: null, x: t, y: r, z: e };
    return this.addTileFeatures(i.range(He((t - o) / n), l, He((t + 1 + o) / n), u), i, t, r, n, c), this.options.wrap && t === 0 && this.addTileFeatures(i.range(He(1 - o / n), l, He(1), u), i, n, r, n, c), this.options.wrap && t === n - 1 && this.addTileFeatures(i.range(He(0), l, He(o / n), u), i, -1, r, n, c), c;
  }
  getClusterExpansionZoom(e) {
    return this.getOriginZoom(e);
  }
  appendLeaves(e, t, r, i, n) {
    let a = this.getChildren(t);
    for (let s of a) {
      let o = s.properties;
      if (o != null && o.cluster ? n + o.point_count <= i ? n += o.point_count : n = this.appendLeaves(e, o.cluster_id, r, i, n) : n < i ? n++ : e.push(s), e.length === r) break;
    }
    return n;
  }
  createTree(e, t, r) {
    let i = new Sb(r, this.options.nodeSize, Int32Array);
    for (let n = 0; n < r; n++) i.add(e[n * 2], e[n * 2 + 1]);
    return i.finish(), i.flatCoords = e, i.flatData = t, i.data = null, i;
  }
  isSameAsTree(e, t, r) {
    if (r !== e.numItems) return !1;
    let i = e.flatData;
    for (let n = 1; n < r * this.stride; n += this.stride) if (t[n] !== i[n]) return !1;
    return !0;
  }
  addTileFeatures(e, t, r, i, n, a) {
    let s = t.flatCoords, o = t.flatData;
    for (let l of e) {
      let u = l * this.stride, c = o[u + 3] > 1, h, p, f;
      if (c) h = qu(o, u, this.clusterProps), p = wi(s[l * 2]), f = wi(s[l * 2 + 1]);
      else {
        let m = this.points[o[u + 1]];
        h = m.tags, [p, f] = m.geometry;
      }
      let d = { type: 1, geometry: [[Math.round(this.options.extent * (p * n - r)), Math.round(this.options.extent * (f * n - i))]], tags: h }, y;
      y = c || this.options.generateId ? o[u + 1] : this.points[o[u + 1]].id, y !== void 0 && (d.id = y), a.features.push(d);
    }
  }
  limitZoom(e) {
    return Math.max(this.options.minZoom, Math.min(Math.floor(+e), this.options.maxZoom + 1));
  }
  cluster(e, t, r, i) {
    let { radius: n, extent: a, reduce: s, minPoints: o, maxZoom: l } = this.options, u = n / (a * 2 ** t) * is, c = l + 1, h = e.flatCoords, p = e.flatData, f = this.stride, d = new Uint32Array(e.numItems), y = 0;
    for (let m = 0; m < e.numItems; m++) {
      let g = m * f;
      if (p[g + 0] <= t) continue;
      p[g + 0] = t;
      let v = h[m * 2], x = h[m * 2 + 1], b = e.withinInto(v, x, u, d), w = p[g + 3], D = w;
      for (let _ = 0; _ < b; _++) {
        let A = d[_] * f;
        p[A + 0] > t && (D += p[A + 3]);
      }
      if (D > w && D >= o) {
        let _ = v * w, A = x * w, E, R = -1, B = (m << 5) + (t + 1) + this.points.length;
        for (let $ = 0; $ < b; $++) {
          let M = d[$], C = M * f;
          if (p[C + 0] <= t) continue;
          p[C + 0] = t;
          let N = p[C + 3];
          _ += h[M * 2] * N, A += h[M * 2 + 1] * N, p[C + 2] = B, s && (E || (E = this.map(p, g, !0), R = this.clusterProps.length, this.clusterProps.push(E)), s(E, this.map(p, C)));
        }
        p[g + 2] = B, r[y * 2] = Math.round(_ / D), r[y * 2 + 1] = Math.round(A / D);
        let L = y * f;
        i[L + 0] = c, i[L + 1] = B, i[L + 2] = -1, i[L + 3] = D, s && (i[L + 4] = R), y++;
      } else {
        r[y * 2] = v, r[y * 2 + 1] = x;
        for (let _ = 0; _ < f; _++) i[y * f + _] = p[g + _];
        if (y++, D > 1) for (let _ = 0; _ < b; _++) {
          let A = d[_], E = A * f;
          if (!(p[E + 0] <= t)) {
            p[E + 0] = t, r[y * 2] = h[A * 2], r[y * 2 + 1] = h[A * 2 + 1];
            for (let R = 0; R < f; R++) i[y * f + R] = p[E + R];
            y++;
          }
        }
      }
    }
    return y;
  }
  getOriginId(e) {
    return e - this.points.length >> 5;
  }
  getOriginZoom(e) {
    return (e - this.points.length) % 32;
  }
  map(e, t, r) {
    if (e[t + 3] > 1) {
      let a = this.clusterProps[e[t + 4]];
      return r ? Object.assign({}, a) : a;
    }
    let i = this.points[e[t + 1]].tags, n = this.options.map(i);
    return r && n === i ? Object.assign({}, n) : n;
  }
};
function ip(e) {
  let t = Object.assign(Object.create(Xy), e);
  return t.minZoom = Math.min(t.minZoom, 30), t.maxZoom = Math.min(t.maxZoom, 30), t;
}
function Eb(e, t, r, i, n) {
  return { id: r[i + 1], type: "Point", tags: qu(r, i, n), geometry: [wi(e[t * 2]), wi(e[t * 2 + 1])] };
}
function Tb(e, t, r, i, n, a) {
  return { type: "Feature", id: r[i + 1], properties: qu(r, i, n), geometry: { type: "Point", coordinates: [a.unprojectX(wi(e[t * 2])), a.unprojectY(wi(e[t * 2 + 1]))] } };
}
function qu(e, t, r) {
  let i = e[t + 3], n = i >= 1e4 ? `${Math.round(i / 1e3)}k` : i >= 1e3 ? `${Math.round(i / 100) / 10}k` : i, a = e[t + 4], s = a === -1 ? {} : Object.assign({}, r[a]);
  return Object.assign(s, { cluster: !0, cluster_id: e[t + 1], point_count: i, point_count_abbreviated: n });
}
function To(e) {
  return e[0] >= 0 && e[0] <= 1 && e[1] >= 0 && e[1] <= 1;
}
const Yy = "geojsonvt_clip_start", Wy = "geojsonvt_clip_end";
function np(e, t, r, i, n) {
  let a = t === n.maxZoom ? 0 : n.tolerance / ((1 << t) * n.extent), s = { transformed: !1, features: [], source: null, x: r, y: i, z: t, minX: 2, minY: 1, maxX: -1, maxY: 0, numPoints: 0, numSimplified: 0, numFeatures: e.length };
  for (let o of e) Ib(s, o, a, n);
  return s;
}
function Ib(e, t, r, i) {
  switch (e.minX = Math.min(e.minX, t.minX), e.minY = Math.min(e.minY, t.minY), e.maxX = Math.max(e.maxX, t.maxX), e.maxY = Math.max(e.maxY, t.maxY), t.type) {
    case "Point":
    case "MultiPoint":
      Cb(e, t);
      return;
    case "LineString":
      kb(e, t, r, i);
      return;
    case "MultiLineString":
    case "Polygon":
      Fb(e, t, r);
      return;
    case "MultiPolygon":
      Mb(e, t, r);
      return;
  }
}
function Cb(e, t) {
  let r = [];
  for (let n = 0; n < t.geometry.length; n += 3) r.push(t.geometry[n], t.geometry[n + 1]), e.numPoints++, e.numSimplified++;
  if (!r.length) return;
  let i = { type: 1, tags: t.tags || null, geometry: r };
  t.id !== null && (i.id = t.id), e.features.push(i);
}
function kb(e, t, r, i) {
  let n = [];
  if (Gu(n, t.geometry, e, r, !1, !1), !n.length) return;
  let a = t.tags || null;
  if (i.lineMetrics) {
    a = {};
    for (let o in t.tags) a[o] = t.tags[o];
    a[Yy] = t.geometry.start / t.geometry.size, a[Wy] = t.geometry.end / t.geometry.size;
  }
  let s = { type: 2, tags: a, geometry: n };
  t.id !== null && (s.id = t.id), e.features.push(s);
}
function Fb(e, t, r) {
  let i = [];
  for (let a = 0; a < t.geometry.length; a++) Gu(i, t.geometry[a], e, r, t.type === "Polygon", a === 0);
  if (!i.length) return;
  let n = { type: t.type === "Polygon" ? 3 : 2, tags: t.tags || null, geometry: i };
  t.id !== null && (n.id = t.id), e.features.push(n);
}
function Mb(e, t, r) {
  let i = [];
  for (let a = 0; a < t.geometry.length; a++) {
    let s = t.geometry[a];
    for (let o = 0; o < s.length; o++) Gu(i, s[o], e, r, !0, o === 0);
  }
  if (!i.length) return;
  let n = { type: 3, tags: t.tags || null, geometry: i };
  t.id !== null && (n.id = t.id), e.features.push(n);
}
function Gu(e, t, r, i, n, a) {
  let s = i * i;
  if (i > 0 && t.size < (n ? s : i)) {
    r.numPoints += t.points.length / 3;
    return;
  }
  let o = [];
  for (let l = 0; l < t.points.length; l += 3) (i === 0 || t.points[l + 2] > s) && (r.numSimplified++, o.push(t.points[l], t.points[l + 1])), r.numPoints++;
  n && Pb(o, a), e.push(o);
}
function Pb(e, t) {
  let r = 0;
  for (let i = 0, n = e.length, a = n - 2; i < n; a = i, i += 2) r += (e[i] - e[a]) * (e[i + 1] + e[a + 1]);
  if (r > 0 === t) for (let i = 0, n = e.length; i < n / 2; i += 2) {
    let a = e[i], s = e[i + 1];
    e[i] = e[n - 2 - i], e[i + 1] = e[n - 1 - i], e[n - 2 - i] = a, e[n - 1 - i] = s;
  }
}
function ap(e, t) {
  if (e.transformed) return e;
  let r = 1 << e.z, i = e.x, n = e.y;
  for (let a of e.features) a.type === 1 ? Bb(a, t, r, i, n) : Lb(a, t, r, i, n);
  return e.transformed = !0, e;
}
function Bb(e, t, r, i, n) {
  let a = e, s = e.geometry, o = [];
  for (let l = 0; l < s.length; l += 2) o.push(Zy(s[l], s[l + 1], t, r, i, n));
  return a.geometry = o, a;
}
function Lb(e, t, r, i, n) {
  let a = e, s = e.geometry, o = [];
  for (let l of s) {
    let u = [];
    for (let c = 0; c < l.length; c += 2) u.push(Zy(l[c], l[c + 1], t, r, i, n));
    o.push(u);
  }
  return a.geometry = o, a;
}
function Zy(e, t, r, i, n, a) {
  return [Math.round(r * (e * i - n)), Math.round(r * (t * i - a))];
}
var zb = class {
  constructor(e) {
    this.options = e, this.total = 0, this.stats = {}, this.tiles = {}, this.tileCoords = [], this.stats = {}, this.total = 0;
  }
  initialize(e) {
    this.splitTile(this.clipToWorld(e), 0, 0, 0), this.options.debug && (e.length && console.log("features: %d, points: %d", this.tiles[0].numFeatures, this.tiles[0].numPoints), console.timeEnd("generate tiles"), console.log("tiles generated:", this.total, JSON.stringify(this.stats)));
  }
  updateIndex(e, t, r) {
    r.debug > 1 && (console.log("invalidating tiles"), console.time("invalidating")), this.invalidateTiles(t), r.debug > 1 && console.timeEnd("invalidating");
    let [i, n, a] = [0, 0, 0], s = this.clipToWorld(e), o = np(s, i, n, a, r);
    o.source = s;
    let l = va(i, n, a);
    if (this.tiles[l] = o, this.tileCoords.push({ z: i, x: n, y: a, id: l }), r.debug) {
      let u = `z${i}`;
      this.stats[u] = (this.stats[u] || 0) + 1, this.total++;
    }
  }
  getClusterExpansionZoom(e) {
    return null;
  }
  getChildren(e) {
    return null;
  }
  getLeaves(e, t, r) {
    return null;
  }
  getTile(e, t, r) {
    let { extent: i, debug: n } = this.options, a = 1 << e;
    if (!this.options.wrap && (t < 0 || t >= a)) return null;
    t = t + a & a - 1;
    let s = va(e, t, r);
    if (this.tiles[s]) return ap(this.tiles[s], i);
    n > 1 && console.log("drilling down to z%d-%d-%d", e, t, r);
    let o = e, l = t, u = r, c;
    for (; !c && o > 0; ) o--, l >>= 1, u >>= 1, c = this.tiles[va(o, l, u)];
    return !(c != null && c.source) || (n > 1 && (console.log("found parent tile z%d-%d-%d", o, l, u), console.time("drilling down")), this.splitTile(c.source, o, l, u, e, t, r), n > 1 && console.timeEnd("drilling down"), !this.tiles[s]) ? null : ap(this.tiles[s], i);
  }
  clipToWorld(e) {
    let { wrap: t, coordinates: r } = this.options;
    if (t && r !== "unitSquare") return e;
    let i = this.options.buffer / this.options.extent;
    return _t(t ? e : _t(e, 1, -i, 1 + i, 0, -1 / 0, 1 / 0, this.options) || [], 1, -i, 1 + i, 1, -1 / 0, 1 / 0, this.options) || [];
  }
  splitTile(e, t, r, i, n, a, s) {
    let o = [e, t, r, i], l = this.options, u = l.debug;
    for (; o.length; ) {
      i = o.pop(), r = o.pop(), t = o.pop(), e = o.pop();
      let c = 1 << t, h = va(t, r, i), p = this.tiles[h];
      if (!p && (u > 1 && console.time("creation"), p = this.tiles[h] = np(e, t, r, i, l), this.tileCoords.push({ z: t, x: r, y: i, id: h }), u)) {
        u > 1 && (console.log("tile z%d-%d-%d (features: %d, points: %d, simplified: %d)", t, r, i, p.numFeatures, p.numPoints, p.numSimplified), console.timeEnd("creation"));
        let _ = `z${t}`;
        this.stats[_] = (this.stats[_] || 0) + 1, this.total++;
      }
      if (p.source = e, n == null) {
        if (t === l.indexMaxZoom || p.numPoints <= l.indexMaxPoints) continue;
      } else {
        if (t === l.maxZoom || t === n) continue;
        if (n != null) {
          let _ = n - t;
          if (r !== a >> _ || i !== s >> _) continue;
        }
      }
      if (p.source = null, !e.length) continue;
      u > 1 && console.time("clipping");
      let f = 0.5 * l.buffer / l.extent, d = 0.5 - f, y = 0.5 + f, m = 1 + f, g = null, v = null, x = null, b = null, w = _t(e, c, r - f, r + y, 0, p.minX, p.maxX, l), D = _t(e, c, r + d, r + m, 0, p.minX, p.maxX, l);
      w && (g = _t(w, c, i - f, i + y, 1, p.minY, p.maxY, l), v = _t(w, c, i + d, i + m, 1, p.minY, p.maxY, l)), D && (x = _t(D, c, i - f, i + y, 1, p.minY, p.maxY, l), b = _t(D, c, i + d, i + m, 1, p.minY, p.maxY, l)), u > 1 && console.timeEnd("clipping"), o.push(g || [], t + 1, r * 2, i * 2), o.push(v || [], t + 1, r * 2, i * 2 + 1), o.push(x || [], t + 1, r * 2 + 1, i * 2), o.push(b || [], t + 1, r * 2 + 1, i * 2 + 1);
    }
  }
  invalidateTiles(e) {
    if (!e.length) return;
    let t = this.options, { debug: r } = t, i = 1 / 0, n = -1 / 0, a = 1 / 0, s = -1 / 0;
    for (let u of e) i = Math.min(i, u.minX), n = Math.max(n, u.maxX), a = Math.min(a, u.minY), s = Math.max(s, u.maxY);
    let o = t.buffer / t.extent, l = /* @__PURE__ */ new Set();
    for (let u in this.tiles) {
      let c = this.tiles[u], h = 1 << c.z, p = (c.x - o) / h, f = (c.x + 1 + o) / h, d = (c.y - o) / h, y = (c.y + 1 + o) / h;
      if (n < p || i >= f || s < d || a >= y) continue;
      let m = !1;
      for (let g of e) if (g.maxX >= p && g.minX < f && g.maxY >= d && g.minY < y) {
        m = !0;
        break;
      }
      if (m) {
        if (r) {
          r > 1 && console.log("invalidate tile z%d-%d-%d (features: %d, points: %d, simplified: %d)", c.z, c.x, c.y, c.numFeatures, c.numPoints, c.numSimplified);
          let g = `z${c.z}`;
          this.stats[g] = (this.stats[g] || 0) - 1, this.total--;
        }
        delete this.tiles[u], l.add(u);
      }
    }
    l.size && (this.tileCoords = this.tileCoords.filter((u) => !l.has(u.id)));
  }
};
function va(e, t, r) {
  return ((1 << e) * r + t) * 32 + e;
}
const Vb = { maxZoom: 14, indexMaxZoom: 5, indexMaxPoints: 1e5, tolerance: 3, extent: 4096, buffer: 64, lineMetrics: !1, promoteId: null, generateId: !1, updateable: !1, cluster: !1, clusterOptions: Xy, debug: 0, coordinates: "lngLat", wrap: !0 };
var Ob = class {
  constructor(e, t) {
    t = this.options = Object.assign({}, Vb, t), this.worldCoordinateHelper = Ou(t.coordinates);
    let r = t.debug;
    if (r && console.time("preprocess data"), t.maxZoom < 0 || t.maxZoom > 24) throw Error("maxZoom should be in the 0-24 range");
    if (t.promoteId && t.generateId) throw Error("promoteId and generateId cannot be used together.");
    t.updateable && (this.unlocated = /* @__PURE__ */ new Map()), this.nextId = e.type === "FeatureCollection" ? e.features.length : 1;
    let i = Ru(e, t, this.unlocated);
    r && (console.timeEnd("preprocess data"), console.log("index: maxZoom: %d, maxPoints: %d", t.indexMaxZoom, t.indexMaxPoints), console.time("generate tiles")), i = ju(i, t), t.updateable && (this.source = i), this.initializeIndex(i, t);
  }
  initializeIndex(e, t) {
    this.tileIndex = t.cluster ? new Ab({ ...t.clusterOptions, coordinates: t.coordinates, wrap: t.wrap }) : new zb(t), e.length && this.tileIndex.initialize(e);
  }
  getTile(e, t, r) {
    return e = +e, t = +t, r = +r, e < 0 || e > 24 ? null : this.tileIndex.getTile(e, t, r);
  }
  updateData(e, t) {
    let r = this.options;
    if (!r.updateable) throw Error("to update tile geojson `updateable` option must be set to true");
    r.generateId && e.add && (e = { ...e, add: e.add.map((a) => ({ ...a, id: this.nextId++ })) });
    let { affected: i, source: n } = bb(this.source, e, r, this.unlocated);
    t && ({ affected: i, source: n } = this.filterUpdate(n, i, t)), i.length && (this.source = n, this.tileIndex.updateIndex(n, i, r));
  }
  filterUpdate(e, t, r) {
    let i = /* @__PURE__ */ new Set();
    for (let n of e) n.id != null && (r(rs(n, this.worldCoordinateHelper)) || (t.push(n), i.add(n.id)));
    e = e.filter((n) => !i.has(n.id));
    for (let [n, a] of this.unlocated ?? []) a.geometry && !r(a) && this.unlocated.delete(n);
    return { affected: t, source: e };
  }
  getData() {
    if (!this.options.updateable) throw Error("to retrieve data the `updateable` option must be set to true");
    return ub(this.source, this.worldCoordinateHelper);
  }
  updateClusterOptions(e, t) {
    let r = this.options.cluster;
    this.options.cluster = e, this.options.clusterOptions = t, r == e ? this.tileIndex.updateIndex(this.source, [], this.options) : this.initializeIndex(this.source, this.options);
  }
  getClusterExpansionZoom(e) {
    return this.tileIndex.getClusterExpansionZoom(e);
  }
  getClusterChildren(e) {
    return this.tileIndex.getChildren(e);
  }
  getClusterLeaves(e, t, r) {
    return this.tileIndex.getLeaves(e, t, r);
  }
};
const Rb = Te([{ name: "a_pos_normal", components: 2, type: "Int16" }, { name: "a_data", components: 4, type: "Uint8" }, { name: "a_offset_normal", components: 2, type: "Int8" }], 2), $b = Rb.members, Nb = Te([{ name: "a_uv_x", components: 1, type: "Float32" }, { name: "a_split_index", components: 1, type: "Float32" }]), Ub = Nb.members, jb = Math.cos(75 / 2 * (Math.PI / 180)), Hy = 1 / 2, sp = 2 ** 14 / Hy;
var Ky = class {
  constructor(e) {
    this.zoom = e.zoom, this.overscaling = e.overscaling, this.layers = e.layers, this.layerIds = this.layers.map((t) => t.id), this.index = e.index, this.hasDependencies = !1, this.patternFeatures = [], this.lineClipsArray = [], this.gradients = {};
    for (let t of this.layers) this.gradients[t.id] = {};
    this.layoutVertexArray = new Cx(), this.layoutVertexArray2 = new kx(), this.indexArray = new Nn(), this.programConfigurations = new Br(e.layers, e.zoom), this.segments = new ut(), this.maxLineLength = 0, this.stateDependentLayerIds = this.layers.filter((t) => t.isStateDependent()).map((t) => t.id);
  }
  populate(e, t, r) {
    this.hasDependencies = Qa("line", this.layers, t) || this.hasLineDasharray(this.layers);
    let i = this.layers[0].layout.get("line-sort-key"), n = !i.isConstant(), a = [], s = new le(this.zoom), o = this.layers[0]._featureFilter.needGeometry;
    for (let { feature: l, id: u, index: c, sourceLayerIndex: h } of e) {
      let p = Ei(l, o);
      if (!this.layers[0]._featureFilter.filter(s, p, r)) continue;
      let f = n ? i.evaluate(p, {}, r) : void 0, d = { id: u, properties: l.properties, type: l.type, sourceLayerIndex: h, index: c, geometry: o ? p.geometry : Or(l), patterns: {}, dashes: {}, sortKey: f };
      a.push(d);
    }
    n && a.sort((l, u) => l.sortKey - u.sortKey);
    for (let l of a) {
      let { geometry: u, index: c, sourceLayerIndex: h } = l;
      this.hasDependencies ? (Qa("line", this.layers, t) ? zu("line", this.layers, l, { zoom: this.zoom }, t) : this.hasLineDasharray(this.layers) && this.addLineDashDependencies(this.layers, l, this.zoom, t), this.patternFeatures.push(l)) : this.addFeature(l, u, c, r, {}, {}, t.subdivisionGranularity);
      let p = e[c].feature;
      t.featureIndex.insert(p, u, c, h, this.index);
    }
  }
  update(e, t, r, i) {
    this.stateDependentLayers.length && this.programConfigurations.updatePaintArrays(e, t, this.stateDependentLayers, { imagePositions: r, dashPositions: i });
  }
  addFeatures({ options: e, canonical: t, patternPositions: r, dashPositions: i }) {
    for (let n of this.patternFeatures) this.addFeature(n, n.geometry, n.index, t, r, i, e.subdivisionGranularity);
  }
  isEmpty() {
    return this.layoutVertexArray.length === 0;
  }
  uploadPending() {
    return !this.uploaded || this.programConfigurations.needsUpload;
  }
  upload(e) {
    this.uploaded || (this.layoutVertexArray2.length !== 0 && (this.layoutVertexBuffer2 = e.createVertexBuffer(this.layoutVertexArray2, Ub)), this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, $b), this.indexBuffer = e.createIndexBuffer(this.indexArray)), this.programConfigurations.upload(e), this.uploaded = !0;
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.programConfigurations.destroy(), this.segments.destroy());
  }
  lineFeatureClips(e) {
    if (e.properties && Object.hasOwn(e.properties, "geojsonvt_clip_start") && Object.hasOwn(e.properties, "geojsonvt_clip_end")) return { start: +e.properties[Yy], end: +e.properties[Wy] };
  }
  addFeature(e, t, r, i, n, a, s) {
    let o = this.layers[0].layout, l = o.get("line-join").evaluate(e, {}), u = o.get("line-cap").evaluate(e, {}), c = o.get("line-miter-limit").evaluate(e, {}), h = o.get("line-round-limit").evaluate(e, {});
    this.lineClips = this.lineFeatureClips(e);
    for (let p of t) this.addLine(p, e, l, u, c, h, i, s);
    this.programConfigurations.populatePaintArrays(this.layoutVertexArray.length, e, r, { imagePositions: n, dashPositions: a, canonical: i });
  }
  addLine(e, t, r, i, n, a, s, o) {
    this.distance = 0, this.scaledDistance = 0, this.totalDistance = 0;
    let l = s ? o.line.getGranularityForZoomLevel(s.z) : 1;
    if (e = Tr(e, l), this.lineClips) {
      this.lineClipsArray.push(this.lineClips);
      for (let x = 0; x < e.length - 1; x++) this.totalDistance += e[x].dist(e[x + 1]);
      this.updateScaledDistance(), this.maxLineLength = Math.max(this.maxLineLength, this.totalDistance);
    }
    let u = Un.types[t.type] === "Polygon", c = e.length;
    for (; c >= 2 && e[c - 1].equals(e[c - 2]); ) c--;
    let h = 0;
    for (; h < c - 1 && e[h].equals(e[h + 1]); ) h++;
    if (c - h < (u ? 3 : 2)) return;
    r === "bevel" && (n = 1.05);
    let p = this.overscaling <= 16 ? 15 * te / (512 * this.overscaling) : 0, f = this.segments.prepareSegment(c * 10, this.layoutVertexArray, this.indexArray), d, y, m, g, v;
    this.e1 = this.e2 = -1, u && (d = e[c - 2], v = e[h].sub(d)._unit()._perp());
    for (let x = h; x < c; x++) {
      if (m = x === c - 1 ? u ? e[h + 1] : void 0 : e[x + 1], m && e[x].equals(m)) continue;
      v && (g = v), d && (y = d), d = e[x], v = m ? m.sub(d)._unit()._perp() : g, g || (g = v);
      let b = g.add(v);
      (b.x !== 0 || b.y !== 0) && b._unit();
      let w = g.x * v.x + g.y * v.y, D = b.x * v.x + b.y * v.y, _ = D === 0 ? 1 / 0 : 1 / D, A = 2 * Math.sqrt(2 - 2 * D), E = D < jb && y && m, R = g.x * v.y - g.y * v.x > 0, B = b.mult(Math.min(_, 2)), L = rt((_ - 3) / 5, 0, 1);
      if (E && x > h) {
        let C = d.dist(y);
        if (C > 2 * p) {
          let N = d.sub(d.sub(y)._mult(p / C)._round());
          this.updateDistance(y, N), this.addCurrentVertex(N, g, 0, 0, f), y = N;
        }
      }
      let $ = y && m, M = $ ? r : u ? "butt" : i;
      if ($ && M === "round" && (_ < a ? M = "miter" : _ <= 2 && (M = "fakeround")), M === "miter" && _ > n && (M = "bevel"), M === "bevel" && (_ > 2 && (M = "flipbevel"), _ < n && (M = "miter")), y && this.updateDistance(y, d), M === "miter") b._mult(_), this.addCurrentVertex(d, b, 0, 0, f, !1, B);
      else if (M === "flipbevel") {
        if (_ > 100) b = v.mult(-1);
        else {
          let C = _ * g.add(v).mag() / g.sub(v).mag();
          b._perp()._mult(C * (R ? -1 : 1));
        }
        this.addCurrentVertex(d, b, 0, 0, f, !1, B, L), this.addCurrentVertex(d, b.mult(-1), 0, 0, f, !1, B, L);
      } else if (M === "bevel" || M === "fakeround") {
        let C = -Math.sqrt(_ * _ - 1), N = R ? C : 0, z = R ? 0 : C;
        if (y && this.addCurrentVertex(d, g, N, z, f, !1, B), M === "fakeround") {
          let O = Math.round(A * 180 / Math.PI / 20);
          for (let re = 1; re < O; re++) {
            let oe = re / O;
            if (oe !== 0.5) {
              let be = oe - 0.5, Ee = 1.0904 + w * (-3.2452 + w * (3.55645 - w * 1.43519)), Ve = 0.848013 + w * (-1.06021 + w * 0.215638);
              oe += oe * be * (oe - 1) * (Ee * be * be + Ve);
            }
            let ue = v.sub(g)._mult(oe)._add(g)._unit()._mult(R ? -1 : 1);
            this.addHalfVertex(d, ue.x, ue.y, R ? -B.x : B.x, R ? -B.y : B.y, !1, R, f);
          }
        }
        m && this.addCurrentVertex(d, v, -N, -z, f, !1, B);
      } else if (M === "butt") this.addCurrentVertex(d, b, 0, 0, f, !1, B);
      else if (M === "square") {
        let C = y ? 1 : -1;
        this.addCurrentVertex(d, b, C, C, f, !1, B);
      } else M === "round" && (y && (this.addCurrentVertex(d, g, 0, 0, f, !1, B, L), this.addCurrentVertex(d, g, 1, 1, f, !0, B, L)), m && (this.addCurrentVertex(d, v, -1, -1, f, !0, B, L), this.addCurrentVertex(d, v, 0, 0, f, !1, B, L)));
      if (E && x < c - 1) {
        let C = d.dist(m);
        if (C > 2 * p) {
          let N = d.add(m.sub(d)._mult(p / C)._round());
          this.updateDistance(d, N), this.addCurrentVertex(N, v, 0, 0, f), d = N;
        }
      }
    }
  }
  addCurrentVertex(e, t, r, i, n, a = !1, s = t, o = 0) {
    let l = t.x + t.y * r, u = t.y - t.x * r, c = -t.x + t.y * i, h = -t.y - t.x * i, p = s.x + (t.x - s.x) * o, f = s.y + (t.y - s.y) * o;
    this.addHalfVertex(e, l, u, p, f, a, !1, n), this.addHalfVertex(e, c, h, -p, -f, a, !0, n), this.distance > sp / 2 && this.totalDistance === 0 && (this.distance = 0, this.updateScaledDistance(), this.addCurrentVertex(e, t, r, i, n, a, s, o));
  }
  addHalfVertex({ x: e, y: t }, r, i, n, a, s, o, l) {
    let u = (this.lineClips ? this.scaledDistance * (sp - 1) : this.scaledDistance) * Hy;
    if (this.layoutVertexArray.emplaceBack((e << 1) + +!!s, (t << 1) + +!!o, Math.round(63 * r) + 128, Math.round(63 * i) + 128, (u & 63) << 2, u >> 6, Math.round(63 * n), Math.round(63 * a)), this.lineClips) {
      let h = (this.scaledDistance - this.lineClips.start) / (this.lineClips.end - this.lineClips.start);
      this.layoutVertexArray2.emplaceBack(h, this.lineClipsArray.length);
    }
    let c = l.vertexLength++;
    this.e1 >= 0 && this.e2 >= 0 && (this.indexArray.emplaceBack(this.e1, c, this.e2), l.primitiveLength++), o ? this.e2 = c : this.e1 = c;
  }
  updateScaledDistance() {
    this.scaledDistance = this.lineClips ? this.lineClips.start + (this.lineClips.end - this.lineClips.start) * this.distance / this.totalDistance : this.distance;
  }
  updateDistance(e, t) {
    this.distance += e.dist(t), this.updateScaledDistance();
  }
  hasLineDasharray(e) {
    for (let t of e) {
      let r = t.paint.get("line-dasharray");
      if (r && !r.isConstant()) return !0;
    }
    return !1;
  }
  addLineDashDependencies(e, t, r, i) {
    for (let n of e) {
      let a = n.paint.get("line-dasharray");
      if (!a || a.value.kind === "constant") continue;
      let s = n.layout.get("line-cap").evaluate(t, {}) === "round", o = { dasharray: a.value.evaluate({ zoom: r - 1 }, t, {}), round: s }, l = { dasharray: a.value.evaluate({ zoom: r }, t, {}), round: s }, u = { dasharray: a.value.evaluate({ zoom: r + 1 }, t, {}), round: s }, c = `${o.dasharray.join(",")},${o.round}`, h = `${l.dasharray.join(",")},${l.round}`, p = `${u.dasharray.join(",")},${u.round}`;
      i.dashDependencies[c] = o, i.dashDependencies[h] = l, i.dashDependencies[p] = u, t.dashes[n.id] = { min: c, mid: h, max: p };
    }
  }
};
P("LineBucket", Ky, { omit: ["layers", "patternFeatures"] });
let qb;
const Gb = () => qb || (qb = new Je({ "line-cap": new j(S.layout_line["line-cap"], "line-cap"), "line-join": new j(S.layout_line["line-join"], "line-join"), "line-miter-limit": new j(S.layout_line["line-miter-limit"], "line-miter-limit"), "line-round-limit": new j(S.layout_line["line-round-limit"], "line-round-limit"), "line-sort-key": new j(S.layout_line["line-sort-key"], "line-sort-key") }));
let Xb;
const Yb = () => Xb || (Xb = new Je({ "line-opacity": new j(S.paint_line["line-opacity"], "line-opacity"), "line-layer-opacity": new V(S.paint_line["line-layer-opacity"], "line-layer-opacity"), "line-layer-blend": new V(S.paint_line["line-layer-blend"], "line-layer-blend"), "line-color": new j(S.paint_line["line-color"], "line-color"), "line-translate": new V(S.paint_line["line-translate"], "line-translate"), "line-translate-anchor": new V(S.paint_line["line-translate-anchor"], "line-translate-anchor"), "line-width": new j(S.paint_line["line-width"], "line-width"), "line-gap-width": new j(S.paint_line["line-gap-width"], "line-gap-width"), "line-offset": new j(S.paint_line["line-offset"], "line-offset"), "line-blur": new j(S.paint_line["line-blur"], "line-blur"), "line-dasharray": new Sn(S.paint_line["line-dasharray"], "line-dasharray"), "line-pattern": new Sn(S.paint_line["line-pattern"], "line-pattern"), "line-gradient": new bs(S.paint_line["line-gradient"], "line-gradient") }));
var op = { get paint() {
  return Yb();
}, get layout() {
  return Gb();
} }, Wb = class extends j {
  possiblyEvaluate(e, t) {
    return t = new le(Math.floor(t.zoom), { now: t.now, fadeDuration: t.fadeDuration, zoomHistory: t.zoomHistory, transition: t.transition }), super.possiblyEvaluate(e, t);
  }
  evaluate(e, t, r, i) {
    return t = it({}, t, { zoom: Math.floor(t.zoom) }), super.evaluate(e, t, r, i);
  }
};
let ba;
var Zb = class extends At {
  constructor(e, t) {
    super(e, op, t), this.gradientVersion = 0, ba || (ba = new Wb(op.paint.properties["line-width"].specification, "line-floorwidth"), ba.useIntegerZoom = !0);
  }
  _handleSpecialPaintPropertyUpdate(e) {
    if (e === "line-gradient") {
      let t = this.gradientExpression();
      this.stepInterpolant = k0(t) ? t._styleExpression.expression instanceof lu : !1, this.gradientVersion = (this.gradientVersion + 1) % (2 ** 53 - 1);
    }
  }
  gradientExpression() {
    return this._transitionablePaint._values["line-gradient"].value.expression;
  }
  recalculate(e, t) {
    super.recalculate(e, t), this.paint._values["line-floorwidth"] = ba.possiblyEvaluate(this._transitioningPaint._values["line-width"].value, e);
  }
  createBucket(e) {
    return new Ky(e);
  }
  queryRadius(e) {
    let t = e, r = lp(oi("line-width", this, t), oi("line-gap-width", this, t)), i = oi("line-offset", this, t);
    return r / 2 + Math.abs(i) + Ss(this.paint.get("line-translate"));
  }
  queryIntersectsFeature({ queryGeometry: e, feature: t, featureState: r, geometry: i, projectedCamera: n, pixelsToTileUnits: a }) {
    let s = As(e, this.paint.get("line-translate"), this.paint.get("line-translate-anchor"), -n.bearingInRadians, a), o = a / 2 * lp(this.paint.get("line-width").evaluate(t, r), this.paint.get("line-gap-width").evaluate(t, r)), l = this.paint.get("line-offset").evaluate(t, r);
    return l && (i = D2(i, l * a)), Yx(s, i, o);
  }
  isTileClipped() {
    return !0;
  }
};
function lp(e, t) {
  return t > 0 ? t + 2 * e : e;
}
const Hb = Te([{ name: "a_pos_offset", components: 4, type: "Int16" }, { name: "a_data", components: 4, type: "Uint16" }, { name: "a_pixeloffset", components: 4, type: "Int16" }, { name: "a_height_offset", components: 1, type: "Float32" }], 4), Kb = Te([{ name: "a_projected_pos", components: 3, type: "Float32" }], 4);
Te([{ name: "a_fade_opacity", components: 1, type: "Uint32" }], 4);
const Jb = Te([{ name: "a_placed", components: 2, type: "Uint8" }, { name: "a_shift", components: 2, type: "Float32" }, { name: "a_box_real", components: 2, type: "Int16" }]);
Te([{ type: "Int16", name: "anchorPointX" }, { type: "Int16", name: "anchorPointY" }, { type: "Int16", name: "x1" }, { type: "Int16", name: "y1" }, { type: "Int16", name: "x2" }, { type: "Int16", name: "y2" }, { type: "Uint32", name: "featureIndex" }, { type: "Uint16", name: "sourceLayerIndex" }, { type: "Uint16", name: "bucketIndex" }]);
const up = Te([{ name: "a_pos", components: 2, type: "Int16" }, { name: "a_anchor_pos", components: 2, type: "Int16" }, { name: "a_extrude", components: 2, type: "Int16" }], 4);
Te([{ name: "a_pos", components: 2, type: "Float32" }, { name: "a_radius", components: 1, type: "Float32" }, { name: "a_flags", components: 2, type: "Int16" }], 4), Te([{ name: "triangle", components: 3, type: "Uint16" }]), Te([{ type: "Int16", name: "anchorX" }, { type: "Int16", name: "anchorY" }, { type: "Uint16", name: "glyphStartIndex" }, { type: "Uint16", name: "numGlyphs" }, { type: "Uint32", name: "vertexStartIndex" }, { type: "Uint32", name: "lineStartIndex" }, { type: "Uint32", name: "lineLength" }, { type: "Uint16", name: "segment" }, { type: "Uint16", name: "lowerSize" }, { type: "Uint16", name: "upperSize" }, { type: "Float32", name: "lineOffsetX" }, { type: "Float32", name: "lineOffsetY" }, { type: "Uint8", name: "writingMode" }, { type: "Uint8", name: "placedOrientation" }, { type: "Uint8", name: "hidden" }, { type: "Uint32", name: "crossTileID" }, { type: "Int16", name: "associatedIconIndex" }, { type: "Float32", name: "heightOffset" }]), Te([{ type: "Int16", name: "anchorX" }, { type: "Int16", name: "anchorY" }, { type: "Int16", name: "rightJustifiedTextSymbolIndex" }, { type: "Int16", name: "centerJustifiedTextSymbolIndex" }, { type: "Int16", name: "leftJustifiedTextSymbolIndex" }, { type: "Int16", name: "verticalPlacedTextSymbolIndex" }, { type: "Int16", name: "placedIconSymbolIndex" }, { type: "Int16", name: "verticalPlacedIconSymbolIndex" }, { type: "Uint16", name: "key" }, { type: "Uint16", name: "textBoxStartIndex" }, { type: "Uint16", name: "textBoxEndIndex" }, { type: "Uint16", name: "verticalTextBoxStartIndex" }, { type: "Uint16", name: "verticalTextBoxEndIndex" }, { type: "Uint16", name: "iconBoxStartIndex" }, { type: "Uint16", name: "iconBoxEndIndex" }, { type: "Uint16", name: "verticalIconBoxStartIndex" }, { type: "Uint16", name: "verticalIconBoxEndIndex" }, { type: "Uint16", name: "featureIndex" }, { type: "Uint16", name: "numHorizontalGlyphVertices" }, { type: "Uint16", name: "numVerticalGlyphVertices" }, { type: "Uint16", name: "numIconVertices" }, { type: "Uint16", name: "numVerticalIconVertices" }, { type: "Uint16", name: "useRuntimeCollisionCircles" }, { type: "Uint32", name: "crossTileID" }, { type: "Float32", name: "textBoxScale" }, { type: "Float32", name: "collisionCircleDiameter" }, { type: "Uint16", name: "textAnchorOffsetStartIndex" }, { type: "Uint16", name: "textAnchorOffsetEndIndex" }, { type: "Float32", name: "heightOffset" }]), Te([{ type: "Float32", name: "offsetX" }]), Te([{ type: "Int16", name: "x" }, { type: "Int16", name: "y" }, { type: "Int16", name: "tileUnitDistanceFromAnchor" }]), Te([{ type: "Uint16", name: "textAnchor" }, { type: "Float32", components: 2, name: "textOffset" }]);
const _i = new class {
  constructor() {
    this.TIMEOUT = 5e3, this.applyArabicShaping = null, this.processBidirectionalText = null, this.processStyledBidirectionalText = null, this.pluginStatus = "unavailable", this.pluginURL = null, this.loadScriptResolve = () => {
    };
  }
  setState(e) {
    this.pluginStatus = e.pluginStatus, this.pluginURL = e.pluginURL;
  }
  getState() {
    return { pluginStatus: this.pluginStatus, pluginURL: this.pluginURL };
  }
  setMethods(e) {
    if (_i.isParsed()) throw Error("RTL text plugin already registered.");
    this.applyArabicShaping = e.applyArabicShaping, this.processBidirectionalText = e.processBidirectionalText, this.processStyledBidirectionalText = e.processStyledBidirectionalText, this.loadScriptResolve();
  }
  isParsed() {
    return this.applyArabicShaping != null && this.processBidirectionalText != null && this.processStyledBidirectionalText != null;
  }
  getRTLTextPluginStatus() {
    return this.pluginStatus;
  }
  async syncState(e, t) {
    if (this.isParsed()) return this.getState();
    if (e.pluginStatus !== "loading") return this.setState(e), e;
    let r = e.pluginURL, i = new Promise((a) => {
      this.loadScriptResolve = a;
    }), n = new Promise((a) => setTimeout(() => a(), this.TIMEOUT));
    if (await t(r), await Promise.race([i, n]), this.isParsed()) {
      let a = { pluginStatus: "loaded", pluginURL: r };
      return this.setState(a), a;
    }
    throw this.setState({ pluginStatus: "error", pluginURL: "" }), Error(`RTL Text Plugin failed to import scripts from ${r}`);
  }
}();
function Qb(e) {
  return /[\u0600-\u0604\u0606-\u060B\u060D-\u061A\u061C-\u061E\u0620-\u063F\u0641-\u064A\u0656-\u066F\u0671-\u06DC\u06DE-\u070D\u070F-\u074A\u074D-\u077F\u07C0-\u07FA\u07FD-\u07FF\u0840-\u085B\u085E\u0860-\u086A\u0870-\u0891\u0897-\u08E1\u08E3-\u08FF\u1800\u1801\u1804\u1806-\u1819\u1820-\u1878\u1880-\u18AA\uA840-\uA877\uFB50-\uFD3D\uFD40-\uFDCF\uFDF0-\uFDFF\uFE70-\uFE74\uFE76-\uFEFC]|\uD802[\uDEC0-\uDEE6\uDEEB-\uDEF6\uDF80-\uDF91\uDF99-\uDF9C\uDFA9-\uDFAF]|\uD803[\uDD00-\uDD27\uDD30-\uDD39\uDE60-\uDE7E\uDEC2-\uDEC7\uDED0-\uDED8\uDEFA-\uDEFF\uDF30-\uDF59\uDF70-\uDF89\uDFB0-\uDFCB]|\uD805[\uDE60-\uDE6C]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9C-\uDC9F]|\uD83A[\uDD00-\uDD4B\uDD50-\uDD59\uDD5E\uDD5F]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB\uDEF0\uDEF1]/gim.test(String.fromCodePoint(e));
}
function ew(e) {
  return /[\u0591-\u05C7\u05D0-\u05EA\u05EF-\u05F4\u0600-\u0604\u0606-\u060B\u060D-\u061A\u061C-\u061E\u0620-\u063F\u0641-\u064A\u0656-\u066F\u0671-\u06DC\u06DE-\u070D\u070F-\u074A\u074D-\u07B1\u07C0-\u07FA\u07FD-\u082D\u0830-\u083E\u0840-\u085B\u085E\u0860-\u086A\u0870-\u0891\u0897-\u08E1\u08E3-\u08FF\uFB1D-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFD3D\uFD40-\uFDCF\uFDF0-\uFDFF\uFE70-\uFE74\uFE76-\uFEFC]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC57-\uDC9E\uDCA7-\uDCAF\uDCE0-\uDCF2\uDCF4\uDCF5\uDCFB-\uDD1B\uDD1F-\uDD39\uDD3F-\uDD59\uDD80-\uDDB7\uDDBC-\uDDCF\uDDD2-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE38-\uDE3A\uDE3F-\uDE48\uDE50-\uDE58\uDE60-\uDE9F\uDEC0-\uDEE6\uDEEB-\uDEF6\uDF00-\uDF35\uDF39-\uDF55\uDF58-\uDF72\uDF78-\uDF91\uDF99-\uDF9C\uDFA9-\uDFAF]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDCFA-\uDD27\uDD30-\uDD39\uDD40-\uDD65\uDD69-\uDD85\uDD8E\uDD8F\uDE60-\uDE7E\uDE80-\uDEA9\uDEAB-\uDEAD\uDEB0\uDEB1\uDEC2-\uDEC7\uDED0-\uDED8\uDEFA-\uDF27\uDF30-\uDF59\uDF70-\uDF89\uDFB0-\uDFCB\uDFE0-\uDFF6]|\uD83A[\uDC00-\uDCC4\uDCC7-\uDCD6\uDD00-\uDD4B\uDD50-\uDD59\uDD5E\uDD5F]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB\uDEF0\uDEF1]/gim.test(String.fromCodePoint(e));
}
function tw(e) {
  return /[\u02EA\u02EB\u2E80-\u2FDF\u2FF0-\u303F\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FD-\u30FF\u3105-\u312F\u31A0-\u4DBF\u4E00-\uA48C\uA490-\uA4C6\uF900-\uFA6D\uFA70-\uFAD9\uFE10-\uFE1F\uFE30-\uFE4F\uFF00-\uFFEF]|\uD81B[\uDFE0-\uDFFF]|[\uD81C-\uD822\uD840-\uD868\uD86A-\uD86D\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD88C][\uDC00-\uDFFF]|\uD823[\uDC00-\uDCD5\uDCFF-\uDD1E\uDD80-\uDDF2]|\uD82B[\uDFF0-\uDFFF]|\uD82C[\uDC00-\uDEFB]|\uD83C[\uDE00-\uDEFF]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEAD\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD88D[\uDC00-\uDC79]/gim.test(String.fromCodePoint(e));
}
function jn(e) {
  return /[\u02EA\u02EB\u1100-\u11FF\u1401-\u167F\u18B0-\u18FF\u2065\u20DD-\u20E0\u20E2-\u20E4\u2B97\u2BF0-\u2BFF\u2E50\u2E51\u2E80-\u3007\u3012\u3013\u3020-\u302F\u3031-\u30FB\u30FD-\uA4CF\uA960-\uA97F\uAC00-\uD7FF\uF900-\uFAFF\uFE10-\uFE1F\uFE30-\uFE48\uFE50-\uFE57\uFE5F-\uFE62\uFE67-\uFE6F\uFF00-\uFF07\uFF0A-\uFF0C\uFF0E-\uFF19\uFF1F-\uFF3A\uFF3C\uFF3E\uFF40-\uFF5A\uFFE0-\uFFE2\uFFE4-\uFFE7\uFFF0-\uFFF8]|\uD802[\uDD80-\uDD9F]|\uD805[\uDD80-\uDDFF]|\uD806[\uDE00-\uDEBF]|[\uD80C-\uD810\uD81C-\uD822\uD83C\uD83D\uD840-\uD87E\uD880-\uD8BE][\uDC00-\uDFFF]|\uD811[\uDC00-\uDE7F]|\uD81B[\uDFE0-\uDFFF]|\uD823[\uDC00-\uDDFF]|\uD82B[\uDFF0-\uDFFF]|\uD82C[\uDC00-\uDEFF]|\uD833[\uDEC0-\uDFCF]|\uD834[\uDC00-\uDDFF\uDEE0-\uDF7F]|\uD836[\uDC00-\uDEAF]|\uD83E[\uDD00-\uDEFF]|[\uD87F\uD8BF][\uDC00-\uDFFD]/gim.test(String.fromCodePoint(e));
}
function rw(e) {
  return /[\xA7\xA9\xAE\xB1\xBC-\xBE\xD7\xF7\u2016\u2020\u2021\u2030\u2031\u203B\u203C\u2042\u2047-\u2049\u2051\u2100-\u218F\u221E\u2234\u2235\u2300-\u2307\u230C-\u231F\u2324-\u2328\u232B\u237D-\u239A\u23BE-\u23CD\u23CF\u23D1-\u23DB\u23E2-\u2422\u2424-\u24FF\u25A0-\u2619\u2620-\u2767\u2776-\u2793\u2B12-\u2B2F\u2B50-\u2B59\u2BB8-\u2BEB\u3000-\u303F\u30A0-\u30FF\uE000-\uF8FF\uFE30-\uFE6F\uFF00-\uFFEF\uFFFC\uFFFD]|[\uDB80-\uDBFF][\uDC00-\uDFFF]/gim.test(String.fromCodePoint(e));
}
function iw(e) {
  return /[\r\u0300-\u036F\u0483-\u0489\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0600-\u0605\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DD\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u070F\u0711\u0730-\u074A\u07A6-\u07B0\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u0890\u0891\u0897-\u089F\u08CA-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A70\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B62\u0B63\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0C00-\u0C04\u0C3C\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0CF3\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D62\u0D63\u0D81-\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E31\u0E33-\u0E3A\u0E47-\u0E4E\u0EB1\u0EB3-\u0EBC\u0EC8-\u0ECE\u0F18\u0F19\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102D-\u1037\u1039-\u103E\u1056-\u1059\u105E-\u1060\u1071-\u1074\u1082\u1084-\u1086\u108D\u109D\u1100-\u11FF\u135D-\u135F\u1712-\u1715\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u180B-\u180D\u180F\u1885\u1886\u18A9\u1920-\u192B\u1930-\u193B\u1A17-\u1A1B\u1A55-\u1A5E\u1A60\u1A62\u1A65-\u1A7C\u1A7F\u1AB0-\u1ADD\u1AE0-\u1AEB\u1B00-\u1B04\u1B34-\u1B44\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BE6-\u1BF3\u1C24-\u1C37\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DFF\u200C\u200D\u20D0-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA66F-\uA672\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA82C\uA880\uA881\uA8B4-\uA8C5\uA8E0-\uA8F1\uA8FF\uA926-\uA92D\uA947-\uA953\uA960-\uA97C\uA980-\uA983\uA9B3-\uA9C0\uA9E5\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA7C\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F\uFF9E\uFF9F]|\uD800[\uDDFD\uDEE0\uDF76-\uDF7A]|\uD802[\uDE01-\uDE03\uDE05\uDE06\uDE0C-\uDE0F\uDE38-\uDE3A\uDE3F\uDEE5\uDEE6]|\uD803[\uDD24-\uDD27\uDD69-\uDD6D\uDEAB\uDEAC\uDEFA-\uDEFF\uDF46-\uDF50\uDF82-\uDF85]|\uD804[\uDC00-\uDC02\uDC38-\uDC46\uDC70\uDC73\uDC74\uDC7F-\uDC82\uDCB0-\uDCBA\uDCBD\uDCC2\uDCCD\uDD00-\uDD02\uDD27-\uDD34\uDD45\uDD46\uDD73\uDD80-\uDD82\uDDB3-\uDDC0\uDDC2\uDDC3\uDDC9-\uDDCC\uDDCE\uDDCF\uDE2C-\uDE37\uDE3E\uDE41\uDEDF-\uDEEA\uDF00-\uDF03\uDF3B\uDF3C\uDF3E-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF57\uDF62\uDF63\uDF66-\uDF6C\uDF70-\uDF74\uDFB8-\uDFC0\uDFC2\uDFC5\uDFC7-\uDFCA\uDFCC-\uDFD2\uDFE1\uDFE2]|\uD805[\uDC35-\uDC46\uDC5E\uDCB0-\uDCC3\uDDAF-\uDDB5\uDDB8-\uDDC0\uDDDC\uDDDD\uDE30-\uDE40\uDEAB-\uDEB7\uDF1D-\uDF1F\uDF22-\uDF2B]|\uD806[\uDC2C-\uDC3A\uDD30-\uDD35\uDD37\uDD38\uDD3B-\uDD43\uDDD1-\uDDD7\uDDDA-\uDDE0\uDDE4\uDE01-\uDE0A\uDE33-\uDE39\uDE3B-\uDE3E\uDE47\uDE51-\uDE5B\uDE84-\uDE99\uDF60-\uDF67]|\uD807[\uDC2F-\uDC36\uDC38-\uDC3F\uDC92-\uDCA7\uDCA9-\uDCB6\uDD31-\uDD36\uDD3A\uDD3C\uDD3D\uDD3F-\uDD47\uDD8A-\uDD8E\uDD90\uDD91\uDD93-\uDD97\uDEF3-\uDEF6\uDF00-\uDF03\uDF34-\uDF3A\uDF3E-\uDF42\uDF5A]|\uD80D[\uDC40\uDC47-\uDC55]|\uD818[\uDD1E-\uDD2F]|\uD81A[\uDEF0-\uDEF4\uDF30-\uDF36]|\uD81B[\uDD63\uDD67-\uDD6A\uDF4F\uDF51-\uDF87\uDF8F-\uDF92\uDFE4\uDFF0\uDFF1]|\uD82F[\uDC9D\uDC9E]|\uD833[\uDF00-\uDF2D\uDF30-\uDF46]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD838[\uDC00-\uDC06\uDC08-\uDC18\uDC1B-\uDC21\uDC23\uDC24\uDC26-\uDC2A\uDC8F\uDD30-\uDD36\uDEAE\uDEEC-\uDEEF]|\uD839[\uDCEC-\uDCEF\uDDEE\uDDEF\uDEE3\uDEE6\uDEEE\uDEEF\uDEF5]|\uD83A[\uDCD0-\uDCD6\uDD44-\uDD4A]|\uD83C[\uDDE6-\uDDFF\uDFFB-\uDFFF]|\uDB40[\uDC20-\uDC7F\uDD00-\uDDEF]/.test(e);
}
function cp(e) {
  return /[\u0E01-\u0E3A\u0E40-\u0E4E\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECE\u0EDC-\u0EDF\u0F00-\u0F47\u0F49-\u0F6C\u0F71-\u0F97\u0F99-\u0FBC\u0FBE-\u0FCC\u0FCE-\u0FD4\u0FD9\u0FDA\u1000-\u103F\u1050-\u108F\u109A-\u109F\u1780-\u17D3\u17D7\u17DC\u17DD\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19DE\u19DF\u1A20-\u1A5E\u1A60-\u1A7C\u1AA0-\u1AAD\u1B00-\u1B4C\u1B4E-\u1B7F\uA980-\uA9CD\uA9D0-\uA9D9\uA9DE-\uA9EF\uA9FA-\uA9FE\uAA60-\uAAC2\uAADB-\uAADF]|\uD805[\uDF00-\uDF1A\uDF1D-\uDF2B\uDF3A\uDF3B\uDF3F-\uDF46]/gim.test(String.fromCodePoint(e));
}
function nw(e, t) {
  return /(?:[\u1039\u17D2\u1A60\u1BAB\u200D\uAAF6]|\uD802\uDE3F|\uD804[\uDD33\uDFD0]|\uD806[\uDD3E\uDE47\uDE99]|\uD807[\uDD45\uDD97\uDF42])$/.test(e) || new RegExp("^\\p{gc=Mc}", "u").test(t);
}
const aw = { C: "18g,1;g2,3;4nb,1", D: "17k,1;5,1;1,1;1,5;4,d;1,7;1,2;z,2;8,g;i,12;1,2;9,1;1,1;1,2;14,3;2,1;28,9;3,f;2,4;1,1;2,3;2,6;7a,1;2,5;1,1;g,a;5,2;2,6;1,f", R: "17m,4;1,1;1,1;5,4;l,1;14,3;1,3;g,i;12,1;2,9;1,1;1,1;2,2;1,1;o,2;2x,3;f,2;4,1;1,2;3,2;6u,j;b,1;r,3;1,1;2,2;6,1", T: "174,b;1,1;1a,l;g,1;2t,7;2,6;2,2;1,4;bt,9;16,o;1,t;1clb,1" }, sw = { 1569: [65152, 0, 0, 0], 1570: [65153, 65154, 0, 0], 1571: [65155, 65156, 0, 0], 1572: [65157, 65158, 0, 0], 1573: [65159, 65160, 0, 0], 1574: [65161, 65162, 65163, 65164], 1575: [65165, 65166, 0, 0], 1576: [65167, 65168, 65169, 65170], 1577: [65171, 65172, 0, 0], 1578: [65173, 65174, 65175, 65176], 1579: [65177, 65178, 65179, 65180], 1580: [65181, 65182, 65183, 65184], 1581: [65185, 65186, 65187, 65188], 1582: [65189, 65190, 65191, 65192], 1583: [65193, 65194, 0, 0], 1584: [65195, 65196, 0, 0], 1585: [65197, 65198, 0, 0], 1586: [65199, 65200, 0, 0], 1587: [65201, 65202, 65203, 65204], 1588: [65205, 65206, 65207, 65208], 1589: [65209, 65210, 65211, 65212], 1590: [65213, 65214, 65215, 65216], 1591: [65217, 65218, 65219, 65220], 1592: [65221, 65222, 65223, 65224], 1593: [65225, 65226, 65227, 65228], 1594: [65229, 65230, 65231, 65232], 1601: [65233, 65234, 65235, 65236], 1602: [65237, 65238, 65239, 65240], 1603: [65241, 65242, 65243, 65244], 1604: [65245, 65246, 65247, 65248], 1605: [65249, 65250, 65251, 65252], 1606: [65253, 65254, 65255, 65256], 1607: [65257, 65258, 65259, 65260], 1608: [65261, 65262, 0, 0], 1609: [65263, 65264, 64488, 64489], 1610: [65265, 65266, 65267, 65268], 1611: [65136, 0, 0, 65137], 1612: [65138, 0, 0, 0], 1613: [65140, 0, 0, 0], 1614: [65142, 0, 0, 65143], 1615: [65144, 0, 0, 65145], 1616: [65146, 0, 0, 65147], 1617: [65148, 0, 0, 65149], 1618: [65150, 0, 0, 65151], 1649: [64336, 64337, 0, 0], 1655: [64477, 0, 0, 0], 1657: [64358, 64359, 64360, 64361], 1658: [64350, 64351, 64352, 64353], 1659: [64338, 64339, 64340, 64341], 1662: [64342, 64343, 64344, 64345], 1663: [64354, 64355, 64356, 64357], 1664: [64346, 64347, 64348, 64349], 1667: [64374, 64375, 64376, 64377], 1668: [64370, 64371, 64372, 64373], 1670: [64378, 64379, 64380, 64381], 1671: [64382, 64383, 64384, 64385], 1672: [64392, 64393, 0, 0], 1676: [64388, 64389, 0, 0], 1677: [64386, 64387, 0, 0], 1678: [64390, 64391, 0, 0], 1681: [64396, 64397, 0, 0], 1688: [64394, 64395, 0, 0], 1700: [64362, 64363, 64364, 64365], 1702: [64366, 64367, 64368, 64369], 1705: [64398, 64399, 64400, 64401], 1709: [64467, 64468, 64469, 64470], 1711: [64402, 64403, 64404, 64405], 1713: [64410, 64411, 64412, 64413], 1715: [64406, 64407, 64408, 64409], 1722: [64414, 64415, 0, 0], 1723: [64416, 64417, 64418, 64419], 1726: [64426, 64427, 64428, 64429], 1728: [64420, 64421, 0, 0], 1729: [64422, 64423, 64424, 64425], 1733: [64480, 64481, 0, 0], 1734: [64473, 64474, 0, 0], 1735: [64471, 64472, 0, 0], 1736: [64475, 64476, 0, 0], 1737: [64482, 64483, 0, 0], 1739: [64478, 64479, 0, 0], 1740: [64508, 64509, 64510, 64511], 1744: [64484, 64485, 64486, 64487], 1746: [64430, 64431, 0, 0], 1747: [64432, 64433, 0, 0] }, ow = { لآ: [65269, 65270], لأ: [65271, 65272], لإ: [65273, 65274], لا: [65275, 65276] }, hp = 1604, lw = /[\u0600-\u06ff\u0750-\u077f\u0870-\u089f\u08a0-\u08ff\ufb50-\ufdff\ufe70-\ufeff]/;
function uw(e, t, r) {
  let i = 0;
  for (let n of e.split(";")) {
    let [a, s] = n.split(",").map((l) => parseInt(l, 36)), o = i + a;
    for (let l = o; l < o + s; l++) r.set(l, t);
    i = o + s;
  }
}
const Jy = /* @__PURE__ */ new Map();
for (let [e, t] of Object.entries(aw)) uw(t, e, Jy);
function cw(e) {
  return Jy.get(e) ?? "U";
}
function hw(e) {
  return e === "D" || e === "L" || e === "C";
}
function pw(e) {
  return e === "D" || e === "R" || e === "C";
}
function fw(e, t, r) {
  return e === "D" ? t && r ? 3 : t ? 1 : r ? 2 : 0 : e === "R" ? +!!t : e === "L" ? r ? 2 : 0 : null;
}
function dw(e) {
  return [...e].map((t) => {
    let r = t.codePointAt(0);
    return { codePoint: r, type: cw(r), form: null };
  });
}
function yw(e) {
  let t = e.filter((r) => r.type !== "T");
  for (let r = 0; r < t.length; r++) {
    let i = t[r], n = r > 0 && hw(t[r - 1].type), a = r + 1 < t.length && pw(t[r + 1].type);
    i.form = fw(i.type, n, a);
  }
}
function mw(e) {
  let t = !1;
  for (let r of e) r.type === "T" ? r.form = t ? 3 : 0 : t = r.form === 2 || r.form === 3;
}
function gw(e) {
  let t = [];
  for (let r = 0; r < e.length; r++) {
    let i = e[r];
    if (i.codePoint !== hp) {
      t.push(i);
      continue;
    }
    let n = r + 1;
    for (; n < e.length && e[n].type === "T"; ) n++;
    let a = e[n], s = a && ow[String.fromCodePoint(hp, a.codePoint)];
    if (!s) {
      t.push(i);
      continue;
    }
    let o = i.form === 3 || i.form === 1;
    t.push({ codePoint: s[+!!o], type: "R", form: 0 }), t.push(...e.slice(r + 1, n)), r = n;
  }
  return t;
}
function xw(e) {
  if (e.form === null) return e.codePoint;
  let t = sw[e.codePoint];
  return t && (t[e.form] || t[0]) || e.codePoint;
}
function vw(e) {
  if (!lw.test(e)) return e;
  let t = dw(e);
  return yw(t), mw(t), gw(t).map((r) => String.fromCodePoint(xw(r))).join("");
}
function bw(e, t, r) {
  let i = t.layout.get("text-transform").evaluate(r, {});
  return i === "uppercase" ? e = e.toLocaleUpperCase() : i === "lowercase" && (e = e.toLocaleLowerCase()), (_i.applyArabicShaping ?? vw)(e);
}
function ww(e, t, r) {
  for (let i of e.sections) i.text = bw(i.text, t, r);
  return e;
}
function Io(e, t, r) {
  let i = r ? t.last.points : t.first.points, n = r ? i[i.length - 1] : i[0];
  return `${e}:${n.x}:${n.y}`;
}
function _w(e) {
  let t = e.first.points, r = t.length;
  for (let a = e.first.next; a; a = a.next) r += a.points.length - 1;
  let i = Array(r);
  for (let a = 0; a < t.length; a++) i[a] = t[a];
  let n = t.length;
  for (let a = e.first.next; a; a = a.next) {
    let s = a.points;
    for (let o = 1; o < s.length; o++) i[n++] = s[o];
  }
  return i;
}
function pp(e, t, r, i, n) {
  let a = t[r];
  delete t[r], t[i] = a;
  let s = e[a];
  return s.last.next = n.first, s.last = n.last, a;
}
function fp(e, t, r, i, n) {
  let a = t[i];
  delete t[i], t[r] = a;
  let s = e[a];
  return n.last.next = s.first, s.first = n.first, a;
}
function Dw(e) {
  let t = {}, r = {}, i = [];
  for (let a of e) {
    let s = a.text ? a.text.toString() : null, o = { points: a.geometry[0], next: null }, l = { feature: a, first: o, last: o };
    if (!s) {
      i.push(l);
      continue;
    }
    let u = Io(s, l), c = Io(s, l, !0);
    if (u in r && c in t && r[u] !== t[c]) {
      let h = fp(i, t, u, c, l), p = pp(i, r, u, c, i[h]);
      delete t[u], delete r[c], r[Io(s, i[p], !0)] = p, i[h].feature.geometry = null;
    } else if (u in r) pp(i, r, u, c, l);
    else if (c in t) fp(i, t, u, c, l);
    else {
      let h = i.push(l) - 1;
      t[u] = h, r[c] = h;
    }
  }
  let n = [];
  for (let a of i) {
    let s = a.feature;
    s.geometry && (a.first.next && (s.geometry[0] = _w(a)), n.push(s));
  }
  return n;
}
const Qy = typeof Intl < "u" && "Segmenter" in Intl;
let dp, yp;
function Ll(e) {
  if (!Qy || !iw(e)) return [...e];
  dp ?? (dp = new Intl.Segmenter(void 0, { granularity: "grapheme" }));
  let t = [];
  for (let { segment: r } of dp.segment(e)) {
    let i = t.length - 1;
    i >= 0 && nw(t[i], r) ? t[i] += r : t.push(r);
  }
  return t;
}
function Sw(e) {
  let t = /* @__PURE__ */ new Set();
  if (Qy) {
    yp ?? (yp = new Intl.Segmenter(void 0, { granularity: "word" }));
    for (let { index: i } of yp.segment(e)) t.add(i);
    return t;
  }
  let r = 0;
  for (let i of e.split(new RegExp("\\b|(?=\\p{Ideo})", "u"))) t.add(r), r += i.length;
  return t;
}
function zl(e) {
  let t = e.codePointAt(0);
  return e.length > (t > 65535 ? 2 : 1);
}
function Pn(e) {
  return /\s/u.test(String.fromCodePoint(e));
}
function Ts(e) {
  return /[\p{P}\p{S}]/u.test(String.fromCodePoint(e));
}
function Vl(e) {
  for (let t of e) if (jn(t.codePointAt(0))) return !0;
  return !1;
}
function e1(e) {
  for (let t of e) if (!Aw(t.codePointAt(0))) return !1;
  return !0;
}
function Aw(e) {
  return !Qb(e);
}
function Di(e) {
  return !(jn(e) || rw(e));
}
function t1(e) {
  return new RegExp("\\p{sc=Arab}", "u").test(String.fromCodePoint(e));
}
function r1(e) {
  return ew(e);
}
function i1(e) {
  for (let t of e) if (r1(t.codePointAt(0))) return !0;
  return !1;
}
const ii = { "!": "︕", "#": "＃", $: "＄", "%": "％", "&": "＆", "(": "︵", ")": "︶", "*": "＊", "+": "＋", ",": "︐", "-": "︲", ".": "・", "/": "／", ":": "︓", ";": "︔", "<": "︿", "=": "＝", ">": "﹀", "?": "︖", "@": "＠", "[": "﹇", "\\": "＼", "]": "﹈", "^": "＾", _: "︳", "`": "｀", "{": "︷", "|": "―", "}": "︸", "~": "～", "¢": "￠", "£": "￡", "¥": "￥", "¦": "￤", "¬": "￢", "¯": "￣", "–": "︲", "—": "︱", "‘": "﹃", "’": "﹄", "“": "﹁", "”": "﹂", "…": "︙", "⋯": "︙", "‧": "・", "₩": "￦", "、": "︑", "。": "︒", "〈": "︿", "〉": "﹀", "《": "︽", "》": "︾", "「": "﹁", "」": "﹂", "『": "﹃", "』": "﹄", "【": "︻", "】": "︼", "〔": "︹", "〕": "︺", "〖": "︗", "〗": "︘", "！": "︕", "（": "︵", "）": "︶", "，": "︐", "－": "︲", "．": "・", "：": "︓", "；": "︔", "＜": "︿", "＞": "﹀", "？": "︖", "［": "﹇", "］": "﹈", "＿": "︳", "｛": "︷", "｜": "―", "｝": "︸", "｟": "︵", "｠": "︶", "｡": "︒", "｢": "﹁", "｣": "﹂" };
function Ew(e) {
  let t = "", r = { premature: !0, value: void 0 }, i = e[Symbol.iterator](), n = i.next(), a = e[Symbol.iterator]();
  a.next();
  let s = a.next();
  for (; !n.done; ) (s.done || !Di(s.value.codePointAt(0)) || ii[s.value]) && (r.premature || !Di(r.value.codePointAt(0)) || ii[r.value]) && ii[n.value] ? t += ii[n.value] : t += n.value, r = { value: n.value, premature: !1 }, n = i.next(), s = a.next();
  return t;
}
const Tw = { 10: !0, 13: !0, 32: !0, 38: !0, 41: !0, 43: !0, 45: !0, 47: !0, 173: !0, 183: !0, 8203: !0, 8208: !0, 8211: !0, 8231: !0 }, Iw = { 40: !0 };
function mp(e, t, r, i, n, a) {
  var s;
  if ("fontStack" in t) {
    let o = (s = r[t.fontStack]) == null ? void 0 : s.default, l = o == null ? void 0 : o[e];
    if (l) return l.metrics.advance * t.scale + n;
    let u = 0;
    for (let c of e) {
      let h = o == null ? void 0 : o[c];
      h && (u += h.metrics.advance * t.scale + n);
    }
    return u;
  }
  {
    let o = i[t.imageName];
    return o ? o.displaySize[0] * t.scale * 24 / a + n : 0;
  }
}
function gp(e, t, r, i) {
  let n = (e - t) ** 2;
  return i ? e < t ? n / 2 : n * 2 : n + Math.abs(r) * r;
}
function xp(e) {
  return /^\s+$/u.test(e);
}
function Cw(e, t, r) {
  let i = 0;
  return (e === 10 || e === 13) && (i -= 1e4), r && (i += 150), (e === 40 || e === 65288) && (i += 50), (t === 41 || t === 65289) && (i += 50), i;
}
function vp(e, t, r, i, n, a) {
  let s = null, o = gp(t, r, n, a);
  for (let l of i) {
    let u = gp(t - l.x, r, n, a) + l.badness;
    u <= o && (s = l, o = u);
  }
  return { index: e, x: t, priorBreak: s, badness: o };
}
function n1(e) {
  return e ? n1(e.priorBreak).concat(e.index) : [];
}
var Xu = class Ol {
  constructor(t = "", r = [], i = []) {
    this.text = t, this.sections = r, this.sectionIndex = i, this.imageSectionID = null, this.cachedGraphemes = null;
  }
  graphemes() {
    return this.cachedGraphemes ?? (this.cachedGraphemes = Ll(this.text)), this.cachedGraphemes;
  }
  static fromFeature(t, r, i, n) {
    let a = new Ol();
    for (let s of t.sections) s.image ? a.addImageSection(s) : a.addTextSection(s, r);
    return i && a.verticalizePunctuation(n), a;
  }
  length() {
    return this.graphemes().length;
  }
  getSection(t) {
    return this.sections[this.sectionIndex[t]];
  }
  getSectionIndex(t) {
    return this.sectionIndex[t];
  }
  verticalizePunctuation(t = {}, r) {
    let i = Ew(this.text), n = 0;
    this.cachedGraphemes = this.graphemes().map((a, s) => {
      var u, c;
      let o = i.slice(n, n + a.length);
      n += a.length;
      let l = this.getSection(s);
      return (r == null ? void 0 : r[s]) !== !1 && "fontStack" in l && ((c = (u = t[l.fontStack]) == null ? void 0 : u.vertical) != null && c[a]) ? a : o;
    }), this.text = this.cachedGraphemes.join("");
  }
  hasZeroWidthSpaces() {
    return this.text.includes("​");
  }
  trim() {
    let t = this.graphemes(), r = 0;
    for (; r < t.length && xp(t[r]); ) r++;
    let i = t.length;
    for (; i > r && xp(t[i - 1]); ) i--;
    this.text = t.slice(r, i).join(""), this.sectionIndex = this.sectionIndex.slice(r, i), this.cachedGraphemes = null;
  }
  substring(t, r) {
    let i = this.graphemes().slice(t, r).join(""), n = this.sectionIndex.slice(t, r);
    return new Ol(i, this.sections, n);
  }
  toCodeUnitIndex(t) {
    return this.graphemes().slice(0, t).join("").length;
  }
  toString() {
    return this.text;
  }
  getMaxScale() {
    return this.sectionIndex.reduce((t, r) => Math.max(t, this.sections[r].scale), 0);
  }
  getMaxImageSize(t) {
    let r = 0, i = 0;
    for (let n = 0; n < this.length(); n++) {
      let a = this.getSection(n);
      if ("imageName" in a) {
        let s = t[a.imageName];
        if (!s) continue;
        let o = s.displaySize;
        r = Math.max(r, o[0]), i = Math.max(i, o[1]);
      }
    }
    return { maxImageWidth: r, maxImageHeight: i };
  }
  _appendSection(t, r) {
    let i = this.graphemes(), n = i.length > 0 ? i[i.length - 1] : "", a = Ll(n + t);
    this.text += t, this.cachedGraphemes = i.slice(0, n ? -1 : void 0).concat(a);
    let s = a.length - +!!n;
    for (let o = 0; o < s; o++) this.sectionIndex.push(r);
  }
  addTextSection(t, r) {
    this.sections.push({ scale: t.scale || 1, verticalAlign: t.verticalAlign || "bottom", fontStack: t.fontStack || r }), this._appendSection(t.text, this.sections.length - 1);
  }
  addImageSection(t) {
    let r = t.image ? t.image.name : "";
    if (r.length === 0) {
      Me("Can't add FormattedSection with an empty image.");
      return;
    }
    let i = this.getNextImageSectionCharCode();
    i ? (this.sections.push({ scale: 1, verticalAlign: t.verticalAlign || "bottom", imageName: r }), this._appendSection(String.fromCharCode(i), this.sections.length - 1)) : Me("Reached maximum number of images 6401");
  }
  getNextImageSectionCharCode() {
    return this.imageSectionID ? this.imageSectionID >= 63743 ? null : ++this.imageSectionID : (this.imageSectionID = 57344, this.imageSectionID);
  }
  determineLineBreaks(t, r, i, n, a) {
    let s = this.determineTotalWidth(t, i, n, a);
    if (t >= 0 && s > 0 && s <= r && !/[\n\r]/.test(this.text)) return [this.length()];
    let o = [], l = s / Math.max(1, Math.ceil(s / r)), u = this.hasZeroWidthSpaces(), c = this.graphemes(), h = null, p = 0, f = 0;
    for (let d = 0; d < c.length; d++) {
      let y = c[d];
      if (d > 0) {
        let m = c[d - 1].codePointAt(0), g = y.codePointAt(0), v = tw(m), x = cp(m) && cp(g);
        (Tw[m] || v || "imageName" in this.getSection(d - 1) || c[d + 1] !== void 0 && Iw[g] || x && (h ?? (h = Sw(this.text))).has(f)) && o.push(vp(d, p, l, o, Cw(m, g, v && u), !1));
      }
      Pn(y.codePointAt(0)) || (p += mp(y, this.getSection(d), i, n, t, a)), f += y.length;
    }
    return n1(vp(this.length(), p, l, o, 0, !0));
  }
  determineTotalWidth(t, r, i, n) {
    let a = 0, s = 0;
    for (let o of this.graphemes()) {
      let l = this.getSection(s);
      a += mp(o, l, r, i, t, n), s++;
    }
    return a;
  }
};
function kw() {
  return (function(e) {
    var t = { R: "13k,1a,2,3,3,2+1j,ch+16,a+1,5+2,2+n,5,a,4,6+16,4+3,h+1b,4mo,179q,2+9,2+11,2i9+7y,2+68,4,3+4,5+13,4+3,2+4k,3+29,8+cf,1t+7z,w+17,3+3m,1t+3z,16o1+5r,8+30,8+mc,29+1r,29+4v,75+73", EN: "1c+9,3d+1,6,187+9,513,4+5,7+9,sf+j,175h+9,qw+q,161f+1d,4xt+a,25i+9", ES: "17,2,6dp+1,f+1,av,16vr,mx+1,4o,2", ET: "z+2,3h+3,b+1,ym,3e+1,2o,p4+1,8,6u,7c,g6,1wc,1n9+4,30+1b,2n,6d,qhx+1,h0m,a+1,49+2,63+1,4+1,6bb+3,12jj", AN: "16o+5,2j+9,2+1,35,ed,1ff2+9,87+u", CS: "18,2+1,b,2u,12k,55v,l,17v0,2,3,53,2+1,b", B: "a,3,f+2,2v,690", S: "9,2,k", WS: "c,k,4f4,1vk+a,u,1j,335", ON: "x+1,4+4,h+5,r+5,r+3,z,5+3,2+1,2+1,5,2+2,3+4,o,w,ci+1,8+d,3+d,6+8,2+g,39+1,9,6+1,2,33,b8,3+1,3c+1,7+1,5r,b,7h+3,sa+5,2,3i+6,jg+3,ur+9,2v,ij+1,9g+9,7+a,8m,4+1,49+x,14u,2+2,c+2,e+2,e+2,e+1,i+n,e+e,2+p,u+2,e+2,36+1,2+3,2+1,b,2+2,6+5,2,2,2,h+1,5+4,6+3,3+f,16+2,5+3l,3+81,1y+p,2+40,q+a,m+13,2r+ch,2+9e,75+hf,3+v,2+2w,6e+5,f+6,75+2a,1a+p,2+2g,d+5x,r+b,6+3,4+o,g,6+1,6+2,2k+1,4,2j,5h+z,1m+1,1e+f,t+2,1f+e,d+3,4o+3,2s+1,w,535+1r,h3l+1i,93+2,2s,b+1,3l+x,2v,4g+3,21+3,kz+1,g5v+1,5a,j+9,n+v,2,3,2+8,2+1,3+2,2,3,46+1,4+4,h+5,r+5,r+a,3h+2,4+6,b+4,78,1r+24,4+c,4,1hb,ey+6,103+j,16j+c,1ux+7,5+g,fsh,jdq+1t,4,57+2e,p1,1m,1m,1m,1m,4kt+1,7j+17,5+2r,d+e,3+e,2+e,2+10,m+4,w,1n+5,1q,4z+5,4b+rb,9+c,4+c,4+37,d+2g,8+b,l+b,5+1j,9+9,7+13,9+t,3+1,27+3c,2+29,2+3q,d+d,3+4,4+2,6+6,a+o,8+6,a+2,e+6,16+42,2+1i", BN: "0+8,6+d,2s+5,2+p,e,4m9,1kt+2,2b+5,5+5,17q9+v,7k,6p+8,6+1,119d+3,440+7,96s+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+75,6p+2rz,1ben+1,1ekf+1,1ekf+1", NSM: "lc+33,7o+6,7c+18,2,2+1,2+1,2,21+a,1d+k,h,2u+6,3+5,3+1,2+3,10,v+q,2k+a,1n+8,a,p+3,2+8,2+2,2+4,18+2,3c+e,2+v,1k,2,5+7,5,4+6,b+1,u,1n,5+3,9,l+1,r,3+1,1m,5+1,5+1,3+2,4,v+1,4,c+1,1m,5+4,2+1,5,l+1,n+5,2,1n,3,2+3,9,8+1,c+1,v,1q,d,1f,4,1m+2,6+2,2+3,8+1,c+1,u,1n,g+1,l+1,t+1,1m+1,5+3,9,l+1,u,21,8+2,2,2j,3+6,d+7,2r,3+8,c+5,23+1,s,2,2,1k+d,2+4,2+1,6+a,2+z,a,2v+3,2+5,2+1,3+1,q+1,5+2,h+3,e,3+1,7,g,jk+2,qb+2,u+2,u+1,v+1,1t+1,2+6,9,3+a,a,1a+2,3c+1,z,3b+2,5+1,a,7+2,64+1,3,1n,2+6,2,2,3+7,7+9,3,1d+g,1s+3,1d,2+4,2,6,15+8,d+1,x+3,3+1,2+2,1l,2+1,4,2+2,1n+7,3+1,49+2,2+c,2+6,5,7,4+1,5j+1l,2+4,k1+w,2db+2,3y,2p+v,ff+3,30+1,n9x+3,2+9,x+1,29+1,7l,4,5,q+1,6,48+1,r+h,e,13+7,q+a,1b+2,1d,3+3,3+1,14,1w+5,3+1,3+1,d,9,1c,1g,2+2,3+1,6+1,2,17+1,9,6n,3,5,fn5,ki+f,h+f,r2,6b,46+4,1af+2,2+1,6+3,15+2,5,4m+1,fy+3,as+1,4a+a,4x,1j+e,1l+2,1e+3,3+1,1y+2,11+4,2+7,1r,d+1,1h+8,b+3,3,2o+2,3,2+1,7,4h,4+7,m+1,1m+1,4,12+6,4+4,5g+7,3+2,2,o,2d+5,2,5+1,2+1,6n+3,7+1,2+1,s+1,2e+7,3,2+1,2z,2,3+5,2,2u+2,3+3,2+4,78+8,2+1,75+1,2,5,41+3,3+1,5,x+5,3+1,15+5,3+3,9,a+5,3+2,1b+c,2+1,bb+6,2+5,2d+l,3+6,2+1,2+1,3f+5,4,2+1,2+6,2,21+1,4,2,9o+1,f0c+4,1o+6,t5,1s+3,2a,f5l+1,43t+2,i+7,3+6,v+3,45+2,1j0+1i,5+1d,9,f,n+4,2+e,11t+6,2+g,3+6,2+1,2+4,7a+6,c6+3,15t+6,32+6,gzhy+6n", AL: "16w,3,2,e+1b,z+2,2+2s,g+1,8+1,b+m,2+t,s+2i,c+e,4h+f,1d+1e,1bwe+dp,3+3z,x+c,2+1,35+3y,2rm+z,5+7,b+5,dt+l,c+u,17nl+27,1t+27,4x+6n,3+d", LRO: "6ct", RLO: "6cu", LRE: "6cq", RLE: "6cr", PDF: "6cs", LRI: "6ee", RLI: "6ef", FSI: "6eg", PDI: "6eh" }, r = {}, i = {};
    r.L = 1, i[1] = "L", Object.keys(t).forEach(function(U, se) {
      r[U] = 1 << se + 1, i[r[U]] = U;
    }), Object.freeze(r);
    var n = r.LRI | r.RLI | r.FSI, a = r.L | r.R | r.AL, s = r.B | r.S | r.WS | r.ON | r.FSI | r.LRI | r.RLI | r.PDI, o = r.BN | r.RLE | r.LRE | r.RLO | r.LRO | r.PDF, l = r.S | r.WS | r.B | n | r.PDI | o, u = null;
    function c() {
      if (!u) {
        u = /* @__PURE__ */ new Map();
        var U = 0;
        for (var se in t) if (t.hasOwnProperty(se)) for (var ie = t[se], k = "", Q = void 0, G = !1, H = 0, X = 0; X <= ie.length + 1; X += 1) {
          var me = ie[X];
          if (me !== "," && X !== ie.length) me === "+" ? (G = !0, H = U = H + parseInt(k, 36), k = "") : k += me;
          else {
            G ? Q = U + parseInt(k, 36) : (H = U = H + parseInt(k, 36), Q = U), G = !1, k = "", H = Q;
            for (var we = U; we < Q + 1; we += 1) u.set(we, r[se]);
          }
        }
      }
    }
    function h(U) {
      return c(), u.get(U.codePointAt(0)) || r.L;
    }
    function p(U) {
      return i[h(U)];
    }
    var f = { pairs: "14>1,1e>2,u>2,2wt>1,1>1,1ge>1,1wp>1,1j>1,f>1,hm>1,1>1,u>1,u6>1,1>1,+5,28>1,w>1,1>1,+3,b8>1,1>1,+3,1>3,-1>-1,3>1,1>1,+2,1s>1,1>1,x>1,th>1,1>1,+2,db>1,1>1,+3,3>1,1>1,+2,14qm>1,1>1,+1,4q>1,1e>2,u>2,2>1,+1", canonical: "6f1>-6dx,6dy>-6dx,6ec>-6ed,6ee>-6ed,6ww>2jj,-2ji>2jj,14r4>-1e7l,1e7m>-1e7l,1e7m>-1e5c,1e5d>-1e5b,1e5c>-14qx,14qy>-14qx,14vn>-1ecg,1ech>-1ecg,1edu>-1ecg,1eci>-1ecg,1eda>-1ecg,1eci>-1ecg,1eci>-168q,168r>-168q,168s>-14ye,14yf>-14ye" };
    function d(U, se) {
      var ie = 0, k = /* @__PURE__ */ new Map(), Q = se && /* @__PURE__ */ new Map(), G;
      return U.split(",").forEach(function H(X) {
        if (X.indexOf("+") !== -1) for (var me = +X; me--; ) H(G);
        else {
          G = X;
          var we = X.split(">"), ne = we[0], Pe = we[1];
          ne = String.fromCodePoint(ie += parseInt(ne, 36)), Pe = String.fromCodePoint(ie += parseInt(Pe, 36)), k.set(ne, Pe), se && Q.set(Pe, ne);
        }
      }), { map: k, reverseMap: Q };
    }
    var y, m, g;
    function v() {
      if (!y) {
        var U = d(f.pairs, !0), se = U.map, ie = U.reverseMap;
        y = se, m = ie, g = d(f.canonical, !1).map;
      }
    }
    function x(U) {
      return v(), y.get(U) || null;
    }
    function b(U) {
      return v(), m.get(U) || null;
    }
    function w(U) {
      return v(), g.get(U) || null;
    }
    var D = r.L, _ = r.R, A = r.EN, E = r.ES, R = r.ET, B = r.AN, L = r.CS, $ = r.B, M = r.S, C = r.ON, N = r.BN, z = r.NSM, O = r.AL, re = r.LRO, oe = r.RLO, ue = r.LRE, be = r.RLE, Ee = r.PDF, Ve = r.LRI, We = r.RLI, mr = r.FSI, Ze = r.PDI;
    function Qt(U, se) {
      for (var ie = 125, k = new Uint32Array(U.length), Q = 0; Q < U.length; Q++) k[Q] = h(U[Q]);
      var G = /* @__PURE__ */ new Map();
      function H(Qe, vt) {
        var et = k[Qe];
        k[Qe] = vt, G.set(et, G.get(et) - 1), et & s && G.set(s, G.get(s) - 1), G.set(vt, (G.get(vt) || 0) + 1), vt & s && G.set(s, (G.get(s) || 0) + 1);
      }
      for (var X = new Uint8Array(U.length), me = /* @__PURE__ */ new Map(), we = [], ne = null, Pe = 0; Pe < U.length; Pe++) ne || we.push(ne = { start: Pe, end: U.length - 1, level: se === "rtl" ? 1 : se === "ltr" ? 0 : zc(Pe, !1) }), k[Pe] & $ && (ne.end = Pe, ne = null);
      for (var ki = be | ue | oe | re | n | Ze | Ee | $, vr = function(Qe) {
        return Qe + (Qe & 1 ? 1 : 2);
      }, rr = function(Qe) {
        return Qe + (Qe & 1 ? 2 : 1);
      }, ir = 0; ir < we.length; ir++) {
        ne = we[ir];
        var ce = [{ _level: ne.level, _override: 0, _isolate: 0 }], _e = void 0, $t = 0, nr = 0, ks = 0;
        G.clear();
        for (var Re = ne.start; Re <= ne.end; Re++) {
          var $e = k[Re];
          if (_e = ce[ce.length - 1], G.set($e, (G.get($e) || 0) + 1), $e & s && G.set(s, (G.get(s) || 0) + 1), $e & ki)
            if ($e & (be | ue)) {
              X[Re] = _e._level;
              var cc = ($e === be ? rr : vr)(_e._level);
              cc <= ie && !$t && !nr ? ce.push({ _level: cc, _override: 0, _isolate: 0 }) : $t || nr++;
            } else if ($e & (oe | re)) {
              X[Re] = _e._level;
              var hc = ($e === oe ? rr : vr)(_e._level);
              hc <= ie && !$t && !nr ? ce.push({ _level: hc, _override: $e & oe ? _ : D, _isolate: 0 }) : $t || nr++;
            } else if ($e & n) {
              $e & mr && ($e = zc(Re + 1, !0) === 1 ? We : Ve), X[Re] = _e._level, _e._override && H(Re, _e._override);
              var pc = ($e === We ? rr : vr)(_e._level);
              pc <= ie && $t === 0 && nr === 0 ? (ks++, ce.push({ _level: pc, _override: 0, _isolate: 1, _isolInitIndex: Re })) : $t++;
            } else if ($e & Ze) {
              if ($t > 0) $t--;
              else if (ks > 0) {
                for (nr = 0; !ce[ce.length - 1]._isolate; ) ce.pop();
                var Fs = ce[ce.length - 1]._isolInitIndex;
                Fs != null && (me.set(Fs, Re), me.set(Re, Fs)), ce.pop(), ks--;
              }
              _e = ce[ce.length - 1], X[Re] = _e._level, _e._override && H(Re, _e._override);
            } else $e & Ee ? ($t === 0 && (nr > 0 ? nr-- : !_e._isolate && ce.length > 1 && (ce.pop(), _e = ce[ce.length - 1])), X[Re] = _e._level) : $e & $ && (X[Re] = ne.level);
          else X[Re] = _e._level, _e._override && $e !== N && H(Re, _e._override);
        }
        for (var Ur = [], Tt = null, br = ne.start; br <= ne.end; br++) {
          var Ms = k[br];
          if (!(Ms & o)) {
            var fc = X[br], dc = Ms & n, dm = Ms === Ze;
            Tt && fc === Tt._level ? (Tt._end = br, Tt._endsWithIsolInit = dc) : Ur.push(Tt = { _start: br, _end: br, _level: fc, _startsWithPDI: dm, _endsWithIsolInit: dc });
          }
        }
        for (var Ps = [], Xn = 0; Xn < Ur.length; Xn++) {
          var Yn = Ur[Xn];
          if (!Yn._startsWithPDI || Yn._startsWithPDI && !me.has(Yn._start)) {
            for (var Bs = [Tt = Yn], yc = void 0; Tt && Tt._endsWithIsolInit && (yc = me.get(Tt._end)) != null; ) for (var Wn = Xn + 1; Wn < Ur.length; Wn++) if (Ur[Wn]._start === yc) {
              Bs.push(Tt = Ur[Wn]);
              break;
            }
            for (var jr = [], Ls = 0; Ls < Bs.length; Ls++) for (var mc = Bs[Ls], zs = mc._start; zs <= mc._end; zs++) jr.push(zs);
            for (var ym = X[jr[0]], gc = ne.level, Zn = jr[0] - 1; Zn >= 0; Zn--) if (!(k[Zn] & o)) {
              gc = X[Zn];
              break;
            }
            var Vs = jr[jr.length - 1], mm = X[Vs], xc = ne.level;
            if (!(k[Vs] & n)) {
              for (var Hn = Vs + 1; Hn <= ne.end; Hn++) if (!(k[Hn] & o)) {
                xc = X[Hn];
                break;
              }
            }
            Ps.push({ _seqIndices: jr, _sosType: Math.max(gc, ym) % 2 ? _ : D, _eosType: Math.max(xc, mm) % 2 ? _ : D });
          }
        }
        for (var Os = 0; Os < Ps.length; Os++) {
          var Rs = Ps[Os], q = Rs._seqIndices, Fi = Rs._sosType, gm = Rs._eosType, qr = X[q[0]] & 1 ? _ : D;
          if (G.get(z)) for (var Kn = 0; Kn < q.length; Kn++) {
            var vc = q[Kn];
            if (k[vc] & z) {
              for (var $s = Fi, Jn = Kn - 1; Jn >= 0; Jn--) if (!(k[q[Jn]] & o)) {
                $s = k[q[Jn]];
                break;
              }
              H(vc, $s & (n | Ze) ? C : $s);
            }
          }
          if (G.get(A)) for (var Qn = 0; Qn < q.length; Qn++) {
            var bc = q[Qn];
            if (k[bc] & A) for (var ea = Qn - 1; ea >= -1; ea--) {
              var wc = ea === -1 ? Fi : k[q[ea]];
              if (wc & a) {
                wc === O && H(bc, B);
                break;
              }
            }
          }
          if (G.get(O)) for (var Ns = 0; Ns < q.length; Ns++) {
            var _c = q[Ns];
            k[_c] & O && H(_c, _);
          }
          if (G.get(E) || G.get(L)) for (var Mi = 1; Mi < q.length - 1; Mi++) {
            var Us = q[Mi];
            if (k[Us] & (E | L)) {
              for (var Gr = 0, js = 0, qs = Mi - 1; qs >= 0 && (Gr = k[q[qs]], Gr & o); qs--) ;
              for (var Gs = Mi + 1; Gs < q.length && (js = k[q[Gs]], js & o); Gs++) ;
              Gr === js && (k[Us] === E ? Gr === A : Gr & (A | B)) && H(Us, Gr);
            }
          }
          if (G.get(A)) {
            for (var It = 0; It < q.length; It++) if (k[q[It]] & A) {
              for (var ta = It - 1; ta >= 0 && k[q[ta]] & (R | o); ta--) H(q[ta], A);
              for (It++; It < q.length && k[q[It]] & (R | o | A); It++) k[q[It]] !== A && H(q[It], A);
            }
          }
          if (G.get(R) || G.get(E) || G.get(L)) for (var Pi = 0; Pi < q.length; Pi++) {
            var Dc = q[Pi];
            if (k[Dc] & (R | E | L)) {
              H(Dc, C);
              for (var ra = Pi - 1; ra >= 0 && k[q[ra]] & o; ra--) H(q[ra], C);
              for (var ia = Pi + 1; ia < q.length && k[q[ia]] & o; ia++) H(q[ia], C);
            }
          }
          if (G.get(A)) for (var Xs = 0, Sc = Fi; Xs < q.length; Xs++) {
            var Ac = q[Xs], Ys = k[Ac];
            Ys & A ? Sc === D && H(Ac, D) : Ys & a && (Sc = Ys);
          }
          if (G.get(s)) {
            for (var Bi = _ | A | B, Ec = Bi | D, na = [], Xr = [], Yr = 0; Yr < q.length; Yr++) if (k[q[Yr]] & s) {
              var Li = U[q[Yr]], Tc = void 0;
              if (x(Li) !== null)
                if (Xr.length < 63) Xr.push({ char: Li, seqIndex: Yr });
                else break;
              else if ((Tc = b(Li)) !== null) for (var zi = Xr.length - 1; zi >= 0; zi--) {
                var Ws = Xr[zi].char;
                if (Ws === Tc || Ws === b(w(Li)) || x(w(Ws)) === Li) {
                  na.push([Xr[zi].seqIndex, Yr]), Xr.length = zi;
                  break;
                }
              }
            }
            na.sort(function(Qe, vt) {
              return Qe[0] - vt[0];
            });
            for (var Zs = 0; Zs < na.length; Zs++) {
              for (var Ic = na[Zs], aa = Ic[0], Hs = Ic[1], Cc = !1, Ct = 0, Ks = aa + 1; Ks < Hs; Ks++) {
                var kc = q[Ks];
                if (k[kc] & Ec) {
                  Cc = !0;
                  var Fc = k[kc] & Bi ? _ : D;
                  if (Fc === qr) {
                    Ct = Fc;
                    break;
                  }
                }
              }
              if (Cc && !Ct) {
                Ct = Fi;
                for (var Js = aa - 1; Js >= 0; Js--) {
                  var Mc = q[Js];
                  if (k[Mc] & Ec) {
                    var Pc = k[Mc] & Bi ? _ : D;
                    Ct = Pc === qr ? qr : Pc;
                    break;
                  }
                }
              }
              if (Ct) {
                if (k[q[aa]] = k[q[Hs]] = Ct, Ct !== qr) {
                  for (var Vi = aa + 1; Vi < q.length; Vi++) if (!(k[q[Vi]] & o)) {
                    h(U[q[Vi]]) & z && (k[q[Vi]] = Ct);
                    break;
                  }
                }
                if (Ct !== qr) {
                  for (var Oi = Hs + 1; Oi < q.length; Oi++) if (!(k[q[Oi]] & o)) {
                    h(U[q[Oi]]) & z && (k[q[Oi]] = Ct);
                    break;
                  }
                }
              }
            }
            for (var ar = 0; ar < q.length; ar++) if (k[q[ar]] & s) {
              for (var Bc = ar, Qs = ar, eo = Fi, Ri = ar - 1; Ri >= 0; Ri--) if (k[q[Ri]] & o) Bc = Ri;
              else {
                eo = k[q[Ri]] & Bi ? _ : D;
                break;
              }
              for (var Lc = gm, $i = ar + 1; $i < q.length; $i++) if (k[q[$i]] & (s | o)) Qs = $i;
              else {
                Lc = k[q[$i]] & Bi ? _ : D;
                break;
              }
              for (var to = Bc; to <= Qs; to++) k[q[to]] = eo === Lc ? eo : qr;
              ar = Qs;
            }
          }
        }
        for (var nt = ne.start; nt <= ne.end; nt++) {
          var xm = X[nt], sa = k[nt];
          if (xm & 1 ? sa & (D | A | B) && X[nt]++ : sa & _ ? X[nt]++ : sa & (B | A) && (X[nt] += 2), sa & o && (X[nt] = nt === 0 ? ne.level : X[nt - 1]), nt === ne.end || h(U[nt]) & (M | $)) for (var oa = nt; oa >= 0 && h(U[oa]) & l; oa--) X[oa] = ne.level;
        }
      }
      return { levels: X, paragraphs: we };
      function zc(Qe, vt) {
        for (var et = Qe; et < U.length; et++) {
          var sr = k[et];
          if (sr & (_ | O)) return 1;
          if (sr & ($ | D) || vt && sr === Ze) return 0;
          if (sr & n) {
            var Vc = vm(et);
            et = Vc === -1 ? U.length : Vc;
          }
        }
        return 0;
      }
      function vm(Qe) {
        for (var vt = 1, et = Qe + 1; et < U.length; et++) {
          var sr = k[et];
          if (sr & $) break;
          if (sr & Ze) {
            if (--vt === 0) return et;
          } else sr & n && vt++;
        }
        return -1;
      }
    }
    var er = "14>1,j>2,t>2,u>2,1a>g,2v3>1,1>1,1ge>1,1wd>1,b>1,1j>1,f>1,ai>3,-2>3,+1,8>1k0,-1jq>1y7,-1y6>1hf,-1he>1h6,-1h5>1ha,-1h8>1qi,-1pu>1,6>3u,-3s>7,6>1,1>1,f>1,1>1,+2,3>1,1>1,+13,4>1,1>1,6>1eo,-1ee>1,3>1mg,-1me>1mk,-1mj>1mi,-1mg>1mi,-1md>1,1>1,+2,1>10k,-103>1,1>1,4>1,5>1,1>1,+10,3>1,1>8,-7>8,+1,-6>7,+1,a>1,1>1,u>1,u6>1,1>1,+5,26>1,1>1,2>1,2>2,8>1,7>1,4>1,1>1,+5,b8>1,1>1,+3,1>3,-2>1,2>1,1>1,+2,c>1,3>1,1>1,+2,h>1,3>1,a>1,1>1,2>1,3>1,1>1,d>1,f>1,3>1,1a>1,1>1,6>1,7>1,13>1,k>1,1>1,+19,4>1,1>1,+2,2>1,1>1,+18,m>1,a>1,1>1,lk>1,1>1,4>1,2>1,f>1,3>1,1>1,+3,db>1,1>1,+3,3>1,1>1,+2,14qm>1,1>1,+1,6>1,4j>1,j>2,t>2,u>2,2>1,+1", tr;
    function Et() {
      if (!tr) {
        var U = d(er, !0), se = U.map;
        U.reverseMap.forEach(function(ie, k) {
          se.set(k, ie);
        }), tr = se;
      }
    }
    function gr(U) {
      return Et(), tr.get(U) || null;
    }
    function Ci(U, se, ie, k) {
      var Q = U.length;
      ie = Math.max(0, ie == null ? 0 : +ie), k = Math.min(Q - 1, k == null ? Q - 1 : +k);
      for (var G = /* @__PURE__ */ new Map(), H = ie; H <= k; H++) if (se[H] & 1) {
        var X = gr(U[H]);
        X !== null && G.set(H, X);
      }
      return G;
    }
    function Oe(U, se, ie, k) {
      var Q = U.length;
      ie = Math.max(0, ie == null ? 0 : +ie), k = Math.min(Q - 1, k == null ? Q - 1 : +k);
      var G = [];
      return se.paragraphs.forEach(function(H) {
        var X = Math.max(ie, H.start), me = Math.min(k, H.end);
        if (X < me) {
          for (var we = se.levels.slice(X, me + 1), ne = me; ne >= X && h(U[ne]) & l; ne--) we[ne] = H.level;
          for (var Pe = H.level, ki = 1 / 0, vr = 0; vr < we.length; vr++) {
            var rr = we[vr];
            rr > Pe && (Pe = rr), rr < ki && (ki = rr | 1);
          }
          for (var ir = Pe; ir >= ki; ir--) for (var ce = 0; ce < we.length; ce++) if (we[ce] >= ir) {
            for (var _e = ce; ce + 1 < we.length && we[ce + 1] >= ir; ) ce++;
            ce > _e && G.push([_e + X, ce + X]);
          }
        }
      }), G;
    }
    function Rt(U, se, ie, k) {
      var Q = xr(U, se, ie, k), G = [].concat(U);
      return Q.forEach(function(H, X) {
        G[X] = (se.levels[H] & 1 ? gr(U[H]) : null) || U[H];
      }), G.join("");
    }
    function xr(U, se, ie, k) {
      for (var Q = Oe(U, se, ie, k), G = [], H = 0; H < U.length; H++) G[H] = H;
      return Q.forEach(function(X) {
        for (var me = X[0], we = X[1], ne = G.slice(me, we + 1), Pe = ne.length; Pe--; ) G[we - Pe] = ne[Pe];
      }), G;
    }
    return e.closingToOpeningBracket = b, e.getBidiCharType = h, e.getBidiCharTypeName = p, e.getCanonicalBracket = w, e.getEmbeddingLevels = Qt, e.getMirroredCharacter = gr, e.getMirroredCharactersMap = Ci, e.getReorderSegments = Oe, e.getReorderedIndices = xr, e.getReorderedString = Rt, e.openingToClosingBracket = x, Object.defineProperty(e, "__esModule", { value: !0 }), e;
  })({});
}
const Yu = kw(), Fw = /[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/, Mw = /* @__PURE__ */ new Set(["WS", "FSI", "LRI", "RLI", "PDI"]), Pw = /* @__PURE__ */ new Set(["S", "B"]);
function Bw(e, t, r, i) {
  let n = [], a = r;
  for (let s of Ll(e.slice(r, i))) n.push({ index: a, text: s, level: t[a] }), a += s.length;
  return n;
}
function Lw(e, t) {
  let r = !0;
  for (let i = e.length - 1; i >= 0; i--) {
    let n = Yu.getBidiCharTypeName(e[i].text[0]);
    Pw.has(n) ? (e[i].level = t, r = !0) : r && Mw.has(n) ? e[i].level = t : r = !1;
  }
}
function zw(e, t) {
  let r = t, i = 1 / 0;
  for (let { level: a } of e) a > r && (r = a), (a | 1) < i && (i = a | 1);
  let n = e.slice();
  for (let a = r; a >= i; a--) for (let s = 0; s < n.length; s++) {
    if (n[s].level < a) continue;
    let o = s;
    for (; o + 1 < n.length && n[o + 1].level >= a; ) o++;
    for (let l = s, u = o; l < u; l++, u--) [n[l], n[u]] = [n[u], n[l]];
    s = o;
  }
  return n;
}
function Vw(e) {
  return e.level % 2 == 0 ? e.text : Yu.getMirroredCharacter(e.text) ?? e.text;
}
function Ow(e, t) {
  var r;
  return ((r = e.find((i) => t >= i.start && t <= i.end)) == null ? void 0 : r.level) ?? 0;
}
function Rw(e, t, r, i, n) {
  let a = Bw(e, t, i, n);
  Lw(a, r);
  let s = "", o = [];
  for (let l of zw(a, r)) {
    if (Fw.test(l.text)) continue;
    let u = Vw(l);
    s += u, o.push(...Array(u.length).fill(l.index));
  }
  return { text: s, sourceIndices: o };
}
function $w(e, t) {
  let r = t.filter((a) => a > 0 && a < e.length), i = [.../* @__PURE__ */ new Set([0, ...r, e.length])].sort((a, s) => a - s), n = [];
  for (let a = 0; a + 1 < i.length; a++) n.push([i[a], i[a + 1]]);
  return n;
}
function a1(e, t) {
  let { levels: r, paragraphs: i } = Yu.getEmbeddingLevels(e);
  return $w(e, t.concat(i.map((n) => n.start))).map(([n, a]) => Rw(e, r, Ow(i, n), n, a));
}
function Nw(e, t) {
  return a1(e, t).map((r) => r.text);
}
function Uw(e, t, r) {
  return a1(e, r).map((i) => [i.text, i.sourceIndices.map((n) => t[n] ?? 0)]);
}
const Rl = 4294967296, bp = 1 / Rl, wp = typeof TextDecoder > "u" ? null : new TextDecoder("utf-8");
var s1 = class {
  constructor(e) {
    this.buf = ArrayBuffer.isView(e) ? e : new Uint8Array(e), this.dataView = new DataView(this.buf.buffer, this.buf.byteOffset, this.buf.byteLength), this.pos = 0, this.type = 0, this._valueStart = -1, this.length = this.buf.length;
  }
  readFields(e, t, r = this.length) {
    let i;
    for (; i = this.nextField(r); ) e(i, t, this);
    return t;
  }
  readMessage(e, t) {
    return this.readFields(e, t, this.readVarint() + this.pos);
  }
  readFixed32() {
    let e = this.dataView.getUint32(this.pos, !0);
    return this.pos += 4, e;
  }
  readSFixed32() {
    let e = this.dataView.getInt32(this.pos, !0);
    return this.pos += 4, e;
  }
  readFixed64() {
    let e = this.dataView.getUint32(this.pos, !0) + this.dataView.getUint32(this.pos + 4, !0) * Rl;
    return this.pos += 8, e;
  }
  readSFixed64() {
    let e = this.dataView.getUint32(this.pos, !0) + this.dataView.getInt32(this.pos + 4, !0) * Rl;
    return this.pos += 8, e;
  }
  readFloat() {
    let e = this.dataView.getFloat32(this.pos, !0);
    return this.pos += 4, e;
  }
  readDouble() {
    let e = this.dataView.getFloat64(this.pos, !0);
    return this.pos += 8, e;
  }
  readVarint(e) {
    let t = this.buf, r = t[this.pos++];
    if (r < 128) return r;
    let i = r & 127, n;
    return n = t[this.pos++], i |= (n & 127) << 7, n < 128 || (n = t[this.pos++], i |= (n & 127) << 14, n < 128) || (n = t[this.pos++], i |= (n & 127) << 21, n < 128) ? i : (n = t[this.pos], i |= (n & 15) << 28, qw(i, e, this));
  }
  readSVarint() {
    let e = this.readVarint();
    return e % 2 == 1 ? (e + 1) / -2 : e / 2;
  }
  readBoolean() {
    return !!this.readVarint();
  }
  readString() {
    let e = this.readVarint() + this.pos, t = this.pos;
    return this.pos = e, e - t >= 12 && wp ? wp.decode(this.buf.subarray(t, e)) : n3(this.buf, t, e);
  }
  readBytes() {
    let e = this.readVarint() + this.pos, t = this.buf.subarray(this.pos, e);
    return this.pos = e, t;
  }
  readPackedVarint(e = [], t) {
    let r = this.readPackedEnd();
    for (; this.pos < r; ) e.push(this.readVarint(t));
    return e;
  }
  readPackedSVarint(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readSVarint());
    return e;
  }
  readPackedBoolean(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readBoolean());
    return e;
  }
  readPackedFloat(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readFloat());
    return e;
  }
  readPackedDouble(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readDouble());
    return e;
  }
  readPackedFixed32(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readFixed32());
    return e;
  }
  readPackedSFixed32(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readSFixed32());
    return e;
  }
  readPackedFixed64(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readFixed64());
    return e;
  }
  readPackedSFixed64(e = []) {
    let t = this.readPackedEnd();
    for (; this.pos < t; ) e.push(this.readSFixed64());
    return e;
  }
  readPackedEnd() {
    return this.type === 2 ? this.readVarint() + this.pos : this.pos + 1;
  }
  nextField(e = this.length) {
    if (this.pos === this._valueStart && this.skip(this.type), this.pos >= e) return 0;
    let t = this.readVarint();
    return this.type = t & 7, this._valueStart = this.pos, t >>> 3;
  }
  skip(e) {
    let t = e & 7;
    if (t === 0) for (; this.buf[this.pos++] > 127; ) ;
    else if (t === 2) this.pos = this.readVarint() + this.pos;
    else if (t === 5) this.pos += 4;
    else if (t === 1) this.pos += 8;
    else throw Error(`Unimplemented type: ${t}`);
  }
}, jw = class {
  constructor(e = /* @__PURE__ */ new Uint8Array(16)) {
    this.buf = ArrayBuffer.isView(e) ? e : new Uint8Array(e), this.dataView = new DataView(this.buf.buffer, this.buf.byteOffset, this.buf.byteLength), this.pos = 0, this.length = this.buf.length;
  }
  writeTag(e, t) {
    this.writeVarint(e << 3 | t);
  }
  realloc(e) {
    let t = this.length || 16;
    for (; t < this.pos + e; ) t *= 2;
    if (t !== this.length) {
      let r = new Uint8Array(t);
      r.set(this.buf), this.buf = r, this.dataView = new DataView(r.buffer), this.length = t;
    }
  }
  finish() {
    return this.length = this.pos, this.pos = 0, this.buf.subarray(0, this.length);
  }
  writeFixed32(e) {
    this.realloc(4), this.dataView.setInt32(this.pos, e, !0), this.pos += 4;
  }
  writeSFixed32(e) {
    this.realloc(4), this.dataView.setInt32(this.pos, e, !0), this.pos += 4;
  }
  writeFixed64(e) {
    this.realloc(8), this.dataView.setInt32(this.pos, e & -1, !0), this.dataView.setInt32(this.pos + 4, Math.floor(e * bp), !0), this.pos += 8;
  }
  writeSFixed64(e) {
    this.realloc(8), this.dataView.setInt32(this.pos, e & -1, !0), this.dataView.setInt32(this.pos + 4, Math.floor(e * bp), !0), this.pos += 8;
  }
  writeVarint(e) {
    e = +e || 0, e >= 0 && e < 128 ? (this.pos >= this.length && this.realloc(1), this.buf[this.pos++] = e) : e > 268435455 || e < 0 ? Xw(e, this) : (this.realloc(4), this.buf[this.pos++] = e & 127 | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = (e >>>= 7) & 127 | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = (e >>>= 7) & 127 | (e > 127 ? 128 : 0), e <= 127 || (this.buf[this.pos++] = e >>> 7 & 127))));
  }
  writeSVarint(e) {
    this.writeVarint(e < 0 ? -e * 2 - 1 : e * 2);
  }
  writeBoolean(e) {
    this.writeVarint(+e);
  }
  writeString(e) {
    e = String(e), this.realloc(e.length * 4), this.pos++;
    let t = this.pos;
    this.pos = a3(this.buf, e, this.pos);
    let r = this.pos - t;
    r >= 128 && _p(t, r, this), this.pos = t - 1, this.writeVarint(r), this.pos += r;
  }
  writeFloat(e) {
    this.realloc(4), this.dataView.setFloat32(this.pos, e, !0), this.pos += 4;
  }
  writeDouble(e) {
    this.realloc(8), this.dataView.setFloat64(this.pos, e, !0), this.pos += 8;
  }
  writeBytes(e) {
    let t = e.length;
    this.writeVarint(t), this.realloc(t), this.buf.set(e, this.pos), this.pos += t;
  }
  writeRawMessage(e, t) {
    this.pos++;
    let r = this.pos;
    e(t, this);
    let i = this.pos - r;
    i >= 128 && _p(r, i, this), this.pos = r - 1, this.writeVarint(i), this.pos += i;
  }
  writeMessage(e, t, r) {
    this.writeTag(e, 2), this.writeRawMessage(t, r);
  }
  writePackedVarint(e, t) {
    t.length && this.writeMessage(e, Zw, t);
  }
  writePackedSVarint(e, t) {
    t.length && this.writeMessage(e, Hw, t);
  }
  writePackedBoolean(e, t) {
    t.length && this.writeMessage(e, Qw, t);
  }
  writePackedFloat(e, t) {
    t.length && this.writeMessage(e, Kw, t);
  }
  writePackedDouble(e, t) {
    t.length && this.writeMessage(e, Jw, t);
  }
  writePackedFixed32(e, t) {
    t.length && this.writeMessage(e, e3, t);
  }
  writePackedSFixed32(e, t) {
    t.length && this.writeMessage(e, t3, t);
  }
  writePackedFixed64(e, t) {
    t.length && this.writeMessage(e, r3, t);
  }
  writePackedSFixed64(e, t) {
    t.length && this.writeMessage(e, i3, t);
  }
  writeBytesField(e, t) {
    this.writeTag(e, 2), this.writeBytes(t);
  }
  writeFixed32Field(e, t) {
    this.writeTag(e, 5), this.writeFixed32(t);
  }
  writeSFixed32Field(e, t) {
    this.writeTag(e, 5), this.writeSFixed32(t);
  }
  writeFixed64Field(e, t) {
    this.writeTag(e, 1), this.writeFixed64(t);
  }
  writeSFixed64Field(e, t) {
    this.writeTag(e, 1), this.writeSFixed64(t);
  }
  writeVarintField(e, t) {
    this.writeTag(e, 0), this.writeVarint(t);
  }
  writeSVarintField(e, t) {
    this.writeTag(e, 0), this.writeSVarint(t);
  }
  writeStringField(e, t) {
    this.writeTag(e, 2), this.writeString(t);
  }
  writeFloatField(e, t) {
    this.writeTag(e, 5), this.writeFloat(t);
  }
  writeDoubleField(e, t) {
    this.writeTag(e, 1), this.writeDouble(t);
  }
  writeBooleanField(e, t) {
    this.writeVarintField(e, +t);
  }
};
function qw(e, t, r) {
  let i = r.buf, n, a;
  if (a = i[r.pos++], n = (a & 112) >> 4, a < 128 || (a = i[r.pos++], n |= (a & 127) << 3, a < 128) || (a = i[r.pos++], n |= (a & 127) << 10, a < 128) || (a = i[r.pos++], n |= (a & 127) << 17, a < 128) || (a = i[r.pos++], n |= (a & 127) << 24, a < 128) || (a = i[r.pos++], n |= (a & 1) << 31, a < 128)) return Gw(e, n, t);
  throw Error("Expected varint not more than 10 bytes");
}
function Gw(e, t, r) {
  return r ? t * 4294967296 + (e >>> 0) : (t >>> 0) * 4294967296 + (e >>> 0);
}
function Xw(e, t) {
  let r, i;
  if (e >= 0 ? (r = e % 4294967296 | 0, i = e / 4294967296 | 0) : (r = ~(-e % 4294967296), i = ~(-e / 4294967296), r ^ 4294967295 ? r = r + 1 | 0 : (r = 0, i = i + 1 | 0)), e >= 18446744073709552e3 || e < -18446744073709552e3) throw Error("Given varint doesn't fit into 10 bytes");
  t.realloc(10), Yw(r, i, t), Ww(i, t);
}
function Yw(e, t, r) {
  r.buf[r.pos++] = e & 127 | 128, e >>>= 7, r.buf[r.pos++] = e & 127 | 128, e >>>= 7, r.buf[r.pos++] = e & 127 | 128, e >>>= 7, r.buf[r.pos++] = e & 127 | 128, e >>>= 7, r.buf[r.pos] = e & 127;
}
function Ww(e, t) {
  let r = (e & 7) << 4;
  t.buf[t.pos++] |= r | ((e >>>= 3) ? 128 : 0), e && (t.buf[t.pos++] = e & 127 | ((e >>>= 7) ? 128 : 0), e && (t.buf[t.pos++] = e & 127 | ((e >>>= 7) ? 128 : 0), e && (t.buf[t.pos++] = e & 127 | ((e >>>= 7) ? 128 : 0), e && (t.buf[t.pos++] = e & 127 | ((e >>>= 7) ? 128 : 0), e && (t.buf[t.pos++] = e & 127)))));
}
function _p(e, t, r) {
  let i = t <= 16383 ? 1 : t <= 2097151 ? 2 : t <= 268435455 ? 3 : Math.floor(Math.log(t) / (Math.LN2 * 7));
  r.realloc(i), r.buf.copyWithin(e + i, e, r.pos);
}
function Zw(e, t) {
  let r = e.length, i = t.buf, n = t.pos, a = t.length;
  for (let s = 0; s < r; s++) {
    let o = e[s];
    if (o < 0 || n + 10 > a) t.pos = n, t.writeVarint(o), i = t.buf, n = t.pos, a = t.length;
    else {
      for (; o > 127; ) i[n++] = o % 128 | 128, o = Math.floor(o / 128);
      i[n++] = o;
    }
  }
  t.pos = n;
}
function Hw(e, t) {
  for (let r = 0; r < e.length; r++) t.writeSVarint(e[r]);
}
function Kw(e, t) {
  for (let r = 0; r < e.length; r++) t.writeFloat(e[r]);
}
function Jw(e, t) {
  for (let r = 0; r < e.length; r++) t.writeDouble(e[r]);
}
function Qw(e, t) {
  for (let r = 0; r < e.length; r++) t.writeBoolean(e[r]);
}
function e3(e, t) {
  for (let r = 0; r < e.length; r++) t.writeFixed32(e[r]);
}
function t3(e, t) {
  for (let r = 0; r < e.length; r++) t.writeSFixed32(e[r]);
}
function r3(e, t) {
  for (let r = 0; r < e.length; r++) t.writeFixed64(e[r]);
}
function i3(e, t) {
  for (let r = 0; r < e.length; r++) t.writeSFixed64(e[r]);
}
function n3(e, t, r) {
  let i = "", n = t;
  for (; n < r; ) {
    let a = e[n], s = null, o = a > 239 ? 4 : a > 223 ? 3 : a > 191 ? 2 : 1;
    if (n + o > r) break;
    let l, u, c;
    o === 1 ? a < 128 && (s = a) : o === 2 ? (l = e[n + 1], (l & 192) == 128 && (s = (a & 31) << 6 | l & 63, s <= 127 && (s = null))) : o === 3 ? (l = e[n + 1], u = e[n + 2], (l & 192) == 128 && (u & 192) == 128 && (s = (a & 15) << 12 | (l & 63) << 6 | u & 63, (s <= 2047 || s >= 55296 && s <= 57343) && (s = null))) : o === 4 && (l = e[n + 1], u = e[n + 2], c = e[n + 3], (l & 192) == 128 && (u & 192) == 128 && (c & 192) == 128 && (s = (a & 15) << 18 | (l & 63) << 12 | (u & 63) << 6 | c & 63, (s <= 65535 || s >= 1114112) && (s = null))), s === null ? (s = 65533, o = 1) : s > 65535 && (s -= 65536, i += String.fromCharCode(s >>> 10 & 1023 | 55296), s = 56320 | s & 1023), i += String.fromCharCode(s), n += o;
  }
  return i;
}
function a3(e, t, r) {
  for (let i = 0, n, a; i < t.length; i++) {
    if (n = t.charCodeAt(i), n > 55295 && n < 57344)
      if (a) {
        if (n < 56320) {
          e[r++] = 239, e[r++] = 191, e[r++] = 189, a = n;
          continue;
        }
        n = a - 55296 << 10 | n - 56320 | 65536, a = null;
      } else {
        n > 56319 || i + 1 === t.length ? (e[r++] = 239, e[r++] = 191, e[r++] = 189) : a = n;
        continue;
      }
    else a && (a = (e[r++] = 239, e[r++] = 191, e[r++] = 189, null));
    n < 128 ? e[r++] = n : (n < 2048 ? e[r++] = n >> 6 | 192 : (n < 65536 ? e[r++] = n >> 12 | 224 : (e[r++] = n >> 18 | 240, e[r++] = n >> 12 & 63 | 128), e[r++] = n >> 6 & 63 | 128), e[r++] = n & 63 | 128);
  }
  return r;
}
function s3(e) {
  return typeof (e == null ? void 0 : e.renderWithWebGL) == "function";
}
function o1(e) {
  let t = 0, r = 0;
  for (let s of e) t += s.w * s.h, r = Math.max(r, s.w);
  e.sort((s, o) => o.h - s.h);
  let i = [{ x: 0, y: 0, w: Math.max(Math.ceil(Math.sqrt(t / 0.95)), r), h: 1 / 0 }], n = 0, a = 0;
  for (let s of e) for (let o = i.length - 1; o >= 0; o--) {
    let l = i[o];
    if (!(s.w > l.w || s.h > l.h)) {
      if (s.x = l.x, s.y = l.y, a = Math.max(a, s.y + s.h), n = Math.max(n, s.x + s.w), s.w === l.w && s.h === l.h) {
        let u = i.pop();
        u && o < i.length && (i[o] = u);
      } else s.h === l.h ? (l.x += s.w, l.w -= s.w) : s.w === l.w ? (l.y += s.h, l.h -= s.h) : (i.push({ x: l.x + s.w, y: l.y, w: l.w - s.w, h: s.h }), l.y += s.h, l.h -= s.h);
      break;
    }
  }
  return { w: n, h: a, fill: t / (n * a) || 0 };
}
var l1 = class {
  constructor(e, { pixelRatio: t, version: r, isWebGLImage: i = !1, stretchX: n, stretchY: a, content: s, textFitWidth: o, textFitHeight: l }) {
    this.paddedRect = e, this.pixelRatio = t, this.stretchX = n, this.stretchY = a, this.content = s, this.version = r, this.needsFirstWebGLRender = i, this.textFitWidth = o, this.textFitHeight = l;
  }
  get tl() {
    return [this.paddedRect.x + 1, this.paddedRect.y + 1];
  }
  get br() {
    return [this.paddedRect.x + this.paddedRect.w - 1, this.paddedRect.y + this.paddedRect.h - 1];
  }
  get tlbr() {
    return this.tl.concat(this.br);
  }
  get displaySize() {
    return [(this.paddedRect.w - 2) / this.pixelRatio, (this.paddedRect.h - 2) / this.pixelRatio];
  }
}, u1 = class {
  constructor(e, t) {
    let r = {}, i = {};
    this.haveRenderCallbacks = [], this.patchedUpdateVersion = -1;
    let n = [];
    this.addImages(e, r, n), this.addImages(t, i, n);
    let { w: a, h: s } = o1(n), o = new ot({ width: a || 1, height: s || 1 });
    for (let l in e) {
      let u = e[l];
      if (u.isWebGLImage) continue;
      let c = r[l].paddedRect;
      ot.copy(u.data, o, { x: 0, y: 0 }, { x: c.x + 1, y: c.y + 1 }, u.data);
    }
    for (let l in t) {
      let u = t[l], c = i[l].paddedRect, h = c.x + 1, p = c.y + 1, f = u.data.width, d = u.data.height;
      ot.copy(u.data, o, { x: 0, y: 0 }, { x: h, y: p }, u.data), ot.copy(u.data, o, { x: 0, y: d - 1 }, { x: h, y: p - 1 }, { width: f, height: 1 }), ot.copy(u.data, o, { x: 0, y: 0 }, { x: h, y: p + d }, { width: f, height: 1 }), ot.copy(u.data, o, { x: f - 1, y: 0 }, { x: h - 1, y: p }, { width: 1, height: d }), ot.copy(u.data, o, { x: 0, y: 0 }, { x: h + f, y: p }, { width: 1, height: d });
    }
    this.image = o, this.iconPositions = r, this.patternPositions = i;
  }
  addImages(e, t, r) {
    for (let i in e) {
      let n = e[i], a = { x: 0, y: 0, w: n.data.width + 2, h: n.data.height + 2 };
      r.push(a), t[i] = new l1(a, n), n.hasRenderCallback && this.haveRenderCallbacks.push(i);
    }
  }
  patchUpdatedImages(e, t) {
    if (e.dispatchRenderCallbacks(this.haveRenderCallbacks), this.patchedUpdateVersion !== e.updateVersion) {
      this.patchedUpdateVersion = e.updateVersion;
      for (let r in this.iconPositions) this.patchUpdatedImage(this.iconPositions[r], e.getImage(r), t);
      for (let r in this.patternPositions) this.patchUpdatedImage(this.patternPositions[r], e.getImage(r), t);
    }
  }
  patchUpdatedImage(e, t, r) {
    var l;
    if (!e || !t || !e.needsFirstWebGLRender && e.version === t.version) return;
    e.needsFirstWebGLRender = !1, e.version = t.version;
    let [i, n] = e.tl, a = (l = t.userImage) == null ? void 0 : l.data;
    if (!s3(a)) {
      r.update(t.data, void 0, { x: i, y: n });
      return;
    }
    let { width: s, height: o } = t.data;
    r.context.setCustomLayerDefaults(), a.renderWithWebGL({ gl: r.context.gl, texture: r.texture, x: i, y: n, width: s, height: o }), r.context.setDirty();
  }
};
P("ImagePosition", l1), P("ImageAtlas", u1);
var c1 = /* @__PURE__ */ (function(e) {
  return e[e.none = 0] = "none", e[e.horizontal = 1] = "horizontal", e[e.vertical = 2] = "vertical", e[e.horizontalOnly = 3] = "horizontalOnly", e;
})(c1 || {});
function o3(e) {
  for (let t of e) if (t.positionedGlyphs.length !== 0) return !1;
  return !0;
}
function l3(e, t) {
  let r = [], i = 0;
  for (let n of t) r.push(e.substring(i, n)), i = n;
  return i < e.length() && r.push(e.substring(i, e.length())), r;
}
const Dp = new RegExp("^\\p{gc=M}$", "u");
function u3(e) {
  let t = [], r = 0;
  for (; r < e.length; ) {
    if (!Dp.test(e[r])) {
      t.push(r), r++;
      continue;
    }
    let i = r;
    for (; i < e.length && Dp.test(e[i]); ) i++;
    let n = e[i];
    if (n !== void 0 && r1(n.codePointAt(0))) {
      t.push(i);
      for (let a = i - 1; a >= r; a--) t.push(a);
      r = i + 1;
    } else {
      for (let a = r; a < i; a++) t.push(a);
      r = i;
    }
  }
  return t;
}
function c3(e) {
  let t = [], r = 0;
  for (let i of e.graphemes()) t.push(...Array(i.length).fill(e.sectionIndex[r])), r++;
  return t;
}
function h3(e, t) {
  let r = t.map((a) => e.toCodeUnitIndex(a)), i = _i.isParsed() ? _i : null;
  if (e.sections.length === 1) return i ? i.processBidirectionalText(e.toString(), r).map((a) => Sp(a, e.sections, [...a].map(() => 0))) : Nw(e.toString(), r).map((a) => $l([...a], e.sections, [...a].map(() => 0)));
  let n = c3(e);
  return i ? i.processStyledBidirectionalText(e.text, n, r).map(([a, s]) => Sp(a, e.sections, s)) : Uw(e.text, n, r).map(([a, s]) => {
    let o = [...a];
    return $l(o, e.sections, h1(o).map((l) => s[l] ?? 0));
  });
}
function $l(e, t, r) {
  let i = new Xu(e.join(""), t, []), n = 0;
  for (let a of i.graphemes()) i.sectionIndex.push(r[n] ?? 0), n += [...a].length;
  return i;
}
function h1(e) {
  let t = [], r = 0;
  for (let i of e) t.push(r), r += i.length;
  return t;
}
function Sp(e, t, r) {
  let i = [...e], n = h1(i), a = u3(i);
  return $l(a.map((s) => i[s]), t, a.map((s) => r[n[s]] ?? 0));
}
function wa(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d) {
  let y = Xu.fromFeature(e, n, h === 2, t), m = y.determineLineBreaks(u, a, t, i, f), g = i1(y.text) ? h3(y, m) : l3(y, m), v = [], x = { positionedLines: v, text: y.toString(), top: c[1], bottom: c[1], left: c[0], right: c[0], writingMode: h, iconsInText: !1, verticalizable: !1 };
  return m3(x, t, r, i, g, s, o, l, h, u, p, d), !o3(v) && x;
}
function p1(e) {
  let t = 0.5, r = 0.5;
  switch (e) {
    case "right":
    case "top-right":
    case "bottom-right":
      t = 1;
      break;
    case "left":
    case "top-left":
    case "bottom-left":
      t = 0;
  }
  switch (e) {
    case "bottom":
    case "bottom-right":
    case "bottom-left":
      r = 1;
      break;
    case "top":
    case "top-right":
    case "top-left":
      r = 0;
  }
  return { horizontalAlign: t, verticalAlign: r };
}
function p3(e, t, r) {
  let i = t.getMaxScale() * 24, { maxImageWidth: n, maxImageHeight: a } = t.getMaxImageSize(e), s = Math.max(i, a * r);
  return { verticalLineContentWidth: Math.max(i, n * r), horizontalLineContentHeight: s };
}
function f1(e) {
  switch (e) {
    case "top":
      return 0;
    case "center":
      return 0.5;
    default:
      return 1;
  }
}
function f3(e, t) {
  return e != null && e.rect ? e : t ? { rect: null, metrics: t.metrics } : null;
}
function d1(e, t, r) {
  return !(e === 1 || !t && !jn(r) || t && (Pn(r) || t1(r)));
}
function Pa(e) {
  return new RegExp("\\p{Nd}", "u").test(String.fromCodePoint(e));
}
function y1(e) {
  return new RegExp("\\p{Lu}", "u").test(String.fromCodePoint(e));
}
function m1(e) {
  let t = e.some(Pa) && e.every((i) => Pa(i) || Ts(i)), r = e.length <= 3 && e.every((i) => y1(i) || Pa(i));
  return t || r;
}
function g1(e) {
  return (Pa(e) || y1(e)) && !t1(e);
}
function d3(e, t) {
  return t ? d1(2, !0, e) : !Di(e) || g1(e) || Ts(e);
}
function y3(e, t, r) {
  let i = !1;
  for (let n = 0; n < e.length; n++) {
    if (t[n]) continue;
    let a = ii[e[n]];
    if (a && (n === 0 || t[n - 1]) && (n === e.length - 1 || t[n + 1])) {
      if (t[n] = !0, r[n]) continue;
      e[n] = a, i = !0;
    }
  }
  return i;
}
function Ap(e, t, r) {
  for (; t >= 0 && t < e.length && Pn(e[t]); ) t += r;
  let i = [];
  for (; t >= 0 && t < e.length && !jn(e[t]) && !Pn(e[t]); ) i.push(e[t]), t += r;
  return !m1(i) && !i.every(Ts) && i.some(Di);
}
function x1(e, t) {
  let r = e.graphemes().slice(), i = r.map((o) => o.codePointAt(0)), n = r.map((o, l) => {
    var c, h;
    let u = e.getSection(l);
    return "fontStack" in u && !!((h = (c = t[u.fontStack]) == null ? void 0 : c.vertical) != null && h[o]);
  }), a = i.map(jn), s = (o) => !a[o] && !Pn(i[o]) && !("imageName" in e.getSection(o));
  for (let o = 0; o < i.length; o++) {
    if (!s(o)) continue;
    let l = o;
    for (; l + 1 < i.length && s(l + 1); ) l++;
    let u = i.slice(o, l + 1), c = m1(u), h = u.every(Ts), p = h && (Ap(i, o - 1, -1) || Ap(i, l + 1, 1)), f = !c && u.some(Di);
    for (let d = o; d <= l; d++) a[d] = c && g1(i[d]) || n[d] && !p && (h || !f && !Di(i[d]));
    o = l;
  }
  if (n.some((o, l) => o && !a[l])) {
    let o = e.text;
    if (e.verticalizePunctuation(t, a), e.text !== o) return x1(e, t);
  }
  return y3(r, a, n) && (e.text = r.join(""), e.cachedGraphemes = r), a;
}
function m3(e, t, r, i, n, a, s, o, l, u, c, h) {
  var w, D;
  let p = 0, f = 0, d = 0, y = 0, m = o === "right" ? 1 : o === "left" ? 0 : 0.5, g = 24 / h, v = 0;
  for (let _ of n) {
    _.trim();
    let A = _.getMaxScale(), E = { positionedGlyphs: [], lineOffset: 0 };
    e.positionedLines[v] = E;
    let R = E.positionedGlyphs, B = 0;
    if (!_.length()) {
      f += a, ++v;
      continue;
    }
    let L = p3(i, _, g), $ = l === 2 && !c ? x1(_, t) : null, M = _.graphemes();
    for (let z = 0; z < M.length; z++) {
      let O = _.getSection(z), re = M[z], oe = re.codePointAt(0), ue = $ ? $[z] : d1(l, c, oe), be = "fontStack" in O && zl(re) && !((D = (w = t[O.fontStack]) == null ? void 0 : w.default) != null && D[re]) ? [...re] : [re];
      for (let Ee of be) {
        let Ve = { glyph: Ee.codePointAt(0), grapheme: Ee, imageName: null, x: p, y: f + -17, vertical: ue, scale: 1, fontStack: "", sectionIndex: _.getSectionIndex(z), metrics: null, rect: null }, We;
        if ("fontStack" in O) {
          if (We = g3(O, Ee, ue, L, t, r), !We) continue;
          Ve.fontStack = O.fontStack;
        } else {
          if (e.iconsInText = !0, O.scale *= g, We = x3(O, ue, A, L, i), !We) continue;
          B = Math.max(B, We.imageOffset), Ve.imageName = O.imageName;
        }
        let { rect: mr, metrics: Ze, baselineOffset: Qt } = We;
        if (Ve.y += Qt, Ve.scale = O.scale, Ve.metrics = Ze, Ve.rect = mr, R.push(Ve), !ue) p += Ze.advance * O.scale + u;
        else {
          e.verticalizable = !0;
          let er = "imageName" in O ? Ze.advance : 24;
          p += er * O.scale + u;
        }
      }
    }
    if (R.length !== 0) {
      let z = p - u;
      d = Math.max(z, d), v3(R, 0, R.length - 1, m);
    }
    p = 0;
    let C = (A - 1) * 24;
    E.lineOffset = Math.max(B, C);
    let N = a * A + B;
    f += N, y = Math.max(N, y), ++v;
  }
  let { horizontalAlign: x, verticalAlign: b } = p1(s);
  b3(e.positionedLines, m, x, b, d, y, a, f, n.length), e.top += -b * f, e.bottom = e.top + f, e.left += -x * d, e.right = e.left + d;
}
function g3(e, t, r, i, n, a) {
  var h, p, f, d, y, m;
  let s = r && ((p = (h = n[e.fontStack]) == null ? void 0 : h.vertical) != null && p[t]) ? "vertical" : "default", o = (d = (f = a[e.fontStack]) == null ? void 0 : f[s]) == null ? void 0 : d[t], l = (m = (y = n[e.fontStack]) == null ? void 0 : y[s]) == null ? void 0 : m[t], u = f3(o, l);
  if (u === null) return null;
  let c;
  if (r) c = i.verticalLineContentWidth - e.scale * 24;
  else {
    let g = f1(e.verticalAlign);
    c = (i.horizontalLineContentHeight - e.scale * 24) * g;
  }
  return { rect: u.rect, metrics: u.metrics, baselineOffset: c };
}
function x3(e, t, r, i, n) {
  let a = n[e.imageName];
  if (!a) return null;
  let s = a.paddedRect, o = a.displaySize, l = { width: o[0], height: o[1], left: 1, top: -3, advance: t ? o[1] : o[0] }, u;
  if (t) u = i.verticalLineContentWidth - o[1] * e.scale;
  else {
    let h = f1(e.verticalAlign);
    u = (i.horizontalLineContentHeight - o[1] * e.scale) * h;
  }
  let c = (t ? o[0] : o[1]) * e.scale - 24 * r;
  return { rect: s, metrics: l, baselineOffset: u, imageOffset: c };
}
function v3(e, t, r, i) {
  if (i === 0) return;
  let n = e[r], a = n.metrics.advance * n.scale, s = (e[r].x + a) * i;
  for (let o = t; o <= r; o++) e[o].x -= s;
}
function b3(e, t, r, i, n, a, s, o, l) {
  let u = (t - r) * n, c = 0;
  c = a === s ? -i * l * s + 0.5 * s : -o * i - -17;
  for (let h of e) for (let p of h.positionedGlyphs) p.x += u, p.y += c;
}
function w3(e, t, r) {
  let { horizontalAlign: i, verticalAlign: n } = p1(r), a = t[0], s = t[1], o = a - e.displaySize[0] * i, l = o + e.displaySize[0], u = s - e.displaySize[1] * n;
  return { image: e, top: u, bottom: u + e.displaySize[1], left: o, right: l };
}
function v1(e) {
  let t = e.left, r = e.top, i = e.right - t, n = e.bottom - r, a = e.image.content[2] - e.image.content[0], s = e.image.content[3] - e.image.content[1], o = e.image.textFitWidth ?? "stretchOrShrink", l = e.image.textFitHeight ?? "stretchOrShrink", u = a / s;
  if (l === "proportional") {
    if (o === "stretchOnly" && i / n < u || o === "proportional") {
      let c = Math.ceil(n * u);
      t *= c / i, i = c;
    }
  } else if (o === "proportional" && l === "stretchOnly" && u !== 0 && i / n > u) {
    let c = Math.ceil(i / u);
    r *= c / n, n = c;
  }
  return { x1: t, y1: r, x2: t + i, y2: r + n };
}
function Ep(e, t, r, i, n, a, s = 1) {
  let o = e.image, l;
  if (o.content) {
    let x = o.content, b = o.pixelRatio || 1;
    l = [x[0] / b, x[1] / b, o.displaySize[0] - x[2] / b, o.displaySize[1] - x[3] / b];
  }
  let u = s > 0 ? a / s : a, c = s > 0 ? 1 / s : 1, h = t.left * u, p = t.right * u, f, d, y, m;
  r === "width" || r === "both" ? (m = n[0] + h - i[3] * c, d = n[0] + p + i[1] * c) : (m = n[0] + (h + p - o.displaySize[0]) / 2, d = m + o.displaySize[0]);
  let g = t.top * u, v = t.bottom * u;
  return r === "height" || r === "both" ? (f = n[1] + g - i[0] * c, y = n[1] + v + i[2] * c) : (f = n[1] + (g + v - o.displaySize[1]) / 2, y = f + o.displaySize[1]), { image: o, top: f, right: d, bottom: y, left: m, collisionPadding: l };
}
const Tp = 32640;
function Ip(e, t) {
  let { expression: r } = t;
  if (r.kind === "constant") return { kind: "constant", layoutSize: r.evaluate(new le(e + 1)) };
  if (r.kind === "source") return { kind: "source" };
  if (r.kind === "composite") {
    let { minZoom: i, maxZoom: n } = _3(r.zoomStops, e);
    return { kind: "composite", minZoom: i, maxZoom: n, interpolationType: r.interpolationType };
  }
  {
    let i = D3(r), n = r.evaluate(new le(e + 1));
    return { kind: "camera", zoomStops: r.zoomStops, sizes: i, layoutSize: n, interpolationType: r.interpolationType };
  }
}
function _3(e, t) {
  let r = 0;
  for (; r < e.length && e[r] <= t; ) r++;
  r = Math.max(0, r - 1);
  let i = r;
  for (; i < e.length && e[i] < t + 1; ) i++;
  return i = Math.min(e.length - 1, i), { minZoom: e[r], maxZoom: e[i] };
}
function D3(e) {
  return e.zoomStops.map((t) => e.evaluate(new le(t === -1 / 0 ? e.zoomStops[1] - 1 : t)));
}
var ui = class b1 extends T {
  constructor(t, r, i, n) {
    super(t, r), this.angle = i, n !== void 0 && (this.segment = n);
  }
  clone() {
    return new b1(this.x, this.y, this.angle, this.segment);
  }
};
P("Anchor", ui);
function w1(e, t, r, i, n) {
  if (t.segment === void 0 || r === 0) return !0;
  let a = t, s = t.segment + 1, o = 0;
  for (; o > -r / 2; ) {
    if (s--, s < 0) return !1;
    o -= e[s].dist(a), a = e[s];
  }
  o += e[s].dist(e[s + 1]), s++;
  let l = [], u = 0;
  for (; o < r / 2; ) {
    let c = e[s - 1], h = e[s], p = e[s + 1];
    if (!p) return !1;
    let f = c.angleTo(h) - h.angleTo(p);
    for (f = Math.abs((f + 3 * Math.PI) % (Math.PI * 2) - Math.PI), l.push({ distance: o, angleDelta: f }), u += f; o - l[0].distance > i; ) u -= l.shift().angleDelta;
    if (u > n) return !1;
    s++, o += h.dist(p);
  }
  return !0;
}
function _1(e) {
  let t = 0;
  for (let r = 0; r < e.length - 1; r++) t += e[r].dist(e[r + 1]);
  return t;
}
function D1(e, t, r) {
  return e ? 3 / 5 * t * r : 0;
}
function S1(e, t) {
  return Math.max(e ? e.right - e.left : 0, t ? t.right - t.left : 0);
}
function S3(e, t, r, i, n, a) {
  let s = D1(r, n, a), o = S1(r, i) * a, l = 0, u = _1(e) / 2;
  for (let c = 0; c < e.length - 1; c++) {
    let h = e[c], p = e[c + 1], f = h.dist(p);
    if (l + f > u) {
      let d = (u - l) / f, y = new ui(Kt.number(h.x, p.x, d), Kt.number(h.y, p.y, d), p.angleTo(h), c);
      return y._round(), !s || w1(e, y, o, s, t) ? y : void 0;
    }
    l += f;
  }
}
function A3(e, t, r, i, n, a, s, o, l) {
  let u = D1(i, a, s), c = S1(i, n), h = c * s, p = e[0].x === 0 || e[0].x === l || e[0].y === 0 || e[0].y === l;
  t - h < t / 4 && (t = h + t / 4);
  let f = a * 2;
  return A1(e, p ? t / 2 * o % t : (c / 2 + f) * s * o % t, t, u, r, h, p, !1, l);
}
function A1(e, t, r, i, n, a, s, o, l) {
  let u = a / 2, c = _1(e), h = 0, p = t - r, f = [];
  for (let d = 0; d < e.length - 1; d++) {
    let y = e[d], m = e[d + 1], g = y.dist(m), v = m.angleTo(y);
    for (; p + r < h + g; ) {
      p += r;
      let x = (p - h) / g, b = Kt.number(y.x, m.x, x), w = Kt.number(y.y, m.y, x);
      if (b >= 0 && b < l && w >= 0 && w < l && p - u >= 0 && p + u <= c) {
        let D = new ui(b, w, v, d);
        D._round(), (!i || w1(e, D, a, i, n)) && f.push(D);
      }
    }
    h += g;
  }
  return o || f.length || s || (f = A1(e, h / 2, r, i, n, a, s, !0, l)), f;
}
function E3(e, t, r, i, n) {
  let a = [];
  for (let s of e) {
    let o;
    for (let l = 0; l < s.length - 1; l++) {
      let u = s[l], c = s[l + 1];
      u.x < t && c.x < t || (u.x < t ? u = new T(t, u.y + (c.y - u.y) * ((t - u.x) / (c.x - u.x)))._round() : c.x < t && (c = new T(t, u.y + (c.y - u.y) * ((t - u.x) / (c.x - u.x)))._round()), u.y < r && c.y < r || (u.y < r ? u = new T(u.x + (c.x - u.x) * ((r - u.y) / (c.y - u.y)), r)._round() : c.y < r && (c = new T(u.x + (c.x - u.x) * ((r - u.y) / (c.y - u.y)), r)._round()), u.x >= i && c.x >= i || (u.x >= i ? u = new T(i, u.y + (c.y - u.y) * ((i - u.x) / (c.x - u.x)))._round() : c.x >= i && (c = new T(i, u.y + (c.y - u.y) * ((i - u.x) / (c.x - u.x)))._round()), u.y >= n && c.y >= n || (u.y >= n ? u = new T(u.x + (c.x - u.x) * ((n - u.y) / (c.y - u.y)), n)._round() : c.y >= n && (c = new T(u.x + (c.x - u.x) * ((n - u.y) / (c.y - u.y)), n)._round()), o && u.equals(o[o.length - 1]) || (o = [u], a.push(o)), o.push(c)))));
    }
  }
  return a;
}
function T3(e, t, r, i, n, a) {
  let s = Cp(e, t, r, n, 0);
  return s = Cp(s, t, i, a, 1), s;
}
function Cp(e, t, r, i, n) {
  switch (t) {
    case 1:
      return I3(e, r, i, n);
    case 2:
      return kp(e, r, i, n, !1);
    case 3:
      return kp(e, r, i, n, !0);
  }
  return [];
}
function I3(e, t, r, i) {
  let n = [];
  for (let a of e) for (let s of a) {
    let o = i === 0 ? s.x : s.y;
    o >= t && o <= r && n.push([s]);
  }
  return n;
}
function C3(e, t, r, i, n) {
  let a = i === 0 ? k3 : F3, s = [], o = [];
  for (let c = 0; c < e.length - 1; c++) {
    let h = e[c], p = e[c + 1], f = i === 0 ? h.x : h.y, d = i === 0 ? p.x : p.y, y = !1;
    f < t ? d >= t && s.push(a(h, p, t)) : f > r ? d <= r && s.push(a(h, p, r)) : s.push(h), d < t && f >= t && (s.push(a(h, p, t)), y = !0), d > r && f <= r && (s.push(a(h, p, r)), y = !0), !n && y && (o.push(s), s = []);
  }
  let l = e.length - 1, u = i === 0 ? e[l].x : e[l].y;
  return u >= t && u <= r && s.push(e[l]), n && s.length > 0 && !s[0].equals(s[s.length - 1]) && s.push(new T(s[0].x, s[0].y)), s.length > 0 && o.push(s), o;
}
function kp(e, t, r, i, n) {
  let a = [];
  for (let s of e) {
    let o = C3(s, t, r, i, n);
    o.length > 0 && a.push(...o);
  }
  return a;
}
function k3(e, t, r) {
  let i = (r - e.x) / (t.x - e.x);
  return new T(r, e.y + (t.y - e.y) * i);
}
function F3(e, t, r) {
  let i = (r - e.y) / (t.y - e.y);
  return new T(e.x + (t.x - e.x) * i, r);
}
function Fp(e, t, r, i, n = 1) {
  let a = [], s = e.image, o = s.pixelRatio, l = s.paddedRect.w - 2, u = s.paddedRect.h - 2, c = { x1: e.left, y1: e.top, x2: e.right, y2: e.bottom }, h = s.stretchX || [[0, l]], p = s.stretchY || [[0, u]], f = (C, N) => C + N[1] - N[0], d = h.reduce(f, 0), y = p.reduce(f, 0), m = l - d, g = u - y, v = 0, x = d, b = 0, w = y, D = 0, _ = m, A = 0, E = g;
  if (s.content && i) {
    let C = s.content, N = C[2] - C[0], z = C[3] - C[1];
    (s.textFitWidth || s.textFitHeight) && (c = v1(e)), v = _a(h, 0, C[0]), b = _a(p, 0, C[1]), x = _a(h, C[0], C[2]), w = _a(p, C[1], C[3]), D = C[0] - v, A = C[1] - b, _ = N - x, E = z - w;
  }
  let R = c.x1, B = c.y1, L = c.x2 - R, $ = c.y2 - B, M = (C, N, z, O) => {
    let re = Da(C.stretch - v, x, L, R), oe = Sa(C.fixed - D, _, C.stretch, d), ue = Da(N.stretch - b, w, $, B), be = Sa(N.fixed - A, E, N.stretch, y), Ee = Da(z.stretch - v, x, L, R), Ve = Sa(z.fixed - D, _, z.stretch, d), We = Da(O.stretch - b, w, $, B), mr = Sa(O.fixed - A, E, O.stretch, y), Ze = new T(re, ue), Qt = new T(Ee, ue), er = new T(Ee, We), tr = new T(re, We), Et = n / o, gr = new T(oe * Et, be * Et), Ci = new T(Ve * Et, mr * Et), Oe = t * Math.PI / 180;
    if (Oe) {
      let ie = Math.sin(Oe), k = Math.cos(Oe), Q = [k, -ie, ie, k];
      Ze._matMult(Q), Qt._matMult(Q), tr._matMult(Q), er._matMult(Q);
    }
    let Rt = C.stretch + C.fixed, xr = z.stretch + z.fixed, U = N.stretch + N.fixed, se = O.stretch + O.fixed;
    return { tl: Ze, tr: Qt, bl: tr, br: er, tex: { x: s.paddedRect.x + 1 + Rt, y: s.paddedRect.y + 1 + U, w: xr - Rt, h: se - U }, writingMode: void 0, glyphOffset: [0, 0], sectionIndex: 0, pixelOffsetTL: gr, pixelOffsetBR: Ci, minFontScaleX: _ * Et / L, minFontScaleY: E * Et / $, isSDF: r };
  };
  if (!i || !s.stretchX && !s.stretchY) a.push(M({ fixed: 0, stretch: -1 }, { fixed: 0, stretch: -1 }, { fixed: 0, stretch: l + 1 }, { fixed: 0, stretch: u + 1 }));
  else {
    let C = Mp(h, m, d), N = Mp(p, g, y);
    for (let z = 0; z < C.length - 1; z++) {
      let O = C[z], re = C[z + 1];
      for (let oe = 0; oe < N.length - 1; oe++) {
        let ue = N[oe], be = N[oe + 1];
        a.push(M(O, ue, re, be));
      }
    }
  }
  return a;
}
function _a(e, t, r) {
  let i = 0;
  for (let n of e) i += Math.max(t, Math.min(r, n[1])) - Math.max(t, Math.min(r, n[0]));
  return i;
}
function Mp(e, t, r) {
  let i = [{ fixed: -1, stretch: 0 }];
  for (let [n, a] of e) {
    let s = i[i.length - 1];
    i.push({ fixed: n - s.stretch, stretch: s.stretch }), i.push({ fixed: n - s.stretch, stretch: s.stretch + (a - n) });
  }
  return i.push({ fixed: t + 1, stretch: r }), i;
}
function Da(e, t, r, i) {
  return e / t * r + i;
}
function Sa(e, t, r, i) {
  return e - t * r / i;
}
function M3(e, t, r, i, n, a, s, o) {
  let l = i.layout.get("text-rotate").evaluate(a, {}) * Math.PI / 180, u = [];
  for (let c of t.positionedLines) for (let h of c.positionedGlyphs) {
    if (!h.rect) continue;
    let p = h.rect || {}, f = 4, d = !0, y = 1, m = 0, g = (n || o) && h.vertical, v = h.metrics.advance * h.scale / 2;
    if (o && t.verticalizable) {
      let z = (h.scale - 1) * 24, O = (24 - h.metrics.width * h.scale) / 2;
      m = c.lineOffset / 2 - (h.imageName ? -O : z);
    }
    if (h.imageName) {
      let z = s[h.imageName];
      d = z.sdf, y = z.pixelRatio, f = 1 / y;
    }
    let x = n ? [h.x + v, h.y] : [0, 0], b = n ? [0, 0] : [h.x + v + r[0], h.y + r[1] - m], w = [0, 0];
    g && (w = b, b = [0, 0]);
    let D = h.metrics.isDoubleResolution ? 2 : 1, _ = (h.metrics.left - f) * h.scale - v + b[0], A = (-h.metrics.top - f) * h.scale + b[1], E = _ + p.w / D * h.scale / y, R = A + p.h / D * h.scale / y, B = new T(_, A), L = new T(E, A), $ = new T(_, R), M = new T(E, R);
    if (g) {
      let z = new T(-v, v - -17), O = -Math.PI / 2, re = 12 - v, oe = h.imageName ? re : 0, ue = new T(22 - re, -oe), be = new T(...w);
      B._rotateAround(O, z)._add(ue)._add(be), L._rotateAround(O, z)._add(ue)._add(be), $._rotateAround(O, z)._add(ue)._add(be), M._rotateAround(O, z)._add(ue)._add(be);
    }
    if (l) {
      let z = Math.sin(l), O = Math.cos(l), re = [O, -z, z, O];
      B._matMult(re), L._matMult(re), $._matMult(re), M._matMult(re);
    }
    let C = new T(0, 0), N = new T(0, 0);
    u.push({ tl: B, tr: L, bl: $, br: M, tex: p, writingMode: t.writingMode, glyphOffset: x, sectionIndex: h.sectionIndex, isSDF: d, pixelOffsetTL: C, pixelOffsetBR: N, minFontScaleX: 0, minFontScaleY: 0 });
  }
  return u;
}
var Aa = class {
  constructor(e, t, r, i, n, a, s, o, l, u) {
    var c;
    if (this.boxStartIndex = e.length, l) {
      let h = a.top, p = a.bottom, f = a.collisionPadding;
      f && (h -= f[1], p += f[3]);
      let d = p - h;
      d > 0 && (d = Math.max(10, d), this.circleDiameter = d);
    } else {
      let h = (c = a.image) != null && c.content && (a.image.textFitWidth || a.image.textFitHeight) ? v1(a) : { x1: a.left, y1: a.top, x2: a.right, y2: a.bottom };
      h.y1 = h.y1 * s - o[0], h.y2 = h.y2 * s + o[2], h.x1 = h.x1 * s - o[3], h.x2 = h.x2 * s + o[1];
      let p = a.collisionPadding;
      if (p && (h.x1 -= p[0] * s, h.y1 -= p[1] * s, h.x2 += p[2] * s, h.y2 += p[3] * s), u) {
        let f = new T(h.x1, h.y1), d = new T(h.x2, h.y1), y = new T(h.x1, h.y2), m = new T(h.x2, h.y2), g = u * Math.PI / 180;
        f._rotate(g), d._rotate(g), y._rotate(g), m._rotate(g), h.x1 = Math.min(f.x, d.x, y.x, m.x), h.x2 = Math.max(f.x, d.x, y.x, m.x), h.y1 = Math.min(f.y, d.y, y.y, m.y), h.y2 = Math.max(f.y, d.y, y.y, m.y);
      }
      e.emplaceBack(t.x, t.y, h.x1, h.y1, h.x2, h.y2, r, i, n);
    }
    this.boxEndIndex = e.length;
  }
}, P3 = class {
  constructor(e = [], t = (r, i) => r < i ? -1 : +(r > i)) {
    if (this.data = e, this.length = this.data.length, this.compare = t, this.length > 0) for (let r = (this.length >> 1) - 1; r >= 0; r--) this._down(r);
  }
  push(e) {
    this.data.push(e), this._up(this.length++);
  }
  pop() {
    if (this.length === 0) return;
    let e = this.data[0], t = this.data.pop();
    return --this.length > 0 && (this.data[0] = t, this._down(0)), e;
  }
  peek() {
    return this.data[0];
  }
  _up(e) {
    let { data: t, compare: r } = this, i = t[e];
    for (; e > 0; ) {
      let n = e - 1 >> 1, a = t[n];
      if (r(i, a) >= 0) break;
      t[e] = a, e = n;
    }
    t[e] = i;
  }
  _down(e) {
    let { data: t, compare: r } = this, i = this.length >> 1, n = t[e];
    for (; e < i; ) {
      let a = (e << 1) + 1, s = a + 1;
      if (s < this.length && r(t[s], t[a]) < 0 && (a = s), r(t[a], n) >= 0) break;
      t[e] = t[a], e = a;
    }
    t[e] = n;
  }
};
function B3(e, t = 1) {
  let r = Tn.fromPoints(e[0]), i = Math.min(r.width(), r.height()), n = i / 2, a = new P3([], L3), { minX: s, minY: o, maxX: l, maxY: u } = r;
  if (i === 0) return new T(s, o);
  for (let p = s; p < l; p += i) for (let f = o; f < u; f += i) a.push(new ei(p + n, f + n, n, e));
  let c = V3(e), h = c;
  for (; a.length; ) {
    let p = a.pop();
    (p.d > h.d || !h.d) && (h = p), p.max - h.d <= t || (n = p.h / 2, a.push(new ei(p.p.x - n, p.p.y - n, n, e)), a.push(new ei(p.p.x + n, p.p.y - n, n, e)), a.push(new ei(p.p.x - n, p.p.y + n, n, e)), a.push(new ei(p.p.x + n, p.p.y + n, n, e)));
  }
  return c.d > 0 && h.d - c.d <= t ? c.p : h.p;
}
function L3(e, t) {
  return t.max - e.max;
}
var ei = class {
  constructor(e, t, r, i) {
    this.p = new T(e, t), this.h = r, this.d = z3(this.p, i), this.max = this.d + this.h * Math.SQRT2;
  }
};
function z3(e, t) {
  let r = !1, i = 1 / 0;
  for (let n of t) for (let a = 0, s = n.length, o = s - 1; a < s; o = a++) {
    let l = n[a], u = n[o];
    l.y > e.y != u.y > e.y && e.x < (u.x - l.x) * (e.y - l.y) / (u.y - l.y) + l.x && (r = !r), i = Math.min(i, ey(e, l, u));
  }
  return (r ? 1 : -1) * Math.sqrt(i);
}
function V3(e) {
  let t = 0, r = 0, i = 0, n = e[0];
  for (let a = 0, s = n.length, o = s - 1; a < s; o = a++) {
    let l = n[a], u = n[o], c = l.x * u.y - u.x * l.y;
    r += (l.x + u.x) * c, i += (l.y + u.y) * c, t += c * 3;
  }
  return new ei(r / t, i / t, 0, e);
}
let O3 = /* @__PURE__ */ (function(e) {
  return e[e.center = 1] = "center", e[e.left = 2] = "left", e[e.right = 3] = "right", e[e.top = 4] = "top", e[e.bottom = 5] = "bottom", e[e["top-left"] = 6] = "top-left", e[e["top-right"] = 7] = "top-right", e[e["bottom-left"] = 8] = "bottom-left", e[e["bottom-right"] = 9] = "bottom-right", e;
})({});
const Wu = 1 / 0;
function E1(e, t) {
  function r(n, a) {
    let s = 0, o = 0;
    a < 0 && (a = 0);
    let l = a / Math.SQRT2;
    switch (n) {
      case "top-right":
      case "top-left":
        o = l - 7;
        break;
      case "bottom-right":
      case "bottom-left":
        o = -l + 7;
        break;
      case "bottom":
        o = -a + 7;
        break;
      case "top":
        o = a - 7;
    }
    switch (n) {
      case "top-right":
      case "bottom-right":
        s = -l;
        break;
      case "top-left":
      case "bottom-left":
        s = l;
        break;
      case "left":
        s = a;
        break;
      case "right":
        s = -a;
    }
    return [s, o];
  }
  function i(n, a, s) {
    let o = 0, l = 0;
    switch (a = Math.abs(a), s = Math.abs(s), n) {
      case "top-right":
      case "top-left":
      case "top":
        l = s - 7;
        break;
      case "bottom-right":
      case "bottom-left":
      case "bottom":
        l = -s + 7;
    }
    switch (n) {
      case "top-right":
      case "bottom-right":
      case "right":
        o = -a;
        break;
      case "top-left":
      case "bottom-left":
      case "left":
        o = a;
    }
    return [o, l];
  }
  return t[1] === Wu ? r(e, t[0]) : i(e, t[0], t[1]);
}
function T1(e, t, r) {
  var s;
  let i = e.layout, n = (s = i.get("text-variable-anchor-offset")) == null ? void 0 : s.evaluate(t, {}, r);
  if (n) {
    let o = n.values, l = [];
    for (let u = 0; u < o.length; u += 2) {
      let c = l[u] = o[u], h = o[u + 1].map((p) => p * 24);
      c.startsWith("top") ? h[1] -= 7 : c.startsWith("bottom") && (h[1] += 7), l[u + 1] = h;
    }
    return new Lt(l);
  }
  let a = i.get("text-variable-anchor");
  if (a) {
    let o;
    o = e._unevaluatedLayout.getValue("text-radial-offset") === void 0 ? i.get("text-offset").evaluate(t, {}, r).map((u) => u * 24) : [i.get("text-radial-offset").evaluate(t, {}, r) * 24, Wu];
    let l = [];
    for (let u of a) l.push(u, E1(u, o));
    return new Lt(l);
  }
  return null;
}
function R3(e) {
  var c, h;
  e.bucket.createArrays();
  let t = 512 * e.bucket.overscaling;
  e.bucket.tilePixelRatio = te / t, e.bucket.compareText = {}, e.bucket.iconsNeedLinear = !1;
  let r = e.bucket.layers[0], i = r.layout, n = r._unevaluatedLayout._values, a = { layoutIconSize: n["icon-size"].possiblyEvaluate(new le(e.bucket.zoom + 1), e.canonical), layoutTextSize: n["text-size"].possiblyEvaluate(new le(e.bucket.zoom + 1), e.canonical), textMaxSize: n["text-size"].possiblyEvaluate(new le(18)) };
  if (e.bucket.textSizeData.kind === "composite") {
    let { minZoom: p, maxZoom: f } = e.bucket.textSizeData;
    a.compositeTextSizes = [n["text-size"].possiblyEvaluate(new le(p), e.canonical), n["text-size"].possiblyEvaluate(new le(f), e.canonical)];
  }
  if (e.bucket.iconSizeData.kind === "composite") {
    let { minZoom: p, maxZoom: f } = e.bucket.iconSizeData;
    a.compositeIconSizes = [n["icon-size"].possiblyEvaluate(new le(p), e.canonical), n["icon-size"].possiblyEvaluate(new le(f), e.canonical)];
  }
  let s = i.get("text-line-height") * 24, o = i.get("text-rotation-alignment") !== "viewport" && i.get("symbol-placement") !== "point", l = i.get("text-keep-upright"), u = i.get("text-size");
  for (let p of e.bucket.features) {
    let f = i.get("text-font").evaluate(p, {}, e.canonical).join(","), d = u.evaluate(p, {}, e.canonical), y = a.layoutTextSize.evaluate(p, {}, e.canonical), m = a.layoutIconSize.evaluate(p, {}, e.canonical), g = { horizontal: {}, vertical: void 0 }, v = p.text, x = [0, 0];
    if (v) {
      let _ = v.toString(), A = i.get("text-letter-spacing").evaluate(p, {}, e.canonical) * 24, E = e1(_) ? A : 0, R = i.get("text-anchor").evaluate(p, {}, e.canonical), B = T1(r, p, e.canonical);
      if (!B) {
        let C = i.get("text-radial-offset").evaluate(p, {}, e.canonical);
        x = C ? E1(R, [C * 24, Wu]) : i.get("text-offset").evaluate(p, {}, e.canonical).map((N) => N * 24);
      }
      let L = o ? "center" : i.get("text-justify").evaluate(p, {}, e.canonical), $ = i.get("symbol-placement") === "point" ? i.get("text-max-width").evaluate(p, {}, e.canonical) * 24 : 1 / 0, M = () => {
        e.bucket.allowVerticalPlacement && Vl(_) && (g.vertical = wa(v, e.glyphMap, e.glyphPositions, e.imagePositions, f, $, s, R, "left", E, x, 2, !0, y, d));
      };
      if (!o && B) {
        let C = /* @__PURE__ */ new Set();
        if (L === "auto") for (let z = 0; z < B.values.length; z += 2) C.add(Pp(B.values[z]));
        else C.add(L);
        let N = !1;
        for (let z of C) if (!g.horizontal[z])
          if (N) g.horizontal[z] = g.horizontal[0];
          else {
            let O = wa(v, e.glyphMap, e.glyphPositions, e.imagePositions, f, $, s, "center", z, E, x, 1, !1, y, d);
            O && (g.horizontal[z] = O, N = O.positionedLines.length === 1);
          }
        M();
      } else {
        L === "auto" && (L = Pp(R));
        let C = wa(v, e.glyphMap, e.glyphPositions, e.imagePositions, f, $, s, R, L, E, x, 1, !1, y, d);
        C && (g.horizontal[L] = C), M(), Vl(_) && o && l && (g.vertical = wa(v, e.glyphMap, e.glyphPositions, e.imagePositions, f, $, s, R, L, E, x, 2, !1, y, d));
      }
    }
    let b, w = !1;
    if ((c = p.icon) != null && c.name) {
      let _ = e.imageMap[p.icon.name];
      _ && (b = w3(e.imagePositions[p.icon.name], i.get("icon-offset").evaluate(p, {}, e.canonical), i.get("icon-anchor").evaluate(p, {}, e.canonical)), w = !!_.sdf, e.bucket.sdfIcons === void 0 ? e.bucket.sdfIcons = w : e.bucket.sdfIcons !== w && Me("Style sheet warning: Cannot mix SDF and non-SDF icons in one buffer"), _.pixelRatio === e.bucket.pixelRatio ? i.get("icon-rotate").constantOr(1) !== 0 && (e.bucket.iconsNeedLinear = !0) : e.bucket.iconsNeedLinear = !0);
    }
    let D = I1(g.horizontal) || g.vertical;
    (h = e.bucket).iconsInText || (h.iconsInText = D ? D.iconsInText : !1), (D || b) && $3(e.bucket, p, g, b, e.imageMap, a, y, m, x, w, e.canonical, e.subdivisionGranularity, e.hasPromoteId);
  }
  e.showCollisionBoxes && e.bucket.generateCollisionDebugBuffers();
}
function Pp(e) {
  switch (e) {
    case "right":
    case "top-right":
    case "bottom-right":
      return "right";
    case "left":
    case "top-left":
    case "bottom-left":
      return "left";
  }
  return "center";
}
function $3(e, t, r, i, n, a, s, o, l, u, c, h, p) {
  let f = a.textMaxSize.evaluate(t, {});
  f === void 0 && (f = s);
  let d = e.layers[0].layout, y = d.get("icon-offset").evaluate(t, {}, c), m = I1(r.horizontal), g = s / 24, v = e.tilePixelRatio * g, x = e.tilePixelRatio * f / 24, b = e.tilePixelRatio * o, w = e.tilePixelRatio * d.get("symbol-spacing"), D = d.get("text-padding") * e.tilePixelRatio, _ = r6(d, t, c, e.tilePixelRatio), A = d.get("text-max-angle") / 180 * Math.PI, E = d.get("text-rotation-alignment") !== "viewport" && d.get("symbol-placement") !== "point", R = d.get("icon-rotation-alignment").constantOr("viewport") === "map" && d.get("symbol-placement") !== "point", B = d.get("symbol-placement"), L = w / 2, $ = d.get("icon-text-fit"), M;
  i && $ !== "none" && (e.allowVerticalPlacement && r.vertical && (M = Ep(i, r.vertical, $, d.get("icon-text-fit-padding"), y, g, o)), m && (i = Ep(i, m, $, d.get("icon-text-fit-padding"), y, g, o)));
  let C = c ? h.line.getGranularityForZoomLevel(c.z) : 1, N = (z, O) => {
    Cu(O) || U3(e, O, z, r, i, n, M, e.layers[0], e.collisionBoxArray, t.index, t.sourceLayerIndex, e.index, v, [D, D, D, D], E, l, b, _, R, y, t, a, u, c, s, o, p);
  };
  if (B === "line") for (let z of E3(t.geometry, 0, 0, te, te)) {
    let O = Tr(z, C), re = A3(O, w, A, r.vertical || m, i, 24, x, e.overscaling, te);
    for (let oe of re) {
      let ue = m;
      ue && j3(e, ue.text, L, oe) || N(O, oe);
    }
  }
  else if (B === "line-center") {
    for (let z of t.geometry) if (z.length > 1) {
      let O = Tr(z, C), re = S3(O, A, r.vertical || m, i, 24, x);
      re && N(O, re);
    }
  } else if (t.type === "Polygon") for (let z of fs(t.geometry, 0)) {
    let O = B3(z, 16);
    N(Tr(z[0], C, !0), new ui(O.x, O.y, 0));
  }
  else if (t.type === "LineString") for (let z of t.geometry) {
    let O = Tr(z, C);
    N(O, new ui(O[0].x, O[0].y, 0));
  }
  else if (t.type === "Point") for (let z of t.geometry) for (let O of z) N([O], new ui(O.x, O.y, 0));
}
function N3(e, t) {
  let r = e.length, i = t == null ? void 0 : t.values;
  if ((i == null ? void 0 : i.length) > 0) for (let n = 0; n < i.length; n += 2) {
    let a = O3[i[n]], s = i[n + 1];
    e.emplaceBack(a, s[0], s[1]);
  }
  return [r, e.length];
}
function Bp(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y) {
  let m = M3(t, r, o, n, a, s, i, e.allowVerticalPlacement), g = e.textSizeData, v = null;
  g.kind === "source" ? (v = [128 * n.layout.get("text-size").evaluate(s, {})], v[0] > 32640 && Me(`${e.layerIds[0]}: Value for "text-size" is >= 255. Reduce your "text-size".`)) : g.kind === "composite" && (v = [128 * d.compositeTextSizes[0].evaluate(s, {}, y), 128 * d.compositeTextSizes[1].evaluate(s, {}, y)], (v[0] > 32640 || v[1] > 32640) && Me(`${e.layerIds[0]}: Value for "text-size" is >= 255. Reduce your "text-size".`)), e.addSymbols(e.text, m, v, o, a, s, c, t, u.lineStartIndex, u.lineLength, f, y, l);
  for (let x of h) p[x] = e.text.placedSymbolArray.length - 1;
  return m.length * 4;
}
function I1(e) {
  for (let t in e) return e[t];
  return null;
}
function U3(e, t, r, i, n, a, s, o, l, u, c, h, p, f, d, y, m, g, v, x, b, w, D, _, A, E, R) {
  let B = e.addToLineVertexArray(t, r), L = o.layout.get("symbol-height-offset").evaluate(b, {}, _);
  L > e.maxHeightOffset && (e.maxHeightOffset = L);
  let $, M, C, N, z = 0, O = 0, re = 0, oe = 0, ue = -1, be = -1, Ee = {}, Ve = (0, Wa.default)("");
  if (e.allowVerticalPlacement && i.vertical) {
    let k = o.layout.get("text-rotate").evaluate(b, {}, _) + 90, Q = i.vertical;
    C = new Aa(l, t, u, c, h, Q, p, f, d, k), s && (N = new Aa(l, t, u, c, h, s, m, g, d, k));
  }
  if (n) {
    let k = o.layout.get("icon-rotate").evaluate(b, {}), Q = o.layout.get("icon-text-fit") !== "none", G = Fp(n, k, D, Q, E), H = s ? Fp(s, k, D, Q, E) : void 0;
    M = new Aa(l, t, u, c, h, n, m, g, !1, k), z = G.length * 4;
    let X = e.iconSizeData, me = null;
    X.kind === "source" ? (me = [128 * o.layout.get("icon-size").evaluate(b, {})], me[0] > 32640 && Me(`${e.layerIds[0]}: Value for "icon-size" is >= 255. Reduce your "icon-size".`)) : X.kind === "composite" && (me = [128 * w.compositeIconSizes[0].evaluate(b, {}, _), 128 * w.compositeIconSizes[1].evaluate(b, {}, _)], (me[0] > 32640 || me[1] > 32640) && Me(`${e.layerIds[0]}: Value for "icon-size" is >= 255. Reduce your "icon-size".`)), e.addSymbols(e.icon, G, me, x, v, b, 0, t, B.lineStartIndex, B.lineLength, -1, _, L), ue = e.icon.placedSymbolArray.length - 1, H && (O = H.length * 4, e.addSymbols(e.icon, H, me, x, v, b, 2, t, B.lineStartIndex, B.lineLength, -1, _, L), be = e.icon.placedSymbolArray.length - 1);
  }
  let We = Object.keys(i.horizontal);
  for (let k of We) {
    let Q = i.horizontal[k];
    $ || ($ = (Ve = (0, Wa.default)(Q.text), new Aa(l, t, u, c, h, Q, p, f, d, o.layout.get("text-rotate").evaluate(b, {}, _))));
    let G = Q.positionedLines.length === 1;
    if (re += Bp(e, t, Q, a, o, d, b, y, L, B, i.vertical ? 1 : 3, G ? We : [k], Ee, ue, w, _), G) break;
  }
  i.vertical && (oe += Bp(e, t, i.vertical, a, o, d, b, y, L, B, 2, ["vertical"], Ee, be, w, _));
  let mr = $ ? $.boxStartIndex : e.collisionBoxArray.length, Ze = $ ? $.boxEndIndex : e.collisionBoxArray.length, Qt = C ? C.boxStartIndex : e.collisionBoxArray.length, er = C ? C.boxEndIndex : e.collisionBoxArray.length, tr = M ? M.boxStartIndex : e.collisionBoxArray.length, Et = M ? M.boxEndIndex : e.collisionBoxArray.length, gr = N ? N.boxStartIndex : e.collisionBoxArray.length, Ci = N ? N.boxEndIndex : e.collisionBoxArray.length, Oe = -1, Rt = (k, Q) => k != null && k.circleDiameter ? Math.max(k.circleDiameter, Q) : Q;
  Oe = Rt($, Oe), Oe = Rt(C, Oe), Oe = Rt(M, Oe), Oe = Rt(N, Oe);
  let xr = +(Oe > -1);
  xr && (Oe *= A / 24), e.glyphOffsetArray.length >= e.maxGlyphs && Me("Too many glyphs being rendered in a tile. See https://github.com/mapbox/mapbox-gl-js/issues/2907"), b.sortKey !== void 0 && e.addToSortKeyRanges(e.symbolInstances.length, b.sortKey);
  let U = T1(o, b, _), [se, ie] = N3(e.textAnchorOffsets, U);
  R && (Ve = q3(Ve, b)), e.symbolInstances.emplaceBack(t.x, t.y, Ee.right >= 0 ? Ee.right : -1, Ee.center >= 0 ? Ee.center : -1, Ee.left >= 0 ? Ee.left : -1, Ee.vertical || -1, ue, be, Ve, mr, Ze, Qt, er, tr, Et, gr, Ci, u, re, oe, z, O, xr, 0, p, Oe, se, ie, L);
}
function j3(e, t, r, i) {
  let n = e.compareText;
  if (!(t in n)) n[t] = [];
  else {
    let a = n[t];
    for (let s = a.length - 1; s >= 0; s--) if (i.dist(a[s]) < r) return !0;
  }
  return n[t].push(i), !1;
}
function q3(e, t) {
  var r;
  return t.id == null || (r = t.properties) != null && r.cluster ? e : (0, Wa.default)(String(t.id), e);
}
function Lp(e, t, r) {
  let i = "never", n = e.get(t);
  return n ? i = n : e.get(r) && (i = "always"), i;
}
const G3 = [{ name: "a_fade_opacity", components: 1, type: "Uint8", offset: 0 }];
function Ea(e, t, r, i, n, a, s, o, l, u, c, h, p, f) {
  let d = o ? Math.min(Tp, Math.round(o[0])) : 0, y = o ? Math.min(Tp, Math.round(o[1])) : 0;
  e.emplaceBack(t, r, Math.round(i * 32), Math.round(n * 32), a, s, (d << 1) + +!!l, y, u * 16, c * 16, h * 256, p * 256, f);
}
function X3(e, t, r) {
  e.emplaceBack(t.x, t.y, r), e.emplaceBack(t.x, t.y, r), e.emplaceBack(t.x, t.y, r), e.emplaceBack(t.x, t.y, r);
}
function Y3(e) {
  for (let t of e.sections) if (i1(t.text)) return !0;
  return !1;
}
function W3(e) {
  return e.sections.some((t) => !e1(t.text));
}
var Nl = class {
  constructor(e) {
    this.layoutVertexArray = new Fx(), this.indexArray = new Nn(), this.programConfigurations = e, this.segments = new ut(), this.dynamicLayoutVertexArray = new Mx(), this.opacityVertexArray = new Px(), this.hasVisibleVertices = !1, this.placedSymbolArray = new Rd();
  }
  isEmpty() {
    return this.layoutVertexArray.length === 0 && this.indexArray.length === 0 && this.dynamicLayoutVertexArray.length === 0 && this.opacityVertexArray.length === 0;
  }
  upload(e, t, r, i) {
    this.isEmpty() || (r && (this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, Hb.members), this.indexBuffer = e.createIndexBuffer(this.indexArray, t), this.dynamicLayoutVertexBuffer = e.createVertexBuffer(this.dynamicLayoutVertexArray, Kb.members, !0), this.opacityVertexBuffer = e.createVertexBuffer(this.opacityVertexArray, G3, !0), this.opacityVertexBuffer.itemSize = 1), (r || i) && this.programConfigurations.upload(e));
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.programConfigurations.destroy(), this.segments.destroy(), this.dynamicLayoutVertexBuffer.destroy(), this.opacityVertexBuffer.destroy());
  }
};
P("SymbolBuffers", Nl);
var Ul = class {
  constructor(e, t, r) {
    this.layoutVertexArray = new e(), this.layoutAttributes = t, this.indexArray = new r(), this.segments = new ut(), this.collisionVertexArray = new Bx();
  }
  upload(e) {
    this.layoutVertexBuffer = e.createVertexBuffer(this.layoutVertexArray, this.layoutAttributes), this.indexBuffer = e.createIndexBuffer(this.indexArray), this.collisionVertexBuffer = e.createVertexBuffer(this.collisionVertexArray, Jb.members, !0);
  }
  destroy() {
    this.layoutVertexBuffer && (this.layoutVertexBuffer.destroy(), this.indexBuffer.destroy(), this.segments.destroy(), this.collisionVertexBuffer.destroy());
  }
};
P("CollisionBuffers", Ul);
var C1 = class {
  constructor(e) {
    this.collisionBoxArray = e.collisionBoxArray, this.zoom = e.zoom, this.overscaling = e.overscaling, this.layers = e.layers, this.layerIds = this.layers.map((s) => s.id), this.index = e.index, this.pixelRatio = e.pixelRatio, this.sourceLayerIndex = e.sourceLayerIndex, this.hasDependencies = !0, this.hasRTLText = !1, this.hasCursiveText = !1, this.maxHeightOffset = 0, this.sortKeyRanges = [], this.collisionCircleArray = [], this.maxGlyphs = 65535;
    let t = this.layers[0]._unevaluatedLayout._values;
    this.textSizeData = Ip(this.zoom, t["text-size"]), this.iconSizeData = Ip(this.zoom, t["icon-size"]);
    let r = this.layers[0].layout, i = r.get("symbol-sort-key"), n = r.get("symbol-z-order");
    this.canOverlap = Lp(r, "text-overlap", "text-allow-overlap") !== "never" || Lp(r, "icon-overlap", "icon-allow-overlap") !== "never" || r.get("text-ignore-placement") || r.get("icon-ignore-placement"), this.sortFeaturesByKey = n !== "viewport-y" && !i.isConstant();
    let a = n === "viewport-y" || n === "auto" && !this.sortFeaturesByKey;
    this.sortFeaturesByY = a && this.canOverlap, r.get("symbol-placement") === "point" && (this.writingModes = r.get("text-writing-mode").map((s) => c1[s])), this.stateDependentLayerIds = this.layers.filter((s) => s.isStateDependent()).map((s) => s.id), this.sourceID = e.sourceID;
  }
  createArrays() {
    this.text = new Nl(new Br(this.layers, this.zoom, (e) => e.startsWith("text"))), this.icon = new Nl(new Br(this.layers, this.zoom, (e) => e.startsWith("icon"))), this.glyphOffsetArray = new Ud(), this.lineVertexArray = new jd(), this.symbolInstances = new Nd(), this.textAnchorOffsets = new Gd();
  }
  calculateGlyphDependencies(e, t, r, i) {
    var s;
    let n = Xu.fromFeature(e, r, !1), a = n.graphemes();
    for (let o = 0; o < a.length; o++) {
      let l = n.getSection(o);
      if ("imageName" in l) continue;
      t[s = l.fontStack] || (t[s] = { default: {}, vertical: {} });
      let u = t[l.fontStack], c = a[o], h = i && d3(c.codePointAt(0), this.allowVerticalPlacement);
      zl(c) && (u.default[c] = !0), h && (u.vertical[c] = !0);
      for (let p of c) {
        if (u.default[p] = !0, !i) continue;
        h && zl(c) && (u.vertical[p] = !0);
        let f = ii[p];
        f && (u.default[f] = !0);
      }
    }
  }
  populate(e, t, r) {
    var g;
    let i = this.layers[0], n = i.layout, a = n.get("text-font"), s = n.get("text-field"), o = n.get("icon-image"), l = (s.value.kind !== "constant" || s.value.value instanceof Ht && !s.value.value.isEmpty() || s.value.value.toString().length > 0) && (a.value.kind !== "constant" || a.value.value.length > 0), u = o.value.kind !== "constant" || !!o.value.value || Object.keys(o.parameters).length > 0, c = n.get("symbol-sort-key"), h = n.get("symbol-placement") === "point";
    if (this.features = [], !l && !u) return;
    let p = t.iconDependencies, f = t.glyphDependencies, d = t.availableImages, y = new le(this.zoom), m = n.get("text-keep-upright");
    for (let { feature: v, id: x, index: b, sourceLayerIndex: w } of e) {
      let D = i._featureFilter.needGeometry, _ = Ei(v, D);
      if (!i._featureFilter.filter(y, _, r) || (D || (_.geometry = Or(v)), h && v.type === 1 && Z3(_.geometry))) continue;
      let A;
      if (l) {
        let L = i.getValueAndResolveTokens("text-field", _, r, d), $ = Ht.factory(L);
        this.hasRTLText || (this.hasRTLText = Y3($)), this.hasCursiveText || (this.hasCursiveText = W3($)), A = ww($, i, _);
      }
      let E;
      if (u) {
        let L = i.getValueAndResolveTokens("icon-image", _, r, d);
        E = L instanceof zt ? L : zt.fromString(L);
      }
      if (!A && !E) continue;
      let R = this.sortFeaturesByKey ? c.evaluate(_, {}, r) : void 0, B = { id: x, text: A, icon: E, index: b, sourceLayerIndex: w, geometry: _.geometry, properties: v.properties, type: Un.types[v.type], sortKey: R };
      if (this.features.push(B), E && (p[E.name] = !0), A) {
        let L = a.evaluate(_, {}, r).join(","), $ = n.get("text-rotation-alignment") !== "viewport" && n.get("symbol-placement") !== "point";
        this.allowVerticalPlacement = (g = this.writingModes) == null ? void 0 : g.includes(2);
        let M = ($ && m || this.allowVerticalPlacement) && Vl(A.toString());
        this.calculateGlyphDependencies(A, f, L, M);
        for (let C of A.sections) C.image && (p[C.image.name] = !0);
      }
    }
    n.get("symbol-placement") === "line" && (this.features = Dw(this.features)), this.sortFeaturesByKey && this.features.sort((v, x) => v.sortKey - x.sortKey);
  }
  update(e, t, r) {
    this.stateDependentLayers.length && (this.text.programConfigurations.updatePaintArrays(e, t, this.layers, { imagePositions: r }), this.icon.programConfigurations.updatePaintArrays(e, t, this.layers, { imagePositions: r }));
  }
  addFeatures({ options: e, canonical: t, glyphMap: r, glyphPositions: i, iconMap: n, iconPositions: a, showCollisionBoxes: s }) {
    R3({ bucket: this, glyphMap: r, glyphPositions: i, imageMap: n, imagePositions: a, showCollisionBoxes: s, canonical: t, subdivisionGranularity: e.subdivisionGranularity, hasPromoteId: e.featureIndex.promoteId != null });
  }
  isEmpty() {
    return this.symbolInstances.length === 0;
  }
  uploadPending() {
    return !this.uploaded || this.text.programConfigurations.needsUpload || this.icon.programConfigurations.needsUpload;
  }
  upload(e) {
    !this.uploaded && this.hasDebugData() && (this.textCollisionBox.upload(e), this.iconCollisionBox.upload(e)), this.text.upload(e, this.sortFeaturesByY, !this.uploaded, this.text.programConfigurations.needsUpload), this.icon.upload(e, this.sortFeaturesByY, !this.uploaded, this.icon.programConfigurations.needsUpload), this.uploaded = !0;
  }
  destroyDebugData() {
    this.textCollisionBox.destroy(), this.iconCollisionBox.destroy();
  }
  destroy() {
    this.text.destroy(), this.icon.destroy(), this.hasDebugData() && this.destroyDebugData();
  }
  addToLineVertexArray(e, t) {
    let r = this.lineVertexArray.length;
    if (e.segment !== void 0) {
      let i = e.dist(t[e.segment + 1]), n = e.dist(t[e.segment]), a = {};
      for (let s = e.segment + 1; s < t.length; s++) a[s] = { x: t[s].x, y: t[s].y, tileUnitDistanceFromAnchor: i }, s < t.length - 1 && (i += t[s + 1].dist(t[s]));
      for (let s = e.segment || 0; s >= 0; s--) a[s] = { x: t[s].x, y: t[s].y, tileUnitDistanceFromAnchor: n }, s > 0 && (n += t[s - 1].dist(t[s]));
      for (let s = 0; s < t.length; s++) {
        let o = a[s];
        this.lineVertexArray.emplaceBack(o.x, o.y, o.tileUnitDistanceFromAnchor);
      }
    }
    return { lineStartIndex: r, lineLength: this.lineVertexArray.length - r };
  }
  addSymbols(e, t, r, i, n, a, s, o, l, u, c, h, p) {
    let f = e.indexArray, d = e.layoutVertexArray, y = e.segments.prepareSegment(4 * t.length, d, f, this.canOverlap ? a.sortKey : void 0), m = this.glyphOffsetArray.length, g = y.vertexLength, v = this.allowVerticalPlacement && s === 2 ? Math.PI / 2 : 0, x = a.text && a.text.sections;
    for (let b = 0; b < t.length; b++) {
      let { tl: w, tr: D, bl: _, br: A, tex: E, pixelOffsetTL: R, pixelOffsetBR: B, minFontScaleX: L, minFontScaleY: $, glyphOffset: M, isSDF: C, sectionIndex: N } = t[b], z = y.vertexLength, O = M[1];
      Ea(d, o.x, o.y, w.x, O + w.y, E.x, E.y, r, C, R.x, R.y, L, $, p), Ea(d, o.x, o.y, D.x, O + D.y, E.x + E.w, E.y, r, C, B.x, R.y, L, $, p), Ea(d, o.x, o.y, _.x, O + _.y, E.x, E.y + E.h, r, C, R.x, B.y, L, $, p), Ea(d, o.x, o.y, A.x, O + A.y, E.x + E.w, E.y + E.h, r, C, B.x, B.y, L, $, p), X3(e.dynamicLayoutVertexArray, o, v), f.emplaceBack(z, z + 2, z + 1), f.emplaceBack(z + 1, z + 2, z + 3), y.vertexLength += 4, y.primitiveLength += 2, this.glyphOffsetArray.emplaceBack(M[0]), (b === t.length - 1 || N !== t[b + 1].sectionIndex) && e.programConfigurations.populatePaintArrays(d.length, a, a.index, { imagePositions: {}, canonical: h, formattedSection: x == null ? void 0 : x[N] });
    }
    e.placedSymbolArray.emplaceBack(o.x, o.y, m, this.glyphOffsetArray.length - m, g, l, u, o.segment, r ? r[0] : 0, r ? r[1] : 0, i[0], i[1], s, 0, !1, 0, c, p);
  }
  _addCollisionDebugVertex(e, t, r, i, n, a) {
    return t.emplaceBack(0, 0), e.emplaceBack(r.x, r.y, i, n, Math.round(a.x), Math.round(a.y));
  }
  addCollisionDebugVertices(e, t, r, i, n, a, s) {
    let o = n.segments.prepareSegment(4, n.layoutVertexArray, n.indexArray), l = o.vertexLength, u = n.layoutVertexArray, c = n.collisionVertexArray, h = s.anchorX, p = s.anchorY;
    this._addCollisionDebugVertex(u, c, a, h, p, new T(e, t)), this._addCollisionDebugVertex(u, c, a, h, p, new T(r, t)), this._addCollisionDebugVertex(u, c, a, h, p, new T(r, i)), this._addCollisionDebugVertex(u, c, a, h, p, new T(e, i)), o.vertexLength += 4;
    let f = n.indexArray;
    f.emplaceBack(l, l + 1), f.emplaceBack(l + 1, l + 2), f.emplaceBack(l + 2, l + 3), f.emplaceBack(l + 3, l), o.primitiveLength += 4;
  }
  addDebugCollisionBoxes(e, t, r, i) {
    for (let n = e; n < t; n++) {
      let a = this.collisionBoxArray.get(n), s = a.x1, o = a.y1, l = a.x2, u = a.y2;
      this.addCollisionDebugVertices(s, o, l, u, i ? this.textCollisionBox : this.iconCollisionBox, a.anchorPoint, r);
    }
  }
  generateCollisionDebugBuffers() {
    this.hasDebugData() && this.destroyDebugData(), this.textCollisionBox = new Ul(Sh, up.members, fl), this.iconCollisionBox = new Ul(Sh, up.members, fl);
    for (let e = 0; e < this.symbolInstances.length; e++) {
      let t = this.symbolInstances.get(e);
      this.addDebugCollisionBoxes(t.textBoxStartIndex, t.textBoxEndIndex, t, !0), this.addDebugCollisionBoxes(t.verticalTextBoxStartIndex, t.verticalTextBoxEndIndex, t, !0), this.addDebugCollisionBoxes(t.iconBoxStartIndex, t.iconBoxEndIndex, t, !1), this.addDebugCollisionBoxes(t.verticalIconBoxStartIndex, t.verticalIconBoxEndIndex, t, !1);
    }
  }
  _deserializeCollisionBoxesForSymbol(e, t, r, i, n, a, s, o, l) {
    let u = {};
    for (let c = t; c < r; c++) {
      let h = e.get(c);
      u.textBox = { x1: h.x1, y1: h.y1, x2: h.x2, y2: h.y2, anchorPointX: h.anchorPointX, anchorPointY: h.anchorPointY }, u.textFeatureIndex = h.featureIndex;
      break;
    }
    for (let c = i; c < n; c++) {
      let h = e.get(c);
      u.verticalTextBox = { x1: h.x1, y1: h.y1, x2: h.x2, y2: h.y2, anchorPointX: h.anchorPointX, anchorPointY: h.anchorPointY }, u.verticalTextFeatureIndex = h.featureIndex;
      break;
    }
    for (let c = a; c < s; c++) {
      let h = e.get(c);
      u.iconBox = { x1: h.x1, y1: h.y1, x2: h.x2, y2: h.y2, anchorPointX: h.anchorPointX, anchorPointY: h.anchorPointY }, u.iconFeatureIndex = h.featureIndex;
      break;
    }
    for (let c = o; c < l; c++) {
      let h = e.get(c);
      u.verticalIconBox = { x1: h.x1, y1: h.y1, x2: h.x2, y2: h.y2, anchorPointX: h.anchorPointX, anchorPointY: h.anchorPointY }, u.verticalIconFeatureIndex = h.featureIndex;
      break;
    }
    return u;
  }
  deserializeCollisionBoxes(e) {
    this.collisionArrays = [];
    for (let t = 0; t < this.symbolInstances.length; t++) {
      let r = this.symbolInstances.get(t);
      this.collisionArrays.push(this._deserializeCollisionBoxesForSymbol(e, r.textBoxStartIndex, r.textBoxEndIndex, r.verticalTextBoxStartIndex, r.verticalTextBoxEndIndex, r.iconBoxStartIndex, r.iconBoxEndIndex, r.verticalIconBoxStartIndex, r.verticalIconBoxEndIndex));
    }
  }
  hasTextData() {
    return this.text.segments.get().length > 0;
  }
  hasIconData() {
    return this.icon.segments.get().length > 0;
  }
  hasDebugData() {
    return this.textCollisionBox && this.iconCollisionBox;
  }
  hasTextCollisionBoxData() {
    return this.hasDebugData() && this.textCollisionBox.segments.get().length > 0;
  }
  hasIconCollisionBoxData() {
    return this.hasDebugData() && this.iconCollisionBox.segments.get().length > 0;
  }
  addIndicesForPlacedSymbol(e, t) {
    let r = e.placedSymbolArray.get(t), i = r.vertexStartIndex + r.numGlyphs * 4;
    for (let n = r.vertexStartIndex; n < i; n += 4) e.indexArray.emplaceBack(n, n + 2, n + 1), e.indexArray.emplaceBack(n + 1, n + 2, n + 3);
  }
  getSortedSymbolIndexes(e) {
    if (this.sortedAngle === e && this.symbolInstanceIndexes !== void 0) return this.symbolInstanceIndexes;
    let t = Math.sin(e), r = Math.cos(e), i = [], n = [], a = [];
    for (let s = 0; s < this.symbolInstances.length; ++s) {
      a.push(s);
      let o = this.symbolInstances.get(s);
      i.push(Math.round(t * o.anchorX + r * o.anchorY) | 0), n.push(o.featureIndex);
    }
    return a.sort((s, o) => i[s] - i[o] || n[o] - n[s]), a;
  }
  addToSortKeyRanges(e, t) {
    let r = this.sortKeyRanges[this.sortKeyRanges.length - 1];
    (r == null ? void 0 : r.sortKey) === t ? r.symbolInstanceEnd = e + 1 : this.sortKeyRanges.push({ sortKey: t, symbolInstanceStart: e, symbolInstanceEnd: e + 1 });
  }
  sortFeatures(e) {
    if (this.sortFeaturesByY && this.sortedAngle !== e && !(this.text.segments.get().length > 1 || this.icon.segments.get().length > 1)) {
      this.symbolInstanceIndexes = this.getSortedSymbolIndexes(e), this.sortedAngle = e, this.text.indexArray.clear(), this.icon.indexArray.clear(), this.featureSortOrder = [];
      for (let t of this.symbolInstanceIndexes) {
        let r = this.symbolInstances.get(t);
        this.featureSortOrder.push(r.featureIndex);
        let i = [r.rightJustifiedTextSymbolIndex, r.centerJustifiedTextSymbolIndex, r.leftJustifiedTextSymbolIndex];
        for (let n = 0; n < i.length; n++) {
          let a = i[n];
          a >= 0 && i.indexOf(a) === n && this.addIndicesForPlacedSymbol(this.text, a);
        }
        r.verticalPlacedTextSymbolIndex >= 0 && this.addIndicesForPlacedSymbol(this.text, r.verticalPlacedTextSymbolIndex), r.placedIconSymbolIndex >= 0 && this.addIndicesForPlacedSymbol(this.icon, r.placedIconSymbolIndex), r.verticalPlacedIconSymbolIndex >= 0 && this.addIndicesForPlacedSymbol(this.icon, r.verticalPlacedIconSymbolIndex);
      }
      this.text.indexBuffer && this.text.indexBuffer.updateData(this.text.indexArray), this.icon.indexBuffer && this.icon.indexBuffer.updateData(this.icon.indexArray);
    }
  }
};
function Z3(e) {
  return e.every((t) => t.every(Cu));
}
P("SymbolBucket", C1, { omit: ["layers", "collisionBoxArray", "features", "compareText"] });
function H3(e, t) {
  return t.replace(/{([^{}]+)}/g, (r, i) => e && i in e ? String(e[i]) : "");
}
let K3;
const J3 = () => K3 || (K3 = new Je({ "symbol-placement": new V(S.layout_symbol["symbol-placement"], "symbol-placement"), "symbol-spacing": new V(S.layout_symbol["symbol-spacing"], "symbol-spacing"), "symbol-avoid-edges": new V(S.layout_symbol["symbol-avoid-edges"], "symbol-avoid-edges"), "symbol-sort-key": new j(S.layout_symbol["symbol-sort-key"], "symbol-sort-key"), "symbol-z-order": new V(S.layout_symbol["symbol-z-order"], "symbol-z-order"), "icon-allow-overlap": new V(S.layout_symbol["icon-allow-overlap"], "icon-allow-overlap"), "icon-overlap": new V(S.layout_symbol["icon-overlap"], "icon-overlap"), "icon-ignore-placement": new V(S.layout_symbol["icon-ignore-placement"], "icon-ignore-placement"), "icon-optional": new V(S.layout_symbol["icon-optional"], "icon-optional"), "icon-rotation-alignment": new j(S.layout_symbol["icon-rotation-alignment"], "icon-rotation-alignment"), "icon-size": new j(S.layout_symbol["icon-size"], "icon-size"), "icon-text-fit": new V(S.layout_symbol["icon-text-fit"], "icon-text-fit"), "icon-text-fit-padding": new V(S.layout_symbol["icon-text-fit-padding"], "icon-text-fit-padding"), "icon-image": new j(S.layout_symbol["icon-image"], "icon-image"), "icon-rotate": new j(S.layout_symbol["icon-rotate"], "icon-rotate"), "icon-padding": new j(S.layout_symbol["icon-padding"], "icon-padding"), "icon-keep-upright": new V(S.layout_symbol["icon-keep-upright"], "icon-keep-upright"), "icon-offset": new j(S.layout_symbol["icon-offset"], "icon-offset"), "icon-anchor": new j(S.layout_symbol["icon-anchor"], "icon-anchor"), "icon-pitch-alignment": new V(S.layout_symbol["icon-pitch-alignment"], "icon-pitch-alignment"), "text-pitch-alignment": new V(S.layout_symbol["text-pitch-alignment"], "text-pitch-alignment"), "text-rotation-alignment": new V(S.layout_symbol["text-rotation-alignment"], "text-rotation-alignment"), "text-field": new j(S.layout_symbol["text-field"], "text-field"), "text-font": new j(S.layout_symbol["text-font"], "text-font"), "text-size": new j(S.layout_symbol["text-size"], "text-size"), "text-max-width": new j(S.layout_symbol["text-max-width"], "text-max-width"), "text-line-height": new V(S.layout_symbol["text-line-height"], "text-line-height"), "text-letter-spacing": new j(S.layout_symbol["text-letter-spacing"], "text-letter-spacing"), "text-justify": new j(S.layout_symbol["text-justify"], "text-justify"), "text-radial-offset": new j(S.layout_symbol["text-radial-offset"], "text-radial-offset"), "text-variable-anchor": new V(S.layout_symbol["text-variable-anchor"], "text-variable-anchor"), "text-variable-anchor-offset": new j(S.layout_symbol["text-variable-anchor-offset"], "text-variable-anchor-offset"), "text-anchor": new j(S.layout_symbol["text-anchor"], "text-anchor"), "text-max-angle": new V(S.layout_symbol["text-max-angle"], "text-max-angle"), "text-writing-mode": new V(S.layout_symbol["text-writing-mode"], "text-writing-mode"), "text-rotate": new j(S.layout_symbol["text-rotate"], "text-rotate"), "text-padding": new V(S.layout_symbol["text-padding"], "text-padding"), "text-keep-upright": new V(S.layout_symbol["text-keep-upright"], "text-keep-upright"), "text-transform": new j(S.layout_symbol["text-transform"], "text-transform"), "text-offset": new j(S.layout_symbol["text-offset"], "text-offset"), "text-allow-overlap": new V(S.layout_symbol["text-allow-overlap"], "text-allow-overlap"), "text-overlap": new V(S.layout_symbol["text-overlap"], "text-overlap"), "text-ignore-placement": new V(S.layout_symbol["text-ignore-placement"], "text-ignore-placement"), "text-optional": new V(S.layout_symbol["text-optional"], "text-optional"), "symbol-height-offset": new j(S.layout_symbol["symbol-height-offset"], "symbol-height-offset"), "symbol-height-anchor": new V(S.layout_symbol["symbol-height-anchor"], "symbol-height-anchor") }));
let Q3;
const e6 = () => Q3 || (Q3 = new Je({ "icon-opacity": new j(S.paint_symbol["icon-opacity"], "icon-opacity"), "icon-color": new j(S.paint_symbol["icon-color"], "icon-color"), "icon-halo-color": new j(S.paint_symbol["icon-halo-color"], "icon-halo-color"), "icon-halo-width": new j(S.paint_symbol["icon-halo-width"], "icon-halo-width"), "icon-halo-blur": new j(S.paint_symbol["icon-halo-blur"], "icon-halo-blur"), "icon-translate": new V(S.paint_symbol["icon-translate"], "icon-translate"), "icon-translate-anchor": new V(S.paint_symbol["icon-translate-anchor"], "icon-translate-anchor"), "text-opacity": new j(S.paint_symbol["text-opacity"], "text-opacity"), "text-color": new j(S.paint_symbol["text-color"], "text-color", { runtimeType: Dt, getOverride: (e) => e.textColor, hasOverride: (e) => !!e.textColor }), "text-halo-color": new j(S.paint_symbol["text-halo-color"], "text-halo-color"), "text-halo-width": new j(S.paint_symbol["text-halo-width"], "text-halo-width"), "text-halo-blur": new j(S.paint_symbol["text-halo-blur"], "text-halo-blur"), "text-translate": new V(S.paint_symbol["text-translate"], "text-translate"), "text-translate-anchor": new V(S.paint_symbol["text-translate-anchor"], "text-translate-anchor") }));
var Co = { get paint() {
  return e6();
}, get layout() {
  return J3();
} }, k1 = class {
  constructor(e) {
    if (e.property.overrides === void 0) throw Error("overrides must be provided to instantiate FormatSectionOverride class");
    this.type = e.property.overrides ? e.property.overrides.runtimeType : Bn, this.defaultValue = e;
  }
  evaluate(e) {
    if (e.formattedSection) {
      let t = this.defaultValue.property.overrides;
      if (t != null && t.hasOverride(e.formattedSection)) return t.getOverride(e.formattedSection);
    }
    return e.feature && e.featureState ? this.defaultValue.evaluate(e.feature, e.featureState) : this.defaultValue.property.specification.default;
  }
  eachChild(e) {
    if (!this.defaultValue.isConstant()) {
      let t = this.defaultValue.value;
      e(t._styleExpression.expression);
    }
  }
  outputDefined() {
    return !1;
  }
  serialize() {
    return null;
  }
};
P("FormatSectionOverride", k1, { omit: ["defaultValue"] });
var t6 = class jl extends At {
  constructor(t, r) {
    super(t, Co, r);
  }
  recalculate(t, r) {
    super.recalculate(t, r);
    let i = this.layout.get("icon-rotation-alignment");
    if ((i.value.kind !== "constant" || i.value.value === "auto") && (this.layout._values["icon-rotation-alignment"] = new mt(i.property, { kind: "constant", value: this.layout.get("symbol-placement") === "point" ? "viewport" : "map" }, i.parameters)), this.layout.get("text-rotation-alignment") === "auto" && (this.layout.get("symbol-placement") === "point" ? this.layout._values["text-rotation-alignment"] = "viewport" : this.layout._values["text-rotation-alignment"] = "map"), this.layout.get("text-pitch-alignment") === "auto" && (this.layout._values["text-pitch-alignment"] = this.layout.get("text-rotation-alignment") === "map" ? "map" : "viewport"), this.layout.get("icon-pitch-alignment") === "auto" && (this.layout._values["icon-pitch-alignment"] = this.layout.get("icon-rotation-alignment").constantOr("viewport")), this.layout.get("symbol-placement") === "point") {
      let n = this.layout.get("text-writing-mode");
      if (n) {
        let a = [];
        for (let s of n) a.includes(s) || a.push(s);
        this.layout._values["text-writing-mode"] = a;
      } else this.layout._values["text-writing-mode"] = ["horizontal"];
    }
    this._setPaintOverrides();
  }
  getValueAndResolveTokens(t, r, i, n) {
    let a = this.layout.get(t).evaluate(r, {}, i, n), s = this._unevaluatedLayout._values[t];
    return !s.isDataDriven() && !gs(s.value) && a ? H3(r.properties, a) : a;
  }
  createBucket(t) {
    return new C1(t);
  }
  queryRadius() {
    return 0;
  }
  queryIntersectsFeature() {
    throw Error("Should take a different path in FeatureIndex");
  }
  _setPaintOverrides() {
    for (let t of Co.paint.overridableProperties) {
      if (!jl.hasPaintOverride(this.layout, t)) continue;
      let r = this.paint.get(t), i = new vu(new k1(r), `layers[${this.id}].paint.${r.property.name}`, r.property.specification), n = null;
      n = r.value.kind === "constant" || r.value.kind === "source" ? new bn("source", i) : new ja("composite", i, r.value.zoomStops), this.paint._values[t] = new mt(r.property, n, r.parameters);
    }
  }
  _handleOverridablePaintPropertyUpdate(t, r, i) {
    return !this.layout || r.isDataDriven() || i.isDataDriven() ? !1 : jl.hasPaintOverride(this.layout, t);
  }
  static hasPaintOverride(t, r) {
    let i = t.get("text-field"), n = Co.paint.properties[r], a = !1, s = (o) => {
      var l;
      for (let u of o) if ((l = n.overrides) != null && l.hasOverride(u)) {
        a = !0;
        return;
      }
    };
    if (i.value.kind === "constant" && i.value.value instanceof Ht) s(i.value.value.sections);
    else if (i.value.kind === "source" || i.value.kind === "composite") {
      let o = (u) => {
        if (!a)
          if (u instanceof mi && Ae(u.value) === Ln) {
            let c = u.value;
            s(c.sections);
          } else u instanceof Gf ? s(u.sections) : u.eachChild(o);
      }, l = i.value;
      l._styleExpression && o(l._styleExpression.expression);
    }
    return a;
  }
};
function r6(e, t, r, i = 1) {
  var a;
  let n = (a = e.get("icon-padding").evaluate(t, {}, r)) == null ? void 0 : a.values;
  return [n[0] * i, n[1] * i, n[2] * i, n[3] * i];
}
let i6;
const n6 = () => i6 || (i6 = new Je({ "background-color": new V(S.paint_background["background-color"], "background-color"), "background-pattern": new Ld(S.paint_background["background-pattern"], "background-pattern"), "background-opacity": new V(S.paint_background["background-opacity"], "background-opacity") }));
var a6 = { get paint() {
  return n6();
} }, s6 = class extends At {
  constructor(e, t) {
    super(e, a6, t);
  }
};
let o6;
const l6 = () => o6 || (o6 = new Je({ "raster-opacity": new V(S.paint_raster["raster-opacity"], "raster-opacity"), "raster-layer-blend": new V(S.paint_raster["raster-layer-blend"], "raster-layer-blend"), "raster-hue-rotate": new V(S.paint_raster["raster-hue-rotate"], "raster-hue-rotate"), "raster-brightness-min": new V(S.paint_raster["raster-brightness-min"], "raster-brightness-min"), "raster-brightness-max": new V(S.paint_raster["raster-brightness-max"], "raster-brightness-max"), "raster-saturation": new V(S.paint_raster["raster-saturation"], "raster-saturation"), "raster-contrast": new V(S.paint_raster["raster-contrast"], "raster-contrast"), resampling: new V(S.paint_raster.resampling, "resampling"), "raster-resampling": new V(S.paint_raster["raster-resampling"], "raster-resampling"), "raster-fade-duration": new V(S.paint_raster["raster-fade-duration"], "raster-fade-duration") }));
var u6 = { get paint() {
  return l6();
} }, c6 = class extends At {
  constructor(e, t) {
    super(e, u6, t);
  }
}, h6 = class extends At {
  constructor(e, t) {
    super(e, {}, t), this.onAdd = (r) => {
      this.implementation.onAdd && this.implementation.onAdd(r, r.painter.context.gl);
    }, this.onRemove = (r) => {
      this.implementation.onRemove && this.implementation.onRemove(r, r.painter.context.gl);
    }, this.implementation = e;
  }
  is3D() {
    return this.implementation.renderingMode === "3d";
  }
  hasOffscreenPass() {
    return this.implementation.prerender !== void 0;
  }
  recalculate() {
  }
  updateTransitions() {
  }
  hasTransition() {
    return !1;
  }
  serialize() {
    throw Error("Custom layers cannot be serialized");
  }
};
function p6(e, t) {
  if (e.type === "custom") return new h6(e, t);
  switch (e.type) {
    case "background":
      return new s6(e, t);
    case "circle":
      return new B2(e, t);
    case "color-relief":
      return new Y2(e, t);
    case "fill":
      return new Iv(e, t);
    case "fill-extrusion":
      return new Wv(e, t);
    case "heatmap":
      return new R2(e, t);
    case "hillshade":
      return new j2(e, t);
    case "line":
      return new Zb(e, t);
    case "raster":
      return new c6(e, t);
    case "symbol":
      return new t6(e, t);
  }
}
var f6 = class {
  constructor(e, t) {
    this.feature = e, this.type = e.type, this.properties = e.tags ? e.tags : {}, this.extent = t, "id" in e && (typeof e.id == "string" ? this.id = parseInt(e.id, 10) : typeof e.id == "number" && !isNaN(e.id) && (this.id = e.id));
  }
  loadGeometry() {
    let e = [], t = this.feature.type === 1 ? [this.feature.geometry] : this.feature.geometry;
    for (let r of t) {
      let i = [];
      for (let n of r) i.push(new T(n[0], n[1]));
      e.push(i);
    }
    return e;
  }
};
const ql = "_geojsonTileLayer";
var d6 = class {
  constructor(e, t) {
    this.layers = { [ql]: this }, this.name = ql, this.version = t ? t.version : 1, this.extent = t ? t.extent : 4096, this.length = e.length, this.features = e;
  }
  feature(e) {
    return new f6(this.features[e], this.extent);
  }
};
function F1(e, t = "") {
  let r = new jw();
  return y6(e, r, t), r.finish();
}
function y6(e, t, r = "") {
  for (let i in e.layers) t.writeMessage(3, (n, a) => m6(n, a, r), e.layers[i]);
}
function m6(e, t, r = "") {
  t.writeVarintField(15, e.version || 1), t.writeStringField(1, e.name || ""), t.writeVarintField(5, e.extent || 4096);
  let i = { jsonPrefix: r, keys: [], values: [], keycache: {}, valuecache: {} };
  for (let s = 0; s < e.length; s++) i.feature = e.feature(s), t.writeMessage(2, g6, i);
  let n = i.keys;
  for (let s of n) t.writeStringField(3, s);
  let a = i.values;
  for (let s of a) t.writeMessage(4, b6, s);
}
function g6(e, t) {
  if (!e.feature) return;
  let r = e.feature;
  r.id !== void 0 && t.writeVarintField(1, r.id), t.writeMessage(2, x6, e), t.writeVarintField(3, r.type), t.writeMessage(4, v6, r);
}
function x6(e, t) {
  var r;
  for (let i in (r = e.feature) == null ? void 0 : r.properties) {
    let n = e.feature.properties[i], a = e.keycache[i];
    if (n == null) continue;
    a === void 0 && (e.keys.push(i), a = e.keys.length - 1, e.keycache[i] = a), t.writeVarint(a), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && (n = e.jsonPrefix + JSON.stringify(n));
    let s = typeof n + ":" + n, o = e.valuecache[s];
    o === void 0 && (e.values.push(n), o = e.values.length - 1, e.valuecache[s] = o), t.writeVarint(o);
  }
}
function ko(e, t) {
  return (t << 3) + (e & 7);
}
function zp(e) {
  return e << 1 ^ e >> 31;
}
function v6(e, t) {
  let r = e.loadGeometry(), i = e.type, n = 0, a = 0;
  for (let s of r) {
    let o = 1;
    i === 1 && (o = s.length), t.writeVarint(ko(1, o));
    let l = s[s.length - 1], u = i === 3 && s.length > 1 && l.x === s[0].x && l.y === s[0].y ? s.length - 1 : s.length;
    for (let c = 0; c < u; c++) {
      c === 1 && i !== 1 && t.writeVarint(ko(2, u - 1));
      let h = s[c].x - n, p = s[c].y - a;
      t.writeVarint(zp(h)), t.writeVarint(zp(p)), n += h, a += p;
    }
    e.type === 3 && t.writeVarint(ko(7, 1));
  }
}
function b6(e, t) {
  let r = typeof e;
  r === "string" ? t.writeStringField(1, e) : r === "boolean" ? t.writeBooleanField(7, e) : r === "number" && (e % 1 == 0 ? e < 0 ? t.writeSVarintField(6, e) : t.writeVarintField(5, e) : t.writeDoubleField(3, e));
}
var M1 = class {
  constructor(e) {
    this._stringToNumber = {}, this._numberToString = [];
    for (let t = 0; t < e.length; t++) {
      let r = e[t];
      this._stringToNumber[r] = t, this._numberToString[t] = r;
    }
  }
  encode(e) {
    return this._stringToNumber[e];
  }
  decode(e) {
    if (e >= this._numberToString.length) throw Error(`Out of bounds. Index requested n=${e} can't be >= this._numberToString.length ${this._numberToString.length}`);
    return this._numberToString[e];
  }
}, dr, w6 = (dr = class {
  constructor(t, r, i, n, a, s) {
    this.type = "Feature", this._vectorTileFeature = t, this._x = i, this._y = n, this._z = r, s !== Qx && dr.worldCoordinateHelpers.set(this, s);
    for (let o in t.properties) typeof t.properties[o] == "string" && t.properties[o].startsWith("__$json__:") && (t.properties[o] = JSON.parse(t.properties[o].slice(10)));
    this.properties = t.properties, this.id = a;
  }
  projectPoint(t, r, i, n, a) {
    if (a) {
      let s = a.lngLatFromWorld((t.x + r) / n, (t.y + i) / n);
      return [s.lng, s.lat];
    }
    return [(t.x + r) * 360 / n - 180, 360 / Math.PI * Math.atan(Math.exp((1 - (t.y + i) * 2 / n) * Math.PI)) - 90];
  }
  projectLine(t, r, i, n, a) {
    return t.map((s) => this.projectPoint(s, r, i, n, a));
  }
  get geometry() {
    if (this._geometry) return this._geometry;
    let t = this._vectorTileFeature, r = dr.worldCoordinateHelpers.get(this), i = t.extent * 2 ** this._z, n = t.extent * this._x, a = t.extent * this._y, s = t.loadGeometry();
    switch (t.type) {
      case 1: {
        let o = [];
        for (let u of s) o.push(u[0]);
        let l = this.projectLine(o, n, a, i, r);
        this._geometry = o.length === 1 ? { type: "Point", coordinates: l[0] } : { type: "MultiPoint", coordinates: l };
        break;
      }
      case 2: {
        let o = s.map((l) => this.projectLine(l, n, a, i, r));
        this._geometry = o.length === 1 ? { type: "LineString", coordinates: o[0] } : { type: "MultiLineString", coordinates: o };
        break;
      }
      case 3: {
        let o = Ly(s), l = [];
        for (let u of o) l.push(u.map((c) => this.projectLine(c, n, a, i, r)));
        this._geometry = l.length === 1 ? { type: "Polygon", coordinates: l[0] } : { type: "MultiPolygon", coordinates: l };
        break;
      }
      default:
        throw Error(`unknown feature type: ${t.type}`);
    }
    return this._geometry;
  }
  set geometry(t) {
    this._geometry = t;
  }
  toJSON() {
    let t = { geometry: this.geometry };
    for (let r in this) r !== "_geometry" && r !== "_vectorTileFeature" && r !== "_x" && r !== "_y" && r !== "_z" && (t[r] = this[r]);
    return t;
  }
}, dr.worldCoordinateHelpers = /* @__PURE__ */ new WeakMap(), dr), Rr = class {
  constructor(e, t, r) {
    this._name = e, this.dataBuffer = t, typeof r == "number" ? this._size = r : (this.nullabilityBuffer = r, this._size = r.size());
  }
  getValue(e) {
    return this.nullabilityBuffer && !this.nullabilityBuffer.get(e) ? null : this.getValueFromBuffer(e);
  }
  has(e) {
    var t;
    return ((t = this.nullabilityBuffer) == null ? void 0 : t.get(e)) || !this.nullabilityBuffer;
  }
  get name() {
    return this._name;
  }
  get size() {
    return this._size;
  }
}, Is = class extends Rr {
}, Zu = class extends Is {
  getValueFromBuffer(e) {
    return this.dataBuffer[e];
  }
}, Hu = class extends Is {
  getValueFromBuffer(e) {
    return this.dataBuffer[e];
  }
}, P1 = class extends Rr {
  constructor(e, t, r, i) {
    super(e, t, i), this.delta = r;
  }
}, Ku = class extends P1 {
  constructor(e, t, r, i, n) {
    super(e, n ? Int32Array.of(t) : Uint32Array.of(t), r, i);
  }
  getValueFromBuffer(e) {
    return this.dataBuffer[0] + e * this.delta;
  }
}, Ju = class extends Rr {
  constructor(e, t, r, i) {
    super(e, i ? Int32Array.of(t) : Uint32Array.of(t), r);
  }
  getValueFromBuffer(e) {
    return this.dataBuffer[0];
  }
}, _6 = class {
  constructor(e, t, r, i, n = 4096) {
    if (this._name = e, this._geometryVector = t, this._idVector = r, this._propertyVectors = i, this._extent = n, e.length === 0) throw Error("Missing layer name");
  }
  get name() {
    return this._name;
  }
  get idVector() {
    return this._idVector;
  }
  get geometryVector() {
    return this._geometryVector;
  }
  get propertyVectors() {
    return this._propertyVectors ?? [];
  }
  getPropertyVector(e) {
    return this.propertyVectorsMap || (this.propertyVectorsMap = new Map(this.propertyVectors.map((t) => [t.name, t]))), this.propertyVectorsMap.get(e);
  }
  get numFeatures() {
    return this.geometryVector.numGeometries;
  }
  get extent() {
    return this._extent;
  }
  getFeatures() {
    let e = [], t = this.geometryVector.getGeometries();
    for (let r = 0; r < this.numFeatures; r++) {
      let i;
      if (this.idVector) {
        let s = this.idVector.getValue(r);
        s !== null && (i = this.containsMaxSafeIntegerValues(this.idVector) ? Number(s) : s);
      }
      let n = { coordinates: t[r], type: this.geometryVector.geometryType(r) }, a = {};
      for (let s of this.propertyVectors) {
        if (!s) continue;
        let o = s.name, l = s.getValue(r);
        l !== null && (a[o] = l);
      }
      e.push({ id: i, geometry: n, properties: a });
    }
    return e;
  }
  containsMaxSafeIntegerValues(e) {
    return e instanceof Zu || e instanceof Ju || e instanceof Ku || e instanceof Hu;
  }
};
const nn = { FEATURE: 0 }, ee = { BOOLEAN: 0, INT_8: 1, UINT_8: 2, INT_32: 3, UINT_32: 4, INT_64: 5, UINT_64: 6, FLOAT: 7, DOUBLE: 8, STRING: 9 }, fr = { GEOMETRY: 0, STRUCT: 1, MAP: 2 }, B1 = { ID: 0 };
var L1 = class {
  constructor(e) {
    this.value = e;
  }
  get() {
    return this.value;
  }
  set(e) {
    this.value = e;
  }
  increment() {
    return this.value++;
  }
  add(e) {
    this.value += e;
  }
}, Z;
(function(e) {
  e.NONE = "NONE", e.DELTA = "DELTA", e.COMPONENTWISE_DELTA = "COMPONENTWISE_DELTA", e.RLE = "RLE", e.MORTON = "MORTON";
})(Z || (Z = {}));
var gt;
(function(e) {
  e.NONE = "NONE", e.FAST_PFOR = "FAST_PFOR", e.VARINT = "VARINT";
})(gt || (gt = {}));
const Qu = /* @__PURE__ */ new Uint32Array(33);
Qu[0] = 0;
for (let e = 1; e <= 32; e++) Qu[e] = e === 32 ? 4294967295 : 4294967295 >>> 32 - e;
const Gl = Qu, z1 = 65536;
function ec(e, t) {
  return e - e % t;
}
function D6(e) {
  return ec(e + 31, 32);
}
function S6(e) {
  if (!Number.isFinite(e) || e <= 0) return z1;
  let t = ec(Math.floor(e), 256);
  return t === 0 ? 256 : t;
}
function A6(e) {
  let t = e >>> 0;
  return ((t & 255) << 24 | (t & 65280) << 8 | t >>> 8 & 65280 | t >>> 24 & 255) >>> 0;
}
function E6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0;
  r[n++] = a >>> 0 & 3, r[n++] = a >>> 2 & 3, r[n++] = a >>> 4 & 3, r[n++] = a >>> 6 & 3, r[n++] = a >>> 8 & 3, r[n++] = a >>> 10 & 3, r[n++] = a >>> 12 & 3, r[n++] = a >>> 14 & 3, r[n++] = a >>> 16 & 3, r[n++] = a >>> 18 & 3, r[n++] = a >>> 20 & 3, r[n++] = a >>> 22 & 3, r[n++] = a >>> 24 & 3, r[n++] = a >>> 26 & 3, r[n++] = a >>> 28 & 3, r[n++] = a >>> 30 & 3, r[n++] = s >>> 0 & 3, r[n++] = s >>> 2 & 3, r[n++] = s >>> 4 & 3, r[n++] = s >>> 6 & 3, r[n++] = s >>> 8 & 3, r[n++] = s >>> 10 & 3, r[n++] = s >>> 12 & 3, r[n++] = s >>> 14 & 3, r[n++] = s >>> 16 & 3, r[n++] = s >>> 18 & 3, r[n++] = s >>> 20 & 3, r[n++] = s >>> 22 & 3, r[n++] = s >>> 24 & 3, r[n++] = s >>> 26 & 3, r[n++] = s >>> 28 & 3, r[n] = s >>> 30 & 3;
}
function T6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0;
  r[n++] = a >>> 0 & 7, r[n++] = a >>> 3 & 7, r[n++] = a >>> 6 & 7, r[n++] = a >>> 9 & 7, r[n++] = a >>> 12 & 7, r[n++] = a >>> 15 & 7, r[n++] = a >>> 18 & 7, r[n++] = a >>> 21 & 7, r[n++] = a >>> 24 & 7, r[n++] = a >>> 27 & 7, r[n++] = (a >>> 30 | (s & 1) << 2) & 7, r[n++] = s >>> 1 & 7, r[n++] = s >>> 4 & 7, r[n++] = s >>> 7 & 7, r[n++] = s >>> 10 & 7, r[n++] = s >>> 13 & 7, r[n++] = s >>> 16 & 7, r[n++] = s >>> 19 & 7, r[n++] = s >>> 22 & 7, r[n++] = s >>> 25 & 7, r[n++] = s >>> 28 & 7, r[n++] = (s >>> 31 | (o & 3) << 1) & 7, r[n++] = o >>> 2 & 7, r[n++] = o >>> 5 & 7, r[n++] = o >>> 8 & 7, r[n++] = o >>> 11 & 7, r[n++] = o >>> 14 & 7, r[n++] = o >>> 17 & 7, r[n++] = o >>> 20 & 7, r[n++] = o >>> 23 & 7, r[n++] = o >>> 26 & 7, r[n] = o >>> 29 & 7;
}
function I6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0;
  r[n++] = a >>> 0 & 15, r[n++] = a >>> 4 & 15, r[n++] = a >>> 8 & 15, r[n++] = a >>> 12 & 15, r[n++] = a >>> 16 & 15, r[n++] = a >>> 20 & 15, r[n++] = a >>> 24 & 15, r[n++] = a >>> 28 & 15, r[n++] = s >>> 0 & 15, r[n++] = s >>> 4 & 15, r[n++] = s >>> 8 & 15, r[n++] = s >>> 12 & 15, r[n++] = s >>> 16 & 15, r[n++] = s >>> 20 & 15, r[n++] = s >>> 24 & 15, r[n++] = s >>> 28 & 15, r[n++] = o >>> 0 & 15, r[n++] = o >>> 4 & 15, r[n++] = o >>> 8 & 15, r[n++] = o >>> 12 & 15, r[n++] = o >>> 16 & 15, r[n++] = o >>> 20 & 15, r[n++] = o >>> 24 & 15, r[n++] = o >>> 28 & 15, r[n++] = l >>> 0 & 15, r[n++] = l >>> 4 & 15, r[n++] = l >>> 8 & 15, r[n++] = l >>> 12 & 15, r[n++] = l >>> 16 & 15, r[n++] = l >>> 20 & 15, r[n++] = l >>> 24 & 15, r[n] = l >>> 28 & 15;
}
function C6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0;
  r[n++] = a >>> 0 & 31, r[n++] = a >>> 5 & 31, r[n++] = a >>> 10 & 31, r[n++] = a >>> 15 & 31, r[n++] = a >>> 20 & 31, r[n++] = a >>> 25 & 31, r[n++] = (a >>> 30 | (s & 7) << 2) & 31, r[n++] = s >>> 3 & 31, r[n++] = s >>> 8 & 31, r[n++] = s >>> 13 & 31, r[n++] = s >>> 18 & 31, r[n++] = s >>> 23 & 31, r[n++] = (s >>> 28 | (o & 1) << 4) & 31, r[n++] = o >>> 1 & 31, r[n++] = o >>> 6 & 31, r[n++] = o >>> 11 & 31, r[n++] = o >>> 16 & 31, r[n++] = o >>> 21 & 31, r[n++] = o >>> 26 & 31, r[n++] = (o >>> 31 | (l & 15) << 1) & 31, r[n++] = l >>> 4 & 31, r[n++] = l >>> 9 & 31, r[n++] = l >>> 14 & 31, r[n++] = l >>> 19 & 31, r[n++] = l >>> 24 & 31, r[n++] = (l >>> 29 | (u & 3) << 3) & 31, r[n++] = u >>> 2 & 31, r[n++] = u >>> 7 & 31, r[n++] = u >>> 12 & 31, r[n++] = u >>> 17 & 31, r[n++] = u >>> 22 & 31, r[n] = u >>> 27 & 31;
}
function k6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0;
  r[n++] = a >>> 0 & 63, r[n++] = a >>> 6 & 63, r[n++] = a >>> 12 & 63, r[n++] = a >>> 18 & 63, r[n++] = a >>> 24 & 63, r[n++] = (a >>> 30 | (s & 15) << 2) & 63, r[n++] = s >>> 4 & 63, r[n++] = s >>> 10 & 63, r[n++] = s >>> 16 & 63, r[n++] = s >>> 22 & 63, r[n++] = (s >>> 28 | (o & 3) << 4) & 63, r[n++] = o >>> 2 & 63, r[n++] = o >>> 8 & 63, r[n++] = o >>> 14 & 63, r[n++] = o >>> 20 & 63, r[n++] = o >>> 26 & 63, r[n++] = l >>> 0 & 63, r[n++] = l >>> 6 & 63, r[n++] = l >>> 12 & 63, r[n++] = l >>> 18 & 63, r[n++] = l >>> 24 & 63, r[n++] = (l >>> 30 | (u & 15) << 2) & 63, r[n++] = u >>> 4 & 63, r[n++] = u >>> 10 & 63, r[n++] = u >>> 16 & 63, r[n++] = u >>> 22 & 63, r[n++] = (u >>> 28 | (c & 3) << 4) & 63, r[n++] = c >>> 2 & 63, r[n++] = c >>> 8 & 63, r[n++] = c >>> 14 & 63, r[n++] = c >>> 20 & 63, r[n] = c >>> 26 & 63;
}
function F6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0;
  r[n++] = a >>> 0 & 127, r[n++] = a >>> 7 & 127, r[n++] = a >>> 14 & 127, r[n++] = a >>> 21 & 127, r[n++] = (a >>> 28 | (s & 7) << 4) & 127, r[n++] = s >>> 3 & 127, r[n++] = s >>> 10 & 127, r[n++] = s >>> 17 & 127, r[n++] = s >>> 24 & 127, r[n++] = (s >>> 31 | (o & 63) << 1) & 127, r[n++] = o >>> 6 & 127, r[n++] = o >>> 13 & 127, r[n++] = o >>> 20 & 127, r[n++] = (o >>> 27 | (l & 3) << 5) & 127, r[n++] = l >>> 2 & 127, r[n++] = l >>> 9 & 127, r[n++] = l >>> 16 & 127, r[n++] = l >>> 23 & 127, r[n++] = (l >>> 30 | (u & 31) << 2) & 127, r[n++] = u >>> 5 & 127, r[n++] = u >>> 12 & 127, r[n++] = u >>> 19 & 127, r[n++] = (u >>> 26 | (c & 1) << 6) & 127, r[n++] = c >>> 1 & 127, r[n++] = c >>> 8 & 127, r[n++] = c >>> 15 & 127, r[n++] = c >>> 22 & 127, r[n++] = (c >>> 29 | (h & 15) << 3) & 127, r[n++] = h >>> 4 & 127, r[n++] = h >>> 11 & 127, r[n++] = h >>> 18 & 127, r[n] = h >>> 25 & 127;
}
function M6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0;
  r[n++] = a >>> 0 & 255, r[n++] = a >>> 8 & 255, r[n++] = a >>> 16 & 255, r[n++] = a >>> 24 & 255, r[n++] = s >>> 0 & 255, r[n++] = s >>> 8 & 255, r[n++] = s >>> 16 & 255, r[n++] = s >>> 24 & 255, r[n++] = o >>> 0 & 255, r[n++] = o >>> 8 & 255, r[n++] = o >>> 16 & 255, r[n++] = o >>> 24 & 255, r[n++] = l >>> 0 & 255, r[n++] = l >>> 8 & 255, r[n++] = l >>> 16 & 255, r[n++] = l >>> 24 & 255, r[n++] = u >>> 0 & 255, r[n++] = u >>> 8 & 255, r[n++] = u >>> 16 & 255, r[n++] = u >>> 24 & 255, r[n++] = c >>> 0 & 255, r[n++] = c >>> 8 & 255, r[n++] = c >>> 16 & 255, r[n++] = c >>> 24 & 255, r[n++] = h >>> 0 & 255, r[n++] = h >>> 8 & 255, r[n++] = h >>> 16 & 255, r[n++] = h >>> 24 & 255, r[n++] = p >>> 0 & 255, r[n++] = p >>> 8 & 255, r[n++] = p >>> 16 & 255, r[n] = p >>> 24 & 255;
}
function P6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0, f = e[t + 8] >>> 0;
  r[n++] = a >>> 0 & 511, r[n++] = a >>> 9 & 511, r[n++] = a >>> 18 & 511, r[n++] = (a >>> 27 | (s & 15) << 5) & 511, r[n++] = s >>> 4 & 511, r[n++] = s >>> 13 & 511, r[n++] = s >>> 22 & 511, r[n++] = (s >>> 31 | (o & 255) << 1) & 511, r[n++] = o >>> 8 & 511, r[n++] = o >>> 17 & 511, r[n++] = (o >>> 26 | (l & 7) << 6) & 511, r[n++] = l >>> 3 & 511, r[n++] = l >>> 12 & 511, r[n++] = l >>> 21 & 511, r[n++] = (l >>> 30 | (u & 127) << 2) & 511, r[n++] = u >>> 7 & 511, r[n++] = u >>> 16 & 511, r[n++] = (u >>> 25 | (c & 3) << 7) & 511, r[n++] = c >>> 2 & 511, r[n++] = c >>> 11 & 511, r[n++] = c >>> 20 & 511, r[n++] = (c >>> 29 | (h & 63) << 3) & 511, r[n++] = h >>> 6 & 511, r[n++] = h >>> 15 & 511, r[n++] = (h >>> 24 | (p & 1) << 8) & 511, r[n++] = p >>> 1 & 511, r[n++] = p >>> 10 & 511, r[n++] = p >>> 19 & 511, r[n++] = (p >>> 28 | (f & 31) << 4) & 511, r[n++] = f >>> 5 & 511, r[n++] = f >>> 14 & 511, r[n] = f >>> 23 & 511;
}
function B6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0, f = e[t + 8] >>> 0, d = e[t + 9] >>> 0;
  r[n++] = a >>> 0 & 1023, r[n++] = a >>> 10 & 1023, r[n++] = a >>> 20 & 1023, r[n++] = (a >>> 30 | (s & 255) << 2) & 1023, r[n++] = s >>> 8 & 1023, r[n++] = s >>> 18 & 1023, r[n++] = (s >>> 28 | (o & 63) << 4) & 1023, r[n++] = o >>> 6 & 1023, r[n++] = o >>> 16 & 1023, r[n++] = (o >>> 26 | (l & 15) << 6) & 1023, r[n++] = l >>> 4 & 1023, r[n++] = l >>> 14 & 1023, r[n++] = (l >>> 24 | (u & 3) << 8) & 1023, r[n++] = u >>> 2 & 1023, r[n++] = u >>> 12 & 1023, r[n++] = u >>> 22 & 1023, r[n++] = c >>> 0 & 1023, r[n++] = c >>> 10 & 1023, r[n++] = c >>> 20 & 1023, r[n++] = (c >>> 30 | (h & 255) << 2) & 1023, r[n++] = h >>> 8 & 1023, r[n++] = h >>> 18 & 1023, r[n++] = (h >>> 28 | (p & 63) << 4) & 1023, r[n++] = p >>> 6 & 1023, r[n++] = p >>> 16 & 1023, r[n++] = (p >>> 26 | (f & 15) << 6) & 1023, r[n++] = f >>> 4 & 1023, r[n++] = f >>> 14 & 1023, r[n++] = (f >>> 24 | (d & 3) << 8) & 1023, r[n++] = d >>> 2 & 1023, r[n++] = d >>> 12 & 1023, r[n] = d >>> 22 & 1023;
}
function L6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0, f = e[t + 8] >>> 0, d = e[t + 9] >>> 0, y = e[t + 10] >>> 0;
  r[n++] = a >>> 0 & 2047, r[n++] = a >>> 11 & 2047, r[n++] = (a >>> 22 | (s & 1) << 10) & 2047, r[n++] = s >>> 1 & 2047, r[n++] = s >>> 12 & 2047, r[n++] = (s >>> 23 | (o & 3) << 9) & 2047, r[n++] = o >>> 2 & 2047, r[n++] = o >>> 13 & 2047, r[n++] = (o >>> 24 | (l & 7) << 8) & 2047, r[n++] = l >>> 3 & 2047, r[n++] = l >>> 14 & 2047, r[n++] = (l >>> 25 | (u & 15) << 7) & 2047, r[n++] = u >>> 4 & 2047, r[n++] = u >>> 15 & 2047, r[n++] = (u >>> 26 | (c & 31) << 6) & 2047, r[n++] = c >>> 5 & 2047, r[n++] = c >>> 16 & 2047, r[n++] = (c >>> 27 | (h & 63) << 5) & 2047, r[n++] = h >>> 6 & 2047, r[n++] = h >>> 17 & 2047, r[n++] = (h >>> 28 | (p & 127) << 4) & 2047, r[n++] = p >>> 7 & 2047, r[n++] = p >>> 18 & 2047, r[n++] = (p >>> 29 | (f & 255) << 3) & 2047, r[n++] = f >>> 8 & 2047, r[n++] = f >>> 19 & 2047, r[n++] = (f >>> 30 | (d & 511) << 2) & 2047, r[n++] = d >>> 9 & 2047, r[n++] = d >>> 20 & 2047, r[n++] = (d >>> 31 | (y & 1023) << 1) & 2047, r[n++] = y >>> 10 & 2047, r[n] = y >>> 21 & 2047;
}
function z6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0, f = e[t + 8] >>> 0, d = e[t + 9] >>> 0, y = e[t + 10] >>> 0, m = e[t + 11] >>> 0;
  r[n++] = a >>> 0 & 4095, r[n++] = a >>> 12 & 4095, r[n++] = (a >>> 24 | (s & 15) << 8) & 4095, r[n++] = s >>> 4 & 4095, r[n++] = s >>> 16 & 4095, r[n++] = (s >>> 28 | (o & 255) << 4) & 4095, r[n++] = o >>> 8 & 4095, r[n++] = o >>> 20 & 4095, r[n++] = l >>> 0 & 4095, r[n++] = l >>> 12 & 4095, r[n++] = (l >>> 24 | (u & 15) << 8) & 4095, r[n++] = u >>> 4 & 4095, r[n++] = u >>> 16 & 4095, r[n++] = (u >>> 28 | (c & 255) << 4) & 4095, r[n++] = c >>> 8 & 4095, r[n++] = c >>> 20 & 4095, r[n++] = h >>> 0 & 4095, r[n++] = h >>> 12 & 4095, r[n++] = (h >>> 24 | (p & 15) << 8) & 4095, r[n++] = p >>> 4 & 4095, r[n++] = p >>> 16 & 4095, r[n++] = (p >>> 28 | (f & 255) << 4) & 4095, r[n++] = f >>> 8 & 4095, r[n++] = f >>> 20 & 4095, r[n++] = d >>> 0 & 4095, r[n++] = d >>> 12 & 4095, r[n++] = (d >>> 24 | (y & 15) << 8) & 4095, r[n++] = y >>> 4 & 4095, r[n++] = y >>> 16 & 4095, r[n++] = (y >>> 28 | (m & 255) << 4) & 4095, r[n++] = m >>> 8 & 4095, r[n] = m >>> 20 & 4095;
}
function V6(e, t, r, i) {
  let n = i, a = e[t] >>> 0, s = e[t + 1] >>> 0, o = e[t + 2] >>> 0, l = e[t + 3] >>> 0, u = e[t + 4] >>> 0, c = e[t + 5] >>> 0, h = e[t + 6] >>> 0, p = e[t + 7] >>> 0, f = e[t + 8] >>> 0, d = e[t + 9] >>> 0, y = e[t + 10] >>> 0, m = e[t + 11] >>> 0, g = e[t + 12] >>> 0, v = e[t + 13] >>> 0, x = e[t + 14] >>> 0, b = e[t + 15] >>> 0;
  r[n++] = a >>> 0 & 65535, r[n++] = a >>> 16 & 65535, r[n++] = s >>> 0 & 65535, r[n++] = s >>> 16 & 65535, r[n++] = o >>> 0 & 65535, r[n++] = o >>> 16 & 65535, r[n++] = l >>> 0 & 65535, r[n++] = l >>> 16 & 65535, r[n++] = u >>> 0 & 65535, r[n++] = u >>> 16 & 65535, r[n++] = c >>> 0 & 65535, r[n++] = c >>> 16 & 65535, r[n++] = h >>> 0 & 65535, r[n++] = h >>> 16 & 65535, r[n++] = p >>> 0 & 65535, r[n++] = p >>> 16 & 65535, r[n++] = f >>> 0 & 65535, r[n++] = f >>> 16 & 65535, r[n++] = d >>> 0 & 65535, r[n++] = d >>> 16 & 65535, r[n++] = y >>> 0 & 65535, r[n++] = y >>> 16 & 65535, r[n++] = m >>> 0 & 65535, r[n++] = m >>> 16 & 65535, r[n++] = g >>> 0 & 65535, r[n++] = g >>> 16 & 65535, r[n++] = v >>> 0 & 65535, r[n++] = v >>> 16 & 65535, r[n++] = x >>> 0 & 65535, r[n++] = x >>> 16 & 65535, r[n++] = b >>> 0 & 65535, r[n] = b >>> 16 & 65535;
}
function O6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0;
    r[n++] = o >>> 0 & 1, r[n++] = o >>> 1 & 1, r[n++] = o >>> 2 & 1, r[n++] = o >>> 3 & 1, r[n++] = o >>> 4 & 1, r[n++] = o >>> 5 & 1, r[n++] = o >>> 6 & 1, r[n++] = o >>> 7 & 1, r[n++] = o >>> 8 & 1, r[n++] = o >>> 9 & 1, r[n++] = o >>> 10 & 1, r[n++] = o >>> 11 & 1, r[n++] = o >>> 12 & 1, r[n++] = o >>> 13 & 1, r[n++] = o >>> 14 & 1, r[n++] = o >>> 15 & 1, r[n++] = o >>> 16 & 1, r[n++] = o >>> 17 & 1, r[n++] = o >>> 18 & 1, r[n++] = o >>> 19 & 1, r[n++] = o >>> 20 & 1, r[n++] = o >>> 21 & 1, r[n++] = o >>> 22 & 1, r[n++] = o >>> 23 & 1, r[n++] = o >>> 24 & 1, r[n++] = o >>> 25 & 1, r[n++] = o >>> 26 & 1, r[n++] = o >>> 27 & 1, r[n++] = o >>> 28 & 1, r[n++] = o >>> 29 & 1, r[n++] = o >>> 30 & 1, r[n++] = o >>> 31 & 1;
  }
}
function R6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0;
    r[n++] = o >>> 0 & 3, r[n++] = o >>> 2 & 3, r[n++] = o >>> 4 & 3, r[n++] = o >>> 6 & 3, r[n++] = o >>> 8 & 3, r[n++] = o >>> 10 & 3, r[n++] = o >>> 12 & 3, r[n++] = o >>> 14 & 3, r[n++] = o >>> 16 & 3, r[n++] = o >>> 18 & 3, r[n++] = o >>> 20 & 3, r[n++] = o >>> 22 & 3, r[n++] = o >>> 24 & 3, r[n++] = o >>> 26 & 3, r[n++] = o >>> 28 & 3, r[n++] = o >>> 30 & 3, r[n++] = l >>> 0 & 3, r[n++] = l >>> 2 & 3, r[n++] = l >>> 4 & 3, r[n++] = l >>> 6 & 3, r[n++] = l >>> 8 & 3, r[n++] = l >>> 10 & 3, r[n++] = l >>> 12 & 3, r[n++] = l >>> 14 & 3, r[n++] = l >>> 16 & 3, r[n++] = l >>> 18 & 3, r[n++] = l >>> 20 & 3, r[n++] = l >>> 22 & 3, r[n++] = l >>> 24 & 3, r[n++] = l >>> 26 & 3, r[n++] = l >>> 28 & 3, r[n++] = l >>> 30 & 3;
  }
}
function $6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0;
    r[n++] = o >>> 0 & 7, r[n++] = o >>> 3 & 7, r[n++] = o >>> 6 & 7, r[n++] = o >>> 9 & 7, r[n++] = o >>> 12 & 7, r[n++] = o >>> 15 & 7, r[n++] = o >>> 18 & 7, r[n++] = o >>> 21 & 7, r[n++] = o >>> 24 & 7, r[n++] = o >>> 27 & 7, r[n++] = (o >>> 30 | (l & 1) << 2) & 7, r[n++] = l >>> 1 & 7, r[n++] = l >>> 4 & 7, r[n++] = l >>> 7 & 7, r[n++] = l >>> 10 & 7, r[n++] = l >>> 13 & 7, r[n++] = l >>> 16 & 7, r[n++] = l >>> 19 & 7, r[n++] = l >>> 22 & 7, r[n++] = l >>> 25 & 7, r[n++] = l >>> 28 & 7, r[n++] = (l >>> 31 | (u & 3) << 1) & 7, r[n++] = u >>> 2 & 7, r[n++] = u >>> 5 & 7, r[n++] = u >>> 8 & 7, r[n++] = u >>> 11 & 7, r[n++] = u >>> 14 & 7, r[n++] = u >>> 17 & 7, r[n++] = u >>> 20 & 7, r[n++] = u >>> 23 & 7, r[n++] = u >>> 26 & 7, r[n++] = u >>> 29 & 7;
  }
}
function N6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0, c = e[a++] >>> 0;
    r[n++] = o >>> 0 & 15, r[n++] = o >>> 4 & 15, r[n++] = o >>> 8 & 15, r[n++] = o >>> 12 & 15, r[n++] = o >>> 16 & 15, r[n++] = o >>> 20 & 15, r[n++] = o >>> 24 & 15, r[n++] = o >>> 28 & 15, r[n++] = l >>> 0 & 15, r[n++] = l >>> 4 & 15, r[n++] = l >>> 8 & 15, r[n++] = l >>> 12 & 15, r[n++] = l >>> 16 & 15, r[n++] = l >>> 20 & 15, r[n++] = l >>> 24 & 15, r[n++] = l >>> 28 & 15, r[n++] = u >>> 0 & 15, r[n++] = u >>> 4 & 15, r[n++] = u >>> 8 & 15, r[n++] = u >>> 12 & 15, r[n++] = u >>> 16 & 15, r[n++] = u >>> 20 & 15, r[n++] = u >>> 24 & 15, r[n++] = u >>> 28 & 15, r[n++] = c >>> 0 & 15, r[n++] = c >>> 4 & 15, r[n++] = c >>> 8 & 15, r[n++] = c >>> 12 & 15, r[n++] = c >>> 16 & 15, r[n++] = c >>> 20 & 15, r[n++] = c >>> 24 & 15, r[n++] = c >>> 28 & 15;
  }
}
function U6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0, c = e[a++] >>> 0, h = e[a++] >>> 0;
    r[n++] = o >>> 0 & 31, r[n++] = o >>> 5 & 31, r[n++] = o >>> 10 & 31, r[n++] = o >>> 15 & 31, r[n++] = o >>> 20 & 31, r[n++] = o >>> 25 & 31, r[n++] = (o >>> 30 | (l & 7) << 2) & 31, r[n++] = l >>> 3 & 31, r[n++] = l >>> 8 & 31, r[n++] = l >>> 13 & 31, r[n++] = l >>> 18 & 31, r[n++] = l >>> 23 & 31, r[n++] = (l >>> 28 | (u & 1) << 4) & 31, r[n++] = u >>> 1 & 31, r[n++] = u >>> 6 & 31, r[n++] = u >>> 11 & 31, r[n++] = u >>> 16 & 31, r[n++] = u >>> 21 & 31, r[n++] = u >>> 26 & 31, r[n++] = (u >>> 31 | (c & 15) << 1) & 31, r[n++] = c >>> 4 & 31, r[n++] = c >>> 9 & 31, r[n++] = c >>> 14 & 31, r[n++] = c >>> 19 & 31, r[n++] = c >>> 24 & 31, r[n++] = (c >>> 29 | (h & 3) << 3) & 31, r[n++] = h >>> 2 & 31, r[n++] = h >>> 7 & 31, r[n++] = h >>> 12 & 31, r[n++] = h >>> 17 & 31, r[n++] = h >>> 22 & 31, r[n++] = h >>> 27 & 31;
  }
}
function j6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0, c = e[a++] >>> 0, h = e[a++] >>> 0, p = e[a++] >>> 0;
    r[n++] = o >>> 0 & 63, r[n++] = o >>> 6 & 63, r[n++] = o >>> 12 & 63, r[n++] = o >>> 18 & 63, r[n++] = o >>> 24 & 63, r[n++] = (o >>> 30 | (l & 15) << 2) & 63, r[n++] = l >>> 4 & 63, r[n++] = l >>> 10 & 63, r[n++] = l >>> 16 & 63, r[n++] = l >>> 22 & 63, r[n++] = (l >>> 28 | (u & 3) << 4) & 63, r[n++] = u >>> 2 & 63, r[n++] = u >>> 8 & 63, r[n++] = u >>> 14 & 63, r[n++] = u >>> 20 & 63, r[n++] = u >>> 26 & 63, r[n++] = c >>> 0 & 63, r[n++] = c >>> 6 & 63, r[n++] = c >>> 12 & 63, r[n++] = c >>> 18 & 63, r[n++] = c >>> 24 & 63, r[n++] = (c >>> 30 | (h & 15) << 2) & 63, r[n++] = h >>> 4 & 63, r[n++] = h >>> 10 & 63, r[n++] = h >>> 16 & 63, r[n++] = h >>> 22 & 63, r[n++] = (h >>> 28 | (p & 3) << 4) & 63, r[n++] = p >>> 2 & 63, r[n++] = p >>> 8 & 63, r[n++] = p >>> 14 & 63, r[n++] = p >>> 20 & 63, r[n++] = p >>> 26 & 63;
  }
}
function q6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0, c = e[a++] >>> 0, h = e[a++] >>> 0, p = e[a++] >>> 0, f = e[a++] >>> 0;
    r[n++] = o >>> 0 & 127, r[n++] = o >>> 7 & 127, r[n++] = o >>> 14 & 127, r[n++] = o >>> 21 & 127, r[n++] = (o >>> 28 | (l & 7) << 4) & 127, r[n++] = l >>> 3 & 127, r[n++] = l >>> 10 & 127, r[n++] = l >>> 17 & 127, r[n++] = l >>> 24 & 127, r[n++] = (l >>> 31 | (u & 63) << 1) & 127, r[n++] = u >>> 6 & 127, r[n++] = u >>> 13 & 127, r[n++] = u >>> 20 & 127, r[n++] = (u >>> 27 | (c & 3) << 5) & 127, r[n++] = c >>> 2 & 127, r[n++] = c >>> 9 & 127, r[n++] = c >>> 16 & 127, r[n++] = c >>> 23 & 127, r[n++] = (c >>> 30 | (h & 31) << 2) & 127, r[n++] = h >>> 5 & 127, r[n++] = h >>> 12 & 127, r[n++] = h >>> 19 & 127, r[n++] = (h >>> 26 | (p & 1) << 6) & 127, r[n++] = p >>> 1 & 127, r[n++] = p >>> 8 & 127, r[n++] = p >>> 15 & 127, r[n++] = p >>> 22 & 127, r[n++] = (p >>> 29 | (f & 15) << 3) & 127, r[n++] = f >>> 4 & 127, r[n++] = f >>> 11 & 127, r[n++] = f >>> 18 & 127, r[n++] = f >>> 25 & 127;
  }
}
function G6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 8; s++) {
    let o = e[a++] >>> 0, l = e[a++] >>> 0, u = e[a++] >>> 0, c = e[a++] >>> 0, h = e[a++] >>> 0, p = e[a++] >>> 0, f = e[a++] >>> 0, d = e[a++] >>> 0;
    r[n++] = o >>> 0 & 255, r[n++] = o >>> 8 & 255, r[n++] = o >>> 16 & 255, r[n++] = o >>> 24 & 255, r[n++] = l >>> 0 & 255, r[n++] = l >>> 8 & 255, r[n++] = l >>> 16 & 255, r[n++] = l >>> 24 & 255, r[n++] = u >>> 0 & 255, r[n++] = u >>> 8 & 255, r[n++] = u >>> 16 & 255, r[n++] = u >>> 24 & 255, r[n++] = c >>> 0 & 255, r[n++] = c >>> 8 & 255, r[n++] = c >>> 16 & 255, r[n++] = c >>> 24 & 255, r[n++] = h >>> 0 & 255, r[n++] = h >>> 8 & 255, r[n++] = h >>> 16 & 255, r[n++] = h >>> 24 & 255, r[n++] = p >>> 0 & 255, r[n++] = p >>> 8 & 255, r[n++] = p >>> 16 & 255, r[n++] = p >>> 24 & 255, r[n++] = f >>> 0 & 255, r[n++] = f >>> 8 & 255, r[n++] = f >>> 16 & 255, r[n++] = f >>> 24 & 255, r[n++] = d >>> 0 & 255, r[n++] = d >>> 8 & 255, r[n++] = d >>> 16 & 255, r[n++] = d >>> 24 & 255;
  }
}
function X6(e, t, r, i) {
  let n = i, a = t;
  for (let s = 0; s < 128; s++) {
    let o = e[a++] >>> 0;
    r[n++] = o & 65535, r[n++] = o >>> 16 & 65535;
  }
}
function Y6(e, t, r, i, n) {
  let a = Gl[n] >>> 0, s = t, o = 0, l = e[s] >>> 0, u = i;
  for (let c = 0; c < 8; c++) {
    for (let h = 0; h < 32; h++) if (o + n <= 32) {
      let p = l >>> o & a;
      r[u + h] = p | 0, o += n, o === 32 && (o = 0, s++, h !== 31 && (l = e[s] >>> 0));
    } else {
      let p = 32 - o, f = l >>> o;
      s++, l = e[s] >>> 0;
      let d = n - p, y = -1 >>> 32 - d >>> 0, m = (f | (l & y) << p) & a;
      r[u + h] = m | 0, o = d;
    }
    u += 32, o = 0, c < 7 && (l = e[s] >>> 0);
  }
}
const Xl = S6(z1), W6 = 3 * Xl / 256 + Xl | 0;
function V1() {
  let e = new Uint8Array(W6);
  return { dataToBePacked: Array(33), dataPointers: /* @__PURE__ */ new Int32Array(33), byteContainer: e, byteContainerI32: new Int32Array(e.buffer, e.byteOffset, e.byteLength >>> 2), exceptionSizes: /* @__PURE__ */ new Int32Array(33) };
}
function Z6(e = 16) {
  if (e < 0) throw RangeError(`initialEncodedWordCapacity must be >= 0, got ${e}`);
  let t = Math.max(16, e | 0);
  return { encodedWords: new Uint32Array(t), decoderWorkspace: V1() };
}
function H6(e, t) {
  if (t <= e.encodedWords.length) return e.encodedWords;
  let r = new Uint32Array(Math.max(16, t * 2));
  return e.encodedWords = r, r;
}
function K6(e, t, r, i) {
  i.byteContainer.length < r && (i.byteContainer = new Uint8Array(r * 2), i.byteContainerI32 = void 0);
  let n = i.byteContainer, a = r >>> 2;
  if (n.byteOffset & 3) for (let o = 0; o < a; o = o + 1 | 0) {
    let l = e[t + o | 0] | 0, u = o << 2;
    n[u] = l & 255, n[u + 1 | 0] = l >>> 8 & 255, n[u + 2 | 0] = l >>> 16 & 255, n[u + 3 | 0] = l >>> 24 & 255;
  }
  else {
    let o = i.byteContainerI32;
    (!o || o.buffer !== n.buffer || o.byteOffset !== n.byteOffset || o.length < a) && (o = i.byteContainerI32 = new Int32Array(n.buffer, n.byteOffset, n.byteLength >>> 2)), o.set(e.subarray(t, t + a));
  }
  let s = r & 3;
  if (s > 0) {
    let o = e[t + a | 0] | 0, l = a << 2;
    for (let u = 0; u < s; u = u + 1 | 0) n[l + u | 0] = o >>> (u << 3) & 255;
  }
  return n;
}
function J6(e, t, r) {
  let i = e[t++] | 0, n = r.dataToBePacked;
  for (let a = 2; a <= 32; a = a + 1 | 0) {
    if (!(i >>> a - 1 & 1)) continue;
    if (t >= e.length) throw Error(`FastPFOR decode: truncated exception stream header (bitWidth=${a}, streamWordIndex=${t}, needWords=1, availableWords=${e.length - t}, encodedWords=${e.length})`);
    let s = e[t++] >>> 0, o = D6(s), l = s * a + 31 >>> 5;
    if (t + l > e.length) throw Error(`FastPFOR decode: truncated exception stream (bitWidth=${a}, size=${s}, streamWordIndex=${t}, needWords=${l}, availableWords=${e.length - t}, encodedWords=${e.length})`);
    let u = n[a];
    (!u || u.length < o) && (u = n[a] = new Uint32Array(o));
    let c = 0;
    for (; c < s; c = c + 32 | 0) l5(e, t, u, c, a), t = t + a | 0;
    let h = c - s | 0;
    t = t - (h * a >>> 5) | 0, r.exceptionSizes[a] = s;
  }
  return t;
}
function Q6(e, t, r, i, n) {
  switch (n) {
    case 1:
      O6(e, t, r, i);
      break;
    case 2:
      R6(e, t, r, i);
      break;
    case 3:
      $6(e, t, r, i);
      break;
    case 4:
      N6(e, t, r, i);
      break;
    case 5:
      U6(e, t, r, i);
      break;
    case 6:
      j6(e, t, r, i);
      break;
    case 7:
      q6(e, t, r, i);
      break;
    case 8:
      G6(e, t, r, i);
      break;
    case 16:
      X6(e, t, r, i);
      break;
    default:
      Y6(e, t, r, i, n);
  }
  return t + (n << 3) | 0;
}
function e5(e, t, r, i) {
  if (r + 2 > t) throw Error(`FastPFOR decode: byteContainer underflow at block=${i} (need 2 bytes for [bitWidth, exceptionCount], bytePos=${r}, byteSize=${t})`);
  let n = e[r++], a = e[r++];
  if (n > 32) throw Error(`FastPFOR decode: invalid bitWidth=${n} at block=${i} (expected 0..32). This likely indicates corrupted or truncated input.`);
  return { bitWidth: n, exceptionCount: a, bytePosIn: r };
}
function t5(e, t, r, i, n, a) {
  if (r + 1 > t) throw Error(`FastPFOR decode: exception header underflow at block=${a} (need 1 byte for maxBits, bytePos=${r}, byteSize=${t})`);
  let s = e[r++];
  if (s < i || s > 32) throw Error(`FastPFOR decode: invalid maxBits=${s} at block=${a} (bitWidth=${i}, expected ${i}..32)`);
  let o = s - i | 0;
  if (o < 1 || o > 32) throw Error(`FastPFOR decode: invalid exceptionBitWidth=${o} at block=${a} (bitWidth=${i}, maxBits=${s})`);
  if (r + n > t) throw Error(`FastPFOR decode: exception positions underflow at block=${a} (need=${n}, have=${t - r})`);
  return { maxBits: s, exceptionBitWidth: o, bytePosIn: r };
}
function r5(e, t, r, i, n, a, s, o, l) {
  let { maxBits: u, exceptionBitWidth: c, bytePosIn: h } = t5(n, a, s, r, i, l);
  if (s = h, c === 1) {
    let m = 1 << r;
    for (let g = 0; g < i; g = g + 1 | 0) {
      let v = n[s++];
      e[v + t | 0] |= m;
    }
    return s;
  }
  let p = o.dataToBePacked[c];
  if (!p) throw Error(`FastPFOR decode: missing exception stream for exceptionBitWidth=${c} (bitWidth=${r}, maxBits=${u}) at block ${l}`);
  let f = o.dataPointers, d = f[c] | 0, y = o.exceptionSizes[c] | 0;
  if (d + i > y) throw Error(`FastPFOR decode: exception stream overflow for exceptionBitWidth=${c} (ptr=${d}, need ${i}, size=${y}) at block ${l}`);
  for (let m = 0; m < i; m = m + 1 | 0) {
    let g = n[s++], v = p[d++] | 0;
    e[g + t | 0] |= v << r;
  }
  return f[c] = d, s;
}
function i5(e, t, r, i, n, a, s, o, l, u) {
  let c = r | 0, h = 0;
  for (let p = 0; p < s; p = p + 1 | 0) {
    let f = e5(o, l, h, p);
    h = f.bytePosIn;
    let d = f.bitWidth, y = f.exceptionCount, m = a + p * 256 | 0;
    switch (d) {
      case 0:
        n.fill(0, m, m + 256);
        break;
      case 32:
        for (let g = 0; g < 256; g = g + 1 | 0) n[m + g | 0] = e[c + g | 0] | 0;
        c = c + 256 | 0;
        break;
      default:
        c = Q6(e, c, n, m, d);
    }
    y > 0 && (h = r5(n, m, d, y, o, l, h, u, p));
  }
  if (c !== i) throw Error(`FastPFOR decode: packed region mismatch (pageStart=${t}, packedStart=${r}, consumedPackedEnd=${c}, expectedPackedEnd=${i}, packedWords=${i - r}, encoded.length=${e.length})`);
}
function n5(e, t, r, i, n, a) {
  let s = r | 0, o = e[s] | 0;
  if (o <= 0 || s + o > e.length - 1) throw Error(`FastPFOR decode: invalid whereMeta=${o} at pageStart=${s} (expected > 0 and pageStart+whereMeta < encoded.length=${e.length})`);
  let l = s + 1 | 0, u = s + o | 0, c = e[u] >>> 0, h = c + 3 >>> 2, p = u + 1, f = p + h;
  if (f >= e.length) throw Error(`FastPFOR decode: invalid byteSize=${c} (metaInts=${h}, pageStart=${s}, packedEnd=${u}, byteContainerStart=${p}) causes bitmapPos=${f} out of bounds (encoded.length=${e.length})`);
  let d = K6(e, p, c, a), y = c, m = J6(e, f, a);
  return a.dataPointers.fill(0), i5(e, s, l, u, t, i | 0, n / 256 | 0, d, y, a), m;
}
function a5(e, t, r, i, n, a) {
  let s = i + ec(n, 256), o = i, l = r;
  for (; o !== s; ) {
    let u = Math.min(Xl, s - o);
    l = n5(e, t, l, o, u, a), o = o + u | 0;
  }
  return l;
}
function s5(e, t, r, i, n, a) {
  if (a === 0) return t;
  let s = 0, o = t, l = t + r, u = n, c = n, h = n + a, p = 0, f = 0;
  for (; o < l && c < h; ) {
    let d = e[o] >>> s & 255;
    if (s += 8, o += s >>> 5, s &= 31, p |= (d & 127) << f, d & 128) i[c++] = p | 0, p = 0, f = 0;
    else if (f += 7, f > 28) throw Error(`FastPFOR VByte: unterminated value (expected MSB=1 terminator within 5 bytes; shift=${f}, partial=${p}, decoded=${c - u}/${a}, inPos=${o}, inEnd=${l})`);
  }
  if (c !== h) throw Error(`FastPFOR VByte: truncated stream (decoded=${c - u}, expected=${a}, consumedWords=${o - t}/${r}, vbyteStart=${t}, vbyteEnd=${l})`);
  return o;
}
function o5(e, t, r) {
  let i = 0, n = 0, a = new Uint32Array(t), s = r ?? V1();
  if (e.length > 0) {
    let u = e[i] | 0;
    if (i = i + 1 | 0, u & 255) throw Error(`FastPFOR decode: invalid alignedLength=${u} (expected multiple of 256)`);
    if (n + u > a.length) throw Error(`FastPFOR decode: output buffer too small (outPos=${n}, alignedLength=${u}, out.length=${a.length})`);
    i = a5(e, a, i, n, u, s), n = n + u | 0;
  }
  let o = e.length - i | 0, l = t - n | 0;
  return s5(e, i, o, a, n, l), a;
}
function l5(e, t, r, i, n) {
  switch (n) {
    case 2:
      E6(e, t, r, i);
      return;
    case 3:
      T6(e, t, r, i);
      return;
    case 4:
      I6(e, t, r, i);
      return;
    case 5:
      C6(e, t, r, i);
      return;
    case 6:
      k6(e, t, r, i);
      return;
    case 7:
      F6(e, t, r, i);
      return;
    case 8:
      M6(e, t, r, i);
      return;
    case 9:
      P6(e, t, r, i);
      return;
    case 10:
      B6(e, t, r, i);
      return;
    case 11:
      L6(e, t, r, i);
      return;
    case 12:
      z6(e, t, r, i);
      return;
    case 16:
      V6(e, t, r, i);
      return;
    case 32:
      for (let u = 0; u < 32; u = u + 1 | 0) r[i + u | 0] = e[t + u | 0] | 0;
      return;
  }
  let a = Gl[n] >>> 0, s = t, o = 0, l = e[s] >>> 0;
  for (let u = 0; u < 32; u++) if (o + n <= 32) {
    let c = l >>> o & a;
    r[i + u] = c | 0, o += n, o === 32 && (o = 0, s++, u !== 31 && (l = e[s] >>> 0));
  } else {
    let c = 32 - o, h = l >>> o;
    s++, l = e[s] >>> 0;
    let p = Gl[n - c] >>> 0, f = (h | (l & p) << c) & a;
    r[i + u] = f | 0, o = n - c;
  }
}
function u5(e, t, r, i) {
  if (t < 0 || r < 0 || t + r > e.length) throw RangeError(`decodeBigEndianInt32sInto: out of bounds (offset=${t}, byteLength=${r}, bytes.length=${e.length})`);
  let n = Math.floor(r / 4), a = r % 4 != 0, s = a ? n + 1 : n;
  if (i.length < s) throw RangeError(`decodeBigEndianInt32sInto: out.length=${i.length} < ${s}`);
  if (n > 0) {
    let o = e.byteOffset + t;
    if (o & 3) for (let l = 0; l < n; l++) {
      let u = t + l * 4;
      i[l] = e[u] << 24 | e[u + 1] << 16 | e[u + 2] << 8 | e[u + 3];
    }
    else {
      let l = new Uint32Array(e.buffer, o, n);
      for (let u = 0; u < n; u++) i[u] = A6(l[u]) | 0;
    }
  }
  if (a) {
    let o = t + n * 4, l = r - n * 4, u = 0;
    for (let c = 0; c < l; c++) u |= e[o + c] << 24 - c * 8;
    i[n] = u | 0;
  }
  return s;
}
function Ge(e, t, r) {
  let i = new Uint32Array(r), n = 0, a = t.get();
  for (let s = 0; s < i.length; s++) {
    let o = e[a++], l = o & 127;
    o < 128 || (o = e[a++], l |= (o & 127) << 7, o < 128 || (o = e[a++], l |= (o & 127) << 14, o < 128 || (o = e[a++], l |= (o & 127) << 21, o < 128 || (o = e[a++], l |= (o & 15) << 28)))), i[n++] = l;
  }
  return t.set(a), i;
}
function tc(e, t, r) {
  let i = new BigUint64Array(r);
  for (let n = 0; n < i.length; n++) i[n] = c5(e, t);
  return i;
}
function c5(e, t) {
  let r = 0n, i = 0, n = t.get();
  for (; n < e.length; ) {
    let a = e[n++];
    if (r |= BigInt(a & 127) << BigInt(i), !(a & 128)) break;
    if (i += 7, i >= 64) throw Error("Varint too long");
  }
  return t.set(n), r;
}
function h5(e, t, r) {
  let i = new Float64Array(r);
  for (let n = 0; n < r; n++) i[n] = p5(e, t);
  return i;
}
function p5(e, t) {
  let r, i;
  return i = e[t.get()], t.increment(), r = i & 127, i < 128 || (i = e[t.get()], t.increment(), r |= (i & 127) << 7, i < 128) || (i = e[t.get()], t.increment(), r |= (i & 127) << 14, i < 128) || (i = e[t.get()], t.increment(), r |= (i & 127) << 21, i < 128) ? r : (i = e[t.get()], r |= (i & 15) << 28, f5(r, e, t));
}
function f5(e, t, r) {
  let i, n;
  if (n = t[r.get()], r.increment(), i = (n & 112) >> 4, n < 128 || (n = t[r.get()], r.increment(), i |= (n & 127) << 3, n < 128) || (n = t[r.get()], r.increment(), i |= (n & 127) << 10, n < 128) || (n = t[r.get()], r.increment(), i |= (n & 127) << 17, n < 128) || (n = t[r.get()], r.increment(), i |= (n & 127) << 24, n < 128) || (n = t[r.get()], r.increment(), i |= (n & 1) << 31, n < 128)) return i * 4294967296 + (e >>> 0);
  throw Error("Expected varint not more than 10 bytes");
}
function d5(e, t, r, i) {
  return y5(e, t, r, i, Z6(r >>> 2));
}
function y5(e, t, r, i, n) {
  let a = i.get();
  if (r & 3) throw Error(`FastPFOR: invalid encodedByteLength=${r} at offset=${a} (encodedBytes.length=${e.length}; expected a multiple of 4 bytes for an int32 big-endian word stream)`);
  let s = r >>> 2, o = H6(n, s);
  u5(e, a, r, o);
  let l = o5(o.subarray(0, s), t, n.decoderWorkspace);
  return i.add(r), l;
}
function ae(e) {
  return e >>> 1 ^ -(e & 1);
}
function Ue(e) {
  return e >> 1n ^ -(e & 1n);
}
function Ar(e) {
  return e % 2 == 1 ? (e + 1) / -2 : e / 2;
}
function m5(e) {
  let t = new Int32Array(e.length);
  for (let r = 0; r < e.length; r++) t[r] = ae(e[r]);
  return t;
}
function g5(e) {
  let t = new BigInt64Array(e.length);
  for (let r = 0; r < e.length; r++) t[r] = Ue(e[r]);
  return t;
}
function Yl(e, t, r) {
  if (r === void 0) {
    r = 0;
    for (let a = 0; a < t; a++) r += e[a];
  }
  let i = new Uint32Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = e[a], o = e[a + t];
    i.fill(o, n, n + s), n += s;
  }
  return i;
}
function Wl(e, t, r) {
  if (r === void 0) {
    r = 0;
    for (let a = 0; a < t; a++) r += Number(e[a]);
  }
  let i = new BigUint64Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = Number(e[a]), o = e[a + t];
    i.fill(o, n, n + s), n += s;
  }
  return i;
}
function O1(e, t, r) {
  let i = new Float64Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = e[a], o = e[a + t];
    i.fill(o, n, n + s), n += s;
  }
  return i;
}
function Vp(e) {
  let t = new Int32Array(e.length);
  t[0] = ae(e[0]);
  let r = e.length / 4 * 4, i = 1;
  if (r >= 4) for (; i < r - 4; i += 4) {
    let n = e[i], a = e[i + 1], s = e[i + 2], o = e[i + 3];
    t[i] = ae(n) + t[i - 1], t[i + 1] = ae(a) + t[i], t[i + 2] = ae(s) + t[i + 1], t[i + 3] = ae(o) + t[i + 2];
  }
  for (; i !== e.length; ++i) t[i] = ae(e[i]) + t[i - 1];
  return t;
}
function Op(e) {
  let t = new BigInt64Array(e.length);
  t[0] = Ue(e[0]);
  let r = e.length / 4 * 4, i = 1;
  if (r >= 4) for (; i < r - 4; i += 4) {
    let n = e[i], a = e[i + 1], s = e[i + 2], o = e[i + 3];
    t[i] = Ue(n) + t[i - 1], t[i + 1] = Ue(a) + t[i], t[i + 2] = Ue(s) + t[i + 1], t[i + 3] = Ue(o) + t[i + 2];
  }
  for (; i !== t.length; ++i) t[i] = Ue(e[i]) + t[i - 1];
  return t;
}
function x5(e) {
  e[0] = Ar(e[0]);
  let t = e.length / 4 * 4, r = 1;
  if (t >= 4) for (; r < t - 4; r += 4) {
    let i = e[r], n = e[r + 1], a = e[r + 2], s = e[r + 3];
    e[r] = Ar(i) + e[r - 1], e[r + 1] = Ar(n) + e[r], e[r + 2] = Ar(a) + e[r + 1], e[r + 3] = Ar(s) + e[r + 2];
  }
  for (; r !== e.length; ++r) e[r] = Ar(e[r]) + e[r - 1];
}
function v5(e, t, r) {
  if (r === void 0) {
    r = 0;
    for (let a = 0; a < t; a++) r += e[a];
  }
  let i = new Int32Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = e[a], o = e[a + t];
    o = ae(o), i.fill(o, n, n + s), n += s;
  }
  return i;
}
function b5(e, t, r) {
  if (r === void 0) {
    r = 0;
    for (let a = 0; a < t; a++) r += Number(e[a]);
  }
  let i = new BigInt64Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = Number(e[a]), o = e[a + t];
    o = Ue(o), i.fill(o, n, n + s), n += s;
  }
  return i;
}
function w5(e, t, r) {
  let i = new Float64Array(r), n = 0;
  for (let a = 0; a < t; a++) {
    let s = e[a], o = e[a + t];
    o = Ar(o), i.fill(o, n, n + s), n += s;
  }
  return i;
}
function rc(e) {
  let t = e.length / 4 * 4, r = 1;
  if (t >= 4) for (let i = e[0]; r < t - 4; r += 4) i = e[r] += i, i = e[r + 1] += i, i = e[r + 2] += i, i = e[r + 3] += i;
  for (; r !== e.length; ) e[r] += e[r - 1], ++r;
}
function _5(e) {
  let t = 0;
  for (let r = 0; r < e.length; r++) e[r] += t, t = e[r];
}
function D5(e) {
  if (e.length < 2) return new Int32Array(e);
  let t = new Int32Array(e.length);
  t[0] = ae(e[0]), t[1] = ae(e[1]);
  let r = e.length / 4 * 4, i = 2;
  if (r >= 4) for (; i < r - 4; i += 4) {
    let n = e[i], a = e[i + 1], s = e[i + 2], o = e[i + 3];
    t[i] = ae(n) + t[i - 2], t[i + 1] = ae(a) + t[i - 1], t[i + 2] = ae(s) + t[i], t[i + 3] = ae(o) + t[i + 1];
  }
  for (; i !== e.length; i += 2) t[i] = ae(e[i]) + t[i - 2], t[i + 1] = ae(e[i + 1]) + t[i - 1];
  return t;
}
function S5(e) {
  let t = new Int32Array(e.length + 1);
  t[0] = 0, t[1] = ae(e[0]);
  let r = t[1];
  for (let i = 2; i !== t.length; ++i) {
    let n = e[i - 1], a = ae(n);
    r += a, t[i] = t[i - 1] + r;
  }
  return new Uint32Array(t);
}
function A5(e, t, r) {
  let i = new Int32Array(r + 1);
  i[0] = 0;
  let n = 1, a = i[0];
  for (let s = 0; s < t; s++) {
    let o = e[s], l = e[s + t];
    l = ae(l);
    for (let u = n; u < n + o; u++) i[u] = l + a, a = i[u];
    n += o;
  }
  return i;
}
function E5(e, t, r) {
  let i = new Uint32Array(r + 1);
  i[0] = 0;
  let n = 1, a = i[0];
  for (let s = 0; s < t; s++) {
    let o = e[s], l = e[s + t];
    for (let u = n; u < n + o; u++) i[u] = l + a, a = i[u];
    n += o;
  }
  return i;
}
function T5(e, t, r) {
  let i = new Int32Array(r), n = 0, a = 0;
  for (let s = 0; s < t; s++) {
    let o = e[s], l = e[s + t], u = ae(l);
    for (let c = 0; c < o; c++) a += u, i[n++] = a;
  }
  return i;
}
function I5(e, t, r) {
  let i = new BigInt64Array(r), n = 0, a = 0n;
  for (let s = 0; s < t; s++) {
    let o = Number(e[s]), l = e[s + t], u = Ue(l);
    for (let c = 0; c < o; c++) a += u, i[n++] = a;
  }
  return i;
}
function Rp(e) {
  let t = new Uint32Array(e.length);
  t[0] = ae(e[0]) >>> 0;
  for (let r = 1; r < e.length; r++) t[r] = t[r - 1] + ae(e[r]) >>> 0;
  return t;
}
function $p(e) {
  let t = new BigUint64Array(e.length);
  t[0] = BigInt.asUintN(64, Ue(e[0]));
  for (let r = 1; r < e.length; r++) t[r] = BigInt.asUintN(64, t[r - 1] + Ue(e[r]));
  return t;
}
function C5(e) {
  if (e.length < 2) return new Uint32Array(e);
  let t = new Uint32Array(e.length);
  t[0] = ae(e[0]) >>> 0, t[1] = ae(e[1]) >>> 0;
  for (let r = 2; r < e.length; r += 2) t[r] = t[r - 2] + ae(e[r]) >>> 0, t[r + 1] = t[r - 1] + ae(e[r + 1]) >>> 0;
  return t;
}
function k5(e) {
  return e[1];
}
function F5(e) {
  return ae(e[1]);
}
function M5(e) {
  if (e.length === 2) {
    let t = ae(e[1]);
    return [t, t];
  }
  return [ae(e[2]), ae(e[3])];
}
function P5(e) {
  return e[1];
}
function B5(e) {
  return Ue(e[1]);
}
function L5(e) {
  if (e.length === 2) {
    let t = Ue(e[1]);
    return [t, t];
  }
  return [Ue(e[2]), Ue(e[3])];
}
var Ie;
(function(e) {
  e.PRESENT = "PRESENT", e.DATA = "DATA", e.OFFSET = "OFFSET", e.LENGTH = "LENGTH";
})(Ie || (Ie = {}));
var Ke;
(function(e) {
  e.NONE = "NONE", e.SINGLE = "SINGLE", e.SHARED = "SHARED", e.VERTEX = "VERTEX", e.MORTON = "MORTON", e.FSST = "FSST";
})(Ke || (Ke = {}));
var Yt;
(function(e) {
  e.VERTEX = "VERTEX", e.INDEX = "INDEX", e.STRING = "STRING", e.KEY = "KEY";
})(Yt || (Yt = {}));
var Le;
(function(e) {
  e.VAR_BINARY = "VAR_BINARY", e.GEOMETRIES = "GEOMETRIES", e.PARTS = "PARTS", e.RINGS = "RINGS", e.TRIANGLES = "TRIANGLES", e.SYMBOL = "SYMBOL", e.DICTIONARY = "DICTIONARY";
})(Le || (Le = {}));
const z5 = [Ie.PRESENT, Ie.DATA, Ie.OFFSET, Ie.LENGTH], Np = [Z.NONE, Z.DELTA, Z.COMPONENTWISE_DELTA, Z.RLE, Z.MORTON], V5 = [gt.NONE, gt.FAST_PFOR, gt.VARINT], O5 = [Ke.NONE, Ke.SINGLE, Ke.SHARED, Ke.VERTEX, Ke.MORTON, Ke.FSST], R5 = [Yt.VERTEX, Yt.INDEX, Yt.STRING, Yt.KEY], $5 = [Le.VAR_BINARY, Le.GEOMETRIES, Le.PARTS, Le.RINGS, Le.TRIANGLES, Le.SYMBOL, Le.DICTIONARY];
function ye(e, t) {
  let r = j5(e, t);
  return r.logicalLevelTechnique1 === Z.MORTON ? N5(r, e, t) : (Z.RLE === r.logicalLevelTechnique1 || Z.RLE === r.logicalLevelTechnique2) && gt.NONE !== r.physicalLevelTechnique ? U5(r, e, t) : r;
}
function N5(e, t, r) {
  let i = Ge(t, r, 2);
  return { physicalStreamType: e.physicalStreamType, logicalStreamType: e.logicalStreamType, logicalLevelTechnique1: e.logicalLevelTechnique1, logicalLevelTechnique2: e.logicalLevelTechnique2, physicalLevelTechnique: e.physicalLevelTechnique, numValues: e.numValues, byteLength: e.byteLength, decompressedCount: e.decompressedCount, numBits: i[0], coordinateShift: i[1] };
}
function U5(e, t, r) {
  let i = Ge(t, r, 2);
  return { physicalStreamType: e.physicalStreamType, logicalStreamType: e.logicalStreamType, logicalLevelTechnique1: e.logicalLevelTechnique1, logicalLevelTechnique2: e.logicalLevelTechnique2, physicalLevelTechnique: e.physicalLevelTechnique, numValues: e.numValues, byteLength: e.byteLength, decompressedCount: i[1], runs: i[0], numRleValues: i[1] };
}
function j5(e, t) {
  let r = e[t.get()], i = z5[r >> 4], n = {};
  switch (i) {
    case Ie.DATA:
      n = { dictionaryType: O5[r & 15] };
      break;
    case Ie.OFFSET:
      n = { offsetType: R5[r & 15] };
      break;
    case Ie.LENGTH:
      n = { lengthType: $5[r & 15] };
  }
  t.increment();
  let a = e[t.get()], s = Np[a >> 5], o = Np[a >> 2 & 7], l = V5[a & 3];
  t.increment();
  let u = Ge(e, t, 2), c = u[0], h = u[1];
  return { physicalStreamType: i, logicalStreamType: n, logicalLevelTechnique1: s, logicalLevelTechnique2: o, physicalLevelTechnique: l, numValues: c, byteLength: h, decompressedCount: c };
}
var pe;
(function(e) {
  e[e.FLAT = 0] = "FLAT", e[e.CONST = 1] = "CONST", e[e.SEQUENCE = 2] = "SEQUENCE", e[e.DICTIONARY = 3] = "DICTIONARY", e[e.FSST_DICTIONARY = 4] = "FSST_DICTIONARY";
})(pe || (pe = {}));
var St = class {
  constructor(e, t) {
    this.values = e, this._size = t;
  }
  get(e) {
    let t = Math.floor(e / 8), r = e % 8;
    return (this.values[t] >> r & 1) == 1;
  }
  set(e, t) {
    let r = Math.floor(e / 8), i = e % 8;
    this.values[r] = this.values[r] | +!!t << i;
  }
  getInt(e) {
    let t = Math.floor(e / 8), r = e % 8;
    return this.values[t] >> r & 1;
  }
  size() {
    return this._size;
  }
  getBuffer() {
    return this.values;
  }
};
function $r(e, t, r) {
  if (!t) return e;
  let i = t.size(), n = e.constructor, a = new n(i), s = 0;
  for (let o = 0; o < i; o++) a[o] = t.get(o) ? e[s++] : r;
  return a;
}
function q5(e, t, r) {
  if (!r) return e;
  let i = r.size(), n = new St(e, t), a = new St(new Uint8Array(Math.ceil(i / 8)), i), s = 0;
  for (let o = 0; o < i; o++) {
    let l = r.get(o) ? n.get(s++) : !1;
    a.set(o, l);
  }
  return a.getBuffer();
}
function Ti(e, t, r, i, n) {
  let a = G5(e, Math.ceil(t / 8), r, i);
  return n ? q5(a, t, n) : a;
}
function G5(e, t, r, i) {
  let n = new Uint8Array(t), a = 0, s = i.get() + r;
  for (; a < t && !(i.get() >= s); ) {
    let o = e[i.increment()];
    if (o <= 127) {
      let l = o + 3, u = e[i.increment()], c = Math.min(a + l, t);
      n.fill(u, a, c), a = c;
    } else {
      let l = 256 - o;
      for (let u = 0; u < l && a < t; u++) n[a++] = e[i.increment()];
    }
  }
  return i.set(s), n;
}
function R1(e, t, r, i) {
  let n = t.get(), a = n + r * Float32Array.BYTES_PER_ELEMENT, s = new Uint8Array(e.subarray(n, a)).buffer, o = new Float32Array(s);
  return t.set(a), i ? $r(o, i, 0) : o;
}
function $1(e, t, r, i) {
  let n = t.get(), a = n + r * Float64Array.BYTES_PER_ELEMENT, s = new Uint8Array(e.subarray(n, a)).buffer, o = new Float64Array(s);
  return t.set(a), i ? $r(o, i, 0) : o;
}
function X5(e, t, r) {
  let i = t.get(), n = r * Uint32Array.BYTES_PER_ELEMENT, a = new DataView(e.buffer, e.byteOffset, e.byteLength), s = new Uint32Array(r);
  for (let o = 0; o < r; o++) s[o] = a.getUint32(i + o * Uint32Array.BYTES_PER_ELEMENT, !0);
  return t.add(n), s;
}
function Y5(e, t, r) {
  let i = t.get(), n = r * BigUint64Array.BYTES_PER_ELEMENT, a = new DataView(e.buffer, e.byteOffset, e.byteLength), s = new BigUint64Array(r);
  for (let o = 0; o < r; o++) s[o] = a.getBigUint64(i + o * BigUint64Array.BYTES_PER_ELEMENT, !0);
  return t.add(n), s;
}
const W5 = new TextDecoder();
function ic(e, t, r) {
  return r - t >= 12 ? W5.decode(e.subarray(t, r)) : Z5(e, t, r);
}
function Z5(e, t, r) {
  let i = "", n = t;
  for (; n < r; ) {
    let a = e[n], s = null, o = a > 239 ? 4 : a > 223 ? 3 : a > 191 ? 2 : 1;
    if (n + o > r) break;
    let l, u, c;
    o === 1 ? a < 128 && (s = a) : o === 2 ? (l = e[n + 1], (l & 192) == 128 && (s = (a & 31) << 6 | l & 63, s <= 127 && (s = null))) : o === 3 ? (l = e[n + 1], u = e[n + 2], (l & 192) == 128 && (u & 192) == 128 && (s = (a & 15) << 12 | (l & 63) << 6 | u & 63, (s <= 2047 || s >= 55296 && s <= 57343) && (s = null))) : o === 4 && (l = e[n + 1], u = e[n + 2], c = e[n + 3], (l & 192) == 128 && (u & 192) == 128 && (c & 192) == 128 && (s = (a & 15) << 18 | (l & 63) << 12 | (u & 63) << 6 | c & 63, (s <= 65535 || s >= 1114112) && (s = null))), s === null ? (s = 65533, o = 1) : s > 65535 && (s -= 65536, i += String.fromCharCode(s >>> 10 & 1023 | 55296), s = 56320 | s & 1023), i += String.fromCharCode(s), n += o;
  }
  return i;
}
function ns(e, t, r, i, n) {
  return e_(Ii(e, t, r), r, i, n);
}
function Ne(e, t, r, i, n) {
  return t_(Ii(e, t, r), r, i, n);
}
function cr(e, t, r) {
  return n_(Ii(e, t, r), r);
}
function Ii(e, t, r) {
  let i = r.physicalLevelTechnique;
  switch (i) {
    case gt.FAST_PFOR:
      return d5(e, r.numValues, r.byteLength, t);
    case gt.VARINT:
      return Ge(e, t, r.numValues);
    case gt.NONE:
      return X5(e, t, r.numValues);
    default:
      throw Error(`Specified physicalLevelTechnique ${i} is not supported (yet).`);
  }
}
function qn(e, t, r) {
  let i = r.physicalLevelTechnique;
  switch (i) {
    case gt.VARINT:
      return tc(e, t, r.numValues);
    case gt.NONE:
      return Y5(e, t, r.numValues);
    default:
      throw Error(`Specified physicalLevelTechnique ${i} is not supported (yet).`);
  }
}
function H5(e, t, r) {
  let i = Ii(e, t, r);
  return i.length === 1 ? ae(i[0]) : F5(i);
}
function nc(e, t, r) {
  let i = Ii(e, t, r);
  return i.length === 1 ? r.logicalLevelTechnique1 === Z.DELTA ? ae(i[0]) : i[0] : k5(i);
}
function N1(e, t, r) {
  return M5(Ii(e, t, r));
}
function U1(e, t, r) {
  return L5(tc(e, t, r.numValues));
}
function j1(e, t, r, i) {
  return r_(qn(e, t, r), r, i);
}
function ac(e, t, r, i) {
  return G1(qn(e, t, r), r, i);
}
function K5(e, t, r, i) {
  let n = J5(e, t, r, !1);
  return i ? $r(n, i, 0) : n;
}
function J5(e, t, r, i) {
  if (r.physicalLevelTechnique === gt.VARINT) return i_(h5(e, t, r.numValues), r, i);
  let n = qn(e, t, r), a = G1(n, r);
  return Float64Array.from(a, Number);
}
function Q5(e, t, r) {
  let i = qn(e, t, r);
  return i.length === 1 ? Ue(i[0]) : B5(i);
}
function q1(e, t, r) {
  let i = qn(e, t, r);
  return i.length === 1 ? r.logicalLevelTechnique1 === Z.DELTA ? Ue(i[0]) : i[0] : P5(i);
}
function e_(e, t, r, i) {
  let n;
  switch (t.logicalLevelTechnique1) {
    case Z.DELTA:
      if (t.logicalLevelTechnique2 === Z.RLE) {
        let a = t;
        if (!i) return T5(e, a.runs, a.numRleValues);
        e = Yl(e, a.runs, a.numRleValues), n = Vp(e);
      } else n = Vp(e);
      break;
    case Z.RLE:
      n = v5(e, t.runs, t.numRleValues);
      break;
    case Z.MORTON:
      rc(e), n = new Int32Array(e);
      break;
    case Z.COMPONENTWISE_DELTA:
      n = D5(e);
      break;
    case Z.NONE:
      n = m5(e);
      break;
    default:
      throw Error(`The specified Logical level technique is not supported: ${t.logicalLevelTechnique1}`);
  }
  return i ? $r(n, i, 0) : n;
}
function t_(e, t, r, i) {
  let n;
  switch (t.logicalLevelTechnique1) {
    case Z.DELTA:
      if (t.logicalLevelTechnique2 === Z.RLE) {
        let a = t;
        n = Rp(Yl(e, a.runs, a.numRleValues));
      } else n = Rp(e);
      break;
    case Z.RLE:
      n = Yl(e, t.runs, t.numRleValues);
      break;
    case Z.MORTON:
      rc(e), n = e;
      break;
    case Z.COMPONENTWISE_DELTA:
      n = C5(e);
      break;
    case Z.NONE:
      n = e;
      break;
    default:
      throw Error(`The specified Logical level technique is not supported: ${t.logicalLevelTechnique1}`);
  }
  return i ? $r(n, i, 0) : n;
}
function r_(e, t, r) {
  let i;
  switch (t.logicalLevelTechnique1) {
    case Z.DELTA:
      if (t.logicalLevelTechnique2 === Z.RLE) {
        let n = t;
        if (!r) return I5(e, n.runs, n.numRleValues);
        e = Wl(e, n.runs, n.numRleValues), i = Op(e);
      } else i = Op(e);
      break;
    case Z.RLE:
      i = b5(e, t.runs, t.numRleValues);
      break;
    case Z.NONE:
      i = g5(e);
      break;
    default:
      throw Error(`The specified Logical level technique is not supported: ${t.logicalLevelTechnique1}`);
  }
  return r ? $r(i, r, 0n) : i;
}
function G1(e, t, r) {
  let i;
  switch (t.logicalLevelTechnique1) {
    case Z.DELTA:
      if (t.logicalLevelTechnique2 === Z.RLE) {
        let n = t;
        i = $p(Wl(e, n.runs, n.numRleValues));
      } else i = $p(e);
      break;
    case Z.RLE:
      i = Wl(e, t.runs, t.numRleValues);
      break;
    case Z.NONE:
      i = e;
      break;
    default:
      throw Error(`The specified Logical level technique is not supported: ${t.logicalLevelTechnique1}`);
  }
  return r ? $r(i, r, 0n) : i;
}
function i_(e, t, r) {
  switch (t.logicalLevelTechnique1) {
    case Z.DELTA:
      if (t.logicalLevelTechnique2 === Z.RLE) {
        let i = t;
        e = O1(e, i.runs, i.numRleValues);
      }
      return x5(e), e;
    case Z.RLE:
      return s_(e, t, r);
    case Z.NONE:
      return e;
    default:
      throw Error(`The specified Logical level technique is not supported: ${t.logicalLevelTechnique1}`);
  }
}
function n_(e, t) {
  if (t.logicalLevelTechnique1 === Z.DELTA && t.logicalLevelTechnique2 === Z.NONE) return S5(e);
  if (t.logicalLevelTechnique1 === Z.RLE && t.logicalLevelTechnique2 === Z.NONE) {
    let r = t;
    return E5(e, r.runs, r.numRleValues);
  }
  if (t.logicalLevelTechnique1 === Z.NONE && t.logicalLevelTechnique2 === Z.NONE) {
    _5(e);
    let r = new Uint32Array(t.numValues + 1);
    return r[0] = 0, r.set(e, 1), r;
  }
  if (t.logicalLevelTechnique1 === Z.DELTA && t.logicalLevelTechnique2 === Z.RLE) {
    let r = t, i = A5(e, r.runs, r.numRleValues);
    return rc(i), new Uint32Array(i);
  }
  throw Error("Only delta encoding is supported for transforming length to offset streams yet.");
}
function Cs(e, t, r, i, n = "int32") {
  let a = e.logicalLevelTechnique1;
  if (a === Z.RLE) return e.runs === 1 ? pe.CONST : pe.FLAT;
  if (a !== Z.DELTA || e.logicalLevelTechnique2 !== Z.RLE) return e.numValues === 1 ? pe.CONST : pe.FLAT;
  let s = t instanceof St ? t.size() : t, o = e;
  if (o.numRleValues !== s) return pe.FLAT;
  if (o.runs === 1) return pe.SEQUENCE;
  if (o.runs !== 2) return e.numValues === 1 ? pe.CONST : pe.FLAT;
  let l = i.get();
  if (e.physicalLevelTechnique === gt.VARINT) return a_(r, i, n) ? pe.SEQUENCE : e.numValues === 1 ? pe.CONST : pe.FLAT;
  let u = i.get(), c = new Int32Array(r.buffer, r.byteOffset + u, 4);
  return i.set(l), c[2] === 2 && c[3] === 2 ? pe.SEQUENCE : e.numValues === 1 ? pe.CONST : pe.FLAT;
}
function a_(e, t, r) {
  let i = new L1(t.get());
  if (r === "int64") {
    let a = tc(e, i, 4);
    return a[2] === 2n && a[3] === 2n;
  }
  let n = Ge(e, i, 4);
  return n[2] === 2 && n[3] === 2;
}
function s_(e, t, r) {
  return r ? w5(e, t.runs, t.numRleValues) : O1(e, t.runs, t.numRleValues);
}
var X1 = class extends Is {
  getValueFromBuffer(e) {
    return this.dataBuffer[e];
  }
}, Y1 = class extends P1 {
  constructor(e, t, r, i, n) {
    super(e, n ? BigInt64Array.of(t) : BigUint64Array.of(t), r, i);
  }
  getValueFromBuffer(e) {
    return this.dataBuffer[0] + BigInt(e) * this.delta;
  }
};
function sc(e, t, r) {
  return { x: Up(e, t) - r, y: Up(e >> 1, t) - r };
}
function Up(e, t) {
  let r = 0;
  for (let i = 0; i < t; i++) r |= (e & 1 << 2 * i) >> i;
  return r;
}
var je;
(function(e) {
  e[e.POINT = 0] = "POINT", e[e.LINESTRING = 1] = "LINESTRING", e[e.POLYGON = 2] = "POLYGON", e[e.MULTIPOINT = 3] = "MULTIPOINT", e[e.MULTILINESTRING = 4] = "MULTILINESTRING", e[e.MULTIPOLYGON = 5] = "MULTIPOLYGON";
})(je || (je = {}));
var o_;
(function(e) {
  e[e.POINT = 0] = "POINT", e[e.LINESTRING = 1] = "LINESTRING", e[e.POLYGON = 2] = "POLYGON";
})(o_ || (o_ = {}));
var Nr;
(function(e) {
  e[e.MORTON = 0] = "MORTON", e[e.VEC_2 = 1] = "VEC_2", e[e.VEC_3 = 2] = "VEC_3";
})(Nr || (Nr = {}));
function l_(e) {
  let t = Array(e.numGeometries), r = 1, i = 1, n = 1, a = 0, s = 0, o = 0, l = e.mortonSettings, u = e.topologyVector, c = u.geometryOffsets, h = u.partOffsets, p = u.ringOffsets, f = e.vertexOffsets, d = !f || f.length === 0, y = e.containsPolygonGeometry(), m = e.vertexBuffer;
  for (let g = 0; g < e.numGeometries; g++) {
    let v = e.geometryType(g);
    switch (v) {
      case je.POINT:
        {
          let x, b;
          if (d) x = m[s++], b = m[s++];
          else if (e.vertexBufferType === Nr.MORTON) {
            let w = m[f[o++]], D = sc(w, l.numBits, l.coordinateShift);
            x = D.x, b = D.y;
          } else {
            let w = f[o++] * 2;
            x = m[w], b = m[w + 1];
          }
          t[a++] = [[new T(x, b)]], c && n++, h && r++, p && i++;
        }
        break;
      case je.MULTIPOINT:
        {
          let x = c[n] - c[n - 1];
          n++;
          let b;
          if (d) {
            b = Array(x);
            for (let w = 0; w < x; w++) {
              let D = m[s++], _ = m[s++];
              b[w] = new T(D, _);
            }
          } else b = Dr(e.vertexBufferType, m, f, o, x, !1, l), o += x;
          t[a++] = b.map((w) => [w]), r += x, i += x;
        }
        break;
      case je.LINESTRING:
        {
          let x;
          y ? (x = p[i] - p[i - 1], i++) : x = h[r] - h[r - 1], r++;
          let b;
          d ? (b = Zr(m, s, x, !1), s += x * 2) : (b = Dr(e.vertexBufferType, m, f, o, x, !1, l), o += x), t[a++] = [b], c && n++;
        }
        break;
      case je.POLYGON:
        {
          let x = h[r] - h[r - 1];
          r++;
          let b = Array(x - 1), w, D = p[i] - p[i - 1];
          if (i++, d) {
            w = Zr(m, s, D, !0), s += D * 2;
            for (let _ = 0; _ < b.length; _++) D = p[i] - p[i - 1], i++, b[_] = Zr(m, s, D, !0), s += D * 2;
          } else {
            w = Dr(e.vertexBufferType, m, f, o, D, !0, l), o += D;
            for (let _ = 0; _ < b.length; _++) D = p[i] - p[i - 1], i++, b[_] = Dr(e.vertexBufferType, m, f, o, D, !0, l), o += D;
          }
          t[a++] = [w].concat(b), c && n++;
        }
        break;
      case je.MULTILINESTRING:
        {
          let x = c[n] - c[n - 1];
          n++;
          let b = Array(x);
          for (let w = 0; w < x; w++) {
            let D;
            if (y ? (D = p[i] - p[i - 1], i++) : D = h[r] - h[r - 1], r++, d) b[w] = Zr(m, s, D, !1), s += D * 2;
            else {
              let _ = Dr(e.vertexBufferType, m, f, o, D, !1, l);
              b[w] = _, o += D;
            }
          }
          t[a++] = b;
        }
        break;
      case je.MULTIPOLYGON:
        {
          let x = c[n] - c[n - 1];
          n++;
          let b = Array(x);
          for (let w = 0; w < x; w++) {
            let D = h[r] - h[r - 1];
            r++;
            let _, A = Array(D - 1), E = p[i] - p[i - 1];
            i++, d ? (_ = Zr(m, s, E, !0), s += E * 2) : (_ = Dr(e.vertexBufferType, m, f, o, E, !0, l), o += E);
            for (let R = 0; R < A.length; R++) {
              let B = p[i] - p[i - 1];
              i++, d ? (A[R] = Zr(m, s, B, !0), s += B * 2) : (A[R] = Dr(e.vertexBufferType, m, f, o, B, !0, l), o += B);
            }
            b[w] = [_].concat(A);
          }
          t[a++] = b.flat();
        }
        break;
      default:
        throw Error(`The specified geometry type (${v}) is currently not supported.`);
    }
  }
  return t;
}
function Dr(e, t, r, i, n, a, s) {
  return e === Nr.MORTON ? c_(t, r, i, n, a, s) : u_(t, r, i, n, a);
}
function Zr(e, t, r, i) {
  let n = Array(i ? r + 1 : r);
  for (let a = 0; a < r * 2; a += 2) {
    let s = e[t + a], o = e[t + a + 1];
    n[a / 2] = new T(s, o);
  }
  return i && (n[n.length - 1] = n[0]), n;
}
function u_(e, t, r, i, n) {
  let a = Array(n ? i + 1 : i);
  for (let s = 0; s < i * 2; s += 2) {
    let o = t[r + s / 2] * 2, l = e[o], u = e[o + 1];
    a[s / 2] = new T(l, u);
  }
  return n && (a[a.length - 1] = a[0]), a;
}
function c_(e, t, r, i, n, a) {
  let s = Array(n ? i + 1 : i);
  for (let o = 0; o < i; o++) {
    let l = e[t[r + o]], u = sc(l, a.numBits, a.coordinateShift);
    s[o] = new T(u.x, u.y);
  }
  return n && (s[s.length - 1] = s[0]), s;
}
var W1 = class {
  constructor(e, t, r, i, n) {
    this._vertexBufferType = e, this._topologyVector = t, this._vertexOffsets = r, this._vertexBuffer = i, this._mortonSettings = n;
  }
  get vertexBufferType() {
    return this._vertexBufferType;
  }
  get topologyVector() {
    return this._topologyVector;
  }
  get vertexOffsets() {
    return this._vertexOffsets;
  }
  get vertexBuffer() {
    return this._vertexBuffer;
  }
  getSimpleEncodedVertex(e) {
    let t = this.vertexOffsets ? this.vertexOffsets[e] * 2 : e * 2;
    return [this.vertexBuffer[t], this.vertexBuffer[t + 1]];
  }
  getVertex(e) {
    if (this.vertexOffsets && this.mortonSettings) {
      let r = this.vertexOffsets[e], i = this.vertexBuffer[r], n = sc(i, this.mortonSettings.numBits, this.mortonSettings.coordinateShift);
      return [n.x, n.y];
    }
    let t = this.vertexOffsets ? this.vertexOffsets[e] * 2 : e * 2;
    return [this.vertexBuffer[t], this.vertexBuffer[t + 1]];
  }
  getGeometries() {
    return l_(this);
  }
  get mortonSettings() {
    return this._mortonSettings;
  }
};
function h_(e, t, r, i, n) {
  return new Z1(e, t, Nr.VEC_2, r, i, n);
}
function p_(e, t, r, i, n, a) {
  return new Z1(e, t, Nr.MORTON, r, i, n, a);
}
var Z1 = class extends W1 {
  constructor(e, t, r, i, n, a, s) {
    super(r, i, n, a, s), this._numGeometries = e, this._geometryType = t;
  }
  geometryType(e) {
    return this._geometryType;
  }
  get numGeometries() {
    return this._numGeometries;
  }
  containsPolygonGeometry() {
    return this._geometryType === je.POLYGON || this._geometryType === je.MULTIPOLYGON;
  }
  containsSingleGeometryType() {
    return !0;
  }
};
function H1(e, t, r, i) {
  return new K1(Nr.VEC_2, e, t, r, i);
}
function f_(e, t, r, i, n) {
  return new K1(Nr.MORTON, e, t, r, i, n);
}
var K1 = class extends W1 {
  constructor(e, t, r, i, n, a) {
    super(e, r, i, n, a), this._geometryTypes = t;
  }
  geometryType(e) {
    return this._geometryTypes[e];
  }
  get numGeometries() {
    return this._geometryTypes.length;
  }
  containsPolygonGeometry() {
    for (let e = 0; e < this.numGeometries; e++) if (this.geometryType(e) === je.POLYGON || this.geometryType(e) === je.MULTIPOLYGON) return !0;
    return !1;
  }
  containsSingleGeometryType() {
    return !1;
  }
}, J1 = class {
  constructor(e, t, r, i) {
    this._triangleOffsets = e, this._indexBuffer = t, this._vertexBuffer = r, this._topologyVector = i;
  }
  get triangleOffsets() {
    return this._triangleOffsets;
  }
  get indexBuffer() {
    return this._indexBuffer;
  }
  get vertexBuffer() {
    return this._vertexBuffer;
  }
  get topologyVector() {
    return this._topologyVector;
  }
  getGeometries() {
    if (!this._topologyVector) throw Error("Cannot convert GpuVector to coordinates without topology information");
    let e = new Uint32Array(this.numGeometries);
    for (let t = 0; t < this.numGeometries; t++) e[t] = this.geometryType(t);
    return H1(e, this._topologyVector, void 0, this._vertexBuffer).getGeometries();
  }
  [Symbol.iterator]() {
    return null;
  }
};
function jp(e, t, r, i, n, a) {
  return new d_(e, t, r, i, n, a);
}
var d_ = class extends J1 {
  constructor(e, t, r, i, n, a) {
    super(r, i, n, a), this._numGeometries = e, this._geometryType = t;
  }
  geometryType(e) {
    return this._geometryType;
  }
  get numGeometries() {
    return this._numGeometries;
  }
  containsSingleGeometryType() {
    return !0;
  }
};
function qp(e, t, r, i, n) {
  return new y_(e, t, r, i, n);
}
var y_ = class extends J1 {
  constructor(e, t, r, i, n) {
    super(t, r, i, n), this._geometryTypes = e;
  }
  geometryType(e) {
    return this._geometryTypes[e];
  }
  get numGeometries() {
    return this._geometryTypes.length;
  }
  containsSingleGeometryType() {
    return !1;
  }
};
function m_(e, t, r, i, n) {
  let a = ye(e, r), s = Cs(a, i, e, r), o, l, u, c;
  if (s === pe.CONST) {
    let x = nc(e, r, a), b, w, D, _;
    for (let A = 0; A < t - 1; A++) {
      let E = ye(e, r);
      switch (E.physicalStreamType) {
        case Ie.LENGTH:
          switch (E.logicalStreamType.lengthType) {
            case Le.GEOMETRIES:
              b = cr(e, r, E);
              break;
            case Le.PARTS:
              w = cr(e, r, E);
              break;
            case Le.RINGS:
              D = cr(e, r, E);
              break;
            case Le.TRIANGLES:
              _ = cr(e, r, E);
          }
          break;
        case Ie.OFFSET:
          switch (E.logicalStreamType.offsetType) {
            case Yt.VERTEX:
              o = Ne(e, r, E);
              break;
            case Yt.INDEX:
              c = Ne(e, r, E);
          }
          break;
        case Ie.DATA:
          if (Ke.VERTEX === E.logicalStreamType.dictionaryType) l = ns(e, r, E, n);
          else {
            let R = E;
            u = { numBits: R.numBits, coordinateShift: R.coordinateShift }, l = Ne(e, r, E, n);
          }
      }
    }
    return c ? b !== void 0 || w !== void 0 ? jp(i, x, _, c, l, { geometryOffsets: b, partOffsets: w, ringOffsets: D }) : jp(i, x, _, c, l) : u === void 0 ? h_(i, x, { geometryOffsets: b, partOffsets: w, ringOffsets: D }, o, l) : p_(i, x, { geometryOffsets: b, partOffsets: w, ringOffsets: D }, o, l, u);
  }
  let h = Ne(e, r, a), p, f, d, y;
  for (let x = 0; x < t - 1; x++) {
    let b = ye(e, r);
    switch (b.physicalStreamType) {
      case Ie.LENGTH:
        switch (b.logicalStreamType.lengthType) {
          case Le.GEOMETRIES:
            p = Ne(e, r, b);
            break;
          case Le.PARTS:
            f = Ne(e, r, b);
            break;
          case Le.RINGS:
            d = Ne(e, r, b);
            break;
          case Le.TRIANGLES:
            y = cr(e, r, b);
        }
        break;
      case Ie.OFFSET:
        switch (b.logicalStreamType.offsetType) {
          case Yt.VERTEX:
            o = Ne(e, r, b);
            break;
          case Yt.INDEX:
            c = Ne(e, r, b);
        }
        break;
      case Ie.DATA:
        if (Ke.VERTEX === b.logicalStreamType.dictionaryType) l = ns(e, r, b, n);
        else {
          let w = b;
          u = { numBits: w.numBits, coordinateShift: w.coordinateShift }, l = Ne(e, r, b, n);
        }
    }
  }
  let m, g, v;
  return p ? (m = Fo(h, p, 2), f && d ? (g = Gp(h, m, f, !1), v = x_(h, m, g, d)) : f && (g = g_(h, m, f))) : f && d ? (g = Fo(h, f, 1), v = Gp(h, g, d, !0)) : f && (g = Fo(h, f, 0)), c && !g ? qp(h, y, c, l) : c ? qp(h, y, c, l, { geometryOffsets: m, partOffsets: g, ringOffsets: v }) : u === void 0 ? H1(h, { geometryOffsets: m, partOffsets: g, ringOffsets: v }, o, l) : f_(h, { geometryOffsets: m, partOffsets: g, ringOffsets: v }, o, l, u);
}
function Fo(e, t, r) {
  let i = new Uint32Array(e.length + 1), n = 0;
  i[0] = n;
  let a = 0;
  for (let s = 0; s < e.length; s++) n = i[s + 1] = n + (e[s] > r ? t[a++] : 1);
  return i;
}
function Gp(e, t, r, i) {
  let n = new Uint32Array(t[t.length - 1] + 1), a = 0;
  n[0] = a;
  let s = 1, o = 0;
  for (let l = 0; l < e.length; l++) {
    let u = e[l], c = t[l + 1] - t[l];
    if (u === 5 || u === 2 || i && (u === 4 || u === 1)) for (let h = 0; h < c; h++) a = n[s++] = a + r[o++];
    else for (let h = 0; h < c; h++) n[s++] = ++a;
  }
  return n;
}
function g_(e, t, r) {
  let i = new Uint32Array(t[t.length - 1] + 1), n = 0;
  i[0] = n;
  let a = 1, s = 0;
  for (let o = 0; o < e.length; o++) {
    let l = e[o], u = t[o + 1] - t[o];
    if (l === 4 || l === 1) for (let c = 0; c < u; c++) n = i[a++] = n + r[s++];
    else for (let c = 0; c < u; c++) i[a++] = ++n;
  }
  return i;
}
function x_(e, t, r, i) {
  let n = new Uint32Array(r[r.length - 1] + 1), a = 0;
  n[0] = a;
  let s = 1, o = 1, l = 0;
  for (let u = 0; u < e.length; u++) {
    let c = e[u], h = t[u + 1] - t[u];
    if (c !== 0 && c !== 3) for (let p = 0; p < h; p++) {
      let f = r[s] - r[s - 1];
      s++;
      for (let d = 0; d < f; d++) a = n[o++] = a + i[l++];
    }
    else for (let p = 0; p < h; p++) n[o++] = ++a, s++;
  }
  return n;
}
var v_ = class extends Rr {
  constructor(e, t, r) {
    super(e, t.getBuffer(), r), this.dataVector = t;
  }
  getValueFromBuffer(e) {
    return this.dataVector.get(e);
  }
}, b_ = class extends Is {
  getValueFromBuffer(e) {
    return this.dataBuffer[e];
  }
}, Q1 = class extends Rr {
  constructor(e, t, r, i) {
    super(e, i ? BigInt64Array.of(t) : BigUint64Array.of(t), r);
  }
  getValueFromBuffer(e) {
    return this.dataBuffer[0];
  }
}, oc = class extends Rr {
  constructor(e, t, r, i) {
    super(e, r, i), this.offsetBuffer = t;
  }
}, Xp = class extends oc {
  constructor(e, t, r, i) {
    super(e, t, r, i ?? t.length - 1);
  }
  getValueFromBuffer(e) {
    let t = this.offsetBuffer[e], r = this.offsetBuffer[e + 1];
    return ic(this.dataBuffer, t, r);
  }
}, ci = class extends oc {
  constructor(e, t, r, i, n) {
    super(e, r, i, n ?? t.length), this.indexBuffer = t, this.indexBuffer = t;
  }
  getValueFromBuffer(e) {
    let t = this.indexBuffer[e], r = this.offsetBuffer[t], i = this.offsetBuffer[t + 1];
    return ic(this.dataBuffer, r, i);
  }
};
function w_(e, t) {
  let r = 0;
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    n === 255 ? (r++, i++) : r += e[n];
  }
  return r;
}
function __(e, t, r) {
  let i = new Uint32Array(t.length);
  for (let s = 1; s < t.length; s++) i[s] = i[s - 1] + t[s - 1];
  let n = new Uint8Array(w_(t, r)), a = 0;
  for (let s = 0; s < r.length; s++) {
    let o = r[s];
    if (o === 255) s++, n[a++] = r[s];
    else {
      let l = t[o], u = i[o];
      for (; l-- > 0; ) n[a++] = e[u++];
    }
  }
  return n;
}
var em = class extends oc {
  constructor(e, t, r, i, n, a, s, o) {
    super(e, r, i, s ?? t.length), this.indexBuffer = t, this.symbolOffsetBuffer = n, this.symbolTableBuffer = a, this.sharedDictionaryCache = o;
  }
  getValueFromBuffer(e) {
    var n;
    this.decodedDictionary ?? (this.decodedDictionary = (n = this.sharedDictionaryCache) == null ? void 0 : n.decodedDictionary, this.decodedDictionary ?? (this.decodedDictionary = this.decodeDictionary(), this.sharedDictionaryCache && (this.sharedDictionaryCache.decodedDictionary = this.decodedDictionary)));
    let t = this.indexBuffer[e], r = this.offsetBuffer[t], i = this.offsetBuffer[t + 1];
    return ic(this.decodedDictionary, r, i);
  }
  decodeDictionary() {
    return this.symbolLengthBuffer ?? (this.symbolLengthBuffer = this.offsetToLengthBuffer(this.symbolOffsetBuffer)), __(this.symbolTableBuffer, this.symbolLengthBuffer, this.dataBuffer);
  }
  offsetToLengthBuffer(e) {
    let t = new Uint32Array(e.length - 1), r = e[0];
    for (let i = 1; i < e.length; i++) {
      let n = e[i];
      t[i - 1] = n - r, r = n;
    }
    return t;
  }
};
function tm(e, t, r, i, n) {
  let a, s, o, l, u, c = n, h, p;
  for (let f = 0; f < i; f++) {
    let d = ye(t, r);
    switch (d.physicalStreamType) {
      case Ie.PRESENT: {
        let y = new St(Ti(t, d.numValues, d.byteLength, r), d.numValues);
        c = n ?? y;
        break;
      }
      case Ie.OFFSET:
        s = Ne(t, r, d, void 0, c);
        break;
      case Ie.LENGTH: {
        let y = cr(t, r, d);
        Le.DICTIONARY === d.logicalStreamType.lengthType ? a = y : Le.SYMBOL === d.logicalStreamType.lengthType ? l = y : h = y;
        break;
      }
      case Ie.DATA: {
        let y = t.subarray(r.get(), r.get() + d.byteLength);
        r.add(d.byteLength);
        let m = d.logicalStreamType.dictionaryType;
        Ke.FSST === m ? u = y : Ke.SINGLE === m || Ke.SHARED === m ? o = y : Ke.NONE === m && (p = y);
        break;
      }
    }
  }
  return D_(e, u, s, a, o, l, c) ?? S_(e, o, s, a, c) ?? A_(e, h, p, s, c);
}
function D_(e, t, r, i, n, a, s) {
  if (t) {
    if (!r || !i || !n || !a) throw Error(`Incomplete FSST dictionary string column "${e}"`);
    return new em(e, r, i, n, a, t, s);
  }
}
function S_(e, t, r, i, n) {
  if (t) {
    if (!r || !i) throw Error(`Incomplete dictionary string column "${e}"`);
    return n ? new ci(e, r, i, t, n) : new ci(e, r, i, t);
  }
}
function A_(e, t, r, i, n) {
  if (t && r) {
    if (i) return n ? new ci(e, i, t, r, n) : new ci(e, i, t, r);
    if (n && n.size() !== t.length - 1) {
      let a = new Uint32Array(n.size()), s = 0;
      for (let o = 0; o < n.size(); o++) n.get(o) ? a[o] = s++ : a[o] = 0;
      return new ci(e, a, t, r, n);
    }
    return n ? new Xp(e, t, r, n) : new Xp(e, t, r);
  }
}
function E_(e, t, r, i) {
  let n, a, s, o, l = !1;
  for (; !l; ) {
    let f = ye(e, t);
    switch (f.physicalStreamType) {
      case Ie.LENGTH:
        Le.DICTIONARY === f.logicalStreamType.lengthType ? n = cr(e, t, f) : s = cr(e, t, f);
        break;
      case Ie.DATA:
        Ke.SINGLE === f.logicalStreamType.dictionaryType || Ke.SHARED === f.logicalStreamType.dictionaryType ? (a = e.subarray(t.get(), t.get() + f.byteLength), l = !0) : o = e.subarray(t.get(), t.get() + f.byteLength), t.add(f.byteLength);
    }
  }
  if (r.type !== "complexType") throw Error(`Shared dictionary column ${r.name} must be a complex (struct) column.`);
  if (!n || !a) throw Error(`Incomplete shared dictionary for column "${r.name}"`);
  let u = r.complexType.children, c = [], h = o ? {} : void 0, p = 0;
  for (let f of u) {
    let d = Ge(e, t, 1)[0];
    if (d === 0) continue;
    let y = f.name ? `${r.name}${f.name}` : r.name;
    if (f.type !== "scalarField" || f.scalarField.physicalType !== ee.STRING) throw Error("Currently only scalar string fields are implemented for a struct.");
    if (d > 1 && !f.nullable || d === 1 && f.nullable) throw Error(`The number of streams for the child field ${f.name} does not match its nullability. nullibilty: ${f.nullable}, numStreams: ${d}`);
    let m;
    if (f.nullable) {
      let v = ye(e, t);
      m = new St(Ti(e, v.numValues, v.byteLength, t), v.numValues);
    }
    let g = Ne(e, t, ye(e, t), void 0, m);
    if (o) {
      if (!s) throw Error(`Incomplete shared FSST dictionary for column "${y}"`);
      c[p++] = new em(y, g, n, a, s, o, m, h);
    } else c[p++] = new ci(y, g, n, a, m);
  }
  return c;
}
var Yp = class extends Rr {
  constructor(e, t, r) {
    super(e, /* @__PURE__ */ new Uint8Array(), r ?? t.length), this.values = t;
  }
  getValueFromBuffer(e) {
    return this.values[e];
  }
}, Wt;
(function(e) {
  e[e.STRING = 1] = "STRING", e[e.INT32 = 2] = "INT32", e[e.UINT32 = 4] = "UINT32", e[e.INT64 = 8] = "INT64", e[e.UINT64 = 16] = "UINT64", e[e.FLOAT = 32] = "FLOAT", e[e.DOUBLE = 64] = "DOUBLE", e[e.PRESENCE = 128] = "PRESENCE";
})(Wt || (Wt = {}));
var Ir;
(function(e) {
  e[e.FALSE = 0] = "FALSE", e[e.TRUE = 1] = "TRUE", e[e.START_MAP = 2] = "START_MAP", e[e.START_LIST = 3] = "START_LIST", e[e.COUNT = 4] = "COUNT";
})(Ir || (Ir = {}));
function T_(e, t, r, i) {
  let n = I_(r);
  if (i === 0) return n.map((c) => new Yp(c, []));
  let a = C_(e, t, i), s = (a.presentStream ? a.presentCount : a.lengthStream.length) / n.length, o = [], l = 0, u = 0;
  for (let c = 0; c < n.length; c++) {
    let h = B_(a, c, s, l, u);
    o.push(new Yp(n[c], h.value, h.nullabilityBuffer)), l = h.countsEnd, u = h.valuesEnd;
  }
  return o;
}
function I_(e) {
  let t = e.type === "complexType" ? e.complexType.children : void 0;
  return !t || t.length === 0 ? [e.name] : t.map((r) => e.name + (r.name ?? ""));
}
function C_(e, t, r) {
  let i = e[t.get()];
  t.add(1);
  let n = Ne(e, t, ye(e, t)), a = r - 1, s = [];
  i & Wt.STRING && (a -= k_(e, t, s)), a -= F_(e, t, i, s), a -= M_(e, t, i, s);
  let o, l = 0;
  if (i & Wt.PRESENCE) {
    let c = P_(e, t);
    o = c.value, l = c.count, a--;
  }
  let u = /* @__PURE__ */ new Uint32Array();
  if (a > 0 && (u = Ne(e, t, ye(e, t)), a--), a !== 0) throw Error(`Unexpected number of remaining streams while decoding map column: ${a}`);
  return { lengthStream: n, dictionary: s, presentStream: o, presentCount: l, flattenedValues: u };
}
function k_(e, t, r) {
  let i = e[t.get()];
  t.add(1);
  let n = tm("", e, t, i);
  if (n) for (let a = 0; a < n.size; a++) r.push(n.getValue(a));
  return i;
}
function F_(e, t, r, i) {
  let n = 0;
  return r & Wt.INT32 ? (ni(i, ns(e, t, ye(e, t))), n++) : r & Wt.INT64 && (ni(i, j1(e, t, ye(e, t))), n++), r & Wt.UINT32 ? (ni(i, Ne(e, t, ye(e, t))), n++) : r & Wt.UINT64 && (ni(i, ac(e, t, ye(e, t))), n++), n;
}
function M_(e, t, r, i) {
  let n = 0;
  return r & Wt.FLOAT && (ni(i, R1(e, t, ye(e, t).numValues)), n++), r & Wt.DOUBLE && (ni(i, $1(e, t, ye(e, t).numValues)), n++), n;
}
function P_(e, t) {
  let r = ye(e, t);
  if (r.physicalStreamType !== Ie.PRESENT) throw Error(`Expected PRESENT stream for map column but found: ${r.physicalStreamType}`);
  let i = r.numValues, n = t.get(), a = new St(Ti(e, i, r.byteLength, t), i);
  return t.set(n + r.byteLength), { value: a, count: i };
}
function B_(e, t, r, i, n) {
  let { lengthStream: a, flattenedValues: s, presentStream: o, dictionary: l } = e, u = t * r, c = r, h;
  if (o) {
    h = new St(new Uint8Array(Math.ceil(r / 8)), r), c = 0;
    for (let v = 0; v < r; v++) o.get(u + v) && (h.set(v, !0), c++);
  }
  let p = i + c;
  if (p > a.length) throw Error("Merged map counts underflow while decoding child streams");
  let f = Array(r), d = i, y = n;
  for (let v = 0; v < r; v++) {
    if (o && !o.get(u + v)) {
      f[v] = null;
      continue;
    }
    let x = y + a[d++];
    if (x > s.length) throw Error("Map value stream underflow while decoding feature payload");
    let b = L_(s, y, x, l);
    f[v] = b.value, y = b.nextIndex;
  }
  let m = 0;
  for (let v = i; v < p; v++) m += a[v];
  let g = n + m;
  if (y !== g) throw Error("Unused flattened map values remain after decode");
  return { value: f, nullabilityBuffer: h, countsEnd: p, valuesEnd: g };
}
function L_(e, t, r, i) {
  return r - t === 1 || e[t] === Ir.START_LIST ? lc(e, t, r, i) : rm(e, t, r, i);
}
function rm(e, t, r, i) {
  let n = /* @__PURE__ */ Object.create(null), a = t;
  for (; a < r; ) {
    let s = im(e[a++], i);
    if (typeof s != "string") throw Error(`Map key dictionary index does not resolve to a string: ${s}`);
    let o = lc(e, a, r, i);
    n[s] = o.value, a = o.nextIndex;
  }
  return { value: n, nextIndex: a };
}
function lc(e, t, r, i) {
  if (t >= r) throw Error("Unexpected end of map value stream");
  let n = e[t];
  if (n === Ir.FALSE) return { value: !1, nextIndex: t + 1 };
  if (n === Ir.TRUE) return { value: !0, nextIndex: t + 1 };
  if (n === Ir.START_MAP) {
    let a = Wp(e, t, r);
    return { value: rm(e, t + 2, a, i).value, nextIndex: a };
  }
  if (n === Ir.START_LIST) {
    let a = Wp(e, t, r), s = [], o = t + 2;
    for (; o < a; ) {
      let l = lc(e, o, a, i);
      s.push(l.value), o = l.nextIndex;
    }
    return { value: s, nextIndex: a };
  }
  return { value: im(n, i), nextIndex: t + 1 };
}
function Wp(e, t, r) {
  if (t + 1 >= r) throw Error("Missing length for nested map/list payload");
  let i = e[t + 1];
  if (i < 2) throw Error(`Invalid nested payload length: ${i}`);
  let n = t + i;
  if (n > r) throw Error("Nested payload exceeds containing payload bounds");
  return n;
}
function im(e, t) {
  let r = e - Ir.COUNT;
  if (r < 0 || r >= t.length) throw Error(`Scalar dictionary index out of range: ${e}`);
  return t[r];
}
function ni(e, t) {
  for (let r of t) e.push(r);
}
function z_(e, t, r, i, n, a) {
  var s;
  return r.type === "scalarType" ? V_(i, e, t, n, r.scalarType, r) : ((s = r.complexType) == null ? void 0 : s.physicalType) === fr.MAP ? T_(e, t, r, i) : i === 0 ? null : E_(e, t, r);
}
function V_(e, t, r, i, n, a) {
  let s;
  if (e === 0) return null;
  if (a.nullable) {
    let l = ye(t, r), u = l.numValues, c = r.get(), h = Ti(t, u, l.byteLength, r);
    r.set(c + l.byteLength), s = new St(h, l.numValues);
  }
  let o = s ?? i;
  switch (n.physicalType) {
    case ee.UINT_32:
    case ee.INT_32:
      return U_(t, r, a, n, o);
    case ee.STRING: {
      let l = a.nullable ? e - 1 : e;
      return tm(a.name, t, r, l, s) ?? null;
    }
    case ee.BOOLEAN:
      return O_(t, r, a, i, o);
    case ee.UINT_64:
    case ee.INT_64:
      return N_(t, r, a, o, n);
    case ee.FLOAT:
      return R_(t, r, a, o);
    case ee.DOUBLE:
      return $_(t, r, a, o);
    default:
      throw Error(`The specified data type for the field is currently not supported: ${n}`);
  }
}
function O_(e, t, r, i, n) {
  let a = ye(e, t), s = a.numValues, o = t.get(), l = Gn(n) ? n : void 0, u = Ti(e, s, a.byteLength, t, l);
  t.set(o + a.byteLength);
  let c = new St(u, s);
  return new v_(r.name, c, n);
}
function R_(e, t, r, i) {
  let n = ye(e, t), a = Gn(i) ? i : void 0, s = R1(e, t, n.numValues, a);
  return new b_(r.name, s, i);
}
function $_(e, t, r, i) {
  let n = ye(e, t), a = Gn(i) ? i : void 0, s = $1(e, t, n.numValues, a);
  return new Hu(r.name, s, i);
}
function N_(e, t, r, i, n) {
  let a = ye(e, t), s = Cs(a, i, e, t, "int64"), o = n.physicalType === ee.INT_64;
  if (s === pe.FLAT) {
    let u = Gn(i) ? i : void 0, c = o ? j1(e, t, a, u) : ac(e, t, a, u);
    return new X1(r.name, c, i);
  }
  if (s === pe.SEQUENCE) {
    let u = U1(e, t, a);
    return new Y1(r.name, u[0], u[1], a.numRleValues, o);
  }
  let l = o ? Q5(e, t, a) : q1(e, t, a);
  return new Q1(r.name, l, i, o);
}
function U_(e, t, r, i, n) {
  let a = ye(e, t), s = Cs(a, n, e, t), o = i.physicalType === ee.INT_32;
  if (s === pe.FLAT) {
    let u = Gn(n) ? n : void 0, c = o ? ns(e, t, a, void 0, u) : Ne(e, t, a, void 0, u);
    return new Zu(r.name, c, n);
  }
  if (s === pe.SEQUENCE) {
    let u = N1(e, t, a);
    return new Ku(r.name, u[0], u[1], a.numRleValues, o);
  }
  let l = o ? H5(e, t, a) : nc(e, t, a);
  return new Ju(r.name, l, n, o);
}
function Gn(e) {
  return e instanceof St;
}
const Be = { ID: 0, ID_NULLABLE: 1, ID_LONG: 2, GEOMETRY: 4, SCALAR_BASE: 10, STRUCT: 30, MAP: 31 };
function nm(e) {
  switch (e) {
    case Be.ID:
    case Be.ID | Be.ID_NULLABLE:
    case Be.ID | Be.ID_LONG:
    case Be.ID | Be.ID_LONG | Be.ID_NULLABLE:
      return { nullable: (e & Be.ID_NULLABLE) !== 0, columnScope: nn.FEATURE, type: "scalarType", scalarType: { longID: (e & Be.ID_LONG) !== 0, type: "logicalType", logicalType: B1.ID } };
    case Be.GEOMETRY:
      return { nullable: !1, columnScope: nn.FEATURE, type: "complexType", complexType: { type: "physicalType", physicalType: fr.GEOMETRY, children: [] } };
    case Be.STRUCT:
      return { nullable: !1, columnScope: nn.FEATURE, type: "complexType", complexType: { type: "physicalType", physicalType: fr.STRUCT, children: [] } };
    case Be.MAP:
      return { nullable: !0, columnScope: nn.FEATURE, type: "complexType", complexType: { type: "physicalType", physicalType: fr.MAP, children: [] } };
    default:
      return Y_(e);
  }
}
function j_(e) {
  return e >= Be.SCALAR_BASE;
}
function am(e) {
  return e === Be.STRUCT || e === Be.MAP;
}
function q_(e) {
  if (e.type === "scalarType") {
    let t = e.scalarType;
    if (t.type === "physicalType") switch (t.physicalType) {
      case ee.BOOLEAN:
      case ee.INT_8:
      case ee.UINT_8:
      case ee.INT_32:
      case ee.UINT_32:
      case ee.INT_64:
      case ee.UINT_64:
      case ee.FLOAT:
      case ee.DOUBLE:
        return !1;
      case ee.STRING:
        return !0;
      default:
        return !1;
    }
    if (t.type === "logicalType") return !1;
  } else if (e.type === "complexType") {
    let t = e.complexType;
    if (t.type === "physicalType") switch (t.physicalType) {
      case fr.GEOMETRY:
      case fr.STRUCT:
      case fr.MAP:
        return !0;
      default:
        return !1;
    }
  }
  return console.warn("Unexpected column type in hasStreamCount", e), !1;
}
function G_(e) {
  var t;
  return e.type === "scalarType" && ((t = e.scalarType) == null ? void 0 : t.type) === "logicalType" && e.scalarType.logicalType === B1.ID;
}
function X_(e) {
  var t;
  return e.type === "complexType" && ((t = e.complexType) == null ? void 0 : t.type) === "physicalType" && e.complexType.physicalType === fr.GEOMETRY;
}
function Y_(e) {
  let t;
  switch (e) {
    case 10:
    case 11:
      t = ee.BOOLEAN;
      break;
    case 12:
    case 13:
      t = ee.INT_8;
      break;
    case 14:
    case 15:
      t = ee.UINT_8;
      break;
    case 16:
    case 17:
      t = ee.INT_32;
      break;
    case 18:
    case 19:
      t = ee.UINT_32;
      break;
    case 20:
    case 21:
      t = ee.INT_64;
      break;
    case 22:
    case 23:
      t = ee.UINT_64;
      break;
    case 24:
    case 25:
      t = ee.FLOAT;
      break;
    case 26:
    case 27:
      t = ee.DOUBLE;
      break;
    case 28:
    case 29:
      t = ee.STRING;
      break;
    default:
      return null;
  }
  return { nullable: !!(e & 1), columnScope: nn.FEATURE, type: "scalarType", scalarType: { longID: !1, type: "physicalType", physicalType: t } };
}
const W_ = new TextDecoder(), Zp = "0-3(ID), 4(GEOMETRY), 10-29(scalars), 30(STRUCT), 31(MAP)";
function uc(e, t) {
  let r = Ge(e, t, 1)[0];
  if (r === 0) return "";
  let i = t.get(), n = i + r, a = e.subarray(i, n);
  return t.add(r), W_.decode(a);
}
function Z_(e) {
  let t = e.name, r = e.nullable;
  return e.type === "scalarType" ? { type: "scalarField", scalarField: e.scalarType, name: t, nullable: r } : { type: "complexField", complexField: e.complexType, name: t, nullable: r };
}
function sm(e, t) {
  let r = Ge(e, t, 1)[0] >>> 0, i = r >= Be.SCALAR_BASE ? nm(r) : null;
  if (!i) throw Error(`Unsupported field type code ${r}. Supported: 10-29(scalars), 30(STRUCT), 31(MAP)`);
  let n = { ...i, name: uc(e, t) };
  if (n.type === "complexType" && am(r)) {
    let a = n.complexType, s = Ge(e, t, 1)[0] >>> 0;
    a.children = Array(s);
    for (let o = 0; o < s; o++) a.children[o] = sm(e, t);
  }
  return Z_(n);
}
function H_(e, t) {
  let r = Ge(e, t, 1)[0] >>> 0, i = nm(r);
  if (!i) throw Error(`Unsupported column type code ${r}. Supported: ${Zp}`);
  let n;
  if (j_(r)) n = uc(e, t);
  else if (r < Be.GEOMETRY) n = "id";
  else if (r === Be.GEOMETRY) n = "geometry";
  else throw Error(`Unsupported column type code ${r}. Supported: ${Zp}`);
  let a = { ...i, name: n };
  if (a.type === "complexType" && am(r)) {
    let s = Ge(e, t, 1)[0] >>> 0, o = a.complexType;
    o.children = Array(s);
    for (let l = 0; l < s; l++) o.children[l] = sm(e, t);
  }
  return a;
}
function K_(e, t) {
  let r = {};
  r.featureTables = [];
  let i = {};
  if (i.name = uc(e, t), i.name.length === 0) throw Error("Missing layer name");
  let n = Ge(e, t, 1)[0] >>> 0, a = Ge(e, t, 1)[0] >>> 0;
  i.columns = Array(a);
  for (let s = 0; s < a; s++) i.columns[s] = H_(e, t);
  return r.featureTables.push(i), [r, n];
}
function J_(e, t, r = !0) {
  let i = new L1(0), n = [];
  for (; i.get() < e.length; ) {
    let a = Ge(e, i, 1)[0] >>> 0, s = i.get() + a;
    if (s > e.length) throw Error(`Block overruns tile: ${s} > ${e.length}`);
    let o = Ge(e, i, 1)[0] >>> 0;
    if (o !== 1 && o !== 2) {
      i.set(s);
      continue;
    }
    let [l, u] = K_(e, i), c = l.featureTables[0], h = null, p = null, f = [], d = 0;
    for (let m of c.columns) {
      let g = m.name;
      if (G_(m)) {
        let v = null;
        if (m.nullable) {
          let b = ye(e, i), w = i.get(), D = Ti(e, b.numValues, b.byteLength, i);
          i.set(w + b.byteLength), v = new St(D, b.numValues);
        }
        let x = ye(e, i);
        d = v ? v.size() : x.decompressedCount, h = Q_(e, m, i, g, x, v ?? d, r);
      } else if (X_(m)) {
        let v = Ge(e, i, 1)[0];
        if (d === 0) {
          let x = i.get();
          d = ye(e, i).decompressedCount, i.set(x);
        }
        p = m_(e, v, i, d, t);
      } else {
        let v = q_(m) ? Ge(e, i, 1)[0] : 1;
        if (v === 0) continue;
        let x = z_(e, i, m, v, d);
        if (x)
          if (Array.isArray(x)) for (let b of x) f.push(b);
          else f.push(x);
      }
    }
    let y = new _6(c.name, p, h, f, u);
    n.push(y), i.set(s);
  }
  return n;
}
function Q_(e, t, r, i, n, a, s = !1) {
  var c;
  let o = (c = t.scalarType) != null && c.longID ? ee.UINT_64 : ee.UINT_32, l = typeof a == "number" ? void 0 : a, u = Cs(n, a, e, r, o === ee.UINT_64 ? "int64" : "int32");
  if (o === ee.UINT_32) switch (u) {
    case pe.FLAT:
      return new Zu(i, Ne(e, r, n, void 0, l), a);
    case pe.SEQUENCE: {
      let h = N1(e, r, n);
      return new Ku(i, h[0], h[1], n.numRleValues, !1);
    }
    case pe.CONST:
      return new Ju(i, nc(e, r, n), a, !1);
  }
  switch (u) {
    case pe.FLAT:
      return s ? new Hu(i, K5(e, r, n, l), a) : new X1(i, ac(e, r, n, l), a);
    case pe.SEQUENCE: {
      let h = U1(e, r, n);
      return new Y1(i, h[0], h[1], n.numRleValues, !1);
    }
    case pe.CONST:
      return new Q1(i, q1(e, r, n), a, !1);
  }
  throw Error("Vector type not supported for id column.");
}
var eD = class {
  constructor(e, t) {
    var r;
    switch (this._featureData = e, this.properties = this._featureData.properties || {}, (r = this._featureData.geometry) == null ? void 0 : r.type) {
      case je.POINT:
      case je.MULTIPOINT:
        this.type = 1;
        break;
      case je.LINESTRING:
      case je.MULTILINESTRING:
        this.type = 2;
        break;
      case je.POLYGON:
      case je.MULTIPOLYGON:
        this.type = 3;
        break;
      default:
        this.type = 0;
    }
    this.extent = t, this.id = Number(this._featureData.id);
  }
  loadGeometry() {
    let e = [];
    for (let t of this._featureData.geometry.coordinates) {
      let r = [];
      for (let i of t) r.push(new T(i.x, i.y));
      e.push(r);
    }
    return e;
  }
}, tD = class {
  constructor(e) {
    this.features = [], this.featureTable = e, this.name = e.name, this.extent = e.extent, this.version = 2, this.features = e.getFeatures(), this.length = this.features.length;
  }
  feature(e) {
    return new eD(this.features[e], this.extent);
  }
}, om = class {
  constructor(e) {
    this.layers = {};
    let t = J_(new Uint8Array(e));
    this.layers = t.reduce((r, i) => ({ ...r, [i.name]: new tD(i) }), {});
  }
}, lm = class {
  constructor(e, t) {
    this.tileID = e, this.x = e.canonical.x, this.y = e.canonical.y, this.z = e.canonical.z, this.grid = new Bo(te, 16, 0), this.grid3D = new Bo(te, 16, 0), this.featureIndexArray = new Yd(), this.promoteId = t;
  }
  insert(e, t, r, i, n, a) {
    let s = this.featureIndexArray.length;
    this.featureIndexArray.emplaceBack(r, i, n);
    let o = a ? this.grid3D : this.grid;
    for (let l of t) {
      let u = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
      for (let c of l) u[0] = Math.min(u[0], c.x), u[1] = Math.min(u[1], c.y), u[2] = Math.max(u[2], c.x), u[3] = Math.max(u[3], c.y);
      u[0] < 8192 && u[1] < 8192 && u[2] >= 0 && u[3] >= 0 && o.insert(s, u[0], u[1], u[2], u[3]);
    }
  }
  loadVTLayers() {
    if (!this.vtLayers) {
      switch (this.encoding) {
        case "mlt":
          this.vtLayers = new om(this.rawTileData).layers;
          break;
        default:
          this.vtLayers = new zy(new s1(this.rawTileData)).layers;
      }
      this.sourceLayerCoder = new M1(this.vtLayers ? Object.keys(this.vtLayers).sort() : [ql]);
    }
    return this.vtLayers;
  }
  query(e, t, r, i) {
    this.loadVTLayers();
    let n = e.params, a = te / e.tileSize / e.scale, s = wn(n.filter, "queryRenderedFeatures filter", n.globalState), o = e.queryGeometry, l = e.queryPadding * a, u = Tn.fromPoints(o), c = this.grid.query(u.minX - l, u.minY - l, u.maxX + l, u.maxY + l), h = Tn.fromPoints(e.cameraQueryGeometry).expandBy(l), p = this.grid3D.query(h.minX, h.minY, h.maxX, h.maxY, (y, m, g, v) => Hx(e.cameraQueryGeometry, y - l, m - l, g + l, v + l));
    for (let y of p) c.push(y);
    c.sort(iD);
    let f = {}, d;
    for (let y of c) {
      if (y === d) continue;
      d = y;
      let m = this.featureIndexArray.get(y), g = null;
      this.loadMatchingFeature(f, m.bucketIndex, m.sourceLayerIndex, m.featureIndex, s, n.layers, n.availableImages, t, r, e.worldCoordinateHelper, i, (v, x, b) => (g || (g = Or(v)), x.queryIntersectsFeature({ queryGeometry: o, feature: v, featureState: b, geometry: g, zoom: this.z, projectedCamera: e.projectedCamera, pixelsToTileUnits: a, unwrappedTileID: this.tileID.toUnwrapped(), getElevation: e.getElevation })));
    }
    return f;
  }
  loadMatchingFeature(e, t, r, i, n, a, s, o, l, u, c, h) {
    let p = this.bucketLayerIDs[t];
    if (a && !p.some((m) => a.has(m))) return;
    let f = this.sourceLayerCoder.decode(r), d = this.vtLayers[f].feature(i);
    if (n.needGeometry) {
      let m = Ei(d, !0);
      if (!n.filter(new le(this.tileID.overscaledZ), m, this.tileID.canonical)) return;
    } else if (!n.filter(new le(this.tileID.overscaledZ), d)) return;
    let y = this.getId(d, f);
    for (let m of p) {
      if (a && !a.has(m)) continue;
      let g = o[m];
      if (!g) continue;
      let v = {};
      y && c && (v = c.getState(g.sourceLayer || "_geojsonTileLayer", y));
      let x = it({}, l[m]);
      x.paint = Hp(x.paint, g.paint, d, v, s), x.layout = Hp(x.layout, g.layout, d, v, s);
      let b = !h || h(d, g, v);
      if (!b) continue;
      let w = new w6(d, this.z, this.x, this.y, y, u);
      w.layer = x;
      let D = e[m];
      D === void 0 && (D = e[m] = []), D.push({ featureIndex: i, feature: w, intersectionZ: b });
    }
  }
  lookupSymbolFeatures(e, t, r, i, n, a, s, o) {
    let l = {};
    this.loadVTLayers();
    let u = wn(n.filterSpec, "queryRenderedFeatures symbol filter", n.globalState);
    for (let c of e) this.loadMatchingFeature(l, r, i, c, u, a, s, o, t, n.worldCoordinateHelper);
    return l;
  }
  hasLayer(e) {
    for (let t of this.bucketLayerIDs) for (let r of t) if (e === r) return !0;
    return !1;
  }
  getId(e, t) {
    var i;
    let r = e.id;
    if (this.promoteId) {
      let n = typeof this.promoteId == "string" ? this.promoteId : this.promoteId[t];
      r = e.properties[n], typeof r == "boolean" && (r = Number(r)), r === void 0 && ((i = e.properties) != null && i.cluster) && this.promoteId && (r = Number(e.properties.cluster_id));
    }
    return r;
  }
};
P("FeatureIndex", lm, { omit: ["rawTileData", "sourceLayerCoder"] });
function rD(e) {
  return typeof e == "object" && !!e && "evaluate" in e;
}
function Hp(e, t, r, i, n) {
  return Va(e, (a, s) => {
    let o = t instanceof vs ? t.get(s) : null;
    return rD(o) ? o.evaluate(r, i, void 0, n) : o;
  });
}
function iD(e, t) {
  return t - e;
}
var nD = class {
  constructor(e, t) {
    this.keyCache = {}, e && this.replace(e, t);
  }
  replace(e, t) {
    this._layerConfigs = {}, this._layers = {}, this.update(e, [], t);
  }
  update(e, t, r) {
    for (let n of e) {
      this._layerConfigs[n.id] = n;
      let a = this._layers[n.id] = p6(n, r);
      a._featureFilter = wn(a.filter, `layers[${n.id}].filter`, r), this.keyCache[n.id] && delete this.keyCache[n.id];
    }
    for (let n of t) delete this.keyCache[n], delete this._layerConfigs[n], delete this._layers[n];
    this.familiesBySource = {};
    let i = $0(Object.values(this._layerConfigs), this.keyCache);
    for (let n of i) {
      let a = n.map((h) => this._layers[h.id]), s = a[0];
      if (s.isHidden()) continue;
      let o = s.source || "", l = this.familiesBySource[o];
      l || (l = this.familiesBySource[o] = {});
      let u = s.sourceLayer || "_geojsonTileLayer", c = l[u];
      c || (c = l[u] = []), c.push(a);
    }
  }
}, um = class {
  constructor(e) {
    let t = {}, r = [];
    for (let s in e) {
      let o = t[s] = {};
      for (let l in e[s]) {
        let u = e[s][l];
        o[l] = {};
        for (let c in u) {
          let h = u[c];
          if (!h || h.bitmap.width === 0 || h.bitmap.height === 0) continue;
          let p = { x: 0, y: 0, w: h.bitmap.width + 2, h: h.bitmap.height + 2 };
          r.push(p), o[l][c] = { rect: p, metrics: h.metrics };
        }
      }
    }
    let { w: i, h: n } = o1(r), a = new Al({ width: i || 1, height: n || 1 });
    for (let s in e) for (let o in e[s]) {
      let l = e[s][o];
      for (let u in l) {
        let c = l[u];
        if (!c || c.bitmap.width === 0 || c.bitmap.height === 0) continue;
        let h = t[s][o][u].rect;
        Al.copy(c.bitmap, a, { x: 0, y: 0 }, { x: h.x + 1, y: h.y + 1 }, c.bitmap);
      }
    }
    this.image = a, this.positions = t;
  }
};
P("GlyphAtlas", um);
var cm = class {
  constructor(e) {
    this.tileID = new _s(e.tileID.overscaledZ, e.tileID.wrap, e.tileID.canonical.z, e.tileID.canonical.x, e.tileID.canonical.y), this.uid = e.uid, this.zoom = e.zoom, this.pixelRatio = e.pixelRatio, this.tileSize = e.tileSize, this.source = e.source, this.overscaling = this.tileID.overscaleFactor(), this.showCollisionBoxes = e.showCollisionBoxes, this.collectResourceTiming = !!e.collectResourceTiming, this.returnDependencies = !!e.returnDependencies, this.promoteId = e.promoteId, this.inFlightDependencies = [];
  }
  async parse(e, t, r, i, n) {
    this.data = e, this.collisionBoxArray = new Vd();
    let a = new M1(Object.keys(e.layers).sort()), s = new lm(this.tileID, this.promoteId);
    s.bucketLayerIDs = [];
    let o = {}, l = { featureIndex: s, iconDependencies: {}, patternDependencies: {}, glyphDependencies: {}, dashDependencies: {}, availableImages: r, subdivisionGranularity: n }, u = t.familiesBySource[this.source];
    for (let A in u) {
      let E = e.layers[A];
      if (!E) continue;
      E.version === 1 && Me(`Vector tile source "${this.source}" layer "${A}" does not use vector tile spec v2 and therefore may have some rendering errors.`);
      let R = a.encode(A), B = [];
      for (let L = 0; L < E.length; L++) {
        let $ = E.feature(L), M = s.getId($, A);
        B.push({ feature: $, id: M, index: L, sourceLayerIndex: R });
      }
      for (let L of u[A]) {
        let $ = L[0];
        $.source !== this.source && Me(`layer.source = ${$.source} does not equal this.source = ${this.source}`), $.isHidden(this.zoom, !0) || (Kp(L, this.zoom, r), (o[$.id] = $.createBucket({ index: s.bucketLayerIDs.length, layers: L, zoom: this.zoom, pixelRatio: this.pixelRatio, overscaling: this.overscaling, collisionBoxArray: this.collisionBoxArray, sourceLayerIndex: R, sourceID: this.source })).populate(B, l, this.tileID.canonical), s.bucketLayerIDs.push(L.map((M) => M.id)));
      }
    }
    let c = Va(l.glyphDependencies, (A) => Va(A, (E) => Object.keys(E)));
    for (let A of this.inFlightDependencies) A == null || A.abort();
    this.inFlightDependencies = [];
    let h = Promise.resolve({});
    if (Object.keys(c).length) {
      let A = new AbortController();
      this.inFlightDependencies.push(A), h = i.sendAsync({ type: "GG", data: { stacks: c, source: this.source, tileID: this.tileID, type: "glyphs" } }, A);
    }
    let p = Object.keys(l.iconDependencies), f = Promise.resolve({});
    if (p.length) {
      let A = new AbortController();
      this.inFlightDependencies.push(A), f = i.sendAsync({ type: "GI", data: { icons: p, source: this.source, tileID: this.tileID, type: "icons" } }, A);
    }
    let d = Object.keys(l.patternDependencies), y = Promise.resolve({});
    if (d.length) {
      let A = new AbortController();
      this.inFlightDependencies.push(A), y = i.sendAsync({ type: "GI", data: { icons: d, source: this.source, tileID: this.tileID, type: "patterns" } }, A);
    }
    let m = l.dashDependencies, g = Promise.resolve({});
    if (Object.keys(m).length) {
      let A = new AbortController();
      this.inFlightDependencies.push(A), g = i.sendAsync({ type: "GDA", data: { dashes: m } }, A);
    }
    let [v, x, b, w] = await Promise.all([h, f, y, g]), D = new um(v), _ = new u1(x, b);
    for (let A in o) {
      let E = o[A];
      E.hasDependencies && (Kp(E.layers, this.zoom, r), E.addFeatures({ options: l, canonical: this.tileID.canonical, glyphMap: v, glyphPositions: D.positions, iconMap: x, iconPositions: _.iconPositions, patternMap: b, patternPositions: _.patternPositions, dashPositions: w, showCollisionBoxes: this.showCollisionBoxes }));
    }
    return { buckets: Object.values(o).filter((A) => !A.isEmpty()), featureIndex: s, collisionBoxArray: this.collisionBoxArray, glyphAtlasImage: D.image, imageAtlas: _, dashPositions: w, glyphMap: this.returnDependencies ? v : null, iconMap: this.returnDependencies ? x : null, glyphPositions: this.returnDependencies ? D.positions : null };
  }
};
function Kp(e, t, r) {
  let i = new le(t);
  for (let n of e) n.recalculate(i, r);
}
var hm = class {
  constructor() {
    this.loading = {}, this.loaded = {}, this.parsing = {};
  }
  startLoading(e, t) {
    this.loading[e] = t;
  }
  finishLoading(e) {
    delete this.loading[e];
  }
  abort(e) {
    let t = this.loading[e];
    t != null && t.abort && (t.abort.abort(), delete this.loading[e]);
  }
  getParsing(e) {
    return this.parsing[e];
  }
  setParsing(e, t) {
    this.parsing[e] = t;
  }
  removeParsing(e) {
    delete this.parsing[e];
  }
  markLoaded(e, t) {
    this.loaded[e] = t;
  }
  getLoaded(e) {
    let t = this.loaded[e];
    if (t) return t;
  }
  removeLoaded(e) {
    delete this.loaded[e];
  }
  clearLoaded() {
    this.loaded = {};
  }
}, aD = class {
  constructor(e) {
    this.maxEntries = e, this.map = /* @__PURE__ */ new Map();
  }
  get(e) {
    let t = this.map.get(e);
    return t !== void 0 && (this.map.delete(e), this.map.set(e, t)), t;
  }
  set(e, t) {
    if (this.map.has(e)) this.map.delete(e);
    else if (this.map.size >= this.maxEntries) {
      let r = this.map.keys().next().value;
      this.map.delete(r);
    }
    this.map.set(e, t);
  }
  clear() {
    this.map.clear();
  }
}, pm = class {
  constructor(e) {
    this.start = `${e}#start`, this.end = `${e}#end`, this.measure = e, performance.mark(this.start);
  }
  finish() {
    performance.mark(this.end);
    let e = performance.getEntriesByName(this.measure);
    return e.length === 0 && (performance.measure(this.measure, this.start, this.end), e = performance.getEntriesByName(this.measure), performance.clearMarks(this.start), performance.clearMarks(this.end), performance.clearMeasures(this.measure)), e;
  }
}, sD = class {
  constructor(e, t, r, i, n) {
    this.type = e, this.properties = r || {}, this.extent = n, this.pointsArray = t, this.id = i;
  }
  loadGeometry() {
    return this.pointsArray.map((e) => e.map((t) => new T(t.x, t.y)));
  }
}, oD = class {
  constructor(e, t, r) {
    this.version = 2, this._myFeatures = e, this.name = t, this.length = e.length, this.extent = r;
  }
  feature(e) {
    return this._myFeatures[e];
  }
}, lD = class {
  constructor() {
    this.layers = {};
  }
  addLayer(e) {
    this.layers[e.name] = e;
  }
};
function uD(e, t, r) {
  let { extent: i } = e, n = 2 ** (r.z - t.z), a = (r.x - t.x * n) * i, s = (r.y - t.y * n) * i, o = [];
  for (let l = 0; l < e.length; l++) {
    let u = e.feature(l), c = u.loadGeometry();
    for (let p of c) for (let f of p) f.x = f.x * n - a, f.y = f.y * n - s;
    let h = Math.max(128, Math.round(128 * i / 4096));
    c = T3(c, u.type, -h, -h, i + h, i + h), c.length !== 0 && o.push(new sD(u.type, c, u.properties, u.id, i));
  }
  return new oD(o, e.name, i);
}
var cD = class {
  constructor(e, t, r) {
    this.actor = e, this.layerIndex = t, this.availableImages = r, this.tileState = new hm(), this.overzoomedTileResultCache = new aD(1e3);
  }
  loadVectorTile(e, t) {
    try {
      return { vectorTile: e.encoding === "mlt" ? new om(t) : new zy(new s1(t)), rawData: t };
    } catch (r) {
      let i = new Uint8Array(t), n = i[0] === 31 && i[1] === 139, a = `Unable to parse the tile at ${e.request.url}, `;
      throw a += n ? "please make sure the data is not gzipped and that you have configured the relevant header in the server" : `got error: ${La(r).message}`, Error(a);
    }
  }
  async loadTile(e) {
    let { uid: t, overzoomParameters: r } = e;
    r && (e.request = r.overzoomRequest);
    let i = this._startRequestTiming(e), n = new cm(e);
    this.tileState.startLoading(t, n);
    let a = new AbortController();
    n.abort = a;
    try {
      let s = await dx(e.request, a), o = this.tileState.getLoaded(t);
      if (e.etag && e.etag === s.etag && (o == null ? void 0 : o.etag) === s.etag) return this.tileState.finishLoading(t), this._getEtagUnmodifiedResult(s, i);
      let l = this.loadVectorTile(e, s.data);
      if (this.tileState.finishLoading(t), !l) return null;
      let { vectorTile: u, rawData: c } = l;
      r && ({ vectorTile: u, rawData: c } = this._getOverzoomTile(e, u));
      let h = this._getExpiryData(s), p = this._finishRequestTiming(i);
      n.vectorTile = u, n.etag = s.etag, this.tileState.markLoaded(t, n);
      let f = { rawData: c, cacheControl: h, resourceTiming: p };
      return this.tileState.setParsing(t, f), await this._parseWorkerTile(n, e);
    } catch (s) {
      throw this.tileState.finishLoading(t), this.tileState.markLoaded(t, n), s;
    }
  }
  _getEtagUnmodifiedResult(e, t) {
    return it({ etagUnmodified: !0 }, this._getExpiryData(e), this._finishRequestTiming(t));
  }
  async _parseWorkerTile(e, t) {
    let r = this.tileState.getParsing(e.uid), i = await e.parse(e.vectorTile, this.layerIndex, this.availableImages, this.actor, t.subdivisionGranularity);
    if (r) {
      let { rawData: n, cacheControl: a, resourceTiming: s } = r, o = t.overzoomParameters ? "mvt" : t.encoding;
      i = it({ rawTileData: n.slice(0), encoding: o }, i, a, s), this.tileState.removeParsing(e.uid);
    } else e.etag && (i = it(i, { etag: e.etag }));
    return i;
  }
  _getExpiryData({ expires: e, cacheControl: t, etag: r }) {
    let i = {};
    return e && (i.expires = e), t && (i.cacheControl = t), r && (i.etag = r), i;
  }
  _startRequestTiming(e) {
    var t;
    if ((t = e.request) != null && t.collectResourceTiming) return new pm(e.request.url);
  }
  _finishRequestTiming(e) {
    let t = e == null ? void 0 : e.finish();
    return t ? { resourceTiming: JSON.parse(JSON.stringify(t)) } : {};
  }
  _getOverzoomTile(e, t) {
    var u;
    let { tileID: r, overzoomParameters: i } = e, { maxZoomTileID: n } = i, a = `${n.key}_${r.key}_${(u = e.request) == null ? void 0 : u.url}`, s = this.overzoomedTileResultCache.get(a);
    if (s) return s;
    let o = new lD();
    for (let c of Object.values(t.layers)) {
      let h = uD(c, n, r.canonical);
      h.length > 0 && o.addLayer(h);
    }
    let l = { vectorTile: o, rawData: F1(o).buffer };
    return this.overzoomedTileResultCache.set(a, l), l;
  }
  async reloadTile(e) {
    let t = e.uid, r = this.tileState.getLoaded(t);
    if (!r) throw Error("Should not be trying to reload a tile that was never loaded or has been removed");
    if (r.vectorTile) return r.showCollisionBoxes = e.showCollisionBoxes, r.tileID = r.tileID.unwrapTo(e.tileID.wrap), await this._parseWorkerTile(r, e);
  }
  async abortTile(e) {
    this.tileState.abort(e.uid);
  }
  async removeTile(e) {
    this.tileState.removeLoaded(e.uid);
  }
}, hD = class {
  constructor() {
    this.loaded = {};
  }
  async loadTile(e) {
    let { uid: t, encoding: r, rawImageData: i, redFactor: n, greenFactor: a, blueFactor: s, baseShift: o } = e, l = i.width + 4, u = i.height + 4, c = new Ay(t, tu(i) ? new ot({ width: l, height: u }, await Gm(i, -2, -2, l, u)) : i, r, n, a, s, o);
    return this.loaded || (this.loaded = {}), this.loaded[t] = c, c;
  }
  removeTile(e) {
    let t = this.loaded, r = e.uid;
    t != null && t[r] && delete t[r];
  }
}, Jp = class {
  constructor(e) {
    this.wraps = !1, this._crs = e, this._originX = e.tileMatrixSet.origin[0], this._originY = e.tileMatrixSet.origin[1], this._extent = e.tileMatrixSet.extentAtZoom0;
  }
  get name() {
    return this._crs.name;
  }
  get tileMatrixSet() {
    return this._crs.tileMatrixSet;
  }
  worldFromLngLat(e, t, r) {
    let [i, n] = this._crs.projection.forward([e, t]);
    return new xt((i - this._originX) / this._extent, (this._originY - n) / this._extent, r === void 0 ? 0 : r / this._extent);
  }
  lngLatFromWorld(e, t) {
    let r = rt(e, 0, 1), i = rt(t, 0, 1), n = this._inverse(e, t) ?? this._inverse(r, i) ?? this._inverseTowardCenter(r, i) ?? this._finiteInverse(r, i);
    if (!n) throw Error(`The inverse of the projection "${this._crs.name}" has no answer inside its tile matrix set.`);
    return new he(n[0], rt(n[1], -90, 90));
  }
  hasLngLat(e, t) {
    let r = this._inverse(e, t);
    return r !== null && Math.abs(r[1]) <= 90;
  }
  _inverse(e, t) {
    let r = this._finiteInverse(e, t);
    if (!r) return null;
    let i = this._originX + e * this._extent, n = this._originY - t * this._extent, [a, s] = this._crs.projection.forward(r);
    return Math.hypot(a - i, s - n) <= 1e-3 * this._extent ? r : null;
  }
  _finiteInverse(e, t) {
    let r;
    try {
      r = this._crs.projection.inverse([this._originX + e * this._extent, this._originY - t * this._extent]);
    } catch {
      return null;
    }
    return r && Number.isFinite(r[0]) && Number.isFinite(r[1]) ? r : null;
  }
  _inverseTowardCenter(e, t) {
    let r = 0, i = 1;
    for (let n = 0; n < 30; n++) {
      let a = (r + i) / 2;
      this._inverse(0.5 + (e - 0.5) * a, 0.5 + (t - 0.5) * a) ? r = a : i = a;
    }
    return this._inverse(0.5 + (e - 0.5) * r, 0.5 + (t - 0.5) * r);
  }
  metersPerWorldUnit(e, t) {
    return this._extent;
  }
  worldZFromAltitude(e, t) {
    return e / this._extent;
  }
  get latitudeRange() {
    return this._latitudeRange ?? (this._latitudeRange = [this._findLatitudeLimit(-90), this._findLatitudeLimit(90)]), this._latitudeRange;
  }
  _findLatitudeLimit(e) {
    let t = this.lngLatFromWorld(0.5, 0.5), r = 10 * this._meridianStretch(t.lng, t.lat);
    if (!(r > 0)) return e;
    let i = Math.sign(e - t.lat);
    for (let n = t.lat; Math.abs(e - n) > 1; n += i) if (!(this._meridianStretch(t.lng, n + i) <= r)) return n;
    return e;
  }
  _meridianStretch(e, t) {
    let [r, i] = this._crs.projection.forward([e, t]), [n, a] = this._crs.projection.forward([e, t >= 0 ? t - 0.01 : t + 0.01]);
    return Math.hypot(n - r, a - i);
  }
}, pD = class {
  forward(e) {
    return [e[0], e[1]];
  }
  inverse(e) {
    return [e[0], e[1]];
  }
};
const fD = new class {
  constructor() {
    this.name = "identity", this.projection = new pD(), this.tileMatrixSet = { origin: [-90, 90], extentAtZoom0: 180 };
  }
}();
let Zl = null;
const Ba = /* @__PURE__ */ new Map();
function dD(e) {
  Zl = e, Ba.clear();
}
function yD(e) {
  if (!e.definition) return new Jp(fD);
  if (!Zl) Me("GeoJSON sources are drawn in the wrong place: no projection handler is set in the workers, see `setProjectionHandler` in the custom CRS guide.");
  else return Ba.has(e.definition) || Ba.set(e.definition, Zl(e.definition)), new Jp({ name: e.name, definition: e.definition, projection: Ba.get(e.definition), tileMatrixSet: e.tileMatrixSet });
}
function Hl(e, t) {
  let r = ([s, o, ...l]) => {
    let { x: u, y: c } = t.worldFromLngLat(s, o);
    return [u, c, ...l];
  }, [i, n] = t.latitudeRange;
  if (i === -90 && n === 90) return hi(e, r);
  let a = (s) => s === i && i > -90 || s === n && n < 90;
  return hi(e, r, (s) => {
    let o = !1, l = s.map((p) => p[1] >= i && p[1] <= n ? r(p) : (o = !0, p));
    if (!o) return l;
    let u = [], c = 0, h = NaN;
    for (let p = 0; p < s.length; p++) {
      let [f, d, ...y] = s[p], m = rt(d, i, n);
      if (m === h && a(m)) {
        let g = Math.ceil(Math.abs(f - c) / 10);
        for (let v = 1; v < g; v++) u.push(r([c + (f - c) * v / g, m]));
      }
      u.push(m === d ? l[p] : r([f, m, ...y])), c = f, h = m;
    }
    return u;
  });
}
function mD(e, t) {
  return hi(e, ([r, i, ...n]) => {
    let a = t.lngLatFromWorld(r, i);
    return [a.lng, a.lat, ...n];
  });
}
function gD(e, t) {
  let r = { ...e };
  return e.add && (r.add = e.add.map((i) => Hl(i, t))), e.update && (r.update = e.update.map((i) => i.newGeometry ? { ...i, newGeometry: Hl(i.newGeometry, t) } : i)), r;
}
function hi(e, t, r = (i) => i.map(t)) {
  if (!e || typeof e != "object") return e;
  switch (e.type) {
    case "FeatureCollection":
      return { ...e, features: e.features.map((i) => hi(i, t, r)) };
    case "Feature":
      return { ...e, geometry: e.geometry ? hi(e.geometry, t, r) : e.geometry };
    case "GeometryCollection":
      return { ...e, geometries: e.geometries.map((i) => hi(i, t, r)) };
    case "Point":
      return { ...e, coordinates: t(e.coordinates) };
    case "MultiPoint":
      return { ...e, coordinates: e.coordinates.map(t) };
    case "LineString":
      return { ...e, coordinates: r(e.coordinates) };
    case "MultiLineString":
    case "Polygon":
      return { ...e, coordinates: e.coordinates.map((i) => r(i)) };
    case "MultiPolygon":
      return { ...e, coordinates: e.coordinates.map((i) => i.map((n) => r(n))) };
    default:
      return e;
  }
}
var xD = class {
  constructor(e, t, r, i = vD) {
    this.actor = e, this.layerIndex = t, this.availableImages = r, this.tileState = new hm(), this._createGeoJSONIndex = i;
  }
  loadVectorTile(e) {
    if (!this._geoJSONIndex) throw Error("Unable to parse the data into a cluster or geojson");
    let { z: t, x: r, y: i } = e.tileID.canonical, n = this._geoJSONIndex.getTile(t, r, i);
    if (!n) return null;
    let a = new d6(n.features, { version: 2, extent: te });
    return { vectorTile: a, rawData: F1(a, "__$json__:").buffer };
  }
  async loadTile(e) {
    let { uid: t } = e, r = new cm(e);
    r.abort = new AbortController();
    try {
      let i = this.loadVectorTile(e);
      if (!i) return null;
      let { vectorTile: n, rawData: a } = i;
      r.vectorTile = n, this.tileState.markLoaded(t, r);
      let s = { rawData: a };
      return this.tileState.setParsing(t, s), await this._parseWorkerTile(r, e);
    } catch (i) {
      throw this.tileState.markLoaded(t, r), i;
    }
  }
  async _parseWorkerTile(e, t) {
    let r = this.tileState.getParsing(e.uid), i = await e.parse(e.vectorTile, this.layerIndex, this.availableImages, this.actor, t.subdivisionGranularity);
    if (r) {
      let { rawData: n } = r;
      i = it({ rawTileData: n.slice(0), encoding: "mvt" }, i), this.tileState.removeParsing(e.uid);
    }
    return i;
  }
  async abortTile(e) {
    this.tileState.abort(e.uid);
  }
  async removeTile(e) {
    this.tileState.removeLoaded(e.uid);
  }
  async loadData(e) {
    var r;
    (r = this._pendingRequest) == null || r.abort();
    let t = this._startRequestTiming(e);
    this._pendingRequest = new AbortController();
    try {
      await this.loadAndProcessGeoJSON(e, this._pendingRequest), delete this._pendingRequest, this.tileState.clearLoaded();
      let i = {};
      return e.request && (i.data = e.data), this._finishRequestTiming(t, e, i), i;
    } catch (i) {
      if (delete this._pendingRequest, !of(i)) throw i;
      return { abandoned: !0 };
    }
  }
  _startRequestTiming(e) {
    var t;
    if ((t = e.request) != null && t.collectResourceTiming) return new pm(e.request.url);
  }
  _finishRequestTiming(e, t, r) {
    let i = e == null ? void 0 : e.finish();
    i && (r.resourceTiming = { [t.source]: JSON.parse(JSON.stringify(i)) });
  }
  async reloadTile(e) {
    let t = e.uid, r = this.tileState.getLoaded(t);
    if (!r) return await this.loadTile(e);
    if (r.vectorTile) return r.showCollisionBoxes = e.showCollisionBoxes, r.tileID = r.tileID.unwrapTo(e.tileID.wrap), await this._parseWorkerTile(r, e);
  }
  async loadAndProcessGeoJSON(e, t) {
    if (e.request && (e.data = (await fx(e.request, t)).data), this._crsHelper = e.crs ? yD(e.crs) : void 0, e.data) {
      e.data = this._filterGeoJSON(e.data, e.filter, e.source);
      let r = this._crsHelper ? Hl(e.data, this._crsHelper) : e.data;
      this._geoJSONIndex = this._createGeoJSONIndex(r, e, this._crsHelper !== void 0);
    } else {
      if (e.dataDiff) {
        this._geoJSONIndex ?? (this._geoJSONIndex = this._createGeoJSONIndex({ type: "FeatureCollection", features: [] }, e, this._crsHelper !== void 0));
        let r = this._crsHelper ? gD(e.dataDiff, this._crsHelper) : e.dataDiff;
        this._geoJSONIndex.updateData(r, this._getFilterPredicate(e.filter, e.source));
      }
      if (e.updateCluster && this._geoJSONIndex.updateClusterOptions(e.geojsonVtOptions.cluster, fm(e)), this._geoJSONIndex == null) throw Error(`Input data given to '${e.source}' is not a valid GeoJSON object.`);
    }
  }
  _filterGeoJSON(e, t, r) {
    if (e.type !== "FeatureCollection") return e;
    let i = this._getFilterPredicate(t, r);
    return i ? { type: "FeatureCollection", features: e.features.filter((n) => i(n)) } : e;
  }
  _getFilterPredicate(e, t) {
    if (typeof e != "boolean" && !(e != null && e.length)) return;
    let r = Mr(e, `sources.${t}.filter`, { type: "boolean", "property-type": "data-driven", overridable: !1, transition: !1 });
    if (r.result === "error") throw Error(r.value.map((i) => `${i.key}: ${i.message}`).join(", "));
    return (i) => r.value.evaluate({ zoom: 0 }, i);
  }
  async removeSource(e) {
    var t;
    (t = this._pendingRequest) == null || t.abort();
  }
  getClusterExpansionZoom(e) {
    return this._geoJSONIndex.getClusterExpansionZoom(e.clusterId);
  }
  getClusterChildren(e) {
    return this._toLngLat(this._geoJSONIndex.getClusterChildren(e.clusterId));
  }
  getClusterLeaves(e) {
    return this._toLngLat(this._geoJSONIndex.getClusterLeaves(e.clusterId, e.limit, e.offset));
  }
  _toLngLat(e) {
    return this._crsHelper ? e.map((t) => mD(t, this._crsHelper)) : e;
  }
};
function vD(e, t, r) {
  return new Ob(e, it(t.geojsonVtOptions || {}, { updateable: !0, clusterOptions: fm(t), coordinates: r ? "unitSquare" : "lngLat", wrap: !r }));
}
function fm({ geojsonVtOptions: e, clusterProperties: t, source: r }) {
  if (!t || !e.clusterOptions) return e.clusterOptions;
  let i = {}, n = {}, a = { accumulated: null, zoom: 0 }, s = { properties: null }, o = Object.keys(t);
  for (let l of o) {
    let [u, c] = t[l], h = Mr(c, `sources.${r}.clusterProperties.${l}[1]`), p = Mr(typeof u == "string" ? [u, ["accumulated"], ["get", l]] : u, `sources.${r}.clusterProperties.${l}[0]`);
    i[l] = h.value, n[l] = p.value;
  }
  return e.clusterOptions.map = (l) => {
    s.properties = l;
    let u = {};
    for (let c of o) u[c] = i[c].evaluate(a, s);
    return u;
  }, e.clusterOptions.reduce = (l, u) => {
    s.properties = u;
    for (let c of o) a.accumulated = l[c], l[c] = n[c].evaluate(a, s);
  }, e.clusterOptions;
}
async function bD(e) {
  if (e.endsWith(".mjs")) {
    await import(
      /* @vite-ignore */
      e
    );
    return;
  }
  let t = await fetch(e, { credentials: "same-origin" });
  if (!t.ok) throw Error(`Failed to load ${e}: ${t.status}`);
  let r = await t.text();
  if (/^[ \t]*(import|export)\s/m.test(r)) {
    let i = URL.createObjectURL(new Blob([r], { type: "text/javascript" }));
    try {
      await import(
        /* @vite-ignore */
        i
      );
    } finally {
      URL.revokeObjectURL(i);
    }
  } else globalThis.eval(r);
}
var wD = class {
  constructor(e) {
    this.self = e, this.actor = new xx(e), this.layerIndexes = {}, this.availableImages = {}, this.workerSources = {}, this.demWorkerSources = {}, this.externalWorkerSourceTypes = {}, this.globalStates = /* @__PURE__ */ new Map(), this.importedScripts = /* @__PURE__ */ new Map(), this.self.registerWorkerSource = (t, r) => {
      if (this.externalWorkerSourceTypes[t]) throw Error(`Worker source with name "${t}" already registered.`);
      this.externalWorkerSourceTypes[t] = r;
    }, this.self.addProtocol = lx, this.self.removeProtocol = ux, this.self.registerRTLTextPlugin = (t) => {
      _i.setMethods(t);
    }, this.self.makeRequest = Au, this.self.setProjectionHandler = dD, this.actor.registerMessageHandler("LDT", (t, r) => this._getDEMWorkerSource(t, r.source).loadTile(r)), this.actor.registerMessageHandler("RDT", async (t, r) => {
      this._getDEMWorkerSource(t, r.source).removeTile(r);
    }), this.actor.registerMessageHandler("GCEZ", async (t, r) => this._getWorkerSource(t, r.type, r.source).getClusterExpansionZoom(r)), this.actor.registerMessageHandler("GCC", async (t, r) => this._getWorkerSource(t, r.type, r.source).getClusterChildren(r)), this.actor.registerMessageHandler("GCL", async (t, r) => this._getWorkerSource(t, r.type, r.source).getClusterLeaves(r)), this.actor.registerMessageHandler("LD", (t, r) => this._getWorkerSource(t, r.type, r.source).loadData(r)), this.actor.registerMessageHandler("LT", (t, r) => this._getWorkerSource(t, r.type, r.source).loadTile(r)), this.actor.registerMessageHandler("RT", (t, r) => this._getWorkerSource(t, r.type, r.source).reloadTile(r)), this.actor.registerMessageHandler("AT", (t, r) => this._getWorkerSource(t, r.type, r.source).abortTile(r)), this.actor.registerMessageHandler("RMT", (t, r) => this._getWorkerSource(t, r.type, r.source).removeTile(r)), this.actor.registerMessageHandler("RS", async (t, r) => {
      var n, a;
      if (!((a = (n = this.workerSources[t]) == null ? void 0 : n[r.type]) != null && a[r.source])) return;
      let i = this.workerSources[t][r.type][r.source];
      delete this.workerSources[t][r.type][r.source], i.removeSource !== void 0 && i.removeSource(r);
    }), this.actor.registerMessageHandler("RM", async (t) => {
      delete this.layerIndexes[t], delete this.availableImages[t], delete this.workerSources[t], delete this.demWorkerSources[t], this.globalStates.delete(t);
    }), this.actor.registerMessageHandler("SR", async (t, r) => {
      this.referrer = r;
    }), this.actor.registerMessageHandler("PI", async () => {
    }), this.actor.registerMessageHandler("SRPS", (t, r) => this._syncRTLPluginState(t, r)), this.actor.registerMessageHandler("IS", (t, r) => this._importScript(r)), this.actor.registerMessageHandler("SI", (t, r) => this._setImages(t, r)), this.actor.registerMessageHandler("UL", async (t, r) => {
      this._getLayerIndex(t).update(r.layers, r.removedIds, this._getGlobalState(t));
    }), this.actor.registerMessageHandler("UGS", async (t, r) => {
      let i = this._getGlobalState(t);
      for (let n in r) i[n] = r[n];
    }), this.actor.registerMessageHandler("SL", async (t, r) => {
      this._getLayerIndex(t).replace(r, this._getGlobalState(t));
    });
  }
  async _importScript(e) {
    let t = this.importedScripts.get(e);
    if (t) return t;
    let r = bD(e);
    this.importedScripts.set(e, r);
    try {
      await r;
    } catch (i) {
      throw this.importedScripts.delete(e), i;
    }
  }
  _getGlobalState(e) {
    let t = this.globalStates.get(e);
    return t || (t = {}, this.globalStates.set(e, t)), t;
  }
  async _setImages(e, t) {
    this.availableImages[e] = t;
    for (let r in this.workerSources[e]) {
      let i = this.workerSources[e][r];
      for (let n in i) i[n].availableImages = t;
    }
  }
  async _syncRTLPluginState(e, t) {
    return await _i.syncState(t, (r) => this._importScript(r));
  }
  _getAvailableImages(e) {
    let t = this.availableImages[e];
    return t || (t = []), t;
  }
  _getLayerIndex(e) {
    let t = this.layerIndexes[e];
    return t || (t = this.layerIndexes[e] = new nD()), t;
  }
  _getWorkerSource(e, t, r) {
    var i, n;
    if ((i = this.workerSources)[e] || (i[e] = {}), (n = this.workerSources[e])[t] || (n[t] = {}), !this.workerSources[e][t][r]) {
      let a = { sendAsync: (s, o) => (s.targetMapId = e, this.actor.sendAsync(s, o)) };
      switch (t) {
        case "vector":
          this.workerSources[e][t][r] = new cD(a, this._getLayerIndex(e), this._getAvailableImages(e));
          break;
        case "geojson":
          this.workerSources[e][t][r] = new xD(a, this._getLayerIndex(e), this._getAvailableImages(e));
          break;
        default:
          this.workerSources[e][t][r] = new this.externalWorkerSourceTypes[t](a, this._getLayerIndex(e), this._getAvailableImages(e));
      }
    }
    return this.workerSources[e][t][r];
  }
  _getDEMWorkerSource(e, t) {
    var r, i;
    return (r = this.demWorkerSources)[e] || (r[e] = {}), (i = this.demWorkerSources[e])[t] || (i[t] = new hD()), this.demWorkerSources[e][t];
  }
};
pi(self) && (self.worker = new wD(self));
